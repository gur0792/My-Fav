﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Diagnostics;
using App.Base;
using DataAccessLayer.GlobalDB;
using System.DirectoryServices;
using System.DirectoryServices.ActiveDirectory;
using System.DirectoryServices.AccountManagement;
using System.Security.Cryptography;



namespace App.UserControls
{
    public partial class login : Form
    {
        globaldbEntity db = new globaldbEntity();
        public login()
        {
            InitializeComponent();
        }

        #region Global Variables

        public int GC_PROJECTID;
        public int GC_UserID;
        public string GC_UserName;
        public bool GC_UserLevel;

        public string GC_PROJ_VERSIONSTATUS;
        // Public ds As New DataSet
        string strSQL;
        int projectid;
        public string Product_Version;
        public string projectname;
        public bool LogedOn = false;
        List<bpo_projects> listProjects = new List<bpo_projects>();
        bpo_versioncontrol listProjectLive = new bpo_versioncontrol();
        bpo_versioncontrol listProjectTest = new bpo_versioncontrol();

        #endregion

        #region Property variables
        public int userid
        {
            get { return GC_UserID; }
            set { GC_UserID = value; }
        }

        public string Username
        {
            get { return GC_UserName; }
            set { GC_UserName = value; }
        }

        public bool UserLevel
        {
            get { return GC_UserLevel; }
            set { GC_UserLevel = value; }
        }
        #endregion

        #region Help Methods

        public bool AuthenticateUser(string path, string user, string pass)
        {
            DirectoryEntry de = new DirectoryEntry(path, user, pass, AuthenticationTypes.Secure);
            try
            {
                //run a search using those credentials.  
                //If it returns anything, then you're authenticated
                DirectorySearcher ds = new DirectorySearcher(de);
                ds.FindOne();
                return true;
            }
            catch
            {
                //otherwise, it will crash out so return false
                return false;
            }

        }

        #endregion

        #region Events

        private void login_Load(object sender, EventArgs e)
        {
            lblUserName.Text = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

            if (Control.IsKeyLocked(Keys.CapsLock))
            {
                lblCapsLock.Visible = true;
            }

            projectid = ConfigurationSettings.AppSettings["projectid"].ToInt();
            projectname = ConfigurationSettings.AppSettings["projectname"];
            //Product_Version = ProductVersion;

            GC_UserID = 0;
            GC_UserLevel = false;
            GC_UserName = "";

            listProjects = new bpo_versioncontrol().bpoprojectsList();

            int value = 0;
            //string strOpenExeName = null;
            //Process strcurrprocess = Process.GetCurrentProcess();
            //string strcurrprocessname = strcurrprocess.MainModule.ModuleName.Replace(".exe", "");

            //listProjects.ForEach(x =>
            //    {
            //        string strExeName = x.assemblyname;
            //        Process[] ArrProcesses = Process.GetProcessesByName(strExeName);
            //        if (ArrProcesses.Length >= 1)
            //        {
            //            value = value + 1;
            //            if (strExeName != strcurrprocessname)
            //            {
            //                strOpenExeName = strExeName;
            //            }
            //        }
            //    });

            //if (value >= 2)
            //{
            //    MessageBox.Show("Already " + strOpenExeName + " exe Opened. So please close " + strOpenExeName + " exe and reopen " + strcurrprocessname + " exe.");
            //    this.Close();

            //}
            //else
            //{
            //    //ds = clsDB.GetDataset("select versionnumber,status,testexpirydate from globaldb.bpo_versioncontrol  where projectid=" & projectid & " and status='L' and currentlive=1 order by inserteddatetime desc limit 1;select versionnumber,status,testexpirydate from globaldb.bpo_versioncontrol where projectid=" & projectid & " and status='T' and currentlive=0 order by inserteddatetime desc limit 1")

                listProjectLive = new bpo_versioncontrol().checkversionList(projectid, "L", 1);
                listProjectTest = new bpo_versioncontrol().checkversionList(projectid, "T", 0);

                if (listProjectLive == null)
                {
                    if (listProjectTest == null)
                    {
                        ExpiryDialogue frm = new ExpiryDialogue();

                        frm.ShowDialog();
                        this.Close();
                    }
                    else if (listProjectTest.versionnumber.ToString() == Product_Version)
                    {
                        GC_PROJ_VERSIONSTATUS = "T";
                    }
                    else
                    {
                        ExpiryDialogue frm = new ExpiryDialogue();
                        frm.ShowDialog();
                        this.Close();
                    }
                }
                else if (listProjectLive.versionnumber.ToString() != Product_Version)
                {
                    if (listProjectTest == null)
                    {
                        ExpiryDialogue frm = new ExpiryDialogue();
                        frm.ShowDialog();
                        this.Close();
                    }
                    else if (listProjectTest.versionnumber.ToString() == Product_Version)
                    {
                        string strexpdate = listProjectTest.testexpirydate.ToString();
                        System.DateTime expdate = Convert.ToDateTime(strexpdate).Date;
                        System.DateTime todate = System.DateTime.Today;

                        if (expdate >= todate)
                        {
                            GC_PROJ_VERSIONSTATUS = "T";
                        }
                        else
                        {
                            MessageBox.Show("Testing Expiry Date is completed. Please Contact Software Department.");
                            Environment.Exit(0);
                        }
                    }
                    else
                    {
                        ExpiryDialogue frm = new ExpiryDialogue();
                        frm.ShowDialog();
                        this.Close();
                    }
                }
                else
                {
                    GC_PROJ_VERSIONSTATUS = "L";
                }
                GC_UserID = 0;
                GC_UserLevel = false;
                GC_UserName = "";
                txtPassword.Focus();
            }

       // }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            {
                if (!string.IsNullOrEmpty(txtPassword.Text))
                {
                    if (AuthenticateUser("LDAP://srjigs.com", lblUserName.Text, txtPassword.Text) == false)
                    {
                        //MessageBox.Show("The username or password might be incorrect");
                        lblErrorlogin.Text = "Password is incorrect.\r\nLetters in password must be typed using the correct case.";
                        lblErrorlogin.Visible = true;
                        txtPassword.Clear();
                        txtPassword.Focus();
                        return;
                    }
                    else
                    {
                        this.Close();
                    }

                    string username = string.Empty;
                    int pos = 0;
                    pos = lblUserName.Text.IndexOf("\\");
                    username = lblUserName.Text.Substring(pos + 1, (lblUserName.Text.ToString().Length) - (pos + 1));

                ADLogin:
                    DataAccessLayer.GlobalDB.login Lgn = new DataAccessLayer.GlobalDB.login().Authentication(username);

                    int ID = (Lgn == null) ? 0 : Lgn.ID;
                    DataAccessLayer.GlobalDB.login objLogin = new DataAccessLayer.GlobalDB.login(ID);

                    if (Lgn == null)
                    {
                        objLogin.Name = username;
                        objLogin.userLevel = true;
                        objLogin.active = 1;
                        objLogin.ADName = username;
                        objLogin.Store();

                        goto ADLogin;
                    }
                    else if (Lgn != null)
                    {
                        GC_UserID = Lgn.ID;
                        GC_UserName = Lgn.ADName;
                        GC_UserLevel = Lgn.userLevel.ToBool();

                        if (!(GC_UserID == 1 || GC_UserID == 5 || GC_UserID == 61 || GC_UserID == 62 || GC_UserID == 96 || GC_UserID == 139 || GC_UserID == 375 || GC_UserID == 453 || GC_UserID == 469 || GC_UserID == 491 || GC_UserID == 530))
                        {
                            //if (Lgn.LoginStatus == true)
                            //{
                            //    MessageBox.Show("This user is already logged on.");
                            //    LogedOn = true;
                            //    return;
                            //}
                        }
                        else
                        {
                            objLogin.LoginStatus = true;
                            objLogin.LastDate = DateTime.Now;
                            objLogin.LastProject = projectname;
                            objLogin.Store();
                        }
                    }
                }
                else
                {
                    lblErrorlogin.Text = string.Format("{0}", "Password Cannot be empty");
                    lblErrorlogin.Visible = true;
                    txtPassword.Focus();
                    return;
                }
            }
            if (GC_UserLevel == true)
            {
                Process[] processlist = Process.GetProcesses();
                foreach (Process b in processlist)
                {
                    Process currentProcess = Process.GetCurrentProcess();
                    string ProcessName = currentProcess.ProcessName;
                    string bstring = null;
                    string Cstring = null;
                    if (ProcessName.Contains("."))
                    {
                        int i = ProcessName.LastIndexOf(".");
                        Cstring = ProcessName.Substring(0, i);
                    }
                    else
                    {
                        Cstring = ProcessName;
                    }
                    if (b.ProcessName.Contains("."))
                    {
                        int j = b.ProcessName.LastIndexOf(".");
                        bstring = b.ProcessName.Substring(0, j);

                    }
                    else
                    {
                        bstring = b.ProcessName;
                    }
                    if (!Cstring.Equals(bstring))
                    {
                        var result = db.bpo_projects.Where(t => t.assemblyname.Contains(bstring)).ToList();
                        if (result.Count>0)
                        {
                            MessageBox.Show("Already Opened " + bstring + ", Please Close exe or Manually end the application process in task manager");
                            Application.Exit();
                            this.Close();  
                            break;
                        }
                    }

                }
            }
          
          
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void login_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                btnLogin_Click(sender, e);
            }
            else if (e.Alt && e.KeyCode == Keys.F4)
            {
                Environment.Exit(0);
            }
            else if (e.KeyCode == Keys.CapsLock)
            {
                if (Control.IsKeyLocked(Keys.CapsLock))
                {
                    lblCapsLock.Visible = true;
                }
                else
                {
                    lblCapsLock.Visible = false;
                }
            }
        }

        private void login_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Environment.Exit(0);            
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
       {
            // lblErrorlogin.Visible = false;
        }

        #endregion
    }
}
