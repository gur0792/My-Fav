﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Diagnostics;
using App.Base;

namespace App.Base
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        #region Global Variables

        public int GC_PROJECTID;
        public int GC_UserID;
        public string GC_UserName;
        public int GC_UserLevel;

        public string GC_PROJ_VERSIONSTATUS;
        // Public ds As New DataSet
        string strSQL;
        DataSet ds = new DataSet();
        int projectid;
        public string Product_Version;
        public string projectname;
        public bool LogedOn = false;


        #endregion

        #region Property variables
        public int userid
        {
            get { return GC_UserID; }
            set { GC_UserID = value; }
        }

        public string Username
        {
            get { return GC_UserName; }
            set { GC_UserName = value; }
        }

        public int UserLevel
        {
            get { return GC_UserLevel; }
            set { GC_UserLevel = value; }
        }
        #endregion

        private void login_Load(object sender, EventArgs e)
        {
            txtUserName.Text = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

            projectid = ConfigurationSettings.AppSettings("projectid");
            Product_Version = Product_Version;

            DataSet ds = new DataSet();
            
            GC_UserID = 0;
            GC_UserLevel = 0;
            GC_UserName = "";


            ds = clsDB.GetDataset(sqlqry);

            int value = 0;
            string strOpenExeName = null;
            Process strcurrprocess = Process.GetCurrentProcess();
            string strcurrprocessname = strcurrprocess.MainModule.ModuleName.Replace(".exe", "");

            foreach (DataRow dr in ds.Tables(0).Rows)
            {
                string strExeName = dr.Item(0);
                Process[] ArrProcesses = Process.GetProcessesByName(strExeName);
                if (ArrProcesses.Length >= 1)
                {
                    value = value + 1;
                    if (strExeName != strcurrprocessname)
                    {
                        strOpenExeName = strExeName;
                    }
                }
            }

            if (value >= 2)
            {
               MessageBox.Show("Already " + strOpenExeName + " exe Opened. So please close " + strOpenExeName + " exe and reopen " + strcurrprocessname + " exe.");
                //application .exit  
                this.Close();

            }
            else
            {
                ds = clsDB.GetDataset("select versionnumber,status,testexpirydate, projectname from globaldb.bpo_versioncontrol a inner join globaldb.bpo_projects b on a.projectid=b.id where projectid=" + projectid + " and status='L' and currentlive=1 order by inserteddatetime desc limit 1;select versionnumber,status,testexpirydate , projectname from globaldb.bpo_versioncontrol a inner join globaldb.bpo_projects b on a.projectid=b.id where projectid=" + projectid + " and status='T' and currentlive=0 order by inserteddatetime desc limit 1", CommandType.Text);
                //ds = clsDB.GetDataset("select versionnumber,status,testexpirydate from globaldb.bpo_versioncontrol  where projectid=" & projectid & " and status='L' and currentlive=1 order by inserteddatetime desc limit 1;select versionnumber,status,testexpirydate from globaldb.bpo_versioncontrol where projectid=" & projectid & " and status='T' and currentlive=0 order by inserteddatetime desc limit 1")
                if (ds.Tables(0).Rows.Count == 0)
                {
                    if (ds.Tables(1).Rows.Count == 0)
                    {
                        ExpiryDialogue frm = new ExpiryDialogue();

                        frm.ShowDialog();
                        this.Close();
                    }
                    else if (ds.Tables(1).Rows(0).Item("versionnumber").ToString == Product_Version)
                    {
                        GC_PROJ_VERSIONSTATUS = "T";
                    }
                    else
                    {
                        ExpiryDialogue frm = new ExpiryDialogue();
                        frm.ShowDialog();
                        this.Close();
                    }
                }
                else if (ds.Tables(0).Rows(0).Item("versionnumber").ToString != Product_Version)
                {
                    if (ds.Tables(1).Rows.Count == 0)
                    {
                        ExpiryDialogue frm = new ExpiryDialogue();
                        frm.ShowDialog();
                        this.Close();
                    }
                    else if (ds.Tables(1).Rows(0).Item("versionnumber").ToString == Product_Version)
                    {
                        string strexpdate = ds.Tables(1).Rows(0)("testexpirydate").ToString();
                        System.DateTime expdate = Convert.ToDateTime(strexpdate).Date;
                        System.DateTime todate = System.DateTime.Today;

                        if (expdate >= todate)
                        {
                            GC_PROJ_VERSIONSTATUS = "T";
                        }
                        else
                        {
                            MessageBox.Show("Testing Expiry Date is completed. Please Contact Software Department.");
                            Environment.Exit(0);
                        }
                    }
                    else
                    {
                        ExpiryDialogue frm = new ExpiryDialogue();
                        frm.ShowDialog();
                        this.Close();
                    }
                }
                else
                {
                    GC_PROJ_VERSIONSTATUS = "L";
                }
                GC_UserID = 0;
                GC_UserLevel = 0;
                GC_UserName = "";

                projectname = ds.Tables(0).Rows(0).Item("ProjectName");
            }

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

        }
    }
}
