﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.IO;
using System.Reflection;
using ExcelLibrary.SpreadSheet;
using System.Data;
using System.ComponentModel;
using System.IO;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace App.Base
{

    public static class IGUtilities
    {
       
        #region Export Method

        public static bool ExportToXL(IEnumerable ListSource, string path)
        {
            IEnumerable listSource = ListSource as object[] ?? ListSource.Cast<object>().ToArray();
            if (ListSource == null || !listSource.OfType<object>().Any())
            {
                return false;
            }
            if (listSource.OfType<object>().FirstOrDefault() == null)
            {
                return false;
            }
            Type type;

            var obj = ListSource.OfType<object>().FirstOrDefault();
            type = obj.GetType();

            PropertyInfo[] properties = type.GetProperties();
            FieldInfo[] fields = type.GetFields();

            int columnsCount = properties.Any() ? properties.Count() : fields.Count();

            Workbook workbook = new Workbook();
            Worksheet worksheet = new Worksheet("Sheet");

            // Write Columns
            // start with 1st row
            int HeadRow = 0;
            int HeadColumns = 0;
            foreach (PropertyInfo property in properties)
            {
                worksheet.Cells[HeadRow, HeadColumns] = new Cell(string.Format("{0}", property.Name));
                HeadColumns++;
            }
            HeadColumns = 0;
            foreach (FieldInfo field in fields)
            {
                worksheet.Cells[HeadRow, HeadColumns] = new Cell(string.Format("{0}", field.Name));
                HeadColumns++;
            }

            // write Data
            // Start with 2nd row
            int DataRow = 1;

            foreach (var item in listSource)
            {
                int DataColumns = 0;
                foreach (PropertyInfo property in properties)
                {
                    var value = ((property.GetValue(item, null) == null || string.IsNullOrEmpty(property.GetValue(item, null).ToString()) || string.IsNullOrEmpty(property.GetValue(item, null).ToString())) ? "" : property.GetValue(item, null).ToString());
                    worksheet.Cells[DataRow, DataColumns] = new Cell(value);
                    DataColumns++;
                }
                DataRow++;
            }

            workbook.Worksheets.Add(worksheet);
            workbook.Save(path);

            return true;
        }

       




        //public static DataTable readtextfile(string FilePath)
        //{
        //    if (File.Exists(FilePath))
        //    {
        //        DataTable dt = new DataTable("FinalTxtImport");
        //        try
        //        {
        //            string rootPath = System.IO.Path.GetDirectoryName(FilePath);
        //            String fname = System.IO.Path.GetFileName(FilePath);    
        //            //string fileName = txtinputfile.Text;

        //            WriteSchemaFile(rootPath, fname);
        //            //WriteSchemaFile_test(rootPath, fname)

        //            string connString = "Driver={Microsoft Text Driver (*.txt; *.csv)};Dbq=" + rootPath.Replace("\\", "\\\\") + ";Table Type = Pipe;Extensions=asc,csv,tab,txt;Persist Security Info=False";
        //            string SQL = null;
        //            System.Data.Odbc.OdbcConnection conn = new System.Data.Odbc.OdbcConnection(connString);
        //            conn.ConnectionTimeout = 0;
        //            conn.Open();
        //            SQL = "SELECT * FROM [" + fname + "]";
        //            System.Data.Odbc.OdbcDataAdapter da = new System.Data.Odbc.OdbcDataAdapter(SQL, conn);
        //            da.SelectCommand.CommandTimeout = 0;
        //            da.Fill(dt);
        //            conn.Close();
        //            conn.Dispose();
        //            return dt;
        //        }
        //        catch (Exception ex)
        //        {
        //            return null;
        //        }
        //    }
        //    else
        //    {
        //        return null;
        //    }
        //}
        private static bool WriteSchemaFile(string FilePath, string FileName)
        {
            try
            {
                StreamWriter fWrite = new StreamWriter(FilePath + "\\schema.ini", false);
                fWrite.WriteLine("[" + FileName.Trim()  + "]");
                fWrite.WriteLine("ColNameHeader=true");
                fWrite.WriteLine("Format=Delimited(|)");
                fWrite.WriteLine("Col1=SNO Text Width 1000");
                fWrite.WriteLine("Col2=IMAGE_NAME Text Width 1000");
                fWrite.WriteLine("Col3=MEMBER_ID Text Width 1000");
                fWrite.WriteLine("Col4=BAR_CODE Text Width 1000");
                fWrite.WriteLine("Col5=FIRSTNAME Text Width 1000");
                fWrite.WriteLine("Col6=LASTNAME Text Width 1000");
                fWrite.WriteLine("Col7=PHONE_CAPTURE Text Width 1000");
                fWrite.WriteLine("Col8=ADDRESS_OVERRIDE Text Width 1000");
                fWrite.WriteLine("Col9=ADDRESS_1 Text Width 1000");
                fWrite.WriteLine("Col10=ADDRESS_2 Text Width 1000 ");
                fWrite.WriteLine("Col11=CITY Text Width 1000 ");
                fWrite.WriteLine("Col12=STATE Text Width 1000 ");
                  fWrite.WriteLine("Col13= ZIP Text Width 1000");
                fWrite.WriteLine("Col14=DOB Text Width 1000");
                fWrite.WriteLine("Col15=DOS Text Width 1000");
                fWrite.WriteLine("Col16=PROVIDER_SIGNATURE Text Width 1000");
                fWrite.WriteLine("Col17=NOT_OPTIN Text Width 1000");
                fWrite.WriteLine("Col18=COMP_EXAM1 Text Width 1000");
                fWrite.WriteLine("Col19=COMP_EXAM2 Text Width 1000");
                fWrite.WriteLine("Col20=COMP_EXAM3 Text Width 1000");
                fWrite.WriteLine("Col21=MERCH_CARD_15 Text Width 1000");
                fWrite.WriteLine("Col22=FORM_SCAN Text Width 1000 ");
                fWrite.WriteLine("Col23=INTERACTION_DATE_TIME Text Width 1000 ");
                fWrite.Close();
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }



        public static DataTable FinalTxtImport(String FilePath)
        {
            var table = new DataTable("TxtImport");

            var fileContents = File.ReadAllLines(FilePath);

            var splitFileContents = (from f in fileContents select f.Split('|')).ToArray();

            int maxLength = (from s in splitFileContents select s.Count()).Max();

            for (int i = 0; i < maxLength; i++)
            {
                int j = 0;
                string ColumName = splitFileContents[j][i].ToString();
                table.Columns.Add();
            }

            foreach (var line in splitFileContents)
            {
                DataRow row = table.NewRow();
                row.ItemArray = (object[])line;
                table.Rows.Add(row);
            }
            return table;
        }

        public static DataSet FinalExcelImport(string FilePath)
        {

            OleDbConnection Econ;
            string constr, Query;
            DataSet ds = new DataSet();
            try
            {
                constr = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=""Excel 12.0 Xml;HDR=YES;""", FilePath);
                Econ = new OleDbConnection(constr);
                Econ.Open();
                DataTable dtSchema = Econ.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                if ((null != dtSchema) && (dtSchema.Rows.Count > 0))
                {
                    string firstSheetName = dtSchema.Rows[0]["TABLE_NAME"].ToString();
                    Query = string.Format("Select * FROM[" + firstSheetName + "]");
                    OleDbCommand Ecom = new OleDbCommand(Query, Econ);
                    OleDbDataAdapter oda = new OleDbDataAdapter(Query, Econ);
                    Econ.Close();
                    oda.Fill(ds);
                    DataTable Exceldt = ds.Tables[0];
                }
            }
            catch (Exception)
            {
           
            }
            return ds;
        }
              
        public static bool ExportToTxt(IEnumerable ListSource, string Delimeter, string path)
        {
            IEnumerable listSource = ListSource as object[] ?? ListSource.Cast<object>().ToArray();
            if (ListSource == null || !listSource.OfType<object>().Any())
            {
                return false;
            }
            if (listSource.OfType<object>().FirstOrDefault() == null)
            {
                return false;
            }
            Type type;

            var obj = ListSource.OfType<object>().FirstOrDefault();
            type = obj.GetType();

            PropertyInfo[] properties = type.GetProperties();
            FieldInfo[] fields = type.GetFields();
            int columnsCount = properties.Any() ? properties.Count() : fields.Count();

            using (StreamWriter sw = new StreamWriter(path, false))
            {
                // Write Columns
                // start with 1st row                
                int HeadColumns = 0;
                string HeaderRowText = string.Empty;
                foreach (PropertyInfo property in properties)
                {
                    HeaderRowText = HeaderRowText + string.Format("{0}{1}", property.Name, Delimeter);
                    HeadColumns++;
                }

                HeadColumns = 0;
                foreach (FieldInfo field in fields)
                {
                    HeaderRowText = HeaderRowText + string.Format("{0}{1}", field.Name, Delimeter);
                    HeadColumns++;
                }
                HeaderRowText = HeaderRowText.Remove(HeaderRowText.Length - Delimeter.Length);
                sw.WriteLine(HeaderRowText);
                // write Data
                // Start with 2nd row
                int DataRow = 1;

                foreach (var item in listSource)
                {
                    int DataColumns = 0;
                    string DataRowText = string.Empty;
                    foreach (PropertyInfo property in properties)
                    {
                        var value = ((property.GetValue(item, null) == null || string.IsNullOrEmpty(property.GetValue(item, null).ToString()) || string.IsNullOrEmpty(property.GetValue(item, null).ToString())) ? "" : property.GetValue(item, null).ToString());
                        DataRowText = DataRowText + string.Format("{0}{1}", value, Delimeter);
                        DataColumns++;
                    }
                    DataRowText = DataRowText.Remove(DataRowText.Length - Delimeter.Length);
                    sw.WriteLine(DataRowText);
                    DataRow++;
                }

            }
            return true;
        }

        #endregion

        #region Converting Methods

        public static int ToInt(this object Value)
        {
            int Integer;
            int.TryParse(Convert.ToString(Value), out Integer);
            return Integer;
        }

        public static float ToFloat(this object Value)
        {
            float Float;
            float.TryParse(Convert.ToString(Value), out Float);
            return Float;
        }

        public static bool ToBool(this object Value)
        {
            bool Bool;
            bool.TryParse(Convert.ToString(Value), out Bool);
            return Bool;
        }

        public static bool IsDate(this object Obj)
        {
            string strDate = Obj.ToString();
            try
            {
                DateTime dt = DateTime.Parse(strDate);
                if ((dt.Month != DateTime.Now.Month) || (dt.Day < 1 && dt.Day > 31) || dt.Year != DateTime.Now.Year)
                {
                    return false;
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        #endregion

        #region Enumeration Methods

        public static string GetEnumDescription(Enum EnumConstant)
        {
            FieldInfo fiEnum = EnumConstant.GetType().GetField(EnumConstant.ToString());
            DescriptionAttribute[] descAttribute = (DescriptionAttribute[])fiEnum.GetCustomAttributes(typeof(DescriptionAttribute), false);
            if (descAttribute.Length > 0)
            {
                return descAttribute[0].Description;
            }

            return EnumConstant.ToString();
        }

        public static string Description(this Enum Value)
        {
            FieldInfo field = Value.GetType().GetField(Value.ToString());
            DescriptionAttribute attribute = Attribute.GetCustomAttribute(field, typeof(DescriptionAttribute)) as DescriptionAttribute;
            return attribute == null ? Value.ToString() : attribute.Description;
        }
        #endregion

        #region File Generation

        public static string GeneratedFileName(string FileName)
        {
            string guid = Guid.NewGuid().ToString();
            string validFile = guid + FileName.Substring(FileName.IndexOf('.'));
            return validFile;
        }
        #endregion

        #region Encription And Decription

        public static string EncryptString(string EncryptedString)
        {
            byte[] byteencrString = Encoding.ASCII.GetBytes(EncryptedString);
            string encryptedConnectionString = Convert.ToBase64String(byteencrString);
            return encryptedConnectionString;
        }

        public static string DecryptString(string String)
        {
            byte[] byteencrString = Convert.FromBase64String(String);
            string decryptedConnectionString = Encoding.ASCII.GetString(byteencrString);
            return decryptedConnectionString;
        }

        #endregion

        #region IGCommonMethods

        public static List<string> ImportFiles(string Path)
        {
            List<string> filelist = new List<string>();
            filelist = System.IO.Directory.GetFiles(Path, "*.pdf",SearchOption.AllDirectories).ToList();
            //filelist = System.IO.Directory.GetFiles(Path).Where(x => x.ToLower().Contains(".pdf")).ToList();
            if (filelist.Count > 0)
            {
                return filelist;
            }

            filelist = System.IO.Directory.GetFiles(Path, "*.tif", SearchOption.AllDirectories).ToList();
            //filelist = System.IO.Directory.GetFiles(Path).Where(x => x.ToLower().Contains(".tif")).ToList();
            if (filelist.Count > 0)
            {
                return filelist;
            }

            filelist = System.IO.Directory.GetFiles(Path, "*.jpg", SearchOption.AllDirectories).ToList();
            //filelist = System.IO.Directory.GetFiles(Path).Where(x => x.ToLower().Contains(".jpg")).ToList();
            if (filelist.Count > 0)
            {
                return filelist;
            }

            return filelist;
        }

        public static string ValidateYear(string month, string date, string year)
        {
            //string year = null;
            string invoiceyear = null;

            if (year.Length == 1)
                year = "0" + year;

            if (year.Length == 0 | year.Length == 4)
            {
                DateTime rightNow = DateTime.Now;
                string strCurrentDateTimeString = null;
                strCurrentDateTimeString = rightNow.ToString("yyyyMMdd");

                if (month.Length != 0 & date.Length != 0 & year.Length != 0)
                {
                    //if ((Convert.ToInt32(year) >= 50 & Convert.ToInt32(year) <= 99))
                    //{
                    //    year = 19 + year;
                    invoiceyear = year + month + date;
                    if (Convert.ToInt32(invoiceyear) > Convert.ToInt32(strCurrentDateTimeString))
                    {
                        return "Future Date is Not Allowed.";
                    }
                    //}
                    //else if ((Convert.ToInt32(year) >= 00 & Convert.ToInt32(year) <= 49))
                    //{
                    //    year = 20 + year;
                    //    invoiceyear = year + month + date;
                    //    if (Convert.ToInt32(invoiceyear) > Convert.ToInt32(strCurrentDateTimeString))
                    //    {
                    //        return "Future Date is Not Allowed.";
                    //    }
                    //}
                    //else
                    //{
                    //    return "Year is Invalid.";
                    //}
                }
                else if (month.Length == 0 & date.Length != 0 & year.Length != 0)
                {
                    return "Date is Invalid.";
                }
                else if (month.Length != 0 & date.Length == 0 & year.Length == 0)
                {
                    return "Date is Invalid.";
                }
                else if (month.Length == 0 & date.Length != 0 & year.Length == 0)
                {
                    return "Date is Invalid.";
                }
            }
            else
            {
                return "Year is Invalid.";
            }
            return year;
        }

        public static string ValidateMonth(string month)
        {
            if (month.Length == 1)
                month = "0" + month;
            if (month.Length == 0 | month.Length == 2)
            {
                {
                    if (Convert.ToInt32(month) > 12 | Convert.ToInt32(month) < 1)
                    {
                        return "Month is Invalid.";
                    }
                }
            }
            return month;
        }

        public static string ValidateDate(string date, string month)
        {
            if (date == "00")
            {
                return "Date is Invalid.";
            }

            if (date.Length == 1)
                date = "0" + date;

            if (date.Length == 2)
            {
                switch (month)
                {
                    case "02":
                        if (Convert.ToInt32(date) > 29)
                        {
                            return "Date is Invalid.";
                        }
                        break;
                    case "01":
                    case "03":
                    case "05":
                    case "07":
                    case "08":
                    case "10":
                    case "12":
                        if (Convert.ToInt32(date) > 31)
                        {
                            return "Date is Invalid.";
                        }
                        break;
                    case "04":
                    case "06":
                    case "09":
                    case "11":
                        if (Convert.ToInt32(date) > 30)
                        {
                            return "Date is Invalid.";
                        }
                        break;
                    default:
                        return null;
                }
            }
            else
            {
                return "Date is Invalid.";
            }
            return date;
        }

        public static string ValidatePhoneNo(string PhoneNo)
        {
            if (PhoneNo.StartsWith("0") | PhoneNo.StartsWith("1"))
            {
                return  "The Phone No Can not Start with 0 or 1.";
            }
            else
            {
                if (PhoneNo.Length == 7 | PhoneNo.Length == 10 | PhoneNo.Length == 0)
                {
                    return null;
                }
                else if (PhoneNo.Length < 7)
                {
                    return "The Home Phone # Can not be less than 7 digits.";
                }
                else if (PhoneNo.Length > 7 & PhoneNo.Length < 10)
                {
                    return "The Home Phone # must be 7 or 10 digits.";
                }
                else if (PhoneNo.Length > 10)
                {
                    return "The Home Phone # Can not be more than 10 digits.";
                }
                return null;
            }
        }       

        #endregion

        #region File Read Methods

        public static List<string> ReadTxtFile(string FilePath)
        {
            List<string> TxtFileDatas = new List<string>();
            try
            {
                StreamReader oRead = new StreamReader(FilePath);                
                TxtFileDatas = File.ReadAllLines(FilePath).ToList();
            }
            catch (Exception ex)
            { }
            return TxtFileDatas;
        }

        #endregion
    }
}
