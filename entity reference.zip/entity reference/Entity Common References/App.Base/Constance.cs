﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace App.Base
{
    public static class Constance
    {
        #region Project Constance Variables

        public static int GC_USERID;
        public static string GC_USERNAME;
        public static bool GC_USERLEVEL;
        public static string GC_Process;

        public static string ProjectName = "TestProject";
        public static string gstrappTitle = "Unicef";
        public const string GC_PROJ_APPNAME = "Unicef";
        public const string GC_PROJ_SECTION = "IGImageViewer";
        public const string GC_PROJ_KEY_ImageFit = "ImageFit";

        public const string GC_PROJ_KEY_ImageSize = "ImageSize";
        public const string GC_MST_BATCHMASTER = "BatchMaster";
        public const string GC_MST_IMAGEMASTER = "ImageMaster";

        public const string GC_MST_LOGIN = "globaldb.Login";
        public const string GC_TBL_LOGINDETAILS = "LoginDetails";
        public const string GC_TBL_KEY1 = "Key1";
        public const string GC_TBL_KEY2 = "Key2";
        public const string GC_TBL_KEY3 = "Key3";
        public const string GC_TBL_KEYQC = "KeyQC";
        public const string GC_TBL_COMQC = "CompareQC";

        public const string GC_TBL_FULLQC = "FullQC";
        //Process Type's
        public const string GC_PROCESS_KEY1 = "Key1";
        public const string GC_PROCESS_KEY2 = "Key2";
        public const string GC_PROCESS_KEY3 = "Key3";
        public const string GC_PROCESS_KEY4 = "Key4";
        public const string GC_PROCESS_KEYQC = "KeyQC";
        public const string GC_PROCESS_COMAPREQC = "CompareQC";
        public const string GC_PROCESS_CompQC_New = "CompareQC_New";

        public const string GC_PROCESS_FullQC = "FullQC";
        public static string GC_PROJ_VERSION = "";
        public static string GC_PROJ_VERSIONSTATUS = "";
        public static string ImageInTime = "";
        public static string ImageOutTime = "";

        //Type Names

        public const string GC_TYPE_0 = "18664";
        public static string GC_TYPE_1 = "18694";
        public static string GC_TYPE_2 = "18731";
        public static string GC_TYPE_3 = "19029";
        #endregion        
    }
}
