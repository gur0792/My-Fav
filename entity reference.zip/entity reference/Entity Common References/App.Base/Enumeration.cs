﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Reflection;

namespace App.Base
{
    public class Enumeration
    {
        #region Basic

        public enum ErrorLogRecordStatus
        {
            Active = 'A',
            Deleted = 'D'
        }
        
        #endregion

        #region Enum functions

        public static string Description(Enum EnumConstant)
        {
            FieldInfo fiEnum = EnumConstant.GetType().GetField(EnumConstant.ToString());
            DescriptionAttribute[] descAttribute = (DescriptionAttribute[])fiEnum.GetCustomAttributes(typeof(DescriptionAttribute), false);
            if (descAttribute.Length > 0)
            {
                return descAttribute[0].Description;
            }

            return EnumConstant.ToString();
        }

        #endregion
    }
}
