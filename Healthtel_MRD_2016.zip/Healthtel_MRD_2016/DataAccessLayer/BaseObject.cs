﻿using System.Collections.Generic;
using DataAccessLayer.GlobalDB;
using System;
using System.Reflection;
using System.Linq;

namespace DataAccessLayer
{
    public abstract class BaseObject
    {
        #region Properties and variables

        public List<string> ErrorMessage;
        public bool HasError;
        public bool IstoBeDeleted;

        #endregion

        #region Abstract methods

        protected abstract void Validate();

        protected abstract void StoreComposite();

        protected abstract void AddImplementation();

        protected abstract void UpdateImplementation();

        protected abstract void DeleteImplementation();

        #endregion

        #region Delegates and events

        public delegate login ApplicationUser();

        public static event ApplicationUser LoggedInUser;

        #endregion

        #region Store

        public void Store()
        {
            login user = null;
            if (LoggedInUser != null)
            {
                user = LoggedInUser.Invoke();
            }

            if (user == null)
            {
                throw new UnauthorizedAccessException();
            }

            if (IstoBeDeleted)
            {
                DeleteImplementation();
                return;
            }

            ResetMessage();
            Validate();

            if (HasError)
            {
                return;
            }

            Type type = GetType();
            AssignProperty(type, "CreatedBy", string.Format("{0}", user.ID));
            AssignProperty(type, "CreatedOn", DateTime.Now);

            StoreComposite();
        }

        #endregion

        #region Helper Methods

        protected void AddMessage(string Message)
        {
            if (ErrorMessage == null)
            {
                ResetMessage();
            }

            ErrorMessage.Add(Message);
            HasError = true;
        }

        protected void AddMessage(List<string> Message)
        {
            if (Message == null)
            {
                return;
            }

            if (Message.Count == 0)
            {
                return;
            }

            if (ErrorMessage == null)
            {
                ResetMessage();
            }

            ErrorMessage.AddRange(Message);
            HasError = true;
        }

        public string GetMessage(string separator)
        {
            if (ErrorMessage == null)
            {
                return string.Empty;
            }

            return string.Join(separator, ErrorMessage.ToArray());
        }

        private void ResetMessage()
        {
            ErrorMessage = new List<string>();
            HasError = false;
        }

        private void AssignProperty(Type type, string PropertyName, object value)
        {
            PropertyInfo property = type.GetProperties().FirstOrDefault(x => x.Name.Equals(PropertyName, StringComparison.OrdinalIgnoreCase));
            if (property == null)
            {
                return;
            }

            switch (property.Name)
            {               
                case "CreatedBy":
                    if (property.PropertyType == typeof(string))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        login user = LoggedInUser.Invoke();
                        property.SetValue(this, user.ID, null);
                    }
                    break;
                case "CreatedDateTime":
                    if (property.PropertyType == typeof(DateTime))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {                        
                        property.SetValue(this, value, null);
                    }
                    break;
                default:
                    property.SetValue(this, value, null);
                    break;
            }
        }

        protected void MapObject(object Destination)
        {
            PropertyInfo[] properties = GetType().GetProperties().Where(x => (x.Name != "CreatedBy" && x.Name != "CreatedDateTime") && x.CanWrite && (!x.PropertyType.IsClass || x.PropertyType.UnderlyingSystemType == typeof(string))).ToArray();
            foreach (PropertyInfo property in properties)
            {
                property.SetValue(Destination, property.GetValue(this, null), null);
            }
        }

        public login getLoginUser()
        {
            return LoggedInUser.Invoke();
        }      

        #endregion   
    }
}