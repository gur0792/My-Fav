﻿using System;
using AutoMapper;
using DataAccessLayer.ProjectDB;
using DataAccessLayer.GlobalDB;
namespace DataAccessLayer
{
    public static class AutoMapperConfiguration
    {
        public static void ConfigureMapper()
        {
            #region Global DB mapping

            Mapper.CreateMap<bpo_versioncontrol, bpo_versioncontrol>();
            Mapper.CreateMap<login, login>();
            Mapper.CreateMap<domainnamedatabase, domainnamedatabase>();
            Mapper.CreateMap<city, city>();
            Mapper.CreateMap<namesdatabase, namesdatabase>();
            Mapper.CreateMap<bpo_projects, bpo_projects>();
            Mapper.CreateMap<projectlogindetail, projectlogindetail>();

            #endregion

            #region Project DB mapping

            Mapper.CreateMap<batchmaster, batchmaster>();
            Mapper.CreateMap<batchmaster_audit, batchmaster_audit>();
            Mapper.CreateMap<compareqc, compareqc>();          
            Mapper.CreateMap<imagemaster, imagemaster>();
            Mapper.CreateMap<key1, key1>();
            Mapper.CreateMap<key2, key2>();
            Mapper.CreateMap<worklog, worklog>();
            Mapper.CreateMap<key1_hra, key1_hra>();
            Mapper.CreateMap<key2_hra, key2_hra>();
            Mapper.CreateMap<compareqc_hra, compareqc_hra>();
            Mapper.CreateMap<key1_hedis, key1_hedis>();
            Mapper.CreateMap<keyqc_hedis, keyqc_hedis>();
            Mapper.CreateMap<key1_hra_v1, key1_hra_v1>();
            Mapper.CreateMap<key2_hra_v1, key2_hra_v1>();
            Mapper.CreateMap<compareqc_hra_v1, compareqc_hra_v1>();
           

            #endregion
        }
    }
}

