﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccessLayer.ZipCodeDB;
using App.Base;
using System.Windows.Forms;
namespace DataAccessLayer.ZipCodeDB
{
    public class Zipcode
    {
        public static AutoCompleteStringCollection AddressListBYZipCode(string ZipCode, string State)
        {
            AutoCompleteStringCollection AddressList = new AutoCompleteStringCollection();
            List<string> ODDEVENNUMBER = new List<string>() { "O", "E" };
            if (State.ToUpper() == "AA")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<aa> AAList = Dbcontext.aas.Where(x => x.ZipCode == ZipCode).ToList();
                    AAList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {                            
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "AE")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<ae> AEList = Dbcontext.aes.Where(x => x.ZipCode == ZipCode).ToList();
                    AEList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "AK")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<ak> AKList = Dbcontext.aks.Where(x => x.ZipCode == ZipCode).ToList();
                    AKList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "AL")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<al> ALList = Dbcontext.als.Where(x => x.ZipCode == ZipCode).ToList();
                    ALList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "AP")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<ap> APList = Dbcontext.aps.Where(x => x.ZipCode == ZipCode).ToList();
                    APList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "AR")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<ar> ARList = Dbcontext.ars.Where(x => x.ZipCode == ZipCode).ToList();
                    ARList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "AS")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<a> ASList = Dbcontext.@as.Where(x => x.ZipCode == ZipCode).ToList();
                    ASList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "AZ")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<az> AZList = Dbcontext.azs.Where(x => x.ZipCode == ZipCode).ToList();
                    AZList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "CA")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<ca> CAList = Dbcontext.cas.Where(x => x.ZipCode == ZipCode).ToList();
                    CAList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "CO")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<co> COList = Dbcontext.coes.Where(x => x.ZipCode == ZipCode).ToList();
                    COList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "CT")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<ct> CTList = Dbcontext.cts.Where(x => x.ZipCode == ZipCode).ToList();
                    CTList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "DC")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<dc> DCList = Dbcontext.dcs.Where(x => x.ZipCode == ZipCode).ToList();
                    DCList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "DE")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<de> DEList = Dbcontext.des.Where(x => x.ZipCode == ZipCode).ToList();
                    DEList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "FL")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<fl> FLList = Dbcontext.fls.Where(x => x.ZipCode == ZipCode).ToList();
                    FLList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "FM")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<fm> FMList = Dbcontext.fms.Where(x => x.ZipCode == ZipCode).ToList();
                    FMList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "GA")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<ga> GAList = Dbcontext.gas.Where(x => x.ZipCode == ZipCode).ToList();
                    GAList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "GU")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<gu> GUList = Dbcontext.gus.Where(x => x.ZipCode == ZipCode).ToList();
                    GUList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "HI")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<hi> HIList = Dbcontext.his.Where(x => x.ZipCode == ZipCode).ToList();
                    HIList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "IA")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<ia> IAList = Dbcontext.ias.Where(x => x.ZipCode == ZipCode).ToList();
                    IAList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "ID")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<id> IDList = Dbcontext.ids.Where(x => x.ZipCode == ZipCode).ToList();
                    IDList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "IL")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<il> ILList = Dbcontext.ils.Where(x => x.ZipCode == ZipCode).ToList();
                    ILList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "IN")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<@in> INList = Dbcontext.ins.Where(x => x.ZipCode == ZipCode).ToList();
                    INList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "IL")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<il> ILList = Dbcontext.ils.Where(x => x.ZipCode == ZipCode).ToList();
                    ILList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "KS")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<k> KSList = Dbcontext.ks.Where(x => x.ZipCode == ZipCode).ToList();
                    KSList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "KY")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<ky> KYList = Dbcontext.kies.Where(x => x.ZipCode == ZipCode).ToList();
                    KYList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "LA")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<la> LAList = Dbcontext.las.Where(x => x.ZipCode == ZipCode).ToList();
                    LAList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "MA")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<ma> MAList = Dbcontext.mas.Where(x => x.ZipCode == ZipCode).ToList();
                    MAList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "MD")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<md> MDList = Dbcontext.mds.Where(x => x.ZipCode == ZipCode).ToList();
                    MDList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "ME")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<me> MEList = Dbcontext.me.Where(x => x.ZipCode == ZipCode).ToList();
                    MEList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "MH")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<mh> MHList = Dbcontext.mhs.Where(x => x.ZipCode == ZipCode).ToList();
                    MHList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "MI")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<mi> MIList = Dbcontext.mis.Where(x => x.ZipCode == ZipCode).ToList();
                    MIList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "MN")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<mn> MNList = Dbcontext.mns.Where(x => x.ZipCode == ZipCode).ToList();
                    MNList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "MO")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<mo> MOList = Dbcontext.moes.Where(x => x.ZipCode == ZipCode).ToList();
                    MOList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "MP")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<mp> MPList = Dbcontext.mps.Where(x => x.ZipCode == ZipCode).ToList();
                    MPList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "MS")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<m> MSList = Dbcontext.ms.Where(x => x.ZipCode == ZipCode).ToList();
                    MSList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "MT")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<mt> MTList = Dbcontext.mts.Where(x => x.ZipCode == ZipCode).ToList();
                    MTList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "nc")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<nc> ncList = Dbcontext.ncs.Where(x => x.ZipCode == ZipCode).ToList();
                    ncList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "ND")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<nd> NDList = Dbcontext.nds.Where(x => x.ZipCode == ZipCode).ToList();
                    NDList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "NE")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<ne> NEList = Dbcontext.nes.Where(x => x.ZipCode == ZipCode).ToList();
                    NEList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "NH")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<nh> NHList = Dbcontext.nhs.Where(x => x.ZipCode == ZipCode).ToList();
                    NHList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "NJ")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<nj> NJList = Dbcontext.njs.Where(x => x.ZipCode == ZipCode).ToList();
                    NJList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "NM")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<nm> NMList = Dbcontext.nms.Where(x => x.ZipCode == ZipCode).ToList();
                    NMList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "NV")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<nv> NVList = Dbcontext.nvs.Where(x => x.ZipCode == ZipCode).ToList();
                    NVList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "NY")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<ny> NYList = Dbcontext.nies.Where(x => x.ZipCode == ZipCode).ToList();
                    NYList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "OH")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<oh> OHList = Dbcontext.ohs.Where(x => x.ZipCode == ZipCode).ToList();
                   OHList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "OK")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<ok> OKList = Dbcontext.oks.Where(x => x.ZipCode == ZipCode).ToList();
                    OKList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "OR")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<or> ORList = Dbcontext.ors.Where(x => x.ZipCode == ZipCode).ToList();
                    ORList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "PA")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<pa> PAList = Dbcontext.pas.Where(x => x.ZipCode == ZipCode).ToList();
                    PAList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "PR")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<pr> PRList = Dbcontext.prs.Where(x => x.ZipCode == ZipCode).ToList();
                    PRList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "PW")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<pw> PWList = Dbcontext.pws.Where(x => x.ZipCode == ZipCode).ToList();
                    PWList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "RI")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<ri> RIList = Dbcontext.ris.Where(x => x.ZipCode == ZipCode).ToList();
                    RIList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "SC")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<sc> SCList = Dbcontext.scs.Where(x => x.ZipCode == ZipCode).ToList();
                    SCList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "SD")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<sd> SDList = Dbcontext.sds.Where(x => x.ZipCode == ZipCode).ToList();
                    SDList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "TN")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<tn> TNList = Dbcontext.tns.Where(x => x.ZipCode == ZipCode).ToList();
                    TNList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "TX")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<tx> TXList = Dbcontext.txes.Where(x => x.ZipCode == ZipCode).ToList();
                    TXList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "UT")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<ut> UTList = Dbcontext.uts.Where(x => x.ZipCode == ZipCode).ToList();
                    UTList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "VA")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<va> VAList = Dbcontext.vas.Where(x => x.ZipCode == ZipCode).ToList();
                    VAList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "VI")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<vi> VIList = Dbcontext.vis.Where(x => x.ZipCode == ZipCode).ToList();
                    VIList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "VT")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<vt> VTList = Dbcontext.vts.Where(x => x.ZipCode == ZipCode).ToList();
                    VTList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "WA")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<wa> WAList = Dbcontext.was.Where(x => x.ZipCode == ZipCode).ToList();
                    WAList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "WI")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<wi> WIList = Dbcontext.wis.Where(x => x.ZipCode == ZipCode).ToList();
                    WIList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "WV")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<wv> WVList = Dbcontext.wvs.Where(x => x.ZipCode == ZipCode).ToList();
                    WVList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            else if (State.ToUpper() == "WY")
            {
                using (zipcodeEntities1 Dbcontext = new zipcodeEntities1())
                {
                    List<wy> WYList = Dbcontext.wies.Where(x => x.ZipCode == ZipCode).ToList();
                    WYList.ForEach(x =>
                    {
                        for (int Address = x.AddressPrimaryLowNumber.ToInt(); Address <= x.AddressPrimaryHighNumber.ToInt(); Address++)
                        {
                            AddressList.Add(string.Format("{0} {1} {2}", Address, x.StName, x.StSuffixAbbr));
                            if (ODDEVENNUMBER.Contains(x.AddressPrimaryEvenOdd)) Address++;
                        }
                    });
                }
            }

            return AddressList;

        }
    }
}
