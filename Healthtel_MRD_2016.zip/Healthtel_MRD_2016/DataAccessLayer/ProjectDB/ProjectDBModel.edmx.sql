
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 09/30/2015 22:41:58
-- Generated from EDMX file: E:\Guru\New Requirments\Healthtel_MRD\DataAccessLayer\ProjectDB\ProjectDBModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[healthtel_mrt].[batchmaster]', 'U') IS NOT NULL
    DROP TABLE [healthtel_mrt].[batchmaster];
GO
IF OBJECT_ID(N'[healthtel_mrt].[batchmaster_audit]', 'U') IS NOT NULL
    DROP TABLE [healthtel_mrt].[batchmaster_audit];
GO
IF OBJECT_ID(N'[healthtel_mrt].[compareqc]', 'U') IS NOT NULL
    DROP TABLE [healthtel_mrt].[compareqc];
GO
IF OBJECT_ID(N'[healthtel_mrt].[imagemaster]', 'U') IS NOT NULL
    DROP TABLE [healthtel_mrt].[imagemaster];
GO
IF OBJECT_ID(N'[healthtel_mrt].[key1]', 'U') IS NOT NULL
    DROP TABLE [healthtel_mrt].[key1];
GO
IF OBJECT_ID(N'[healthtel_mrt].[key2]', 'U') IS NOT NULL
    DROP TABLE [healthtel_mrt].[key2];
GO
IF OBJECT_ID(N'[healthtel_mrt].[worklog]', 'U') IS NOT NULL
    DROP TABLE [healthtel_mrt].[worklog];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'UserWiseReportEntities'
CREATE TABLE [dbo].[UserWiseReportEntities] (
    [Batch_Name] longtext  NOT NULL,
    [Name] longtext  NOT NULL,
    [KeyDate] datetime  NULL,
    [Key1_Count] int  NULL,
    [Key1_KeyStroke] int  NULL,
    [Key2_Count] int  NULL,
    [Key2_KeyStroke] int  NULL,
    [compareQC_Count] int  NULL,
    [compareQC_Keystroke] int  NULL,
    [ID] int IDENTITY(1,1) NOT NULL
);
GO

-- Creating table 'batchmasters'
CREATE TABLE [dbo].[batchmasters] (
    [ID] int IDENTITY(1,1) NOT NULL,
    [Name] varchar(150)  NULL,
    [SurveyID] int  NULL,
    [CreatedOn] datetime  NULL,
    [CreatedBy] int  NULL,
    [Key1] int  NULL,
    [Key2] int  NULL,
    [Key3] int  NULL,
    [KeyQC] int  NULL,
    [CompareQC] int  NULL,
    [FullQC] int  NULL,
    [AuditQC] int  NULL,
    [Export] int  NULL,
    [ExportDate] datetime  NULL
);
GO

-- Creating table 'batchmaster_audit'
CREATE TABLE [dbo].[batchmaster_audit] (
    [ID] int IDENTITY(1,1) NOT NULL,
    [Name] varchar(150)  NULL,
    [SurveyID] int  NULL,
    [CreatedOn] datetime  NULL,
    [CreatedBy] int  NULL,
    [Key1] int  NULL,
    [Key2] int  NULL,
    [Key3] int  NULL,
    [KeyQC] int  NULL,
    [CompareQC] int  NULL,
    [FullQC] int  NULL,
    [AuditQC] int  NULL,
    [Export] int  NULL,
    [ExportDate] datetime  NULL
);
GO

-- Creating table 'compareqcs'
CREATE TABLE [dbo].[compareqcs] (
    [CompareQCID] int IDENTITY(1,1) NOT NULL,
    [ImageId] int  NULL,
    [Image_Folder] varchar(65535)  NULL,
    [Image_Number] varchar(250)  NULL,
    [First_Name] varchar(250)  NULL,
    [Last_Name] varchar(250)  NULL,
    [Zip] varchar(15)  NULL,
    [City] varchar(250)  NULL,
    [State] varchar(2)  NULL,
    [Address1] varchar(250)  NULL,
    [Address2] varchar(250)  NULL,
    [Phone_No] varchar(250)  NULL,
    [MemberId] varchar(25)  NULL,
    [Barcode] varchar(45)  NULL,
    [DOSmm] varchar(250)  NULL,
    [DOSdd] varchar(45)  NULL,
    [DOSyy] varchar(45)  NULL,
    [DOBmm] varchar(250)  NULL,
    [DOBdd] varchar(45)  NULL,
    [DOByy] varchar(45)  NULL,
    [ProviderSignature] varchar(20)  NULL,
    [MotOptin] varchar(25)  NULL,
    [FormScan] varchar(5)  NULL,
    [FormScanData] varchar(45)  NULL,
    [LDL_C] varchar(45)  NULL,
    [HbA1c] varchar(45)  NULL,
    [Microalbumin] varchar(45)  NULL,
    [KeyStroke] int  NULL,
    [CreatedBy] int  NULL,
    [CreatedOn] datetime  NULL
);
GO

-- Creating table 'imagemasters'
CREATE TABLE [dbo].[imagemasters] (
    [ImageID] int IDENTITY(1,1) NOT NULL,
    [ImagePath] varchar(255)  NULL,
    [BatchID] int  NULL,
    [Key1] utinyint  NULL,
    [Key2] utinyint  NULL,
    [Key3] utinyint  NULL,
    [Key4] utinyint  NULL,
    [KeyQC] utinyint  NULL,
    [keyverify] tinyint  NULL,
    [CompareQC] utinyint  NULL,
    [CompareQC_New] utinyint  NULL,
    [FullQC] utinyint  NULL,
    [AuditQC] utinyint  NULL,
    [Export] utinyint  NULL,
    [Images] longblob  NULL,
    [IsTiff] bool  NULL
);
GO

-- Creating table 'key1'
CREATE TABLE [dbo].[key1] (
    [Key1ID] int IDENTITY(1,1) NOT NULL,
    [ImageId] int  NULL,
    [Image_Folder] varchar(65535)  NULL,
    [Image_Number] varchar(250)  NULL,
    [First_Name] varchar(250)  NULL,
    [Last_Name] varchar(250)  NULL,
    [Zip] varchar(15)  NULL,
    [City] varchar(250)  NULL,
    [State] varchar(2)  NULL,
    [Address1] varchar(250)  NULL,
    [Address2] varchar(250)  NULL,
    [Phone_No] varchar(250)  NULL,
    [MemberId] varchar(25)  NULL,
    [Barcode] varchar(45)  NULL,
    [DOSmm] varchar(250)  NULL,
    [DOSdd] varchar(45)  NULL,
    [DOSyy] varchar(45)  NULL,
    [DOBmm] varchar(250)  NULL,
    [DOBdd] varchar(45)  NULL,
    [DOByy] varchar(45)  NULL,
    [ProviderSignature] varchar(20)  NULL,
    [MotOptin] varchar(25)  NULL,
    [FormScan] varchar(5)  NULL,
    [FormScanData] varchar(45)  NULL,
    [LDL_C] varchar(45)  NULL,
    [HbA1c] varchar(45)  NULL,
    [Microalbumin] varchar(45)  NULL,
    [KeyStroke] int  NULL,
    [CreatedBy] int  NULL,
    [CreatedOn] datetime  NULL
);
GO

-- Creating table 'key2'
CREATE TABLE [dbo].[key2] (
    [Key2ID] int IDENTITY(1,1) NOT NULL,
    [ImageId] int  NULL,
    [Image_Folder] varchar(65535)  NULL,
    [Image_Number] varchar(250)  NULL,
    [First_Name] varchar(250)  NULL,
    [Last_Name] varchar(250)  NULL,
    [Zip] varchar(15)  NULL,
    [City] varchar(250)  NULL,
    [State] varchar(2)  NULL,
    [Address1] varchar(250)  NULL,
    [Address2] varchar(250)  NULL,
    [Phone_No] varchar(250)  NULL,
    [MemberId] varchar(25)  NULL,
    [Barcode] varchar(45)  NULL,
    [DOSmm] varchar(250)  NULL,
    [DOSdd] varchar(45)  NULL,
    [DOSyy] varchar(45)  NULL,
    [DOBmm] varchar(250)  NULL,
    [DOBdd] varchar(45)  NULL,
    [DOByy] varchar(45)  NULL,
    [ProviderSignature] varchar(20)  NULL,
    [MotOptin] varchar(25)  NULL,
    [FormScan] varchar(5)  NULL,
    [FormScanData] varchar(45)  NULL,
    [LDL_C] varchar(45)  NULL,
    [HbA1c] varchar(45)  NULL,
    [Microalbumin] varchar(45)  NULL,
    [KeyStroke] int  NULL,
    [CreatedBy] int  NULL,
    [CreatedOn] datetime  NULL
);
GO

-- Creating table 'worklogs'
CREATE TABLE [dbo].[worklogs] (
    [WorkLogID] int IDENTITY(1,1) NOT NULL,
    [UserID] int  NULL,
    [ImageID] int  NULL,
    [In] datetime  NULL,
    [Out] datetime  NULL,
    [Process] varchar(50)  NULL,
    [EXE_Status] varchar(3)  NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [ID] in table 'UserWiseReportEntities'
ALTER TABLE [dbo].[UserWiseReportEntities]
ADD CONSTRAINT [PK_UserWiseReportEntities]
    PRIMARY KEY CLUSTERED ([ID] ASC);
GO

-- Creating primary key on [ID] in table 'batchmasters'
ALTER TABLE [dbo].[batchmasters]
ADD CONSTRAINT [PK_batchmasters]
    PRIMARY KEY CLUSTERED ([ID] ASC);
GO

-- Creating primary key on [ID] in table 'batchmaster_audit'
ALTER TABLE [dbo].[batchmaster_audit]
ADD CONSTRAINT [PK_batchmaster_audit]
    PRIMARY KEY CLUSTERED ([ID] ASC);
GO

-- Creating primary key on [CompareQCID] in table 'compareqcs'
ALTER TABLE [dbo].[compareqcs]
ADD CONSTRAINT [PK_compareqcs]
    PRIMARY KEY CLUSTERED ([CompareQCID] ASC);
GO

-- Creating primary key on [ImageID] in table 'imagemasters'
ALTER TABLE [dbo].[imagemasters]
ADD CONSTRAINT [PK_imagemasters]
    PRIMARY KEY CLUSTERED ([ImageID] ASC);
GO

-- Creating primary key on [Key1ID] in table 'key1'
ALTER TABLE [dbo].[key1]
ADD CONSTRAINT [PK_key1]
    PRIMARY KEY CLUSTERED ([Key1ID] ASC);
GO

-- Creating primary key on [Key2ID] in table 'key2'
ALTER TABLE [dbo].[key2]
ADD CONSTRAINT [PK_key2]
    PRIMARY KEY CLUSTERED ([Key2ID] ASC);
GO

-- Creating primary key on [WorkLogID] in table 'worklogs'
ALTER TABLE [dbo].[worklogs]
ADD CONSTRAINT [PK_worklogs]
    PRIMARY KEY CLUSTERED ([WorkLogID] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------