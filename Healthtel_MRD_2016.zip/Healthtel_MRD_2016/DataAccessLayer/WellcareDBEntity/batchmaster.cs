﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using DataAccessLayer.WelcareDB;
using DataAccessLayer.GlobalDB;
using System;
using App.Base;
using System.Reflection;

namespace DataAccessLayer.WelcareDB
{
    public partial class batchmaster //: BaseObject
    {
        #region Properties & Constructor

        public bool IstoBeDeleted { get; set; }
        public bool HasError { get; set; }

        public batchmaster()
        {
        }

        public batchmaster(int batchmasterID)
        {
            using (WelcareEntities dbcontext = new WelcareEntities())
            {
                batchmaster Batchmaster = dbcontext.batchmasters.FirstOrDefault(x => x.ID == ID);
                Mapper.Map(Batchmaster, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        public void Store()
        {

            if (IstoBeDeleted)
            {
                DeleteImplementation();
                return;
            }
            Validate();

            if (HasError)
            {
                return;
            }

            Type type = GetType();
            AssignProperty(type, "CreatedBy", string.Format("{0}", Constance.GC_USERID));
            AssignProperty(type, "CreatedOn", DateTime.Now);

            StoreComposite();
        }

        private void Validate()
        {
            HasError = false;
            if (string.IsNullOrEmpty(Name))
            {
                HasError = true;
            }
        }

        private void StoreComposite()
        {
            if (ID == 0)
            {
                AddImplementation();
            }
            else
            {
                UpdateImplementation();
            }
        }

        private void AddImplementation()
        {
            using (WelcareEntities dbcontext = new WelcareEntities())
            {
                dbcontext.batchmasters.AddObject(this);
                dbcontext.SaveChanges();
                ID = this.ID;
            }
        }

        private void UpdateImplementation()
        {
            using (WelcareEntities dbcontext = new WelcareEntities())
            {
                batchmaster addObject = dbcontext.batchmasters.FirstOrDefault(x => x.ID == ID);
                if (addObject == null)
                {
                    return;
                }
                addObject.Name = Name;
                addObject.Key1 = Key1;
                addObject.Key2 = Key2;
                addObject.Key3 = Key3;
                addObject.KeyQC = KeyQC;
                addObject.CompareQC = CompareQC;
                addObject.FullQC = FullQC;
                addObject.AuditQC = AuditQC;
                addObject.Export = Export;
                addObject.ExportDate = ExportDate;
                addObject.CreatedBy = CreatedBy;
                addObject.CreatedOn = CreatedOn;
                addObject.BatchType = BatchType;

                dbcontext.SaveChanges();
            }
        }

        private void DeleteImplementation()
        {
            using (WelcareEntities dbcontext = new WelcareEntities())
            {
                batchmaster DeleteObject = dbcontext.batchmasters.FirstOrDefault(x => x.ID == ID);
                if (DeleteObject == null)
                {
                    return;
                }
                dbcontext.batchmasters.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        private void AssignProperty(Type type, string PropertyName, object value)
        {
            PropertyInfo property = type.GetProperties().FirstOrDefault(x => x.Name.Equals(PropertyName, StringComparison.OrdinalIgnoreCase));
            if (property == null)
            {
                return;
            }

            switch (property.Name)
            {
                case "CreatedBy":
                    if (property.PropertyType == typeof(string))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        //login user = LoggedInUser.Invoke();
                        property.SetValue(this, Constance.GC_USERID, null);
                    }
                    break;
                case "CreatedDateTime":
                    if (property.PropertyType == typeof(DateTime))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        property.SetValue(this, value, null);
                    }
                    break;
                default:
                    property.SetValue(this, value, null);
                    break;
            }
        }

        #endregion

        #region Help Methods

        public List<batchmaster> List()
        {
            using (WelcareEntities dbcontext = new WelcareEntities())
            {
                return dbcontext.batchmasters.ToList();
            }
        }

        public bool ISBatchNameExist(string Name)
        {
            using (WelcareEntities dbcontext = new WelcareEntities())
            {
                batchmaster objBatchmaster = dbcontext.batchmasters.Where(x => x.Name == Name).FirstOrDefault();

                if (objBatchmaster == null)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }       

        public int Batchid(string Name)
        {
            int Batchid = 0;

            using (WelcareEntities dbcontext = new WelcareEntities())
            {

                List<batchmaster> batchMasterlist = new List<batchmaster>();
                batchMasterlist = dbcontext.batchmasters.ToList();

                List<batchmaster_audit> batchMasterlist_audit = new List<batchmaster_audit>();
                batchMasterlist_audit = dbcontext.batchmaster_audit.ToList();

                var Query = (from b in batchMasterlist where b.Name == Name select b.ID).Union(from c in batchMasterlist_audit where c.Name == Name select c.ID).ToList();
                var item = batchMasterlist.OrderBy(x => x.ID).ToList();
                foreach (var value in Query)
                {
                    Batchid = value;
                   
                }
                return Batchid;        
            }
        }
        public int Batchid_Wellcare(string Name)
        {
            int Batchid = 0;

            using (WelcareEntities dbcontext = new WelcareEntities())
            {

                List<batchmaster> batchMasterlist = new List<batchmaster>();
                batchMasterlist = dbcontext.batchmasters.ToList();

                List<batchmaster_audit> batchMasterlist_audit = new List<batchmaster_audit>();
                batchMasterlist_audit = dbcontext.batchmaster_audit.ToList();

                var Query = (from b in batchMasterlist where b.Name.Contains(Name) select b.ID).Union(from c in batchMasterlist_audit where c.Name.Contains(Name) select c.ID).ToList();
                foreach (var value in Query)
                {
                    Batchid = value;

                }
                return Batchid;
            }
        }
        #endregion Help Methods
    }
}