﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using DataAccessLayer.WelcareDB;
using DataAccessLayer.GlobalDB;

namespace DataAccessLayer.WelcareDB
{
    public partial class batchmaster_audit //: BaseObject
    {
        #region Properties & Constructor

        public bool IstoBeDeleted { get; set; }
        public bool HasError { get; set; }

        public batchmaster_audit()
        {
        }

        public batchmaster_audit(int ID)
        {
            using (WelcareEntities dbcontext = new WelcareEntities())
            {
                batchmaster_audit Batchmaster_audit = dbcontext.batchmaster_audit.FirstOrDefault(x => x.ID == ID);
                Mapper.Map(Batchmaster_audit, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        public void Store()
        {
            if (IstoBeDeleted)
            {
                DeleteImplementation();
                return;
            }
            Validate();

            if (HasError)
            {
                return;
            }

            StoreComposite();
        }

        private void Validate()
        {
            HasError = false;
            if (string.IsNullOrEmpty(Name))
            {
                HasError = true;
            }
        }

        private void StoreComposite()
        {
            if (ID == 0)
            {
                AddImplementation();
            }
            else
            {
                UpdateImplementation();
            }
        }

        private void AddImplementation()
        {
            using (WelcareEntities dbcontext = new WelcareEntities())
            {
                dbcontext.batchmaster_audit.AddObject(this);
                dbcontext.SaveChanges();
            }
        }

        private void UpdateImplementation()
        {
            using (WelcareEntities dbcontext = new WelcareEntities())
            {
                batchmaster_audit UpdateObject = dbcontext.batchmaster_audit.FirstOrDefault(x => x.ID == ID);
                if (UpdateObject == null)
                {
                    HasError = true;
                    return;
                }
                UpdateObject.AuditQC = AuditQC;
                UpdateObject.CompareQC = CompareQC;
                UpdateObject.CreatedBy = CreatedBy;
                UpdateObject.CreatedOn = CreatedOn;
                UpdateObject.Export = Export;
                UpdateObject.ExportDate = ExportDate;
                UpdateObject.FullQC = FullQC;
                UpdateObject.Key1 = Key1;
                UpdateObject.Key2 = Key2;
                UpdateObject.Key3 = Key3;
                UpdateObject.KeyQC = KeyQC;
                UpdateObject.Name = Name;
                UpdateObject.BatchID = BatchID;
                UpdateObject._BatchType = BatchType;
                dbcontext.SaveChanges();
            }
        }

        private void DeleteImplementation()
        {
            using (WelcareEntities dbcontext = new WelcareEntities())
            {
                batchmaster_audit DeleteObject = dbcontext.batchmaster_audit.FirstOrDefault(x => x.ID == ID);
                if (DeleteObject == null)
                {
                    HasError = true;
                    return;
                }
                dbcontext.batchmaster_audit.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        #endregion CRUD Operation

        #region Help Methods

        public List<batchmaster> List()
        {
            using (WelcareEntities dbcontext = new WelcareEntities())
            {
                return dbcontext.batchmasters.ToList();
            }
        }

        public static bool BatchDelete(int BatchID)
        {
            return true;
        }

        #endregion Help Methods
    }
}
