﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AutoMapper;
using DataAccessLayer.GlobalDB;
using System.Reflection;
using App.Base;

namespace DataAccessLayer.ProjectDB
{
    public partial class compareqc_hra
    {        
        #region Properties & Constructor

        public bool IstoBeDeleted { get; set; }
        public bool HasError { get; set; }
        public string UserName { get; set; }

        public compareqc_hra()
        {
        }

        public compareqc_hra(int CompareQC_HRAID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                compareqc_hra ComapreQC_HRA = dbcontext.compareqc_hra.FirstOrDefault(x => x.ComapreQC_HRAID == CompareQC_HRAID);
                Mapper.Map(ComapreQC_HRA, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        public void Store()
        {
            if (IstoBeDeleted)
            {
                DeleteImplementation();
                return;
            }
            Validate();

            if (HasError)
            {
                return;
            }

            Type type = GetType();
            AssignProperty(type, "CreatedBy", string.Format("{0}", Constance.GC_USERID));
            AssignProperty(type, "CreatedOn", DateTime.Now);

            StoreComposite();
        }

        private void Validate()
        { }

        private void StoreComposite()
        {
            if (ComapreQC_HRAID == 0)
            {
                AddImplementation();
            }
            else
            {
                UpdateImplementation();
            }
        }

        private void AddImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                dbcontext.compareqc_hra.AddObject(this);
                dbcontext.SaveChanges();
            }
        }

        private void UpdateImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                compareqc_hra UpdateObject = dbcontext.compareqc_hra.FirstOrDefault(x => x.ComapreQC_HRAID == ComapreQC_HRAID);
                if (UpdateObject == null)
                {
                    HasError = true;
                    return;
                }
                UpdateObject.ImageId = ImageId;
                UpdateObject.Image_Folder = Image_Folder;
                UpdateObject.Image_Number = Image_Number;
                UpdateObject.Respondent_ID = Respondent_ID;
                UpdateObject.Q1 = Q1;
                UpdateObject.Q2_1 = Q2_1;
                UpdateObject.Q2_2 = Q2_2;
                UpdateObject.Q2_3 = Q2_3;
                UpdateObject.Q2_4 = Q2_4;
                UpdateObject.Q2_5 = Q2_5;
                UpdateObject.Q2_6 = Q2_6;
                UpdateObject.Q2_7 = Q2_7;
                UpdateObject.Q2_8 = Q2_8;
                UpdateObject.Q4 = Q4;
                UpdateObject.Q5 = Q5;
                UpdateObject.Q6 = Q6;
                UpdateObject.Q7 = Q7;
                UpdateObject.Q8 = Q8;
                UpdateObject.Q9 = Q9;
                UpdateObject.Q10 = Q10;
                UpdateObject.Q11 = Q11;
                UpdateObject.Q12 = Q12;
                UpdateObject.Q13 = Q13;
                UpdateObject.Q14 = Q14;
                UpdateObject.Q15 = Q15;
                UpdateObject.Q16 = Q16;
                UpdateObject.Q17 = Q17;
                UpdateObject.Language = Language;
                UpdateObject.Q3 = Q3;
                UpdateObject.CreatedBy = CreatedBy;
                UpdateObject.CreatedOn = CreatedOn;
                UpdateObject.KeyStroke = KeyStroke;
                dbcontext.SaveChanges();
            }
        }

        private void DeleteImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                compareqc_hra DeleteObject = dbcontext.compareqc_hra.FirstOrDefault(x => x.ComapreQC_HRAID == ComapreQC_HRAID);
                if (DeleteObject == null)
                {
                    HasError = true;
                    return;
                }
                dbcontext.compareqc_hra.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        private void AssignProperty(Type type, string PropertyName, object value)
        {
            PropertyInfo property = type.GetProperties().FirstOrDefault(x => x.Name.Equals(PropertyName, StringComparison.OrdinalIgnoreCase));
            if (property == null)
            {
                return;
            }

            switch (property.Name)
            {
                case "CreatedBy":
                    if (property.PropertyType == typeof(string))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        //login user = LoggedInUser.Invoke();
                        property.SetValue(this, Constance.GC_USERID, null);
                    }
                    break;
                case "CreatedDateTime":
                    if (property.PropertyType == typeof(DateTime))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        property.SetValue(this, value, null);
                    }
                    break;
                default:
                    property.SetValue(this, value, null);
                    break;
            }
        }

        #endregion

        #region Help Methods

        public List<compareqc_hra> List()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                return dbcontext.compareqc_hra.ToList();
            }
        }

        public compareqc_hra isImageIDExists(long ImageID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                compareqc_hra ComapreQC_HRA = dbcontext.compareqc_hra.FirstOrDefault(x => x.ImageId == ImageID);
                return ComapreQC_HRA;
            }
        }

        public compareqc_hra CompareQCDatas(int ImageID)
        {
            compareqc_hra ComapreQC_HRA = new compareqc_hra();
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                ComapreQC_HRA = dbcontext.compareqc_hra.FirstOrDefault(x => x.ImageId == ImageID);
            }
            if (ComapreQC_HRA != null)
            {
                login userData = new login((int)ComapreQC_HRA.CreatedBy);
                ComapreQC_HRA.UserName = userData.Name;
            }
            return ComapreQC_HRA;
        }        

        #endregion
    }
}
