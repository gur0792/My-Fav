﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;

namespace DataAccessLayer.ProjectDB
{
    public partial class compareqc_fields : BaseObject
    {
        #region Properties & Constructor

        public compareqc_fields()
        {
        }

        public compareqc_fields(int ImageID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                compareqc_fields compareqc_field = dbcontext.compareqc_fields.FirstOrDefault(x => x.ImageID == ImageID);
                Mapper.Map(compareqc_field, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        protected override void Validate()
        {
            if (ImageID ==0 )
            {
                AddMessage("ImageID is not zero or null");
            }
        }

        protected override void StoreComposite()
        {          
            if (CompareQCFieldID == 0)
            {
                AddImplementation();
            }
            else
            {
                UpdateImplementation();
            }
        }

        protected override void AddImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                dbcontext.compareqc_fields.AddObject(this);
                dbcontext.SaveChanges();
            }
        }

        protected override void UpdateImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                compareqc_fields UpdateObject = dbcontext.compareqc_fields.FirstOrDefault(x => x.CompareQCFieldID == CompareQCFieldID);
                if (UpdateObject == null)
                {
                    AddMessage("ID Does not exist.");
                    return;
                }
                UpdateObject.BatchID = BatchID;
                UpdateObject.CreatedBy = CreatedBy;
                UpdateObject.CreatedDateTime = CreatedDateTime;
                UpdateObject.FieldNo = FieldNo;
                UpdateObject.ImageID = ImageID;
                UpdateObject.Status = Status;                
                dbcontext.SaveChanges();
            }
        }

        protected override void DeleteImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                compareqc_fields DeleteObject = dbcontext.compareqc_fields.FirstOrDefault(x => x.CompareQCFieldID == CompareQCFieldID);
                if (DeleteObject == null)
                {
                    AddMessage("ID Does not exist.");
                    return;
                }
                dbcontext.compareqc_fields.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        #endregion CRUD Operation

        #region Help Methods

        public List<compareqc_fields> List()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                return dbcontext.compareqc_fields.ToList();
            }
        }

        #endregion Help Methods
    }
}


