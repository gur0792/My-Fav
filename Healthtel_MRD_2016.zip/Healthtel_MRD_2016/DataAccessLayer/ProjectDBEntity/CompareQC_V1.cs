﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AutoMapper;
using DataAccessLayer.GlobalDB;
using System.Reflection;
using App.Base;

namespace DataAccessLayer.ProjectDB
{
    public partial class compareqc_hra_v1
    {
        #region Properties & Constructor

        public bool IstoBeDeleted { get; set; }
        public bool HasError { get; set; }
        public string UserName { get; set; }

        public compareqc_hra_v1()
        {
        }

        public compareqc_hra_v1(int CompareQC_HRAID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                compareqc_hra_v1 ComapreQC_HRA = dbcontext.compareqc_hra_v1.FirstOrDefault(x => x.Key1_HRAID == CompareQC_HRAID);
                Mapper.Map(ComapreQC_HRA, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        public void Store()
        {
            if (IstoBeDeleted)
            {
                DeleteImplementation();
                return;
            }
            Validate();

            if (HasError)
            {
                return;
            }

            Type type = GetType();
            AssignProperty(type, "CreatedBy", string.Format("{0}", Constance.GC_USERID));
            AssignProperty(type, "CreatedOn", DateTime.Now);

            StoreComposite();
        }

        private void Validate()
        { }

        private void StoreComposite()
        {
            if (Key1_HRAID == 0)
            {
                AddImplementation();
            }
            else
            {
                UpdateImplementation();
            }
        }

        private void AddImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                dbcontext.compareqc_hra_v1.AddObject(this);
                dbcontext.SaveChanges();
            }
        }

        private void UpdateImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                compareqc_hra_v1 UpdateObject = dbcontext.compareqc_hra_v1.FirstOrDefault(x => x.Key1_HRAID == Key1_HRAID);
                if (UpdateObject == null)
                {
                    HasError = true;
                    return;
                }
                UpdateObject.ImageId = ImageId;
                UpdateObject.Image_Folder = Image_Folder;
                UpdateObject.Image_Number = Image_Number;
                UpdateObject.Respondent_ID = Respondent_ID;
                UpdateObject.Q1_9 = Q1_9;
                UpdateObject.Q1_1 = Q1_1;
                UpdateObject.Q1_2 = Q1_2;
                UpdateObject.Q1_3 = Q1_3;
                UpdateObject.Q1_4 = Q1_4;
                UpdateObject.Q1_5 = Q1_5;
                UpdateObject.Q1_6 = Q1_6;
                UpdateObject.Q1_7 = Q1_7;
                UpdateObject.Q1_8 = Q1_8;
                UpdateObject.Q3_1 = Q3_1;
                UpdateObject.Q3_2 = Q3_2;
                UpdateObject.Q3_2 = Q3_2;
                UpdateObject.Q3_2 = Q3_2;
                UpdateObject.Q3_2 = Q3_2;
                UpdateObject.Q3_2 = Q3_2;
                UpdateObject.Q3_2 = Q3_2;
                UpdateObject.Q3_2 = Q3_2;
                UpdateObject.Q3_2 = Q3_2;
                UpdateObject.Q2_ttl = Q2_ttl;
                UpdateObject.Q5_1 = Q5_1;
                UpdateObject.Q5_TTL = Q5_TTL;
                UpdateObject.Q6_1 = Q6_1;
                UpdateObject.Q7_2 = Q7_2;
                UpdateObject.Q7_1 = Q7_1;
                UpdateObject.Q8_1 = Q8_1;
                UpdateObject.Language = Language;
                UpdateObject.CreatedBy = CreatedBy;
                UpdateObject.CreatedOn = CreatedOn;
                UpdateObject.KeyStroke = KeyStroke;
                dbcontext.SaveChanges();
                dbcontext.SaveChanges();
            }
        }

        private void DeleteImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                compareqc_hra_v1 DeleteObject = dbcontext.compareqc_hra_v1.FirstOrDefault(x => x.Key1_HRAID == Key1_HRAID);
                if (DeleteObject == null)
                {
                    HasError = true;
                    return;
                }
                dbcontext.compareqc_hra_v1.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        private void AssignProperty(Type type, string PropertyName, object value)
        {
            PropertyInfo property = type.GetProperties().FirstOrDefault(x => x.Name.Equals(PropertyName, StringComparison.OrdinalIgnoreCase));
            if (property == null)
            {
                return;
            }

            switch (property.Name)
            {
                case "CreatedBy":
                    if (property.PropertyType == typeof(string))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        //login user = LoggedInUser.Invoke();
                        property.SetValue(this, Constance.GC_USERID, null);
                    }
                    break;
                case "CreatedDateTime":
                    if (property.PropertyType == typeof(DateTime))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        property.SetValue(this, value, null);
                    }
                    break;
                default:
                    property.SetValue(this, value, null);
                    break;
            }
        }

        #endregion

        #region Help Methods

        public List<compareqc_hra_v1> List()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                return dbcontext.compareqc_hra_v1.ToList();
            }
        }

        public compareqc_hra_v1 isImageIDExists(long ImageID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                compareqc_hra_v1 compareqc_hra_v1 = dbcontext.compareqc_hra_v1.FirstOrDefault(x => x.ImageId == ImageID);
                return compareqc_hra_v1;
            }
        }

        public compareqc_hra_v1 CompareQCDatas(int ImageID)
        {
            compareqc_hra_v1 ComapreQC_HRA = new compareqc_hra_v1();
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                ComapreQC_HRA = dbcontext.compareqc_hra_v1.FirstOrDefault(x => x.ImageId == ImageID);
            }
            if (ComapreQC_HRA != null)
            {
                login userData = new login((int)ComapreQC_HRA.CreatedBy);
                ComapreQC_HRA.UserName = userData.Name;
            }
            return ComapreQC_HRA;
        }

        #endregion
    }
}
