﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;

namespace DataAccessLayer.ProjectDB
{
    public partial class auditqc : BaseObject
    {
        #region Properties & Constructor

        public auditqc()
        {
        }

        public auditqc(int ImageID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                auditqc Auditqc = dbcontext.auditqcs.FirstOrDefault(x => x.ImageID == ImageID);
                Mapper.Map(Auditqc, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        protected override void Validate()
        {
            if (ImageID == 0)
            {
                AddMessage("ImageID is not null or zero");
            }

            if (string.IsNullOrEmpty(Names))
            {
                AddMessage("Name is not empty or null");
            }
        }

        protected override void StoreComposite()
        {
            if (AuditQCID == 0)
            {
                AddImplementation();
            }
            else
            {
                UpdateImplementation();
            }
        }

        protected override void AddImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                dbcontext.auditqcs.AddObject(this);
                dbcontext.SaveChanges();
            }
        }

        protected override void UpdateImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                auditqc UpdateObject = dbcontext.auditqcs.FirstOrDefault(x => x.AuditQCID == AuditQCID);
                if (UpdateObject == null)
                {
                    AddMessage("ImageID Does not exist.");
                    return;
                }
                UpdateObject.EmailAddress = EmailAddress;
                UpdateObject.Flag = Flag;
                UpdateObject.GradYear = GradYear;
                UpdateObject.Illegible = Illegible;
                UpdateObject.ImageFolder = ImageFolder;
                UpdateObject.ImageID = ImageID;
                UpdateObject.KeyStroke = KeyStroke;
                UpdateObject.Names = Names;
                UpdateObject.School = School;
                UpdateObject.SNo = SNo;
                UpdateObject.CreatedBy = CreatedBy;
                UpdateObject.CreatedDateTime = CreatedDateTime;
                dbcontext.SaveChanges();
            }
        }

        protected override void DeleteImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                auditqc DeleteObject = dbcontext.auditqcs.FirstOrDefault(x => x.AuditQCID == AuditQCID);
                if (DeleteObject == null)
                {
                    AddMessage("ID Does not exist.");
                    return;
                }
                dbcontext.auditqcs.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        #endregion CRUD Operation

        #region Help Methods

        public List<auditqc> List()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                return dbcontext.auditqcs.ToList();
            }
        }

        #endregion Help Methods
    }
}