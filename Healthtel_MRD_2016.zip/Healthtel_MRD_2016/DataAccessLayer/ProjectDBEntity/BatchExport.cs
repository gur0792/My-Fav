﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccessLayer.ProjectDB
{
    //public class BatchExport
    //{
    //    public int SNO { get; set; }
    //    public string IMAGE_NAME { get; set; }
    //    public string MEMBER_ID { get; set; }
    //    public string BAR_CODE { get; set; }
    //    public string FIRSTNAME { get; set; }
    //    public string LASTNAME { get; set; }
    //    public string PHONE_CAPTURE { get; set; }
    //    public string ADDRESS_OVERRIDE { get; set; }
    //    public string ADDRESS_1 { get; set; }
    //    public string ADDRESS_2 { get; set; }
    //    public string CITY { get; set; }
    //    public string STATE { get; set; }
    //    public string ZIP { get; set; }
    //    public string DOB { get; set; }
    //    public string DOS { get; set; }
    //    public string PROVIDER_SIGNATURE { get; set; }
    //    public string MOT_OPTIN { get; set; }
    //    public string COMP_EXAM1 { get; set; }
    //    public string COMP_EXAM2 { get; set; }
    //    public string COMP_EXAM3 { get; set; }
    //    public string MERCH_CARD_15 { get; set; }
    //    public string FORM_SCAN { get; set; }
    //    public string INTERACTION_DATE_TIME { get; set; }
    //    public string USER_NAME { get; set; }


    //}

    public class BatchwiseReport
    {
        public string BATCHNAME { get; set; }
        public int TOTAL_RECORDS { get; set; }
        public int KEY1_PROCESSING { get; set; }
        public int KEY1_COMPLETED { get; set; }
        public int KEY2_PROCESSING { get; set; }
        public int KEY2_COMPLETED { get; set; }
        public int KEYQC_PROCESSING { get; set; }
        public int KEYQC_COMPLETED { get; set; }
        public int COMPAREQC_PROCESSING { get; set; }
        public int COMPAREQC_COMPLETED { get; set; }
        public int? EXPORT_STATUS { get; set; }
    }

    public class UserwiseReport
    {
        public string BATCHNAME { get; set; }
        public string USERNAME { get; set; }
        public int KEY_DATE { get; set; }
        public int KEY1_COUNT { get; set; }
        public int KEY1_KEYSTROKES { get; set; }
        public int KEY2_COUNT { get; set; }
        public int KEY2_KEYSTROKES { get; set; }
        public int COMPAREQC_COUNT { get; set; }
        public int COMPAREQC_KEYSTROKES { get; set; }
    }

    public class ResetBatchImages
    {
        public string IMAGENAME { get; set; }
        public int IMAGEID { get; set; }
    }

}
