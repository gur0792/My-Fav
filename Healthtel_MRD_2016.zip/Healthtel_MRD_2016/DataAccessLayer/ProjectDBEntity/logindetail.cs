﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;

namespace DataAccessLayer.ProjectDB
{
    public partial class worklog //: BaseObject
    {
        #region Properties & Constructor

        public bool IstoBeDeleted { get; set; }
        public bool HasError { get; set; }

        public worklog()
        {
        }

        public worklog(int WorkLogID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                worklog Logindetail = dbcontext.worklogs.FirstOrDefault(x => x.WorkLogID == WorkLogID);
                Mapper.Map(Logindetail, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        public void Store()
        {
            if (IstoBeDeleted)
            {
                DeleteImplementation();
                return;
            }
            Validate();

            if (HasError)
            {
                return;
            }

            StoreComposite();
        }

        private void Validate()
        {
            HasError = false;
            if (ImageID == 0)
            {
                HasError = true;
            }
        }

        private void StoreComposite()
        {
            if (WorkLogID == 0)
            {
                AddImplementation();
            }
            else
            {
                UpdateImplementation();
            }
        }

        private void AddImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                dbcontext.worklogs.AddObject(this);
                dbcontext.SaveChanges();
            }
        }

        private void UpdateImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                worklog UpdateObject = dbcontext.worklogs.FirstOrDefault(x => x.WorkLogID == WorkLogID);
                if (UpdateObject == null)
                {
                    HasError = true;
                    return;
                }
                UpdateObject.EXE_Status = EXE_Status;
                UpdateObject.ImageID = ImageID;
                UpdateObject.In = In;
                UpdateObject.Out = Out;
                UpdateObject.Process = Process;
                UpdateObject.UserID = UserID;                
                
                dbcontext.SaveChanges();
            }
        }

        private void DeleteImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                worklog DeleteObject = dbcontext.worklogs.FirstOrDefault(x => x.WorkLogID == WorkLogID);
                if (DeleteObject == null)
                {
                    HasError = true;
                    return;
                }
                dbcontext.worklogs.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        #endregion CRUD Operation

        #region Help Methods

        public List<worklog> List()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                return dbcontext.worklogs.ToList();
            }
        }

        #endregion Help Methods
    }
}


