﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using DataAccessLayer.ProjectDB;
using DataAccessLayer.GlobalDB;
using System;
using System.IO;
using App.Base;
using System.Threading;

namespace DataAccessLayer.ProjectDB
{
    public partial class imagemaster //: BaseObject
    {
        #region Properties & Constructor

        public bool IstoBeDeleted { get; set; }
        public bool HasError { get; set; }

        public imagemaster()
        {
        }

        public imagemaster(int ImageID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                imagemaster Imagemaster = dbcontext.imagemasters.FirstOrDefault(x => x.ImageID == ImageID);
                Mapper.Map(Imagemaster, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        public void Store()
        {
            if (IstoBeDeleted)
            {
                DeleteImplementation();
                return;
            }
            Validate();

            if (HasError)
            {
                return;
            }

            StoreComposite();
        }

        private void Validate()
        {
            if (string.IsNullOrEmpty(ImagePath))
            {
                HasError = true;
            }
        }

        private void StoreComposite()
        {
            if (ImageID == 0)
            {
                AddImplementation();
            }
            else
            {
                UpdateImplementation();
            }
        }

        private void AddImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                dbcontext.imagemasters.AddObject(this);
                dbcontext.SaveChanges();
            }
        }

        private void UpdateImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                imagemaster UpdateObject = dbcontext.imagemasters.FirstOrDefault(x => x.ImageID == ImageID);
                if (UpdateObject == null)
                {
                    HasError = true;
                    return;
                }
                UpdateObject.AuditQC = AuditQC;
                UpdateObject.BatchID = BatchID;
                UpdateObject.CompareQC = CompareQC;
                UpdateObject.Export = Export;
                UpdateObject.FullQC = FullQC;
                UpdateObject.ImagePath = ImagePath;
                UpdateObject.Images = Images;
                UpdateObject.Key1 = Key1;
                UpdateObject.Key2 = Key2;
                UpdateObject.Key3 = Key3;
                UpdateObject.KeyQC = KeyQC;
                UpdateObject.CompareQC = CompareQC;
                UpdateObject.userId = Constance.GC_USERID;
                dbcontext.SaveChanges();
            }
        }

        private void DeleteImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                imagemaster DeleteObject = dbcontext.imagemasters.FirstOrDefault(x => x.ImageID == ImageID);
                if (DeleteObject == null)
                {
                    HasError = true;
                    return;
                }
                dbcontext.imagemasters.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        #endregion CRUD Operation

        #region Help Methods

        public List<imagemaster> List()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                return dbcontext.imagemasters.ToList();
            }
        }

        public imagemaster LoadImage(string Process, long BatchID, int UserID)
        {
            imagemaster Img = new imagemaster();
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                if (Process.ToUpper() == "KEY1")
                {
                    Img = dbcontext.imagemasters.Where(x => x.Key1 == 0 && x.BatchID == BatchID).OrderBy(x => x.ImageID).FirstOrDefault();
                    if (Img != null)
                    {
                        Img.Key1 = 1;
                        Img.Store();
                    }
                    return Img;
                }

                if (Process.ToUpper() == "KEY2")
                {
                    var key1list = dbcontext.key1.Where(x => x.CreatedBy == UserID).ToList();
                    var ImageList = dbcontext.imagemasters.Where(x => x.Key2 == 0 && x.BatchID == BatchID).ToList();
                    Img = ImageList.Where(x => !key1list.Any(z => x.ImageID == z.ImageId)).FirstOrDefault();

                    if (Img != null)
                    {
                        Img.Key2 = 1;
                        Img.Store();
                    }
                    return Img;
                }

                if (Process.ToUpper() == "COMPAREQC")
                {
                    Img = dbcontext.imagemasters.Where(x => x.Key1 == 2 && x.Key2 == 2 && x.CompareQC == 0 && x.BatchID == BatchID).OrderBy(x => x.ImageID).FirstOrDefault();
                    if (Img != null)
                    {
                        Img.CompareQC = 1;
                        Img.Store();
                    }
                    return Img;
                }

                if (Process.ToUpper() == "KEYQC")
                {
                    //Img = dbcontext.imagemasters.Where(x => x.Key1 == 2 && x.KeyQC == 0 && x.BatchID == BatchID).OrderBy(x => x.ImageID).FirstOrDefault();
                    //if (Img != null)
                    //{
                    //    Img.KeyQC = 1;
                    //    Img.Store();
                    //}
                    //return Img;

                    var key1list = dbcontext.key1.Where(x => x.CreatedBy == UserID).ToList();
                    var ImageList = dbcontext.imagemasters.Where(x => x.KeyQC == 0 && x.Key1 == 2 && x.BatchID == BatchID).ToList();
                    Img = ImageList.Where(x => !key1list.Any(z => x.ImageID == z.ImageId)).FirstOrDefault();

                    if (Img != null)
                    {
                        Img.KeyQC = 1;
                        Img.Store();
                    }
                    return Img;
                }

                return Img;
            }

        }

        public imagemaster LoadImage_HRA(string Process, long BatchID, int UserID)
        {
            imagemaster Img = new imagemaster();
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                if (Process.ToUpper() == "KEY1")
                {
                    Img = dbcontext.imagemasters.Where(x => x.Key1 == 0 && x.BatchID == BatchID).OrderBy(x => x.ImageID).FirstOrDefault();
                    if (Img != null)
                    {
                        Img.Key1 = 1;
                        Img.Store();
                    }
                    return Img;
                }

                if (Process.ToUpper() == "KEY2")
                {
                    var key1list = dbcontext.key1_hra.Where(x => x.CreatedBy == UserID).ToList();
                    var ImageList = dbcontext.imagemasters.Where(x => x.Key2 == 0 && x.BatchID == BatchID).ToList();
                    Img = ImageList.Where(x => !key1list.Any(z => x.ImageID == z.ImageId)).FirstOrDefault();

                    if (Img != null)
                    {
                        Img.Key2 = 1;
                        Img.Store();
                    }
                    return Img;
                }

                if (Process.ToUpper() == "COMPAREQC")
                {
                    Img = dbcontext.imagemasters.Where(x => x.Key1 == 2 && x.Key2 == 2 && x.CompareQC == 0 && x.BatchID == BatchID).OrderBy(x => x.ImageID).FirstOrDefault();
                    if (Img != null)
                    {
                        Img.CompareQC = 1;
                        Img.Store();
                    }
                    return Img;
                }

                return Img;
            }

        }
        public imagemaster LoadImage_HRA_v1(string Process, long BatchID, int UserID)
        {
            imagemaster Img = new imagemaster();
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
            Home:
                if (Process.ToUpper() == "KEY1")
                {
                    //Img = dbcontext.imagemasters.Where(x => x.Key1 == 0 && x.BatchID == BatchID).OrderBy(x => x.ImageID).FirstOrDefault();
                    Img = dbcontext.imagemasters.Where(x => x.Key1 == 0 && x.BatchID == BatchID).FirstOrDefault();

                    if (Img != null)
                    {
                        Img.Key1 = 1;
                        Img.userId = UserID;
                        Img.Store();
                    }
                    else
                    {
                        return null;
                    }
                    
                    int _image_id = Convert.ToInt32( Img.ImageID);
                    int _user_id = Convert.ToInt32(Img.userId);   
                    Random rng = new Random();
                    Thread.Sleep(rng.Next(30));

                    Img = dbcontext.imagemasters.Where(x => x.ImageID == _image_id && x.userId == UserID).OrderBy(x => x.ImageID).FirstOrDefault();
                    if (Img != null)
                    {
                        return Img;
                    }
                    else
                    {
                        goto Home;
                    }

                  
                }

                if (Process.ToUpper() == "KEY2")
                {
                    var key1list = dbcontext.key1_hra_v1.Where(x => x.CreatedBy == UserID).ToList();
                    var ImageList = dbcontext.imagemasters.Where(x => x.Key2 == 0 && x.BatchID == BatchID).ToList();
                    Img = ImageList.Where(x => !key1list.Any(z => x.ImageID == z.ImageId)).FirstOrDefault();

                    if (Img != null)
                    {
                        Img.Key2 = 1;
                        Img.Store();
                    }
                    return Img;
                }

                if (Process.ToUpper() == "COMPAREQC")
                {
                    Img = dbcontext.imagemasters.Where(x => x.Key1 == 2 && x.Key2 == 2 && x.CompareQC == 0 && x.BatchID == BatchID).OrderBy(x => x.ImageID).FirstOrDefault();
                    if (Img != null)
                    {
                        Img.CompareQC = 1;
                        Img.Store();
                    }
                    return Img;
                }

                return Img;
            }

        }

        public imagemaster LoadImage_HEDIS(string Process, long BatchID, int UserID)
        {
            imagemaster Img = new imagemaster();
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                if (Process.ToUpper() == "KEY1")
                {
                    Img = dbcontext.imagemasters.Where(x => x.Key1 == 0 && x.BatchID == BatchID).OrderBy(x => x.ImageID).FirstOrDefault();
                    if (Img != null)
                    {
                        Img.Key1 = 1;
                        Img.Store();
                    }
                    return Img;
                }

                if (Process.ToUpper() == "KEYQC")
                {
                    var key1list = dbcontext.key1_hedis.Where(x => x.CreatedBy == UserID).ToList();
                    var ImageList = dbcontext.imagemasters.Where(x => x.KeyQC == 0 && x.Key1 == 2 && x.BatchID == BatchID).ToList();
                    Img = ImageList.Where(x => !key1list.Any(z => x.ImageID == z.ImageId)).FirstOrDefault();

                    if (Img != null)
                    {
                        Img.KeyQC = 1;
                        Img.Store();
                    }
                    return Img;
                }

                return Img;
            }

        }

        public void RecordStatus(string process, long BatchID, ref int Totalrecord, ref int FinishedRecord, ref int RemainingRecord, int BatchType)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                //DataAccessLayer.GlobalDB.login LoggedUsers = new DataAccessLayer.ProjectDB.batchmaster().getLoginUser();
                Totalrecord = 0;
                FinishedRecord = 0;
                RemainingRecord = 0;
                List<imagemaster> totalImage = dbcontext.imagemasters.Where(x => x.BatchID == BatchID).ToList();
                Totalrecord = totalImage.Count;
                if (process.ToUpper() == "KEY1")
                {
                    if (BatchType == 0 || BatchType == 1)
                    {
                      //  var key1list = dbcontext.key1_hra.Select(x => x).ToList();
                        //RAJESH Done for slow issue while saving
                        var key1list = (from a in dbcontext.key1_hra
                                        join b in dbcontext.imagemasters on a.ImageId equals b.ImageID
                                        where b.BatchID == BatchID
                                        select new { a.ImageId, a.CreatedBy }).ToList();
                        FinishedRecord = key1list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID) && x.CreatedBy == Constance.GC_USERID).Count();
                        var key1ProcessedCount = key1list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID)).Count();
                        RemainingRecord = Totalrecord - key1ProcessedCount;
                    }
                    else if (BatchType == 2)
                    {
                        //var key1list = dbcontext.key1.Select(x => x).ToList();
                        //RAJESH Done for slow issue while saving
                        var key1list = (from a in dbcontext.key1
                                        join b in dbcontext.imagemasters on a.ImageId equals b.ImageID
                                        where b.BatchID == BatchID
                                        select new { a.ImageId, a.CreatedBy }).ToList();
                        FinishedRecord = key1list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID) && x.CreatedBy == Constance.GC_USERID).Count();
                        var key1ProcessedCount = key1list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID)).Count();
                        RemainingRecord = Totalrecord - key1ProcessedCount;
                    }

                    else if (BatchType == 3)
                    {
                       // var key1list = dbcontext.key1_hedis.Select(x => x).ToList();
                        var key1list = (from a in dbcontext.key1_hedis
                                        join b in dbcontext.imagemasters on a.ImageId equals b.ImageID
                                        where b.BatchID == BatchID
                                        select new { a.ImageId, a.CreatedBy }).ToList();
                        FinishedRecord = key1list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID) && x.CreatedBy == Constance.GC_USERID).Count();
                        var key1ProcessedCount = key1list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID)).Count();
                        RemainingRecord = Totalrecord - key1ProcessedCount;
                    }

                    else if (BatchType == 5)
                    {
                        // var key1list = dbcontext.key1_hedis.Select(x => x).ToList();
                        var key1list = (from a in dbcontext.key1_pediatric
                                        join b in dbcontext.imagemasters on a.ImageId equals b.ImageID
                                        where b.BatchID == BatchID
                                        select new { a.ImageId, a.CreatedBy }).ToList();
                        FinishedRecord = key1list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID) && x.CreatedBy == Constance.GC_USERID).Count();
                        var key1ProcessedCount = key1list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID)).Count();
                        RemainingRecord = Totalrecord - key1ProcessedCount;
                    }


                    else if (BatchType == 4)
                    {
                        //var key1list = dbcontext.key1_hra_v1.Select(x => x).ToList();
                        var key1list = (from a in dbcontext.key1_hra_v1
                                         join b in dbcontext.imagemasters on a.ImageId equals b.ImageID
                                         where b.BatchID == BatchID 
                                         select new { a.ImageId, a.userid  }).ToList();
                        FinishedRecord = key1list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID) && x.userid == Constance.GC_USERID).Count();
                        var key1ProcessedCount = key1list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID)).Count();
                        RemainingRecord = Totalrecord - key1ProcessedCount;
                    }

                    //FinishedRecord = dbcontext.key1.Where(x => x.CreatedBy == LoggedUsers.ID && totalImage.Any(z => x.ImageId == z.ImageID)).Count();
                }
                if (process.ToUpper() == "KEY2")
                {
                    if (BatchType == 0 || BatchType == 1)
                    {
                       // var key2list = dbcontext.key2_hra.Select(x => x).ToList();
                        var key2list = (from a in dbcontext.key2_hra
                                        join b in dbcontext.imagemasters on a.ImageId equals b.ImageID
                                        where b.BatchID == BatchID
                                        select new { a.ImageId, a.CreatedBy }).ToList();
                        //FinishedRecord = dbcontext.key1.Where(x => x.CreatedBy == LoggedUsers.ID && totalImage.Any(z => x.ImageId == z.ImageID)).Count();
                        FinishedRecord = key2list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID) && x.CreatedBy == Constance.GC_USERID).Count();
                        var key1ProcessedCount = key2list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID)).Count();

                        RemainingRecord = Totalrecord - key1ProcessedCount;
                    }
                    else if (BatchType == 2)
                    {
                      //  var key2list = dbcontext.key2.Select(x => x).ToList();
                        var key2list = (from a in dbcontext.key2
                                        join b in dbcontext.imagemasters on a.ImageId equals b.ImageID
                                        where b.BatchID == BatchID
                                        select new { a.ImageId, a.CreatedBy }).ToList();
                        //FinishedRecord = dbcontext.key1.Where(x => x.CreatedBy == LoggedUsers.ID && totalImage.Any(z => x.ImageId == z.ImageID)).Count();
                        FinishedRecord = key2list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID) && x.CreatedBy == Constance.GC_USERID).Count();
                        var key1ProcessedCount = key2list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID)).Count();

                        RemainingRecord = Totalrecord - key1ProcessedCount;
                    }
                    else if (BatchType == 3)
                    {
                        //var key2list = dbcontext.keyqc_hedis.Select(x => x).ToList();
                        var key2list = (from a in dbcontext.keyqc_hedis
                                        join b in dbcontext.imagemasters on a.ImageId equals b.ImageID
                                        where b.BatchID == BatchID
                                        select new { a.ImageId, a.CreatedBy }).ToList();
                        //FinishedRecord = dbcontext.key1.Where(x => x.CreatedBy == LoggedUsers.ID && totalImage.Any(z => x.ImageId == z.ImageID)).Count();
                        FinishedRecord = key2list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID) && x.CreatedBy == Constance.GC_USERID).Count();
                        var key1ProcessedCount = key2list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID)).Count();

                        RemainingRecord = Totalrecord - key1ProcessedCount;
                    }

                    else if (BatchType == 5)
                    {
                        // var key1list = dbcontext.key1_hedis.Select(x => x).ToList();
                        var key1list = (from a in dbcontext.key2_pediatric
                                        join b in dbcontext.imagemasters on a.ImageId equals b.ImageID
                                        where b.BatchID == BatchID
                                        select new { a.ImageId, a.CreatedBy }).ToList();
                        FinishedRecord = key1list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID) && x.CreatedBy == Constance.GC_USERID).Count();
                        var key1ProcessedCount = key1list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID)).Count();
                        RemainingRecord = Totalrecord - key1ProcessedCount;
                    }

                    else if (BatchType == 4)
                    {
                       // var key1list = dbcontext.key2_hra_v1.Select(x => x).ToList();
                        var key2list = (from a in dbcontext.key2_hra_v1
                                        join b in dbcontext.imagemasters on a.ImageId equals b.ImageID
                                        where b.BatchID == BatchID
                                        select new { a.ImageId, a.userid  }).ToList();
                        FinishedRecord = key2list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID) && x.userid  == Constance.GC_USERID).Count();
                        var key1ProcessedCount = key2list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID)).Count();
                        RemainingRecord = Totalrecord - key1ProcessedCount;
                    }
                }
                if (process.ToUpper() == "COMPAREQC" || process.ToUpper() == "KEYQC")
                {
                    if (BatchType == 0 || BatchType == 1)
                    {
                        //var compareqclist = dbcontext.compareqc_hra.Select(x => x).ToList();
                        var compareqclist = (from a in dbcontext.compareqc_hra
                                        join b in dbcontext.imagemasters on a.ImageId equals b.ImageID
                                        where b.BatchID == BatchID
                                        select new { a.ImageId, a.CreatedBy }).ToList();
                        //FinishedRecord = dbcontext.key1.Where(x => x.CreatedBy == LoggedUsers.ID && totalImage.Any(z => x.ImageId == z.ImageID)).Count();
                        FinishedRecord = compareqclist.Where(x => totalImage.Any(z => x.ImageId == z.ImageID) && x.CreatedBy == Constance.GC_USERID).Count();
                        var key1ProcessedCount = compareqclist.Where(x => totalImage.Any(z => x.ImageId == z.ImageID)).Count();

                        RemainingRecord = Totalrecord - key1ProcessedCount;
                    }
                    else if (BatchType == 2)
                    {
                      //  var compareqclist = dbcontext.compareqcs.Select(x => x).ToList();
                        var compareqclist = (from a in dbcontext.compareqcs
                                             join b in dbcontext.imagemasters on a.ImageId equals b.ImageID
                                             where b.BatchID == BatchID
                                             select new { a.ImageId, a.CreatedBy }).ToList();
                        //FinishedRecord = dbcontext.key1.Where(x => x.CreatedBy == LoggedUsers.ID && totalImage.Any(z => x.ImageId == z.ImageID)).Count();
                        FinishedRecord = compareqclist.Where(x => totalImage.Any(z => x.ImageId == z.ImageID) && x.CreatedBy == Constance.GC_USERID).Count();
                        var key1ProcessedCount = compareqclist.Where(x => totalImage.Any(z => x.ImageId == z.ImageID)).Count();

                        RemainingRecord = Totalrecord - key1ProcessedCount;
                    }
                    else if (BatchType == 5)
                    {
                        // var key1list = dbcontext.key1_hedis.Select(x => x).ToList();
                        var key1list = (from a in dbcontext.compareqc_pediatric
                                        join b in dbcontext.imagemasters on a.ImageId equals b.ImageID
                                        where b.BatchID == BatchID
                                        select new { a.ImageId, a.CreatedBy }).ToList();
                        FinishedRecord = key1list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID) && x.CreatedBy == Constance.GC_USERID).Count();
                        var key1ProcessedCount = key1list.Where(x => totalImage.Any(z => x.ImageId == z.ImageID)).Count();
                        RemainingRecord = Totalrecord - key1ProcessedCount;
                    }
                    else if (BatchType == 4)
                    {
                     //   var compareqclist = dbcontext.compareqcs.Select(x => x).ToList();
                        var compareqclist = (from a in dbcontext.compareqcs
                                             join b in dbcontext.imagemasters on a.ImageId equals b.ImageID
                                             where b.BatchID == BatchID
                                             select new { a.ImageId, a.CreatedBy }).ToList();
                        //FinishedRecord = dbcontext.key1.Where(x => x.CreatedBy == LoggedUsers.ID && totalImage.Any(z => x.ImageId == z.ImageID)).Count();
                        FinishedRecord = compareqclist.Where(x => totalImage.Any(z => x.ImageId == z.ImageID) && x.CreatedBy == Constance.GC_USERID).Count();
                        var key1ProcessedCount = compareqclist.Where(x => totalImage.Any(z => x.ImageId == z.ImageID)).Count();

                        RemainingRecord = Totalrecord - key1ProcessedCount;
                    }
                }
            }
        }

        public void ImageReset(string Process, long ImageID)
        {
            imagemaster Img = new imagemaster();
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                if (Process.ToUpper() == "KEY1")
                {
                    Img = dbcontext.imagemasters.Where(x => x.Key1 == 1 && x.ImageID == ImageID).OrderBy(x => x.ImageID).FirstOrDefault();
                    if (Img != null)
                    {
                        Img.Key1 = 0;
                        Img.Store();
                    }
                }
                if (Process.ToUpper() == "KEY2")
                {
                    Img = dbcontext.imagemasters.Where(x => x.Key2 == 1 && x.ImageID == ImageID).OrderBy(x => x.ImageID).FirstOrDefault();
                    if (Img != null)
                    {
                        Img.Key2 = 0;
                        Img.Store();
                    }
                }
                if (Process.ToUpper() == "COMPAREQC")
                {
                    Img = dbcontext.imagemasters.Where(x => x.CompareQC == 1 && x.ImageID == ImageID).OrderBy(x => x.ImageID).FirstOrDefault();
                    if (Img != null)
                    {
                        Img.CompareQC = 0;
                        Img.Store();
                    }
                }
                if (Process.ToUpper() == "KEYQC")
                {
                    Img = dbcontext.imagemasters.Where(x => x.KeyQC == 1 && x.ImageID == ImageID).OrderBy(x => x.ImageID).FirstOrDefault();
                    if (Img != null)
                    {
                        Img.KeyQC = 0;
                        Img.Store();
                    }
                }
            }
        }

        //public List<BatchExport> getExportImageList(int BatchID, string process)
        //{
        //    List<imagemaster> ImageList = new List<imagemaster>();
        //    List<BatchExport> ExportList = new List<BatchExport>();

        //    List<BatchExport> BatchList = new List<BatchExport>();
        //    using (ProjectDBEntity dbcontext = new ProjectDBEntity())
        //    {
        //        //using (globaldbEntity dbglobalcontext = new globaldbEntity())
        //        //{
        //            if (process.ToUpper() == "KEY1")
        //            {
        //                ExportList = (from batchMaster in dbcontext.batchmasters
        //                              join ImageMaster in dbcontext.imagemasters on batchMaster.ID equals ImageMaster.BatchID
        //                              join Key1 in dbcontext.key1 on ImageMaster.ImageID equals Key1.ImageId
        //                              //join Login in dbglobalcontext.logins on Key1.CreatedBy equals Login.ID
        //                              where batchMaster.ID == BatchID
        //                              select new BatchExport
        //                              {
        //                                  SNO = 0,
        //                                  IMAGE_NAME = Key1.Image_Number,
        //                                  MEMBER_ID = Key1.MemberId,
        //                                  BAR_CODE = Key1.Barcode,
        //                                  FIRSTNAME = Key1.First_Name,
        //                                  LASTNAME = Key1.Last_Name,
        //                                  PHONE_CAPTURE = Key1.Phone_No,
        //                                  ADDRESS_OVERRIDE = "0",
        //                                  ADDRESS_1 = Key1.Address1,
        //                                  ADDRESS_2 = Key1.Address2,
        //                                  CITY = Key1.City,
        //                                  STATE = Key1.State,
        //                                  ZIP = Key1.Zip,
        //                                  DOB = string.Format("{0}{1}{2}", Key1.DOByy, Key1.DOBmm, Key1.DOBdd),
        //                                  DOS = string.Format("{0}{1}{2}", Key1.DOSyy, Key1.DOSmm, Key1.DOSdd),
        //                                  PROVIDER_SIGNATURE = Key1.ProviderSignature,
        //                                  MOT_OPTIN = Key1.MotOptin,
        //                                  COMP_EXAM1 = Key1.HbA1c,
        //                                  COMP_EXAM2 = Key1.LDL_C,
        //                                  COMP_EXAM3 = Key1.Microalbumin,
        //                                  MERCH_CARD_15 = "",
        //                                  FORM_SCAN = Key1.FormScan,
        //                                  INTERACTION_DATE_TIME = "",
        //                                  //USER_NAME = Login.Name
        //                              }).ToList();
        //            }

        //            if (process.ToUpper() == "KEY2")
        //            {
        //                ExportList = (from batchMaster in dbcontext.batchmasters
        //                              join ImageMaster in dbcontext.imagemasters on batchMaster.ID equals ImageMaster.BatchID
        //                              join Key2 in dbcontext.key2 on ImageMaster.ImageID equals Key2.ImageId
        //                              //join Login in dbglobalcontext.logins on Key2.CreatedBy equals Login.ID
        //                              where batchMaster.ID == BatchID
        //                              select new BatchExport
        //                              {
        //                                  SNO = 0,
        //                                  IMAGE_NAME = Key2.Image_Number,
        //                                  MEMBER_ID = Key2.MemberId,
        //                                  BAR_CODE = Key2.Barcode,
        //                                  FIRSTNAME = Key2.First_Name,
        //                                  LASTNAME = Key2.Last_Name,
        //                                  PHONE_CAPTURE = Key2.Phone_No,
        //                                  ADDRESS_OVERRIDE = "0",
        //                                  ADDRESS_1 = Key2.Address1,
        //                                  ADDRESS_2 = Key2.Address2,
        //                                  CITY = Key2.City,
        //                                  STATE = Key2.State,
        //                                  ZIP = Key2.Zip,
        //                                  DOB = string.Format("{0}{1}{2}", Key2.DOByy, Key2.DOBmm, Key2.DOBdd),
        //                                  DOS = string.Format("{0}{1}{2}", Key2.DOSyy, Key2.DOSmm, Key2.DOSdd),
        //                                  PROVIDER_SIGNATURE = Key2.ProviderSignature,
        //                                  MOT_OPTIN = Key2.MotOptin,
        //                                  COMP_EXAM1 = Key2.HbA1c,
        //                                  COMP_EXAM2 = Key2.LDL_C,
        //                                  COMP_EXAM3 = Key2.Microalbumin,
        //                                  MERCH_CARD_15 = "",
        //                                  FORM_SCAN = Key2.FormScan,
        //                                  INTERACTION_DATE_TIME = "",
        //                                  //USER_NAME = Login.Name
        //                              }).ToList();
        //            }

        //            if (process.ToUpper() == "COMPAREQC")
        //            {
        //                ExportList = (from batchMaster in dbcontext.batchmasters
        //                              join ImageMaster in dbcontext.imagemasters on batchMaster.ID equals ImageMaster.BatchID
        //                              join Compareqc in dbcontext.compareqcs on ImageMaster.ImageID equals Compareqc.ImageId
        //                              //join Login in dbglobalcontext.logins on Compareqc.CreatedBy equals Login.ID
        //                              where batchMaster.ID == BatchID
        //                              select new BatchExport
        //                              {
        //                                  SNO = 0,
        //                                  IMAGE_NAME = Compareqc.Image_Number,
        //                                  MEMBER_ID = Compareqc.MemberId,
        //                                  BAR_CODE = Compareqc.Barcode,
        //                                  FIRSTNAME = Compareqc.First_Name,
        //                                  LASTNAME = Compareqc.Last_Name,
        //                                  PHONE_CAPTURE = Compareqc.Phone_No,
        //                                  ADDRESS_OVERRIDE = "0",
        //                                  ADDRESS_1 = Compareqc.Address1,
        //                                  ADDRESS_2 = Compareqc.Address2,
        //                                  CITY = Compareqc.City,
        //                                  STATE = Compareqc.State,
        //                                  ZIP = Compareqc.Zip,
        //                                  DOB = string.Format("{0}{1}{2}", Compareqc.DOByy, Compareqc.DOBmm, Compareqc.DOBdd),
        //                                  DOS = string.Format("{0}{1}{2}", Compareqc.DOSyy, Compareqc.DOSmm, Compareqc.DOSdd),
        //                                  PROVIDER_SIGNATURE = Compareqc.ProviderSignature,
        //                                  MOT_OPTIN = Compareqc.MotOptin,
        //                                  COMP_EXAM1 = Compareqc.HbA1c,
        //                                  COMP_EXAM2 = Compareqc.LDL_C,
        //                                  COMP_EXAM3 = Compareqc.Microalbumin,
        //                                  MERCH_CARD_15 = "",
        //                                  FORM_SCAN = Compareqc.FormScan,
        //                                  INTERACTION_DATE_TIME = "",
        //                                  //USER_NAME = Login.Name
        //                              }).ToList();
        //            }
        //        //}
        //    }

        //    //ImageIDList = (from Img in ImageList where Img.BatchID == BatchID orderby Img.ImageID select new { Img.ImageID }).ToList();
        //    return ExportList;
        //}

        public List<Export> BatchExport(int BatchID, string Process)
        {
            try
            {   
                List<Export> BatchExport = new List<Export>();
                using (ProjectDBEntity dbcontext = new ProjectDBEntity())
                {
                    using (var Export = new ProjectDBEntity())
                    {
                        //Execute stored procedure as a function
                        BatchExport = Export.Export(BatchID, Process).ToList();
                    }
                }
                return BatchExport;
            }
            catch (Exception ex)
            {
                return new List<Export>();
            }
        }

        public List<Export_HRA> BatchExport_HRA(int BatchID, string Process)
        {
            try
            {
                List<Export_HRA> BatchExport = new List<Export_HRA>();
                using (ProjectDBEntity dbcontext = new ProjectDBEntity())
                {
                    using (var Export = new ProjectDBEntity())
                    {
                        //Execute stored procedure as a function
                        BatchExport = Export.Export_HRA(BatchID, Process).ToList();
                    }
                }
                return BatchExport;
            }
            catch (Exception ex)
            {
                return new List<Export_HRA>();
            }
        }
        public List<Export_HRA_MailType> BatchExport_HRA_MailType(int BatchID, string Process)
        {
            try
            {
                List<Export_HRA_MailType> BatchExport = new List<Export_HRA_MailType>();
                using (ProjectDBEntity dbcontext = new ProjectDBEntity())
                {
                    using (var Export = new ProjectDBEntity())
                    {
                        //Execute stored procedure as a function
                       BatchExport = Export.Export_HRA_MailType(BatchID, Process).ToList();
                    }
                }
                return BatchExport;
            }
            catch (Exception ex)
            {
                return new List<Export_HRA_MailType>();
            }
        }

        public List<Export_Hedis> BatchExport_HEDIS(int BatchID, string Process)
        {
            try
            {
                List<Export_Hedis> BatchExport = new List<Export_Hedis>();
                using (ProjectDBEntity dbcontext = new ProjectDBEntity())
                {
                    using (var Export = new ProjectDBEntity())
                    {
                        //Execute stored procedure as a function
                        BatchExport = Export.Export_Hedis(BatchID, Process).ToList();
                    }
                }
                return BatchExport;
            }
            catch (Exception ex)
            {
                return new List<Export_Hedis>();
            }
        }
        public List<Export_HRA_V1> BatchExport_Hra_v1(int BatchID, string Process)
        {
            try
            {
                List<Export_HRA_V1> BatchExport = new List<Export_HRA_V1>();
                using (ProjectDBEntity dbcontext = new ProjectDBEntity())
                {
                    using (var Export = new ProjectDBEntity())
                    {
                        //Execute stored procedure as a function
                        BatchExport = Export.Export_HRA_V1(BatchID, Process).ToList();
                    }
                }
                return BatchExport;
            }
            catch (Exception ex)
            {
                return new List<Export_HRA_V1>();
            }
        }
        public List<Export_HRA_V1_MailType> BatchExport_Hra_v1_MailType(int BatchID, string Process)
        {
            try
            {
                List<Export_HRA_V1_MailType> BatchExport = new List<Export_HRA_V1_MailType>();
                using (ProjectDBEntity dbcontext = new ProjectDBEntity())
                {
                    using (var Export = new ProjectDBEntity())
                    {
                        //Execute stored procedure as a function
                        BatchExport = Export.Export_HRA_V1_MailType(BatchID, Process).ToList();
                    }
                }
                return BatchExport;
            }
            catch (Exception ex)
            {
                return new List<Export_HRA_V1_MailType>();
            }
        }
      

        public List<Export_pediotric> BatchExport_pediatric(int BatchID, string Process)
        {
            try
            {
                List<Export_pediotric> BatchExport = new List<Export_pediotric>();
                using (ProjectDBEntity dbcontext = new ProjectDBEntity())
                {
                    using (var Export = new ProjectDBEntity())
                    {
                        //Execute stored procedure as a function
                        BatchExport = Export.Export_pediatric(BatchID, Process).ToList();
                    }
                }
                return BatchExport;
            }
            catch (Exception ex)
            {
                return new List<Export_pediotric>();
            }
        }

        public List<batchmaster> BatchtoReset(string process)
        {
            List<batchmaster> BatchList = new List<batchmaster>();

            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                if (process == Constance.GC_PROCESS_KEY1)
                {
                    BatchList = (from BatchMaster in dbcontext.batchmasters
                                 join ImageMaster in dbcontext.imagemasters on BatchMaster.ID equals ImageMaster.BatchID
                                 where ImageMaster.Key1 == 1
                                 select (BatchMaster)).Distinct().ToList();
                }
                else if (process == Constance.GC_PROCESS_KEY2)
                {
                    BatchList = (from BatchMaster in dbcontext.batchmasters
                                 join ImageMaster in dbcontext.imagemasters on BatchMaster.ID equals ImageMaster.BatchID
                                 where ImageMaster.Key2 == 1
                                 select (BatchMaster)).ToList();
                }
                else if (process == Constance.GC_PROCESS_COMAPREQC)
                {
                    BatchList = (from BatchMaster in dbcontext.batchmasters
                                 join ImageMaster in dbcontext.imagemasters on BatchMaster.ID equals ImageMaster.BatchID
                                 where ImageMaster.CompareQC == 1
                                 select (BatchMaster)).ToList();
                }
                else if (process == Constance.GC_PROCESS_KEYQC)
                {
                    BatchList = (from BatchMaster in dbcontext.batchmasters
                                 join ImageMaster in dbcontext.imagemasters on BatchMaster.ID equals ImageMaster.BatchID
                                 where ImageMaster.KeyQC == 1
                                 select (BatchMaster)).ToList();
                }
            }
            return BatchList;
        }

        public List<ResetBatchImages> ImagestoReset(int BatchID, string Process)
        {
            List<ResetBatchImages> ImageList = new List<ResetBatchImages>();

            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                if (Process == Constance.GC_PROCESS_KEY1)
                {
                    //ImageList = dbcontext.imagemasters.Where(x => x.Key1 == 1 && x.BatchID == BatchID).ToList();
                    ImageList = (from ImageMaster in dbcontext.imagemasters
                                 where ImageMaster.Key1 == 1 && ImageMaster.BatchID == BatchID
                                 select new ResetBatchImages
                                 {
                                     IMAGEID = (int)ImageMaster.ImageID,
                                     IMAGENAME = ImageMaster.ImagePath
                                 }).ToList();
                    ImageList.ForEach(x =>
                    {
                        x.IMAGENAME = File.Exists(x.IMAGENAME) ? Path.GetFileName(x.IMAGENAME) : "";
                    });
                }
                else if (Process == Constance.GC_PROCESS_KEY2)
                {
                    ImageList = (from ImageMaster in dbcontext.imagemasters
                                 where ImageMaster.Key2 == 1 && ImageMaster.BatchID == BatchID
                                 select new ResetBatchImages
                                 {
                                     IMAGEID = (int)ImageMaster.ImageID,
                                     IMAGENAME = ImageMaster.ImagePath
                                 }).ToList();
                    ImageList.ForEach(x =>
                    {
                        x.IMAGENAME = File.Exists(x.IMAGENAME) ? Path.GetFileName(x.IMAGENAME) : "";
                    });
                }
                else if (Process == Constance.GC_PROCESS_COMAPREQC)
                {
                    ImageList = (from ImageMaster in dbcontext.imagemasters
                                 where ImageMaster.CompareQC == 1 && ImageMaster.BatchID == BatchID
                                 select new ResetBatchImages
                                 {
                                     IMAGEID = (int)ImageMaster.ImageID,
                                     IMAGENAME = ImageMaster.ImagePath
                                 }).ToList();
                    ImageList.ForEach(x =>
                    {
                        x.IMAGENAME = File.Exists(x.IMAGENAME) ? Path.GetFileName(x.IMAGENAME) : "";
                    });
                }
                else if (Process == Constance.GC_PROCESS_KEYQC)
                {
                    ImageList = (from ImageMaster in dbcontext.imagemasters
                                 where ImageMaster.KeyQC == 1 && ImageMaster.BatchID == BatchID
                                 select new ResetBatchImages
                                 {
                                     IMAGEID = (int)ImageMaster.ImageID,
                                     IMAGENAME = ImageMaster.ImagePath
                                 }).ToList();
                    ImageList.ForEach(x =>
                    {
                        x.IMAGENAME = File.Exists(x.IMAGENAME) ? Path.GetFileName(x.IMAGENAME) : "";
                    });
                }
            }
            return ImageList;
        }

        public List<UserWiseReport> UserwiseReport(DateTime DateFrom, DateTime DateTo)
        {
            try
            {
                List<UserWiseReport> UserwiseRpt = new List<UserWiseReport>();
                using (ProjectDBEntity dbcontext = new ProjectDBEntity())
                {
                    using (var UserReport = new ProjectDBEntity())
                    {
                        //Execute stored procedure as a function
                        UserwiseRpt = UserReport.UserWiseReport(DateFrom, DateTo).ToList();
                    }
                }
                return UserwiseRpt;
            }
            catch (Exception ex)
            {
                return new List<UserWiseReport>();
            }
        }

        public List<IndividualUserReport> UserwiseReport_Ind(DateTime DateFrom, DateTime DateTo, int UserID)
        {
            try
            {
                List<IndividualUserReport> UserwiseRpt = new List<IndividualUserReport>();
                using (ProjectDBEntity dbcontext = new ProjectDBEntity())
                {
                    using (var UserReport = new ProjectDBEntity())
                    {
                        //Execute stored procedure as a function
                        UserwiseRpt = UserReport.UserWiseReport_individual(DateFrom, DateTo, UserID).ToList();
                    }
                }
                return UserwiseRpt;
            }
            catch (Exception ex)
            {
                return new List<IndividualUserReport>();
            }
        }

        #endregion Help Methods
    }
}




