﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AutoMapper;
using DataAccessLayer.ProjectDB;
using App.Base;
using DataAccessLayer.GlobalDB;
using System.Reflection;

namespace DataAccessLayer.ProjectDB
{
    public partial class compareqc_pediatric
    {
        
        #region Properties & Constructor

        public bool IstoBeDeleted { get; set; }
        public bool HasError { get; set; }
        public string UserName { get; set; }

        public compareqc_pediatric()
        {
        }

        public compareqc_pediatric(int compareqc_PEDIATRICID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                compareqc_pediatric compareqc_pediatric_k1 = dbcontext.compareqc_pediatric.FirstOrDefault(x => x.Compareqc_PEDIATRICID == compareqc_PEDIATRICID);

                Mapper.Map(compareqc_pediatric_k1, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        public void Store()
        {
            if (IstoBeDeleted)
            {
                DeleteImplementation();
                return;
            }
            Validate();

            if (HasError)
            {
                return;
            }

            Type type = GetType();
            AssignProperty(type, "CreatedBy", string.Format("{0}", Constance.GC_USERID));
            AssignProperty(type, "CreatedOn", DateTime.Now);

            StoreComposite();
        }

        private void Validate()
        { }

        private void StoreComposite()
        {
            if (Compareqc_PEDIATRICID == 0)
            {
                AddImplementation();
            }
            else
            {
                UpdateImplementation();
            }
        }

        private void AddImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                dbcontext.compareqc_pediatric.AddObject(this);
                dbcontext.SaveChanges();
            }
        }

        private void UpdateImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                compareqc_pediatric UpdateObject = dbcontext.compareqc_pediatric.FirstOrDefault(x => x.Compareqc_PEDIATRICID == Compareqc_PEDIATRICID);
                if (UpdateObject == null)
                {
                    HasError = true;
                    return;
                }
                UpdateObject.ImageId = ImageId;
                UpdateObject.Image_Folder = Image_Folder;
                UpdateObject.Image_Number = Image_Number;
                UpdateObject.BARCODE = BARCODE;
                UpdateObject.Q1 = Q1;
                UpdateObject.Q2 = Q2;
                UpdateObject.Q3 = Q3;
                UpdateObject.Q4 = Q4;
                UpdateObject.Q5 = Q5;
                UpdateObject.Q6 = Q6;
                UpdateObject.Q7 = Q7;
                UpdateObject.Q8 = Q8;
                UpdateObject.Q9 = Q9;
                UpdateObject.Q10 = Q10;
                UpdateObject.Q11 = Q11;
                UpdateObject.Q12 = Q12;
                UpdateObject.Q13 = Q13;
                UpdateObject.Q14 = Q14;
                UpdateObject.Q15 = Q15;
                UpdateObject.Q16 = Q16;
                UpdateObject.Q17 = Q17;
                UpdateObject.Q18 = Q18;
                UpdateObject.Q19 =Q19;
                UpdateObject.Q20 = Q20;
                UpdateObject.Q21 = Q21;
                UpdateObject.Q22 = Q22;
                UpdateObject.Q23 = Q23;
                UpdateObject.Q24 = Q24;
                UpdateObject.Q25 = Q25;
                UpdateObject.Q26 = Q26;
                UpdateObject.Q27 = Q27;
                UpdateObject.Q28 = Q28;
                UpdateObject.Q29 = Q29;
                UpdateObject.Q30 = Q30;
                UpdateObject.Q31 = Q31;
                UpdateObject.Q32 = Q32;
                UpdateObject.Q33 = Q33;
                UpdateObject.Q34 = Q34;
                UpdateObject.CreatedBy = CreatedBy;
                UpdateObject.CreatedOn = CreatedOn;
                UpdateObject.KeyStroke = KeyStroke;
                dbcontext.SaveChanges();
            }
        }

        private void DeleteImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                compareqc_pediatric DeleteObject = dbcontext.compareqc_pediatric.FirstOrDefault(x => x.Compareqc_PEDIATRICID == Compareqc_PEDIATRICID);
                if (DeleteObject == null)
                {
                    HasError = true;
                    return;
                }
                dbcontext.compareqc_pediatric.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        private void AssignProperty(Type type, string PropertyName, object value)
        {
            PropertyInfo property = type.GetProperties().FirstOrDefault(x => x.Name.Equals(PropertyName, StringComparison.OrdinalIgnoreCase));
            if (property == null)
            {
                return;
            }

            switch (property.Name)
            {
                case "CreatedBy":
                    if (property.PropertyType == typeof(string))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        //login user = LoggedInUser.Invoke();
                        property.SetValue(this, Constance.GC_USERID, null);
                    }
                    break;
                case "CreatedDateTime":
                    if (property.PropertyType == typeof(DateTime))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        property.SetValue(this, value, null);
                    }
                    break;
                default:
                    property.SetValue(this, value, null);
                    break;
            }
        }

        #endregion

        #region Help Methods

        public List<compareqc_pediatric> List()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                return dbcontext.compareqc_pediatric.ToList();
            }
        }

        public compareqc_pediatric isImageIDExists(long ImageID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                compareqc_pediatric compareqc_pedia = dbcontext.compareqc_pediatric.FirstOrDefault(x => x.ImageId == ImageID);
                return compareqc_pedia;
            }
        }

        public compareqc_pediatric compareqcDatas(int ImageID)
        {
            compareqc_pediatric compareqc_HRA = new compareqc_pediatric();
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                compareqc_HRA = dbcontext.compareqc_pediatric.FirstOrDefault(x => x.ImageId == ImageID);
            }
            if (compareqc_HRA != null)
            {
            login userData = new login((int)compareqc_HRA.CreatedBy);
            compareqc_HRA.UserName = userData.Name;
            }
            return compareqc_HRA;
        }
        #endregion

       
    }
}
