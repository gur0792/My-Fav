﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;

namespace DataAccessLayer.ProjectDB
{
    public partial class fullqc : BaseObject
    {
        #region Properties & Constructor

        public fullqc()
        {
        }

        public fullqc(int ImageID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                fullqc Fullqc = dbcontext.fullqcs.FirstOrDefault(x => x.ImageID == ImageID);
                Mapper.Map(Fullqc, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        protected override void Validate()
        {
            if (string.IsNullOrEmpty(Names))
            {
                AddMessage("Name is not empty or null");
            }
        }

        protected override void StoreComposite()
        {
            if (FullQCID == 0)
            {
                AddImplementation();
            }
            else
            {
                UpdateImplementation();
            }
        }

        protected override void AddImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                dbcontext.fullqcs.AddObject(this);
                dbcontext.SaveChanges();
            }
        }

        protected override void UpdateImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                fullqc UpdateObject = dbcontext.fullqcs.FirstOrDefault(x => x.FullQCID == FullQCID);
                if (UpdateObject == null)
                {
                    AddMessage("ID Does not exist.");
                    return;
                }
                UpdateObject.CreatedBy = CreatedBy;
                UpdateObject.CreatedDateTime = CreatedDateTime;
                UpdateObject.EmailAddress = EmailAddress;
                UpdateObject.GradYear = GradYear;
                UpdateObject.Illegible = Illegible;
                UpdateObject.ImageFolder = ImageFolder;
                UpdateObject.ImageID = ImageID;
                UpdateObject.KeyStroke = KeyStroke;
                UpdateObject.LastName = LastName;
                UpdateObject.Names = Names;
                UpdateObject.School = School;
                UpdateObject.SNo = SNo;
                dbcontext.SaveChanges();
            }
        }

        protected override void DeleteImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                fullqc DeleteObject = dbcontext.fullqcs.FirstOrDefault(x => x.FullQCID == FullQCID);
                if (DeleteObject == null)
                {
                    AddMessage("ID Does not exist.");
                    return;
                }
                dbcontext.fullqcs.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        #endregion CRUD Operation

        #region Help Methods

        public List<fullqc> List()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                return dbcontext.fullqcs.ToList();
            }
        }

        #endregion Help Methods
    }
}


