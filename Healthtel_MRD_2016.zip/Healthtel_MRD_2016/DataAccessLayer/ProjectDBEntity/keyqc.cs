﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;

namespace DataAccessLayer.ProjectDB
{
    public partial class keyqc : BaseObject
    {
        #region Properties & Constructor

        public keyqc()
        {
        }

        public keyqc(int ImageID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                keyqc KeyQC = dbcontext.keyqcs.FirstOrDefault(x => x.ImageID == ImageID);
                Mapper.Map(KeyQC, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        protected override void Validate()
        {
            if (string.IsNullOrEmpty(Names))
            {
                AddMessage("Name is not empty or null");
            }
        }

        protected override void StoreComposite()
        {
            if (KeyQCID == 0)
            {
                AddImplementation();
            }
            else
            {
                UpdateImplementation();
            }
        }

        protected override void AddImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                dbcontext.keyqcs.AddObject(this);
                dbcontext.SaveChanges();
            }
        }

        protected override void UpdateImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                keyqc UpdateObject = dbcontext.keyqcs.FirstOrDefault(x => x.KeyQCID == KeyQCID);
                if (UpdateObject == null)
                {
                    AddMessage("ID Does not exist.");
                    return;
                }
                UpdateObject.CreatedBy = CreatedBy;
                UpdateObject.CreatedDateTime = CreatedDateTime;
                UpdateObject.EmailAddress = EmailAddress;
                UpdateObject.GradYear = GradYear;
                UpdateObject.Illegible = Illegible;
                UpdateObject.ImageFolder = ImageFolder;
                UpdateObject.ImageID = ImageID;
                UpdateObject.KeyStroke = KeyStroke;
                UpdateObject.Names = Names;
                UpdateObject.School = School;
                UpdateObject.SNo = SNo;                
                dbcontext.SaveChanges();
            }
        }

        protected override void DeleteImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                keyqc DeleteObject = dbcontext.keyqcs.FirstOrDefault(x => x.KeyQCID == KeyQCID);
                if (DeleteObject == null)
                {
                    AddMessage("ID Does not exist.");
                    return;
                }
                dbcontext.keyqcs.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        #endregion CRUD Operation

        #region Help Methods

        public List<keyqc> List()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                return dbcontext.keyqcs.ToList();
            }
        }

        #endregion Help Methods
    }
}


