﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AutoMapper;
using DataAccessLayer.GlobalDB;
using System.Reflection;
using App.Base;

namespace DataAccessLayer.ProjectDB
{
    public partial class keyqc_hedis
    {
        #region Properties & Constructor

        public bool IstoBeDeleted { get; set; }
        public bool HasError { get; set; }
        public string UserName { get; set; }

        public keyqc_hedis()
        {
        }

        public keyqc_hedis(int keyqc_ID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                keyqc_hedis keyqc_HEDIS = dbcontext.keyqc_hedis.FirstOrDefault(x => x.Keyqc_ID == keyqc_ID);
                Mapper.Map(keyqc_HEDIS, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        public void Store()
        {
            if (IstoBeDeleted)
            {
                DeleteImplementation();
                return;
            }
            Validate();

            if (HasError)
            {
                return;
            }

            Type type = GetType();
            AssignProperty(type, "CreatedBy", string.Format("{0}", Constance.GC_USERID));
            AssignProperty(type, "CreatedOn", DateTime.Now);

            StoreComposite();
        }

        private void Validate()
        { }

        private void StoreComposite()
        {
            if (Keyqc_ID == 0)
            {
                AddImplementation();
            }
            else
            {
                UpdateImplementation();
            }
        }

        private void AddImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                dbcontext.keyqc_hedis.AddObject(this);
                dbcontext.SaveChanges();
            }
        }

        private void UpdateImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                keyqc_hedis UpdateObject = dbcontext.keyqc_hedis.FirstOrDefault(x => x.Keyqc_ID == Keyqc_ID);
                if (UpdateObject == null)
                {
                    HasError = true;
                    return;
                }
                UpdateObject.ImageId = ImageId;
                UpdateObject.Image_Folder = Image_Folder;
                UpdateObject.Image_Number = Image_Number;
                UpdateObject.Q1_1A_MM = Q1_1A_MM;
                UpdateObject.Q1_1A_DD = Q1_1A_DD;
                UpdateObject.Q1_1A_YY = Q1_1A_YY;
                UpdateObject.Q1_1B_MM = Q1_1B_MM;
                UpdateObject.Q1_1B_DD = Q1_1B_DD;
                UpdateObject.Q1_1B_YY = Q1_1B_YY;
                UpdateObject.Q1_2A_MM = Q1_2A_MM;
                UpdateObject.Q1_2A_DD = Q1_2A_DD;
                UpdateObject.Q1_2A_YY = Q1_2A_YY;
                UpdateObject.Q1_2B_MM = Q1_2B_MM;
                UpdateObject.Q1_2B_DD = Q1_2B_DD;
                UpdateObject.Q1_2B_YY = Q1_2B_YY;
                UpdateObject.Q1_3A_MM = Q1_3A_MM;
                UpdateObject.Q1_3A_DD = Q1_3A_DD;
                UpdateObject.Q1_3A_YY = Q1_3A_YY;
                UpdateObject.Q1_3B_MM = Q1_3B_MM;
                UpdateObject.Q1_3B_DD = Q1_3B_DD;
                UpdateObject.Q1_3B_YY = Q1_3B_YY;
                UpdateObject.Q1_4 = Q1_4;
                UpdateObject.Q1_5 = Q1_5;
                UpdateObject.Q2_1 = Q2_1;
                UpdateObject.Q2_2 = Q2_2;
                UpdateObject.Q2_3A_MM = Q2_3A_MM;
                UpdateObject.Q2_3A_DD = Q2_3A_DD;
                UpdateObject.Q2_3A_YY = Q2_3A_YY;
                UpdateObject.Q2_3B_MM = Q2_3B_MM;
                UpdateObject.Q2_3B_DD = Q2_3B_DD;
                UpdateObject.Q2_3B_YY = Q2_3B_YY;
                UpdateObject.Q3_1 = Q3_1;
                UpdateObject.Q3_2 = Q3_2;
                UpdateObject.Q3_3A_MM = Q3_3A_MM;
                UpdateObject.Q3_3A_DD = Q3_3A_DD;
                UpdateObject.Q3_3A_YY = Q3_3A_YY;
                UpdateObject.Q3_3B_MM = Q3_3B_MM;
                UpdateObject.Q3_3B_DD = Q3_3B_DD;
                UpdateObject.Q3_3B_YY = Q3_3B_YY;
                UpdateObject.Q3_4_MM = Q3_4_MM;
                UpdateObject.Q3_4_DD = Q3_4_DD;
                UpdateObject.Q3_4_YY = Q3_4_YY;
                UpdateObject.Signature = Signature;
                UpdateObject.SIGNATUREDATE_MM = SIGNATUREDATE_MM;
                UpdateObject.SIGNATUREDATE_DD = SIGNATUREDATE_DD;
                UpdateObject.SIGNATUREDATE_YY = SIGNATUREDATE_YY; 
                UpdateObject.CreatedBy = CreatedBy;
                UpdateObject.CreatedOn = CreatedOn;
                UpdateObject.KeyStroke = KeyStroke;
                UpdateObject.Comments = Comments;
                dbcontext.SaveChanges();
            }
        }

        private void DeleteImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                keyqc_hedis DeleteObject = dbcontext.keyqc_hedis.FirstOrDefault(x => x.Keyqc_ID == Keyqc_ID);
                if (DeleteObject == null)
                {
                    HasError = true;
                    return;
                }
                dbcontext.keyqc_hedis.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        private void AssignProperty(Type type, string PropertyName, object value)
        {
            PropertyInfo property = type.GetProperties().FirstOrDefault(x => x.Name.Equals(PropertyName, StringComparison.OrdinalIgnoreCase));
            if (property == null)
            {
                return;
            }

            switch (property.Name)
            {
                case "CreatedBy":
                    if (property.PropertyType == typeof(string))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        //login user = LoggedInUser.Invoke();
                        property.SetValue(this, Constance.GC_USERID, null);
                    }
                    break;
                case "CreatedDateTime":
                    if (property.PropertyType == typeof(DateTime))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        property.SetValue(this, value, null);
                    }
                    break;
                default:
                    property.SetValue(this, value, null);
                    break;
            }
        }

        #endregion

        #region Help Methods

        public List<keyqc_hedis> List()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                return dbcontext.keyqc_hedis.ToList();
            }
        }

        public keyqc_hedis isImageIDExists(long ImageID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                keyqc_hedis keyqc_HEDIS = dbcontext.keyqc_hedis.FirstOrDefault(x => x.ImageId == ImageID);
                return keyqc_HEDIS;
            }
        }



        public keyqc_hedis KeyQCDatas(int ImageID)
        {
            keyqc_hedis keyqc_HEDIS = new keyqc_hedis();
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                keyqc_HEDIS = dbcontext.keyqc_hedis.FirstOrDefault(x => x.ImageId == ImageID);
            }
            if (keyqc_HEDIS != null)
            {
                login userData = new login((int)keyqc_HEDIS.CreatedBy);
                keyqc_HEDIS.UserName = userData.Name;
            }
            return keyqc_HEDIS;
        }

        #endregion
    }
}
