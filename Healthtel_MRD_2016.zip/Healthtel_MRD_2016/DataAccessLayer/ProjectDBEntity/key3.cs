﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;

namespace DataAccessLayer.ProjectDB
{
    public partial class key3 : BaseObject
    {
        #region Properties & Constructor

        public key3()
        {
        }

        public key3(int ImageID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                key3 Key3 = dbcontext.key3.FirstOrDefault(x => x.ImageID == ImageID);
                Mapper.Map(Key3, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        protected override void Validate()
        {
            if (string.IsNullOrEmpty(Names))
            {
                AddMessage("Name is not empty or null");
            }
        }

        protected override void StoreComposite()
        {
            if (Key3ID == 0)
            {
                AddImplementation();
            }
            else
            {
                UpdateImplementation();
            }
        }

        protected override void AddImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                dbcontext.key3.AddObject(this);
                dbcontext.SaveChanges();
            }
        }

        protected override void UpdateImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                key3 UpdateObject = dbcontext.key3.FirstOrDefault(x => x.Key3ID == Key3ID);
                if (UpdateObject == null)
                {
                    AddMessage("ID Does not exist.");
                    return;
                }
                UpdateObject.CreatedBy = CreatedBy;
                UpdateObject.CreatedDateTime = CreatedDateTime;
                UpdateObject.EmailAddress = EmailAddress;
                UpdateObject.GradYear = GradYear;
                UpdateObject.Illegible = Illegible;
                UpdateObject.ImageFolder = ImageFolder;
                UpdateObject.ImageID = ImageID;
                UpdateObject.KeyStroke = KeyStroke;
                UpdateObject.Names = Names;
                UpdateObject.School = School;
                UpdateObject.SNo = SNo;                
                dbcontext.SaveChanges();
            }
        }

        protected override void DeleteImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                key3 DeleteObject = dbcontext.key3.FirstOrDefault(x => x.Key3ID == Key3ID);
                if (DeleteObject == null)
                {
                    AddMessage("ID Does not exist.");
                    return;
                }
                dbcontext.key3.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        #endregion CRUD Operation

        #region Help Methods

        public List<key3> List()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                return dbcontext.key3.ToList();
            }
        }

        #endregion Help Methods
    }
}


