﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using DataAccessLayer.GlobalDB;
using System;
using System.Reflection;
using App.Base;

namespace DataAccessLayer.ProjectDB
{
    public partial class key1 //: BaseObject
    {
        #region Properties & Constructor

        public bool IstoBeDeleted { get; set; }
        public bool HasError { get; set; }
        public string UserName { get; set; }

        public key1()
        {
        }

        public key1(int Key1ID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                key1 Key1 = dbcontext.key1.FirstOrDefault(x => x.Key1ID == Key1ID);
                Mapper.Map(Key1, this);
            }
        }
        
        #endregion Properties & Constructor

        #region CRUD Operation

        public void Store()
        {
            if (IstoBeDeleted)
            {
                DeleteImplementation();
                return;
            }
            Validate();

            if (HasError)
            {
                return;
            }

            Type type = GetType();
            AssignProperty(type, "CreatedBy", string.Format("{0}", Constance.GC_USERID));
            AssignProperty(type, "CreatedOn", DateTime.Now);
            
            StoreComposite();
        }

        private void Validate()
        {
            //if (string.IsNullOrEmpty(Names))
            //{
            //    AddMessage("Name is not empty or null");
            //}
        }

        private void StoreComposite()
        {
            if (Key1ID == 0)
            {
                AddImplementation();
            }
            else
            {
                UpdateImplementation();
            }
        }

        private void AddImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                dbcontext.key1.AddObject(this);
                dbcontext.SaveChanges();
            }
        }

        private void UpdateImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                key1 UpdateObject = dbcontext.key1.FirstOrDefault(x => x.Key1ID == Key1ID);
                if (UpdateObject == null)
                {
                    HasError = true;
                    return;
                }
                UpdateObject.ImageId = ImageId;
                UpdateObject.Image_Folder = Image_Folder;
                UpdateObject.Image_Number = Image_Number;
                UpdateObject.First_Name = First_Name;
                UpdateObject.Last_Name = Last_Name;
                UpdateObject.Zip = Zip;
                UpdateObject.City = City;
                UpdateObject.State = State;
                UpdateObject.Address1 = Address1;
                UpdateObject.Address2 = Address2;
                UpdateObject.Phone_No = Phone_No;
                UpdateObject.MemberId = MemberId;
                UpdateObject.Barcode = Barcode;
                UpdateObject.DOSmm = DOSmm;
                UpdateObject.DOSdd = DOSdd;
                UpdateObject.DOSyy = DOSyy;
                UpdateObject.DOSmm = DOBmm;
                UpdateObject.DOBdd = DOBdd;
                UpdateObject.DOByy = DOByy;
                UpdateObject.ProviderSignature = ProviderSignature;
                UpdateObject.AddressUpdate = AddressUpdate;
                UpdateObject.MotOptin = MotOptin;
                UpdateObject.FormScan = FormScan;
                UpdateObject.HbA1c = HbA1c;
                UpdateObject.LDL_C = LDL_C;
                UpdateObject.Microalbumin = Microalbumin;
                UpdateObject.CreatedBy = CreatedBy;
                UpdateObject.CreatedOn = CreatedOn;
                UpdateObject.KeyStroke = KeyStroke;
                dbcontext.SaveChanges();
            }
        }

        private void DeleteImplementation()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                key1 DeleteObject = dbcontext.key1.FirstOrDefault(x => x.Key1ID == Key1ID);
                if (DeleteObject == null)
                {
                    HasError = true;
                    return;
                }
                dbcontext.key1.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        private void AssignProperty(Type type, string PropertyName, object value)
        {
            PropertyInfo property = type.GetProperties().FirstOrDefault(x => x.Name.Equals(PropertyName, StringComparison.OrdinalIgnoreCase));
            if (property == null)
            {
                return;
            }

            switch (property.Name)
            {
                case "CreatedBy":
                    if (property.PropertyType == typeof(string))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        //login user = LoggedInUser.Invoke();
                        property.SetValue(this, Constance.GC_USERID, null);
                    }
                    break;
                case "CreatedDateTime":
                    if (property.PropertyType == typeof(DateTime))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        property.SetValue(this, value, null);
                    }
                    break;
                default:
                    property.SetValue(this, value, null);
                    break;
            }
        }

        #endregion CRUD Operation

        #region Help Methods

        public List<key1> List()
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                return dbcontext.key1.ToList();
            }
        }

        public key1 isImageIDExists(long ImageID)
        {
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                key1 Key1 = dbcontext.key1.FirstOrDefault(x => x.ImageId == ImageID);
                return Key1;
            }            
        }

        public key1 Key1Datas(int ImageID)
        {
            key1 Key1 = new key1();
            using (ProjectDBEntity dbcontext = new ProjectDBEntity())
            {
                Key1 = dbcontext.key1.FirstOrDefault(x => x.ImageId == ImageID);
            }
            login userData = new login((int)Key1.CreatedBy);
            Key1.UserName = userData.Name;
            return Key1;
        }        

        #endregion Help Methods
    }
}

