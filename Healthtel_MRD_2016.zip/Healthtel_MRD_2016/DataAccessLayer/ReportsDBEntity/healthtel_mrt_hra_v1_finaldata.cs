﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AutoMapper;
using App.Base;
using System.Reflection;

namespace DataAccessLayer.ReportsDB
{
   public partial class healthtel_mrt_hra_v1_finaldata
    {
        #region Properties & Constructor

        public bool IstoBeDeleted { get; set; }
        public bool HasError { get; set; }

        public healthtel_mrt_hra_v1_finaldata()
        {
        }

        public healthtel_mrt_hra_v1_finaldata(int RecNo)
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                healthtel_mrt_hra_v1_finaldata Batchmaster = dbcontext.healthtel_mrt_hra_v1_finaldata.FirstOrDefault(x => x.recno == recno);
                Mapper.Map(Batchmaster, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        public void Store()
        {

            StoreComposite();
        }


        private void StoreComposite()
        {
            AddImplementation();
            //if (recno == 0)
            //{
            //    AddImplementation();
            //}
            //else
            //{
            //    UpdateImplementation();
            //}
        }
        private void AddImplementation()
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {

                dbcontext.healthtel_mrt_hra_v1_finaldata.AddObject(this);
                dbcontext.SaveChanges();
                //recno = this.recno; 



            }
        }

        private void UpdateImplementation()
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                healthtel_mrt_hra_v1_finaldata addObject = dbcontext.healthtel_mrt_hra_v1_finaldata.FirstOrDefault(x => x.recno == recno);
                if (addObject == null)
                {
                    return;
                }
                addObject.Respondent_ID = Respondent_ID;
                addObject.Q1_9 = Q1_9;
                addObject.Q1_1 = Q1_1;
                addObject.Q1_2 = Q1_2;
                addObject.Q1_3 = Q1_3;
                addObject.Q1_4 = Q1_4;
                addObject.Q1_5 = Q1_5;
                addObject.Q1_6 = Q1_6;
                addObject.Q1_7 = Q1_7;
                addObject.Q1_8 = Q1_8;
                addObject.Q3_1 = Q3_1;
                addObject.Q3_2 = Q3_2;
                addObject.Q3_3 = Q3_3;
                addObject.Q3_4 = Q3_4;
                addObject.Q3_5 = Q3_5;
                addObject.Q4_1 = Q4_1;
                addObject.Q4_2 = Q4_2;
                addObject.Q4_3 = Q4_3;
                addObject.Q2_1 = Q2_1;
                addObject.Q2_ttl = Q2_ttl;
                addObject.Q5_1 = Q5_1;
                addObject.Q5_ttl = Q5_ttl;
                addObject.Q6_1 = Q6_1;
                addObject.Q7_2 = Q7_2;
                addObject.Q7_1 = Q7_1;
                addObject.Q8_1 = Q8_1;
                addObject.Language = Language;
                addObject.Batch_Number = Batch_Number;
                addObject.Image_Number = Image_Number;
                addObject.BatchName = BatchName;
                addObject.importfileid = importfileid;
                addObject.batchid = batchid;
                dbcontext.SaveChanges();
            }
        }

        private void DeleteImplementation()
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                healthtel_mrt_hra_v1_finaldata DeleteObject = dbcontext.healthtel_mrt_hra_v1_finaldata.FirstOrDefault(x => x.batchid == batchid);
                if (DeleteObject == null)
                {
                    return;
                }
                dbcontext.healthtel_mrt_hra_v1_finaldata.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        private void AssignProperty(Type type, string PropertyName, object value)
        {
            PropertyInfo property = type.GetProperties().FirstOrDefault(x => x.Name.Equals(PropertyName, StringComparison.OrdinalIgnoreCase));
            if (property == null)
            {
                return;
            }

            switch (property.Name)
            {
                case "Userid":
                    if (property.PropertyType == typeof(string))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        //login user = LoggedInUser.Invoke();
                        property.SetValue(this, Constance.GC_USERID, null);
                    }
                    break;
                case "Importdate":
                    if (property.PropertyType == typeof(DateTime))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        property.SetValue(this, value, null);
                    }
                    break;
                default:
                    property.SetValue(this, value, null);
                    break;
            }
        }

        #endregion

        # region Help methods

        public bool ISImportFileInfoExist(string Name)
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                importedfileinfo objImportedFileInfo = dbcontext.importedfileinfoes.Where(x => x.filename == Name.Trim()).FirstOrDefault();

                if (objImportedFileInfo == null)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        public int DeleteFileId(int ImportId)
        {
            string ImpId = ImportId.ToString();
            using (reportsEntities dbcontext = new reportsEntities())
            {
                List<healthtel_mrt_hra_v1_finaldata> DeleteObject = new List<healthtel_mrt_hra_v1_finaldata>();
                DeleteObject = dbcontext.healthtel_mrt_hra_v1_finaldata.Where(x => x.importfileid == ImpId).ToList();
                if (DeleteObject == null)
                {
                    return 0;
                }
                else
                {
                    foreach (var item in DeleteObject)
                    {
                        dbcontext.healthtel_mrt_hra_v1_finaldata.DeleteObject(item);
                        dbcontext.SaveChanges();
                    }
                }
                return 1;
            }
        }

        # endregion
    }
}
