﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AutoMapper;
using App.Base;
using System.Reflection;

namespace DataAccessLayer.ReportsDB
{
    public partial class healthtel_mrt_finaldata
    {

         #region Properties & Constructor

        public bool IstoBeDeleted { get; set; }
        public bool HasError { get; set; }

        public healthtel_mrt_finaldata()
        {
        }

        public healthtel_mrt_finaldata(int RecNo)
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                healthtel_mrt_finaldata Batchmaster = dbcontext.healthtel_mrt_finaldata.FirstOrDefault(x => x.recno == recno);
                Mapper.Map(Batchmaster, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        public void Store()
        {

            //if (IstoBeDeleted)
            //{
            //    //DeleteImplementation();
            //    //return;
            //}
            ////Validate();

            //if (HasError)
            //{
            //    return;
            //}

            //Type type = GetType();
            //AssignProperty(type, "Importdate", string.Format("{0}", Constance.GC_USERID));
            //AssignProperty(type, "Userid", DateTime.Now);
            StoreComposite();
        }

        //private void Validate()
        //{
        //    HasError = false;
        //    if (string.IsNullOrEmpty(Name))
        //    {
        //        HasError = true;
        //    }
        //}

        private void StoreComposite()
        {
           // if (recno== 0)
           // {
                AddImplementation();
            //}
           // else
            //{
               // UpdateImplementation();
            //}
        }

        private void AddImplementation()
        {
            using (reportsEntities  dbcontext = new reportsEntities ())
            {
                dbcontext.healthtel_mrt_finaldata.AddObject(this);
                dbcontext.SaveChanges();
                   
                //recno= this.recno;
            }
        }

        private void UpdateImplementation()
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                healthtel_mrt_finaldata addObject = dbcontext.healthtel_mrt_finaldata.FirstOrDefault(x => x.recno == recno);
                if (addObject == null)
                {
                    return;
                }
                addObject.RECORD_NUMBER = RECORD_NUMBER;
                addObject.BatchName = BatchName;
                addObject.Image_Number = Image_Number;
                addObject.MemberId = MemberId;
                addObject.Barcode = Barcode;
                addObject.First_Name = First_Name;
                addObject.Last_Name = Last_Name;
                addObject.Phone_No = Phone_No;
                addObject.addressupdate = addressupdate;
                addObject.Address1 = Address1;
                addObject.Address2 = Address2;
                addObject.City = City;
                addObject.State = State;
                addObject.DOB = DOB;
                addObject.DOS = DOS;
                addObject.ProviderSignature = ProviderSignature;
                addObject.MotOptin = MotOptin;
                addObject.HbA1c = HbA1c;
                addObject.LDL_c = LDL_c;
                addObject.Microalbumin= Microalbumin;
                addObject.formscandata = formscandata;
                addObject.createdon = createdon;
                addObject.importfileid = importfileid;
                dbcontext.SaveChanges();
            }
        }

        private void DeleteImplementation()
        {
            using (reportsEntities  dbcontext = new reportsEntities())
            {
                healthtel_mrt_finaldata  DeleteObject = dbcontext.healthtel_mrt_finaldata.FirstOrDefault(x => x.batchid==batchid);
                if (DeleteObject == null)
                {
                    return;
                }
                dbcontext.healthtel_mrt_finaldata.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        private void AssignProperty(Type type, string PropertyName, object value)
        {
            PropertyInfo property = type.GetProperties().FirstOrDefault(x => x.Name.Equals(PropertyName, StringComparison.OrdinalIgnoreCase));
            if (property == null)
            {
                return;
            }

            switch (property.Name)
            {
                case "Userid":
                    if (property.PropertyType == typeof(string))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        //login user = LoggedInUser.Invoke();
                        property.SetValue(this, Constance.GC_USERID, null);
                    }
                    break;
                case "Importdate":
                    if (property.PropertyType == typeof(DateTime))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        property.SetValue(this, value, null);
                    }
                    break;
                default:
                    property.SetValue(this, value, null);
                    break;
            }
        }

        #endregion 

        #region Help Methods
        
    

       


        //public bool UpdateBatchmaster(int BatchID, string Process)
        //{
        //    using (ProjectDBEntity dbcontext = new ProjectDBEntity())
        //    {
        //        batchmaster UpdateBatchMaster = new batchmaster();
        //        List<imagemaster> UpdateImageMaster = new List<imagemaster>();

        //        UpdateBatchMaster = dbcontext.batchmasters.Where(x => x.ID == BatchID).FirstOrDefault();
        //        //UpdateBatchMaster = dbcontext.batchmasters.Where(x => x.ID == BatchID).ToList();

        //        //UpdateImageMaster = dbcontext.imagemasters.Where(x => x.Key1 == 1 && x.BatchID == BatchID).ToList();
                                
        //        if (Process.ToUpper() == "KEY1")
        //        {
        //            UpdateImageMaster = dbcontext.imagemasters.Where(x => (x.Key1 == 1 || x.Key1 == 0)  && x.BatchID == BatchID).ToList();
        //            if (UpdateImageMaster.Count == 0)
        //            {
        //                UpdateBatchMaster.Key1 = 2;
        //            }
        //        }
                    
        //        else if (Process.ToUpper() == "KEY2")
        //        {
        //            UpdateImageMaster = dbcontext.imagemasters.Where(x => (x.Key2 == 1 || x.Key2 == 0) && x.BatchID == BatchID).ToList();
        //            if (UpdateImageMaster.Count == 0)
        //            {
        //                UpdateBatchMaster.Key2 = 2; 
        //            }                    
        //        }
        //        else if (Process.ToUpper() == "COMPAREQC")
        //        {
        //            UpdateImageMaster = dbcontext.imagemasters.Where(x => (x.CompareQC == 1 || x.CompareQC == 0) && x.BatchID == BatchID).ToList();
        //            if (UpdateImageMaster.Count == 0)
        //            {
        //                UpdateBatchMaster.CompareQC = 2; 
        //            }                    
        //        }
        //        else if (Process.ToUpper() == "KEYQC")
        //        {
        //            UpdateImageMaster = dbcontext.imagemasters.Where(x => (x.KeyQC == 1 || x.KeyQC == 0) && x.BatchID == BatchID).ToList();
        //            if (UpdateImageMaster.Count == 0)
        //            {
        //                UpdateBatchMaster.KeyQC = 2;
        //            }
        //        }

        //        UpdateBatchMaster.Store();

        //        return true;
        //    }
        //}

        #endregion Help Methods


        public bool ISImportFileInfoExist(string Name)
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                importedfileinfo  objImportedFileInfo = dbcontext.importedfileinfoes.Where(x => x.filename== Name.Trim()).FirstOrDefault();

                if (objImportedFileInfo == null)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        public int DeleteFileId(int  ImportId)
        {
            string ImpId = ImportId.ToString();
            List<healthtel_mrt_finaldata> DeleteObject = new List<healthtel_mrt_finaldata>();
            using (reportsEntities dbcontext = new reportsEntities())
            {
                DeleteObject = dbcontext.healthtel_mrt_finaldata.Where(x => x.importfileid == ImpId).ToList();
                if (DeleteObject == null)
                {
                    return 0;
                }
                else
                {
                    foreach (var item in DeleteObject)
                    {
                        dbcontext.healthtel_mrt_finaldata.DeleteObject(item);
                        dbcontext.SaveChanges();
                    }
                    return 1;
                }
            }
        }

    }
}
