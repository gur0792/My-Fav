﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AutoMapper;
using App.Base;
using System.Reflection;

namespace DataAccessLayer.ReportsDB
{
    public partial class healthtel_mrt_hra_finaldata
    {

        #region Properties & Constructor

        public bool IstoBeDeleted { get; set; }
        public bool HasError { get; set; }

        public healthtel_mrt_hra_finaldata()
        {
        }

        public healthtel_mrt_hra_finaldata(int RecNo)
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                healthtel_mrt_hra_finaldata Batchmaster = dbcontext.healthtel_mrt_hra_finaldata.FirstOrDefault(x => x.recno == recno);
                Mapper.Map(Batchmaster, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        public void Store()
        {

            StoreComposite();
        }


        private void StoreComposite()
        {
            AddImplementation();
            //if (recno == 0)
            //{
            //    AddImplementation();
            //}
            //else
            //{
            //    UpdateImplementation();
            //}
        }
        private void AddImplementation()
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {

                dbcontext.healthtel_mrt_hra_finaldata.AddObject(this);
                dbcontext.SaveChanges();
                //recno = this.recno; 



            }
        }

        private void UpdateImplementation()
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                healthtel_mrt_hra_finaldata addObject = dbcontext.healthtel_mrt_hra_finaldata.FirstOrDefault(x => x.recno == recno);
                if (addObject == null)
                {
                    return;
                }
                addObject.Respondent_ID = Respondent_ID;
                addObject.Q1 = Q1;
                addObject.Q2_1 = Q2_1;
                addObject.Q2_2 = Q2_2;
                addObject.Q2_3 = Q2_3;
                addObject.Q2_4 = Q2_4;
                addObject.Q2_5 = Q2_5;
                addObject.Q2_6 = Q2_6;
                addObject.Q2_7 = Q2_7;
                addObject.Q2_8 = Q2_8;
                addObject.Q4 = Q4;
                addObject.Q5 = Q5;
                addObject.Q6 = Q6;
                addObject.Q7 = Q7;
                addObject.Q8 = Q8;
                addObject.Q9 = Q9;
                addObject.Q10 = Q10;
                addObject.Q11 = Q11;
                addObject.Q12 = Q12;
                addObject.Q13 = Q13;
                addObject.Q14 = Q14;
                addObject.Q15 = Q15;
                addObject.Q16 = Q16;
                addObject.Q17 = Q17;
                addObject.Language = Language;
                addObject.Q3 = Q3;
                addObject.Batch_Number = Batch_Number;
                addObject.Image_Number = Image_Number;
                addObject.BatchName = BatchName;
                addObject.importfileid = importfileid;
                addObject.batchid = batchid;
                dbcontext.SaveChanges();
            }
        }

        private void DeleteImplementation()
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                healthtel_mrt_hra_finaldata DeleteObject = dbcontext.healthtel_mrt_hra_finaldata.FirstOrDefault(x => x.batchid == batchid);
                if (DeleteObject == null)
                {
                    return;
                }
                dbcontext.healthtel_mrt_hra_finaldata.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        private void AssignProperty(Type type, string PropertyName, object value)
        {
            PropertyInfo property = type.GetProperties().FirstOrDefault(x => x.Name.Equals(PropertyName, StringComparison.OrdinalIgnoreCase));
            if (property == null)
            {
                return;
            }

            switch (property.Name)
            {
                case "Userid":
                    if (property.PropertyType == typeof(string))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        //login user = LoggedInUser.Invoke();
                        property.SetValue(this, Constance.GC_USERID, null);
                    }
                    break;
                case "Importdate":
                    if (property.PropertyType == typeof(DateTime))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        property.SetValue(this, value, null);
                    }
                    break;
                default:
                    property.SetValue(this, value, null);
                    break;
            }
        }

        #endregion

        #region Help Methods







        #endregion Help Methods


        public bool ISImportFileInfoExist(string Name)
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                importedfileinfo objImportedFileInfo = dbcontext.importedfileinfoes.Where(x => x.filename == Name.Trim()).FirstOrDefault();

                if (objImportedFileInfo == null)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        public int DeleteFileId(int ImportId)
        {
            string ImpId = ImportId.ToString();
            using (reportsEntities dbcontext = new reportsEntities())
            {
                List<healthtel_mrt_hra_finaldata> DeleteObject = new List<healthtel_mrt_hra_finaldata>();
                DeleteObject = dbcontext.healthtel_mrt_hra_finaldata.Where(x => x.importfileid == ImpId).ToList();
                if (DeleteObject == null)
                {
                    return 0;
                }
                else
                {
                    foreach (var item in DeleteObject)
                    {
                        dbcontext.healthtel_mrt_hra_finaldata.DeleteObject(item);
                        dbcontext.SaveChanges();
                    }
                }
                return 1;
            }
        }

    }
}
