﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AutoMapper;
using App.Base;
using System.Reflection;

namespace DataAccessLayer.ReportsDB
{
    public partial class healthteladult_finaldata
    {
        #region Properties & Constructor

        public bool IstoBeDeleted { get; set; }
        public bool HasError { get; set; }

        public healthteladult_finaldata()
        {
        }

        public healthteladult_finaldata(int RecNo)
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                healthteladult_finaldata Batchmaster = dbcontext.healthteladult_finaldata.FirstOrDefault(x => x.recno == recno);
                Mapper.Map(Batchmaster, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        public void Store()
        {

            StoreComposite();
        }


        private void StoreComposite()
        {
            AddImplementation();
        }
        private void AddImplementation()
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                dbcontext.healthteladult_finaldata.AddObject(this);
                dbcontext.SaveChanges();
            }
        }

     

        private void AssignProperty(Type type, string PropertyName, object value)
        {
            PropertyInfo property = type.GetProperties().FirstOrDefault(x => x.Name.Equals(PropertyName, StringComparison.OrdinalIgnoreCase));
            if (property == null)
            {
                return;
            }

            switch (property.Name)
            {
                case "Userid":
                    if (property.PropertyType == typeof(string))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        //login user = LoggedInUser.Invoke();
                        property.SetValue(this, Constance.GC_USERID, null);
                    }
                    break;
                case "Importdate":
                    if (property.PropertyType == typeof(DateTime))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        property.SetValue(this, value, null);
                    }
                    break;
                default:
                    property.SetValue(this, value, null);
                    break;
            }
        }

        #endregion

        # region Help methods

        public bool ISImportFileInfoExist(string Name)
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                importedfileinfo objImportedFileInfo = dbcontext.importedfileinfoes.Where(x => x.filename == Name.Trim()).FirstOrDefault();

                if (objImportedFileInfo == null)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        public int DeleteFileId(int ImportId)
        {
            string ImpId = ImportId.ToString();
            using (reportsEntities dbcontext = new reportsEntities())
            {
                List<healthteladult_finaldata> DeleteObject = new List<healthteladult_finaldata>();
                DeleteObject = dbcontext.healthteladult_finaldata.Where(x => x.importfileid == ImpId).ToList();
                if (DeleteObject == null)
                {
                    return 0;
                }
                else
                {
                    foreach (var item in DeleteObject)
                    {
                        dbcontext.healthteladult_finaldata.DeleteObject(item);
                        dbcontext.SaveChanges();
                    }
                }
                return 1;
            }
        }

        # endregion
    }
}
