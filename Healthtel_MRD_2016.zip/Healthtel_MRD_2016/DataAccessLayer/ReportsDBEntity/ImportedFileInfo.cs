﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AutoMapper;
using App.Base;
using System.Reflection;

namespace DataAccessLayer.ReportsDB
{
    public partial class importedfileinfo
    {
        #region Properties & Constructor

        public bool IstoBeDeleted { get; set; }
        public bool HasError { get; set; }

        public importedfileinfo()
        {
        }

        public importedfileinfo(int id)
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                importedfileinfo Batchmaster = dbcontext.importedfileinfoes.FirstOrDefault(x => x.id == id);
                Mapper.Map(Batchmaster, this);
            }
        }

        #endregion Properties & Constructor

        #region CRUD Operation

        public void Store()
        {

            if (IstoBeDeleted)
            {
                DeleteImplementation();
                return;
            }
            //Validate();

            if (HasError)
            {
                return;
            }

            Type type = GetType();
            AssignProperty(type, "importdate",DateTime.Now);
            AssignProperty(type, "userid", Constance.GC_USERID);
            StoreComposite();
        }

        //private void Validate()
        //{
        //    HasError = false;
        //    if (string.IsNullOrEmpty(Name))
        //    {
        //        HasError = true;
        //    }
        //}

        private void StoreComposite()
        {
            //if (id == 0)
            //{
                AddImplementation();
            //}
            //else
            //{
            //    UpdateImplementation();
            //}
        }

        private void AddImplementation()
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                dbcontext.importedfileinfoes.AddObject(this);
                dbcontext.SaveChanges();
                id = this.id;
            }
        }

        private void UpdateImplementation()
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                importedfileinfo addObject = dbcontext.importedfileinfoes.FirstOrDefault(x => x.id == id);
                if (addObject == null)
                {
                    return;
                }
                importedfileinfo objImportFileInfo = new importedfileinfo();
                objImportFileInfo.filename = filename;
                objImportFileInfo.userid = userid;
                objImportFileInfo.username = username;
                objImportFileInfo.projectid = projectid;
                objImportFileInfo.status = status;
                objImportFileInfo.importdate = importdate;
                //dbcontext.SaveChanges();
            }
        }

        private void DeleteImplementation()
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                importedfileinfo DeleteObject = dbcontext.importedfileinfoes.FirstOrDefault(x => x.id == id);
                if (DeleteObject == null)
                {
                    return;
                }
                dbcontext.importedfileinfoes.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        private void AssignProperty(Type type, string PropertyName, object value)
        {
            PropertyInfo property = type.GetProperties().FirstOrDefault(x => x.Name.Equals(PropertyName, StringComparison.OrdinalIgnoreCase));
            if (property == null)
            {
                return;
            }

            switch (property.Name)
            {
                case "userid":
                    if (property.PropertyType == typeof(string))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        //login user = LoggedInUser.Invoke();
                        property.SetValue(this, Constance.GC_USERID, null);
                    }
                    break;
                case "importdate":
                    if (property.PropertyType == typeof(DateTime))
                    {
                        property.SetValue(this, value, null);
                    }
                    else
                    {
                        property.SetValue(this, value, null);
                    }
                    break;
                default:
                    property.SetValue(this, value, null);
                    break;
            }
        }

        #endregion

        public bool ISImportFileInfoExist(string Name)
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                importedfileinfo objImportedFileInfo = dbcontext.importedfileinfoes.Where(x => x.filename == Name.Trim()).FirstOrDefault();

                if (objImportedFileInfo == null)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
        public int ISImportFileId(string Name)
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                int ImportId = 0;
                importedfileinfo objImportedFileInfo = dbcontext.importedfileinfoes.Where(x => x.filename == Name.Trim()).FirstOrDefault();

                if (objImportedFileInfo == null)
                {
                    return 0;
                }
                else
                {
                    ImportId = objImportedFileInfo.id;
                    return ImportId;
                }
            }
        }

       

    }
}
