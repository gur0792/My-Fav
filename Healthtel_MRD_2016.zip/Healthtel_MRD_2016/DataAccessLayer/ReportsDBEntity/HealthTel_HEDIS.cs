﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccessLayer.ReportsDB;
using AutoMapper;

namespace DataAccessLayer.ReportsDB
{
    public partial class hedis_finaldata
    {

        #region Properties & Constructor
        public bool IstoBeDeleted { get; set; }
        public bool HasError { get; set; }

        public hedis_finaldata()
        {
        }

        public hedis_finaldata(int RecNo)
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                hedis_finaldata Batchmaster = dbcontext.hedis_finaldata.FirstOrDefault(x => x.recno == recno);
                Mapper.Map(Batchmaster, this);
            }
        }

        public void Store()
        {
            StoreComposite();
        }


        private void StoreComposite()
        {
            AddImplementation();
        }
        private void AddImplementation()
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                dbcontext.hedis_finaldata.AddObject(this);
                dbcontext.SaveChanges();
            }
        }

        private void UpdateImplementation()
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                hedis_finaldata addObject = dbcontext.hedis_finaldata.FirstOrDefault(x => x.recno == recno);
                if (addObject == null)
                {
                    return;
                }
                addObject.Image_Number = Image_Number;
                addObject.Barcode = Barcode;
                addObject.Q1_1 = Q1_1;
                addObject.Q1_2 = Q1_2;
                addObject.Q1_3 = Q1_3;
                addObject.Q1_4 = Q1_4;
                addObject.Q1_5 = Q1_5;
                addObject.Q2_1 = Q2_1;
                addObject.Q2_2 = Q2_2;
                addObject.Q2_3 = Q2_3;
                addObject.Q3_1 = Q3_1;
                addObject.Q3_2 = Q3_2;
                addObject.Q3_3 = Q3_3;
                addObject.Q3_4 = Q3_4;
                addObject.Signature = Signature;
                addObject.Signature_Date = Signature_Date;
                addObject.createdon = createdon;
                addObject.batchid = batchid;
                addObject.Image_Number = Image_Number;
                addObject.BatchName = BatchName;
                addObject.importfileid = importfileid;
                addObject.batchid = batchid;
                dbcontext.SaveChanges();
            }
        }

        private void DeleteImplementation()
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                hedis_finaldata DeleteObject = dbcontext.hedis_finaldata.FirstOrDefault(x => x.batchid == batchid);
                if (DeleteObject == null)
                {
                    return;
                }
                dbcontext.hedis_finaldata.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        #endregion

        public bool ISImportFileInfoExist(string Name)
        {
            using (reportsEntities dbcontext = new reportsEntities())
            {
                importedfileinfo objImportedFileInfo = dbcontext.importedfileinfoes.Where(x => x.filename == Name.Trim()).FirstOrDefault();

                if (objImportedFileInfo == null)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        public int DeleteFileId(int ImportId)
        {
            string ImpId = ImportId.ToString();
            using (reportsEntities dbcontext = new reportsEntities())
            {
                List<hedis_finaldata> DeleteObject = new List<hedis_finaldata>();
                DeleteObject = dbcontext.hedis_finaldata.Where(x => x.importfileid == ImpId).ToList();
                if (DeleteObject == null)
                {
                    return 0;
                }
                else
                {
                    foreach (var item in DeleteObject)
                    {
                        dbcontext.hedis_finaldata.DeleteObject(item);
                        dbcontext.SaveChanges();
                    }
                }
                return 1;
            }
        }

    }
}
