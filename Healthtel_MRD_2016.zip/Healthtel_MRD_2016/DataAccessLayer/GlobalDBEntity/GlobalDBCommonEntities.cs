﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccessLayer.ProjectDB;
using AutoMapper;

namespace DataAccessLayer.GlobalDB
{
    public partial class bpo_versioncontrol 
    {
        #region Properties & Constructor

        public bpo_versioncontrol()
        {
        }

        public bpo_versioncontrol(int ID)
        {

            using (globaldbEntity dbContext = new globaldbEntity())
            {
                bpo_versioncontrol Bpo_versioncontrol = dbContext.bpo_versioncontrol.FirstOrDefault(x => x.id == ID);
                Mapper.Map(Bpo_versioncontrol, this);
            }
        }

        #endregion

        #region Help Methods

        public List<bpo_versioncontrol> bpoversionList()
        {
            using (globaldbEntity dbContext = new globaldbEntity())
            {
                return dbContext.bpo_versioncontrol.ToList();
            }
        }

        public List<bpo_projects> bpoprojectsList()
        {
            using (globaldbEntity dbContext = new globaldbEntity())
            {
                return dbContext.bpo_projects.Where(x => x.assemblyname != null).OrderBy(x=>x.ID).ToList();
            }
        }

        public bpo_versioncontrol checkversionList(int projectid, string status, int currentlive)
        {
            bpo_versioncontrol checkversionList = new bpo_versioncontrol();
            using (globaldbEntity dbContext = new globaldbEntity())
            {
                checkversionList = (from bpoversioncontrol in dbContext.bpo_versioncontrol
                                        join bpoprojects in dbContext.bpo_projects on bpoversioncontrol.projectid equals bpoprojects.ID
                                        where bpoversioncontrol.projectid == projectid && bpoversioncontrol.status == status && bpoversioncontrol.currentlive == currentlive 
                                        orderby bpoversioncontrol.id descending
                                        select (bpoversioncontrol)).FirstOrDefault();
            }
            return checkversionList;
        }       

        #endregion
    }

    public partial class login 
    {
        #region Properties & Constructor

        public bool IstoBeDeleted { get; set; }
        public bool HasError { get; set; }

        public login()
        {
        }

        public login(int ID)
        {
            using (globaldbEntity dbContext = new globaldbEntity())
            {
                login Login = dbContext.logins.FirstOrDefault(x => x.ID == ID);
                Mapper.Map(Login, this);
            }
        }

        #endregion

        #region CRUD Operation

        public void Store()
        {
            if (IstoBeDeleted)
            {
                DeleteImplementation();
                return;
            }
            Validate();

            if (HasError)
            {
                return;
            }

            StoreComposite();
        }

        private void Validate()
        {
            HasError = false;
            if (string.IsNullOrEmpty(Name))
            {
                HasError = true;
            }
        }

        private void StoreComposite()
        {
            if (ID == 0)
            {
                AddImplementation();
            }
            else
            {
                UpdateImplementation();
            }
        }

        private void AddImplementation()
        {
            using (globaldbEntity dbcontext = new globaldbEntity())
            {
                dbcontext.logins.AddObject(this);
                dbcontext.SaveChanges();
                ID = this.ID;
            }
        }

        private void UpdateImplementation()
        {
            using (globaldbEntity dbcontext = new globaldbEntity())
            {
                login addObject = dbcontext.logins.FirstOrDefault(x => x.ID == ID);
                if (addObject == null)
                {
                    return;
                }
                addObject.Name = Name;
                addObject.Password = Password;
                addObject.userLevel = userLevel;
                addObject.EmployeeName = EmployeeName;
                addObject.Employeecode = Employeecode;
                addObject.LoginStatus = LoginStatus;
                addObject.LastDate = LastDate;
                addObject.LastProject = LastProject;
                addObject.reportuserlevel = reportuserlevel;
                addObject.shiftid = shiftid;
                addObject.dateofjoin = dateofjoin;
                addObject.modifiedby = modifiedby;
                addObject.modifiedon = modifiedon;
                addObject.active = active;
                addObject.ADName = ADName;
                addObject.ADPassword = ADPassword;
                dbcontext.SaveChanges();
            }
        }

        private void DeleteImplementation()
        {
            using (globaldbEntity dbcontext = new globaldbEntity())
            {
                login DeleteObject = dbcontext.logins.FirstOrDefault(x => x.ID == ID);
                if (DeleteObject == null)
                {
                    return;
                }
                dbcontext.logins.DeleteObject(DeleteObject);
                dbcontext.SaveChanges();
            }
        }

        #endregion CRUD Operation

        #region Help Methods

        public login Authentication(string UserName)
        {
            using (globaldbEntity dbContext = new globaldbEntity())
            {
                return dbContext.logins.FirstOrDefault(x => x.ADName.ToUpper() == UserName.ToUpper());
            }
        }

        public List<login> getLoggedUsers()
        {
            using (globaldbEntity dbContext = new globaldbEntity())
            {
                return dbContext.logins.Where(x => x.LoginStatus == true && (x.ID != 1 && x.ID != 5 && x.ID != 61 && x.ID != 62 && x.ID != 96 && x.ID != 375 && x.ID != 453 && x.ID != 469 && x.ID != 491)).OrderBy(x => x.Name).ToList();
            }
        }               

        #endregion

        //protected override void Validate()
        //{
        //    throw new NotImplementedException();
        //}

        //protected override void StoreComposite()
        //{
        //    throw new NotImplementedException();
        //}

        //protected override void AddImplementation()
        //{
        //    throw new NotImplementedException();
        //}

        //protected override void UpdateImplementation()
        //{
        //    throw new NotImplementedException();
        //}

        //protected override void DeleteImplementation()
        //{
        //    throw new NotImplementedException();
        //}
    }

    public partial class domainnamedatabase
    {
        #region Properties & Constructor

        public domainnamedatabase()
        {
        }

        public domainnamedatabase(int ID)
        {
            using (globaldbEntity dbContext = new globaldbEntity())
            {
                domainnamedatabase Domainnamedatabase = dbContext.domainnamedatabases.FirstOrDefault(x => x.ID == ID);
                Mapper.Map(Domainnamedatabase, this);
            }
        }

        #endregion

        #region Help Methods

        public List<domainnamedatabase> List()
        {
            using (globaldbEntity dbContext = new globaldbEntity())
            {
                return dbContext.domainnamedatabases.ToList();
            }
        }

        #endregion
    }

    public partial class city
    {
        #region Properties & Constructor

        public city()
        {
        }

        public city(int ID)
        {
            using (globaldbEntity dbContext = new globaldbEntity())
            {
                city City = dbContext.cities.FirstOrDefault(x => x.Id == ID);
                Mapper.Map(City, this);
            }
        }

        #endregion

        #region Help Methods

        public List<city> List()
        {
            using (globaldbEntity dbContext = new globaldbEntity())
            {
                return dbContext.cities.ToList();
            }
        }

        public List<city> getCities(string Zip)
        {
            using (globaldbEntity dbContext = new globaldbEntity())
            {
                return dbContext.cities.Where(x => x.ZIPCODE == Zip).ToList();
            }
        }

        #endregion
    }

    public partial class namesdatabase
    {
        #region Properties & Constructor

        public namesdatabase()
        {
        }

        public namesdatabase(int ID)
        {
            using (globaldbEntity dbContext = new globaldbEntity())
            {
                namesdatabase Namesdatabase = dbContext.namesdatabases.FirstOrDefault(x => x.ID == ID);
                Mapper.Map(Namesdatabase, this);
            }
        }

        #endregion

        #region Help Methods

        public List<namesdatabase> List()
        {
            using (globaldbEntity dbContext = new globaldbEntity())
            {
                return dbContext.namesdatabases.ToList();
            }
        }

        #endregion
    }
}


