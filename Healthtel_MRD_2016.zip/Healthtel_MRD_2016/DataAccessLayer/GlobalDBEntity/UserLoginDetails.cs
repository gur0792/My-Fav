﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccessLayer.GlobalDB;
using AutoMapper;
using System.Transactions;

namespace DataAccessLayer.GlobalDB
{
    public partial class projectlogindetail
    {
       
        public projectlogindetail()
        {
        }

        public projectlogindetail(int _ID)
        {
            using (globaldbEntity dbcontext = new globaldbEntity())
            {
                projectlogindetail Batchmaster = dbcontext.projectlogindetails.FirstOrDefault(x => x.ID == _ID);
                Mapper.Map(Batchmaster, this);
            }
        }

        public void Store()
        {
            StoreComposite();
        }
        private void StoreComposite()
        {
            AddImplementation();
        }
      

        private void AddImplementation()
        {
            using (globaldbEntity dbcontext = new globaldbEntity())
            {
                using (var tran = new TransactionScope())
                {
                    dbcontext.projectlogindetails.AddObject(this);
                    dbcontext.SaveChanges();
                    tran.Complete();

                }

            }
        }

    }
}
