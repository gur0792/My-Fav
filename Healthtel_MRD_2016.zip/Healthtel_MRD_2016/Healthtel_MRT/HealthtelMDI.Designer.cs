﻿using App.Base;
using System;

namespace Healthtel_MRT
{
    partial class HealthtelMDI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HealthtelMDI));
            this.mnuHealthtel = new System.Windows.Forms.MenuStrip();
            this.mnuAdmin = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImport = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuExport = new System.Windows.Forms.ToolStripMenuItem();
            this.mnumaintaince = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBatchDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuUserReset = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAlluserwiserpt = new System.Windows.Forms.ToolStripMenuItem();
            this.finalImportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuKey = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuKey1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuKey2 = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuKeyQC = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCompareQC = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuReport = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBatchRpt = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuUserRpt = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuUserRptAll = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuKeyReset = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuKey1Reset = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuKey2Reset = new System.Windows.Forms.ToolStripMenuItem();
            this.mnukeyQCReset = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCompareQCReset = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.lblversion = new System.Windows.Forms.Label();
            this.mnuHealthtel.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuHealthtel
            // 
            this.mnuHealthtel.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuHealthtel.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuAdmin,
            this.mnuKey,
            this.mnuReport,
            this.mnuSettings,
            this.mnuExit});
            this.mnuHealthtel.Location = new System.Drawing.Point(0, 0);
            this.mnuHealthtel.Name = "mnuHealthtel";
            this.mnuHealthtel.Size = new System.Drawing.Size(1062, 24);
            this.mnuHealthtel.TabIndex = 1;
            this.mnuHealthtel.Text = "menuStrip1";
            // 
            // mnuAdmin
            // 
            this.mnuAdmin.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuImport,
            this.mnuExport,
            this.mnumaintaince,
            this.mnuUserReset,
            this.mnuAlluserwiserpt,
            this.finalImportToolStripMenuItem});
            this.mnuAdmin.Name = "mnuAdmin";
            this.mnuAdmin.Size = new System.Drawing.Size(66, 20);
            this.mnuAdmin.Text = "Admin";
            // 
            // mnuImport
            // 
            this.mnuImport.Name = "mnuImport";
            this.mnuImport.Size = new System.Drawing.Size(227, 22);
            this.mnuImport.Text = "Batch Import";
            this.mnuImport.Click += new System.EventHandler(this.mnuImport_Click);
            // 
            // mnuExport
            // 
            this.mnuExport.Name = "mnuExport";
            this.mnuExport.Size = new System.Drawing.Size(227, 22);
            this.mnuExport.Text = "Batch Export";
            this.mnuExport.Click += new System.EventHandler(this.mnuExport_Click);
            // 
            // mnumaintaince
            // 
            this.mnumaintaince.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuBatchDelete});
            this.mnumaintaince.Name = "mnumaintaince";
            this.mnumaintaince.Size = new System.Drawing.Size(227, 22);
            this.mnumaintaince.Text = "Batch Maintaince";
            // 
            // mnuBatchDelete
            // 
            this.mnuBatchDelete.Name = "mnuBatchDelete";
            this.mnuBatchDelete.Size = new System.Drawing.Size(169, 22);
            this.mnuBatchDelete.Text = "Batch Delete";
            this.mnuBatchDelete.Click += new System.EventHandler(this.mnuBatchDelete_Click);
            // 
            // mnuUserReset
            // 
            this.mnuUserReset.Name = "mnuUserReset";
            this.mnuUserReset.Size = new System.Drawing.Size(227, 22);
            this.mnuUserReset.Text = "User Reset";
            this.mnuUserReset.Click += new System.EventHandler(this.mnuUserReset_Click);
            // 
            // mnuAlluserwiserpt
            // 
            this.mnuAlluserwiserpt.Name = "mnuAlluserwiserpt";
            this.mnuAlluserwiserpt.Size = new System.Drawing.Size(227, 22);
            this.mnuAlluserwiserpt.Text = "Userwise Report - All";
            this.mnuAlluserwiserpt.Visible = false;
            this.mnuAlluserwiserpt.Click += new System.EventHandler(this.mnuAlluserwiserpt_Click);
            // 
            // finalImportToolStripMenuItem
            // 
            this.finalImportToolStripMenuItem.Name = "finalImportToolStripMenuItem";
            this.finalImportToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.finalImportToolStripMenuItem.Text = "Final Import";
            this.finalImportToolStripMenuItem.Click += new System.EventHandler(this.finalImportToolStripMenuItem_Click);
            // 
            // mnuKey
            // 
            this.mnuKey.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuKey1,
            this.mnuKey2,
            this.mnuKeyQC,
            this.mnuCompareQC});
            this.mnuKey.Name = "mnuKey";
            this.mnuKey.Size = new System.Drawing.Size(47, 20);
            this.mnuKey.Text = "Key";
            // 
            // mnuKey1
            // 
            this.mnuKey1.Name = "mnuKey1";
            this.mnuKey1.Size = new System.Drawing.Size(167, 22);
            this.mnuKey1.Text = "Key 1";
            this.mnuKey1.Click += new System.EventHandler(this.mnuKey1_Click);
            // 
            // mnuKey2
            // 
            this.mnuKey2.Name = "mnuKey2";
            this.mnuKey2.Size = new System.Drawing.Size(167, 22);
            this.mnuKey2.Text = "Key 2";
            this.mnuKey2.Click += new System.EventHandler(this.mnuKey2_Click);
            // 
            // mnuKeyQC
            // 
            this.mnuKeyQC.Name = "mnuKeyQC";
            this.mnuKeyQC.Size = new System.Drawing.Size(167, 22);
            this.mnuKeyQC.Text = "KeyQC";
            this.mnuKeyQC.Click += new System.EventHandler(this.mnuKeyQC_Click);
            // 
            // mnuCompareQC
            // 
            this.mnuCompareQC.Name = "mnuCompareQC";
            this.mnuCompareQC.Size = new System.Drawing.Size(167, 22);
            this.mnuCompareQC.Text = "Compare QC";
            this.mnuCompareQC.Click += new System.EventHandler(this.mnuCompareQC_Click);
            // 
            // mnuReport
            // 
            this.mnuReport.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuBatchRpt,
            this.mnuUserRpt,
            this.mnuUserRptAll});
            this.mnuReport.Name = "mnuReport";
            this.mnuReport.Size = new System.Drawing.Size(68, 20);
            this.mnuReport.Text = "Report";
            // 
            // mnuBatchRpt
            // 
            this.mnuBatchRpt.Name = "mnuBatchRpt";
            this.mnuBatchRpt.Size = new System.Drawing.Size(264, 22);
            this.mnuBatchRpt.Text = "Batchwise Report";
            this.mnuBatchRpt.Click += new System.EventHandler(this.mnuBatchRpt_Click);
            // 
            // mnuUserRpt
            // 
            this.mnuUserRpt.Name = "mnuUserRpt";
            this.mnuUserRpt.Size = new System.Drawing.Size(264, 22);
            this.mnuUserRpt.Text = "Userwise Report-Personal";
            this.mnuUserRpt.Click += new System.EventHandler(this.mnuUserRpt_Click);
            // 
            // mnuUserRptAll
            // 
            this.mnuUserRptAll.Name = "mnuUserRptAll";
            this.mnuUserRptAll.Size = new System.Drawing.Size(264, 22);
            this.mnuUserRptAll.Text = "Userwise Report-ALL";
            this.mnuUserRptAll.Click += new System.EventHandler(this.mnuUserRptAll_Click);
            // 
            // mnuSettings
            // 
            this.mnuSettings.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuKeyReset});
            this.mnuSettings.Name = "mnuSettings";
            this.mnuSettings.Size = new System.Drawing.Size(80, 20);
            this.mnuSettings.Text = "Settings";
            // 
            // mnuKeyReset
            // 
            this.mnuKeyReset.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuKey1Reset,
            this.mnuKey2Reset,
            this.mnukeyQCReset,
            this.mnuCompareQCReset});
            this.mnuKeyReset.Name = "mnuKeyReset";
            this.mnuKeyReset.Size = new System.Drawing.Size(152, 22);
            this.mnuKeyReset.Text = "Key Reset";
            // 
            // mnuKey1Reset
            // 
            this.mnuKey1Reset.Name = "mnuKey1Reset";
            this.mnuKey1Reset.Size = new System.Drawing.Size(212, 22);
            this.mnuKey1Reset.Text = "Key 1 Reset";
            this.mnuKey1Reset.Click += new System.EventHandler(this.mnuKey1Reset_Click);
            // 
            // mnuKey2Reset
            // 
            this.mnuKey2Reset.Name = "mnuKey2Reset";
            this.mnuKey2Reset.Size = new System.Drawing.Size(212, 22);
            this.mnuKey2Reset.Text = "Key 2 Reset";
            this.mnuKey2Reset.Click += new System.EventHandler(this.mnuKey2Reset_Click);
            // 
            // mnukeyQCReset
            // 
            this.mnukeyQCReset.Name = "mnukeyQCReset";
            this.mnukeyQCReset.Size = new System.Drawing.Size(212, 22);
            this.mnukeyQCReset.Text = "KeyQC Reset";
            this.mnukeyQCReset.Click += new System.EventHandler(this.mnukeyQCReset_Click);
            // 
            // mnuCompareQCReset
            // 
            this.mnuCompareQCReset.Name = "mnuCompareQCReset";
            this.mnuCompareQCReset.Size = new System.Drawing.Size(212, 22);
            this.mnuCompareQCReset.Text = "Compare QC Reset";
            this.mnuCompareQCReset.Click += new System.EventHandler(this.mnuCompareQCReset_Click);
            // 
            // mnuExit
            // 
            this.mnuExit.Name = "mnuExit";
            this.mnuExit.Size = new System.Drawing.Size(48, 20);
            this.mnuExit.Text = "Exit";
            this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
            // 
            // lblversion
            // 
            this.lblversion.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblversion.AutoSize = true;
            this.lblversion.BackColor = System.Drawing.SystemColors.Window;
            this.lblversion.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblversion.ForeColor = System.Drawing.Color.Red;
            this.lblversion.Location = new System.Drawing.Point(132, 38);
            this.lblversion.Name = "lblversion";
            this.lblversion.Size = new System.Drawing.Size(787, 33);
            this.lblversion.TabIndex = 13;
            this.lblversion.Text = "This application is only for testing purpose, not for Live.";
            this.lblversion.Visible = false;
            // 
            // HealthtelMDI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1062, 453);
            this.Controls.Add(this.lblversion);
            this.Controls.Add(this.mnuHealthtel);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.mnuHealthtel;
            this.Name = "HealthtelMDI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Healthtel";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.HealthtelMDI_FormClosing);
            this.Load += new System.EventHandler(this.HealthtelMDI_Load);
            this.mnuHealthtel.ResumeLayout(false);
            this.mnuHealthtel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.MenuStrip mnuHealthtel;
        private System.Windows.Forms.ToolStripMenuItem mnuAdmin;
        private System.Windows.Forms.ToolStripMenuItem mnuImport;
        private System.Windows.Forms.ToolStripMenuItem mnuExport;
        private System.Windows.Forms.ToolStripMenuItem mnumaintaince;
        private System.Windows.Forms.ToolStripMenuItem mnuKey;
        private System.Windows.Forms.ToolStripMenuItem mnuKey1;
        private System.Windows.Forms.ToolStripMenuItem mnuKey2;
        private System.Windows.Forms.ToolStripMenuItem mnuCompareQC;
        private System.Windows.Forms.ToolStripMenuItem mnuReport;
        private System.Windows.Forms.ToolStripMenuItem mnuBatchRpt;
        private System.Windows.Forms.ToolStripMenuItem mnuUserRpt;
        private System.Windows.Forms.ToolStripMenuItem mnuSettings;
        private System.Windows.Forms.ToolStripMenuItem mnuKeyReset;
        private System.Windows.Forms.ToolStripMenuItem mnuKey1Reset;
        private System.Windows.Forms.ToolStripMenuItem mnuKey2Reset;
        private System.Windows.Forms.ToolStripMenuItem mnuCompareQCReset;
        private System.Windows.Forms.ToolStripMenuItem mnuExit;
        private System.Windows.Forms.ToolStripMenuItem mnuBatchDelete;

        public void New()
        {
            if (Constance.GC_USERID == 0)
            {
                App.UserControls.login fl = new App.UserControls.login();

                //product version declaration

                fl.Product_Version = ProductVersion;

                fl.ShowDialog();

                if (fl.LogedOn == true)
                {
                    Environment.Exit(0);
                }
                else
                {
                    Constance.GC_USERID = fl.userid;
                    Constance.GC_USERNAME = fl.Username;
                    Constance.GC_USERLEVEL = fl.UserLevel;
                    Constance.GC_PROJ_VERSIONSTATUS = fl.GC_PROJ_VERSIONSTATUS;
                }
            }
            InitializeComponent();
            //End If

            // This call is required by the designer.

            //InitializeComponent()

            // Add any initialization after the InitializeComponent() call.

        }

        internal System.Windows.Forms.Label lblversion;
        private System.Windows.Forms.ToolStripMenuItem mnuUserReset;
        private System.Windows.Forms.ToolStripMenuItem mnuKeyQC;
        private System.Windows.Forms.ToolStripMenuItem mnukeyQCReset;
        private System.Windows.Forms.ToolStripMenuItem mnuAlluserwiserpt;
        private System.Windows.Forms.ToolStripMenuItem finalImportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuUserRptAll;

    }
}



