﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DataAccessLayer.ProjectDB;
using DataAccessLayer.GlobalDB;
using App.Base;

namespace Healthtel_MRT
{
    public partial class frmBatchSelection : Form
    {
        public frmBatchSelection()
        {
            InitializeComponent();
        }

        #region Variable Declaration

        batchmaster objBatchmaster = new batchmaster();

        string ProcessType;
        long lngBatchID;
        int BatchType;
        int ProjectId = 0;

        #endregion

        #region Property Variables
        public string Process
        {
            get { return ProcessType; }

            set { ProcessType = value; }
        }
        #endregion

        #region Events and Methods

        private void frmBatchSelection_Load(object sender, EventArgs e)
        {
            LoadBatch();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                lngBatchID = Convert.ToInt64(lstBatches.SelectedValue);

                BatchType = objBatchmaster.getSelectedBatch(lngBatchID.ToInt()).BatchType.ToInt();

                if (BatchType == 0)
                {
                    ProjectId = 79;
                    switch (Process)
                    {
                        case Constance.GC_PROCESS_KEY1:
                            frmKeying_HRA_V2 Key1 = new frmKeying_HRA_V2();
                            Key1.Process = Constance.GC_PROCESS_KEY1;
                            Key1.BatchID = lngBatchID;
                            Key1.BatchType = BatchType;
                            Key1.Show();
                            break;

                        case Constance.GC_PROCESS_KEY2:
                            frmKeying_HRA_V2 Key2 = new frmKeying_HRA_V2();
                            Key2.Process = Constance.GC_PROCESS_KEY2;
                            Key2.BatchID = lngBatchID;
                            Key2.BatchType = BatchType;
                            Key2.Show();
                            break;

                        case Constance.GC_PROCESS_COMAPREQC:
                            frmKeying_HRA_V2 CompareQC = new frmKeying_HRA_V2();
                            CompareQC.Process = Constance.GC_PROCESS_COMAPREQC;
                            CompareQC.BatchID = lngBatchID;
                            CompareQC.BatchType = BatchType;
                            CompareQC.Show();
                            break;
                    }
                }

                else  if (BatchType == 1)
                {
                    ProjectId = 79;
                    switch (Process)
                    {
                        case Constance.GC_PROCESS_KEY1:
                            frmKeying_HRA Key1 = new frmKeying_HRA();
                            Key1.Process = Constance.GC_PROCESS_KEY1;
                            Key1.BatchID = lngBatchID;
                            Key1.BatchType = BatchType;
                            Key1.Show();
                            break;

                        case Constance.GC_PROCESS_KEY2:
                            frmKeying_HRA Key2 = new frmKeying_HRA();
                            Key2.Process = Constance.GC_PROCESS_KEY2;
                            Key2.BatchID = lngBatchID;
                            Key2.BatchType = BatchType;
                            Key2.Show();
                            break;

                        case Constance.GC_PROCESS_COMAPREQC:
                            frmKeying_HRA CompareQC = new frmKeying_HRA();
                            CompareQC.Process = Constance.GC_PROCESS_COMAPREQC;
                            CompareQC.BatchID = lngBatchID;
                            CompareQC.BatchType = BatchType;
                            CompareQC.Show();
                            break;
                    }
                }
                else if (BatchType == 2)
                {
                    ProjectId = 80;
                    switch (Process)
                    {
                        case Constance.GC_PROCESS_KEY1:
                            FrmKeying Key1 = new FrmKeying();
                            Key1.Process = Constance.GC_PROCESS_KEY1;
                            Key1.BatchID = lngBatchID;
                            Key1.BatchType = BatchType;
                            Key1.Show();
                            break;

                        case Constance.GC_PROCESS_KEY2:
                            FrmKeying Key2 = new FrmKeying();
                            Key2.Process = Constance.GC_PROCESS_KEY2;
                            Key2.BatchID = lngBatchID;
                            Key2.BatchType = BatchType;
                            Key2.Show();
                            break;

                        case Constance.GC_PROCESS_COMAPREQC:
                            FrmKeying CompareQC = new FrmKeying();
                            CompareQC.Process = Constance.GC_PROCESS_COMAPREQC;
                            CompareQC.BatchID = lngBatchID;
                            CompareQC.BatchType = BatchType;
                            CompareQC.Show();
                            break;

                        case Constance.GC_PROCESS_KEYQC:
                            FrmKeying KeyQC = new FrmKeying();
                            KeyQC.Process = Constance.GC_PROCESS_KEYQC;
                            KeyQC.BatchID = lngBatchID;
                            KeyQC.BatchType = BatchType;
                            KeyQC.Show();
                            break;
                    }
                }
                else if (BatchType == 3)
                {
                    ProjectId = 82;
                    switch (Process)
                    {
                        case Constance.GC_PROCESS_KEY1:
                            FrmKeying_HEDIS Key1 = new FrmKeying_HEDIS();
                            Key1.Process = Constance.GC_PROCESS_KEY1;
                            Key1.BatchID = lngBatchID;
                            Key1.BatchType = BatchType;
                            Key1.Show();
                            break;

                        case Constance.GC_PROCESS_KEYQC:
                            FrmKeying_HEDIS KeyQC = new FrmKeying_HEDIS();
                            KeyQC.Process = Constance.GC_PROCESS_KEYQC;
                            KeyQC.BatchID = lngBatchID;
                            KeyQC.BatchType = BatchType;
                            KeyQC.Show();
                            break;
                    }
                }
                else if (BatchType == 4)
                {
                    ProjectId =79;
                    switch (Process)
                    {
                        case Constance.GC_PROCESS_KEY1:
                            HRAV1 Key1 = new HRAV1();
                            Key1.Process = Constance.GC_PROCESS_KEY1;
                            Key1.BatchID = lngBatchID;
                            Key1.BatchType = BatchType;
                            Key1.Show();
                            break;

                        case Constance.GC_PROCESS_KEY2:
                            HRAV1 Key2 = new HRAV1();
                            Key2.Process = Constance.GC_PROCESS_KEY2;
                            Key2.BatchID = lngBatchID;
                            Key2.BatchType = BatchType;
                            Key2.Show();
                            break;

                        case Constance.GC_PROCESS_COMAPREQC:
                            HRAV1 CompareQC = new HRAV1();
                            CompareQC.Process = Constance.GC_PROCESS_COMAPREQC;
                            CompareQC.BatchID = lngBatchID;
                            CompareQC.BatchType = BatchType;
                            CompareQC.Show();
                            break;
                      
                    }
                }
                else if (BatchType == 5)
                {
                    ProjectId = 86;
                    switch (Process)
                    {
                        case Constance.GC_PROCESS_KEY1:
                            Healthtel_pediatric key1 = new Healthtel_pediatric();
                            key1.Process = Constance.GC_PROCESS_KEY1;
                            key1.BatchID = lngBatchID;
                            key1.BatchType = BatchType;
                            key1.Show();
                            break;

                        case Constance.GC_PROCESS_KEY2:
                            Healthtel_pediatric Key2 = new Healthtel_pediatric();
                            Key2.Process = Constance.GC_PROCESS_KEY2;
                            Key2.BatchID = lngBatchID;
                            Key2.BatchType = BatchType;
                            Key2.Show();
                            break;

                        case Constance.GC_PROCESS_COMAPREQC:
                            Healthtel_pediatric CompareQC = new Healthtel_pediatric();
                            CompareQC.Process = Constance.GC_PROCESS_COMAPREQC;
                            CompareQC.BatchID = lngBatchID;
                            CompareQC.BatchType = BatchType;
                            CompareQC.Show();
                            break;

                    }
                }
                else if (BatchType == 6)
                {
                    ProjectId = 86;
                    switch (Process)
                    {
                        case Constance.GC_PROCESS_KEY1:
                            Healthtel_pediatric key1 = new Healthtel_pediatric();
                            key1.Process = Constance.GC_PROCESS_KEY1;
                            key1.BatchID = lngBatchID;
                            key1.BatchType = BatchType;
                            key1.Show();
                            break;

                        case Constance.GC_PROCESS_KEY2:
                            Healthtel_pediatric Key2 = new Healthtel_pediatric();
                            Key2.Process = Constance.GC_PROCESS_KEY2;
                            Key2.BatchID = lngBatchID;
                            Key2.BatchType = BatchType;
                            Key2.Show();
                            break;

                        case Constance.GC_PROCESS_COMAPREQC:
                            Healthtel_pediatric CompareQC = new Healthtel_pediatric();
                            CompareQC.Process = Constance.GC_PROCESS_COMAPREQC;
                            CompareQC.BatchID = lngBatchID;
                            CompareQC.BatchType = BatchType;
                            CompareQC.Show();
                            break;

                    }
                }
                else
                {
                    MessageBox.Show("Invalid BatchSelection");
                }

                try
                {
                    
                    projectlogindetail projectLogin = new projectlogindetail();
                    projectLogin.ProjectID = ProjectId;
                    projectLogin.UserID = Constance.GC_USERID;
                    projectLogin.LoginDate = DateTime.Now;
                    projectLogin.Store();
                }
                catch (Exception)
                {
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmBatchSelection_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                btnOK_Click(sender, e);
            }
        }

        #endregion

        #region Help Methods

        public void LoadBatch()
        {
            List<batchmaster> BatchList = new List<batchmaster>();
            BatchList = objBatchmaster.LoadBatch(Process);
            if (BatchList.Count > 0)
            {
                lstBatches.DisplayMember = "Name";
                lstBatches.ValueMember = "ID";
                lstBatches.DataSource = BatchList;
            }
        }

        #endregion
    }
}
