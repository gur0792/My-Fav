﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DataAccessLayer.ProjectDB;
using DataAccessLayer.GlobalDB;
using App.Base;

namespace Healthtel_MRT
{
    public partial class frmReport : Form
    {
        public frmReport()
        {
            InitializeComponent();
        }

        #region Varibales

        string ReportType;
        batchmaster objBatchMaster = new batchmaster();
        imagemaster objImageMaster = new imagemaster();

        #endregion

        #region Property Variables

        public string Report
        {
            get { return ReportType; }

            set { ReportType = value; }
        }
        #endregion

        #region HelpMethods

        public void report()
        {
            if (ReportType.ToUpper() == "BATCHWISE")
            {
                BatchWiseRpt();
            }
            else if (ReportType.ToUpper() == "USERWISE")
            {
                grpDate.Visible = true;
                UserWiseRpt();
            }
            else if (ReportType.ToUpper() == "USERWISEALL")
            {
                grpDate.Visible = true;
                UserWiseRptAll();
            }

            for (int col = 0; col <= dgvBatchWiseReport.Columns.Count - 1; col++)
            {
                dgvBatchWiseReport.Columns[col].Width = 120;
            }
            dgvBatchWiseReport.Columns[0].Frozen = true;
            dgvBatchWiseReport.Columns[1].Frozen = true;
        }

        private void BatchWiseRpt()
        {
            try
            {
                List<BatchwiseReport> BatchwiseRpt = new List<BatchwiseReport>();
                BatchwiseRpt = objBatchMaster.BatchwiseReport();

                dgvBatchWiseReport.DataSource = BatchwiseRpt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void UserWiseRpt()
        {
            try
            {
                //List<UserWiseReport> UserwiseRpt = new List<UserWiseReport>();
                //UserwiseRpt = objImageMaster.UserwiseReport(Convert.ToDateTime(txtfromdate.Text.Trim()), Convert.ToDateTime(txttodate.Text.Trim()));

                List<IndividualUserReport> UserwiseRptIndi = new List<IndividualUserReport>();
                UserwiseRptIndi = objImageMaster.UserwiseReport_Ind(Convert.ToDateTime(txtfromdate.Text.Trim()), Convert.ToDateTime(txttodate.Text.Trim()), Constance.GC_USERID);

                dgvBatchWiseReport.DataSource = UserwiseRptIndi;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void UserWiseRptAll()
        {
            try
            {
                List<UserWiseReport> UserwiseRpt = new List<UserWiseReport>();
                UserwiseRpt = objImageMaster.UserwiseReport(Convert.ToDateTime(txtfromdate.Text.Trim()), Convert.ToDateTime(txttodate.Text.Trim()));

                dgvBatchWiseReport.DataSource = UserwiseRpt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region Events




        private void frmBatchWiseReport_Load(object sender, EventArgs e)
        {
            if (ReportType.ToUpper() == "BATCHWISE")
            {
                this.Text = "Healthtel MRD : : Batchwise Report";
            }
            else if (ReportType.ToUpper() == "USERWISE")
            {
                this.Text = "Healthtel MRD : : Userwise Report";
            }

            txtfromdate.Text = string.Format("{0} 00:00", DateTime.Now.ToString("MM-dd-yyyy"));
            txttodate.Text = string.Format("{0} 23:59", DateTime.Now.ToString("MM-dd-yyyy"));
            report();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            report();
        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            report();
        }

        #endregion

    }
}
