﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using MySql.Data.MySqlClient;
using DataAccessLayer.ProjectDB;
using DataAccessLayer.GlobalDB;
using DataAccessLayer.ZipCodeDB;
using App.Base;

namespace Healthtel_MRT
{
    public partial class FrmKeying : Form
    {
        public FrmKeying()
        {
            InitializeComponent();

            //BarcodeWorker.DoWork += new DoWorkEventHandler(BarcodeWorker_DoWork);
            //BarcodeWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(BarcodeWorker_RunWorkerCompleted);
            ////BarcodeWorker.ProgressChanged += new ProgressChangedEventHandler(BarcodeWorker_ProgressChanged);
            //BarcodeWorker.WorkerReportsProgress = true;
            //BarcodeWorker.WorkerSupportsCancellation = true;

            AddressWorker.DoWork += new DoWorkEventHandler(AddressWorker_DoWork);
            AddressWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(AddressWorker_RunWorkerCompleted);
            //AddressWorker.ProgressChanged += new ProgressChangedEventHandler(AddressWorker_ProgressChanged);
            AddressWorker.WorkerReportsProgress = true;
            AddressWorker.WorkerSupportsCancellation = true;

        }

        #region Global Variables
        //login LoggedUsers = new batchmaster().getLoginUser();
        batchmaster objBatchmaster = new batchmaster();
        imagemaster objImagemaster = new imagemaster();
        key1 objKey1 = new key1();
        key2 objKey2 = new key2();
        compareqc objCompareQC = new compareqc();

        imagemaster Image = new imagemaster();
        key1 getkey1Data = new key1();
        key2 getkey2Data = new key2();
        compareqc getCompareqcData = new compareqc();

        long lngBatchID;
        long lngImageID;
        int intBatchType;
        string strImagePath;
        int totRecs;
        int RemRecs;
        int FinRecs;
        string ProcessType;
        string strSQL;
        DataSet dsKeyData;
        DataSet dsKey1;
        DataSet dskey;
        string strImageSize;
        string strImageFit;
        int iHScrol = 0;
        int iVScrol = 0;

        bool bCtrl = false;
        bool bAlt = false;
        bool bShift = false;
        bool bImageLoad = false;
        AutoCompleteStringCollection citycollection = new AutoCompleteStringCollection();
        bool bPreview = true;
        DataSet dsCities;
        AutoCompleteStringCollection AddressList = new AutoCompleteStringCollection();
        private BackgroundWorker BarcodeWorker = new BackgroundWorker();
        private BackgroundWorker AddressWorker = new BackgroundWorker();
        bool loadaddress = false;

        System.Collections.ArrayList barcodes = new System.Collections.ArrayList();
        //DateTime dtStart = DateTime.Now;
        int iScans = 100;
        string barcode = "";
        System.Drawing.Bitmap bmp;

        #endregion

        #region Global Fields For Controls
        public const string GC_FIELDS_FIRSTNAME = "txtFirstName";
        public const string GC_FIELDS_LASTNAME = "txtLastName";
        public const string GC_FIELDS_ZIP = "txtZip";
        public const string GC_FIELDS_CITY = "cmbCity";
        public const string GC_FIELDS_STATE = "txtState";
        public const string GC_FIELDS_ADDRESS1 = "txtAddress1";
        public const string GC_FIELDS_ADDRESS2 = "txtAddress2";
        public const string GC_FIELDS_PHONE = "txtPhoneNo";
        public const string GC_FIELDS_MEMBERID = "txtMemberID";
        public const string GC_FIELDS_BARCODE = "txtBarcode";
        public const string GC_FIELDS_DOSmm = "txtDOSmm";
        public const string GC_FIELDS_DOSdd = "txtDOSdd";
        public const string GC_FIELDS_DOSyy = "txtDOSyy";
        public const string GC_FIELDS_DOBmm = "txtDOBmm";
        public const string GC_FIELDS_DOBdd = "txtDOBdd";
        public const string GC_FIELDS_DOByy = "txtDOByy";
        public const string GC_FIELDS_CHKPROVIDERSIGNATURE = "chkProviderSignature";
        public const string GC_FIELDS_CHKMOTOPTIN = "chkMotOptin";
        public const string GC_FIELDS_CHKADDRESSUPDATE = "chkAddressUpdate";
        public const string GC_FIELDS_FORMSCAN = "txtFormScan";
        public const string GC_FIELDS_CHKHBA1C = "chkHbA1c";
        public const string GC_FIELDS_CHKLDLC = "chkLDLC";
        public const string GC_FIELDS_CHKMICROALBUMIN = "chkMicroalbumin";
        public const string GC_FIELDS_CMBFORMSCANDATAS = "cmbFormScanDatas";
        #endregion

        #region Property Variables

        public long BatchID
        {
            get { return lngBatchID; }

            set { lngBatchID = value; }
        }

        public string Process
        {
            get { return ProcessType; }

            set { ProcessType = value; }
        }

        public int BatchType
        {
            get { return intBatchType; }

            set { intBatchType = value; }
        }

        #endregion

        #region help Methods

        private bool txtKeyPress(object Sender, System.Windows.Forms.KeyPressEventArgs e, Control ObjControl)
        {
            try
            {
                if ((ObjControl is TextBox) || (ObjControl is ComboBox))
                {
                    e.KeyChar = char.ToUpper(e.KeyChar);

                    switch (ObjControl.Name)
                    {
                        case GC_FIELDS_FIRSTNAME:
                        case GC_FIELDS_LASTNAME:
                        case GC_FIELDS_STATE:
                        case GC_FIELDS_CITY:
                        case GC_FIELDS_CMBFORMSCANDATAS:
                            if (char.IsLetter(e.KeyChar) || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back) || e.KeyChar == '-' || char.IsWhiteSpace(e.KeyChar) || char.IsPunctuation(e.KeyChar) || char.IsSymbol(e.KeyChar) || e.KeyChar == '_')
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;

                        case GC_FIELDS_ZIP:                 
                        case GC_FIELDS_DOSmm:
                        case GC_FIELDS_DOSdd:
                        case GC_FIELDS_DOSyy:
                        case GC_FIELDS_DOBmm:
                        case GC_FIELDS_DOBdd:
                        case GC_FIELDS_DOByy:
                        case GC_FIELDS_BARCODE:
                            if (char.IsDigit(e.KeyChar) || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back) || char.IsWhiteSpace(e.KeyChar) ||  char.IsSymbol(e.KeyChar))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;

                        case GC_FIELDS_PHONE:
                            if (char.IsDigit(e.KeyChar) || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back) || char.IsWhiteSpace(e.KeyChar) || char.IsPunctuation(e.KeyChar) || char.IsSymbol(e.KeyChar) || e.KeyChar == '/')
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;

                        case GC_FIELDS_ADDRESS1:
                        case GC_FIELDS_ADDRESS2:
                        case GC_FIELDS_MEMBERID:
                            if (char.IsLetter(e.KeyChar) || char.IsNumber(e.KeyChar) || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back) || e.KeyChar == '-' || e.KeyChar == '#' || e.KeyChar == '&' || e.KeyChar == '/' || char.IsPunctuation(e.KeyChar) || char.IsSymbol(e.KeyChar) || char.IsWhiteSpace(e.KeyChar) || e.KeyChar == '!' || e.KeyChar == '#' || e.KeyChar == '_')
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;

                        case GC_FIELDS_FORMSCAN:
                            if (e.KeyChar == 'A' || e.KeyChar == 'B' || e.KeyChar == 'C' || e.KeyChar == 'D' || e.KeyChar == 'E' || e.KeyChar == 'F' || e.KeyChar == 'G' || e.KeyChar == 'H' || e.KeyChar == 'M' || e.KeyChar == 'L' || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;
                    }


                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private bool txtChanged(object Sender, System.EventArgs e, Control ObjControl)
        {
            try
            {
                if ((ObjControl is TextBox) || (ObjControl is ComboBox) || (ObjControl is CheckBox))
                {
                    switch (ObjControl.Name)
                    {
                        case GC_FIELDS_FIRSTNAME:
                            if (txtFirstName.TextLength == txtFirstName.MaxLength)
                            {
                                txtLastName.Focus();
                            }
                            break;
                        case GC_FIELDS_LASTNAME:
                            if (txtLastName.TextLength == txtLastName.MaxLength)
                            {
                                txtZip.Focus();
                            }
                            break;
                        case GC_FIELDS_ZIP:
                            cmbCity.Items.Clear();
                            cmbCity.Text = "";
                            txtState.Clear();
                            if (txtAddress1.AutoCompleteCustomSource.Count > 0) { txtAddress1.AutoCompleteCustomSource.Clear(); }
                            if (txtZip.TextLength == txtZip.MaxLength)
                            {
                                cmbCity.Focus();
                            }
                            loadaddress = true;
                            break;
                        case GC_FIELDS_CITY:
                            if (cmbCity.Text.Length == cmbCity.MaxLength)
                            {
                                txtState.Focus();
                            }
                            break;
                        case GC_FIELDS_STATE:
                            if (txtState.TextLength == txtState.MaxLength)
                            {
                                txtAddress1.Focus();
                            }
                            break;
                        case GC_FIELDS_ADDRESS1:
                            if (txtAddress1.TextLength == txtAddress1.MaxLength)
                            {
                                txtAddress2.Focus();
                            }
                            break;
                        case GC_FIELDS_ADDRESS2:
                            if (txtAddress2.TextLength == txtAddress2.MaxLength)
                            {
                                txtPhoneNo.Focus();
                            }
                            break;
                        case GC_FIELDS_PHONE:
                            if (txtPhoneNo.TextLength == txtPhoneNo.MaxLength)
                            {
                                txtMemberID.Focus();
                            }
                            break;
                        case GC_FIELDS_MEMBERID:
                            if (txtMemberID.TextLength == txtMemberID.MaxLength)
                            {
                                txtBarcode.Focus();
                            }
                            break;
                        case GC_FIELDS_BARCODE:
                            if (txtBarcode.TextLength == txtBarcode.MaxLength)
                            {
                                txtDOSmm.Focus();
                            }
                            break;
                        case GC_FIELDS_DOSmm:
                            if (txtDOSmm.TextLength == txtDOSmm.MaxLength)
                            {
                                txtDOSdd.Focus();
                            }
                            break;
                        case GC_FIELDS_DOSdd:
                            if (txtDOSdd.TextLength == txtDOSdd.MaxLength)
                            {
                                txtDOSyy.Focus();
                            }
                            break;
                        case GC_FIELDS_DOSyy:
                            if (txtDOSyy.TextLength == txtDOSyy.MaxLength)
                            {
                                txtDOBmm.Focus();
                            }
                            break;
                        case GC_FIELDS_DOBmm:
                            if (txtDOBmm.TextLength == txtDOBmm.MaxLength)
                            {
                                txtDOBdd.Focus();
                            }
                            break;
                        case GC_FIELDS_DOBdd:
                            if (txtDOBdd.TextLength == txtDOBdd.MaxLength)
                            {
                                txtDOByy.Focus();
                            }
                            break;
                        case GC_FIELDS_DOByy:
                            if (txtDOByy.TextLength == txtDOByy.MaxLength)
                            {
                                chkAddressUpdate.Focus();
                            }
                            break;
                        case GC_FIELDS_CHKADDRESSUPDATE:
                            if (chkAddressUpdate.Checked == true)
                            {
                                chkProviderSignature.Focus();
                            }
                            break;
                        case GC_FIELDS_CHKPROVIDERSIGNATURE:
                            if (chkProviderSignature.Checked == true)
                            {
                                chkMotOptin.Focus();
                            }
                            break;
                        case GC_FIELDS_CHKMOTOPTIN:
                            if (chkMotOptin.Checked == true)
                            {
                                txtFormScan.Focus();
                            }
                            break;
                        case GC_FIELDS_FORMSCAN:
                            //cmbFormScanDatas.Items.Clear();
                            //cmbFormScanDatas.Visible = false;
                            //grpFormScanDetails.Visible = false;
                            //chkHbA1c.Checked = false;
                            //chkLDLC.Checked = false;
                            //chkMicroalbumin.Checked = false;
                            FormScanChanges();
                            break;
                        case GC_FIELDS_CHKHBA1C:
                            if (chkHbA1c.Checked == true)
                            {
                                chkLDLC.Focus();
                            }
                            break;
                        case GC_FIELDS_CHKLDLC:
                            if (chkLDLC.Checked == true)
                            {
                                chkMicroalbumin.Focus();
                            }
                            break;
                        case GC_FIELDS_CHKMICROALBUMIN:
                            if (chkMicroalbumin.Checked == true)
                            {
                                cmbFormScanDatas.Focus();
                            }
                            break;
                        case GC_FIELDS_CMBFORMSCANDATAS:
                            if (cmbFormScanDatas.Text.Length == cmbFormScanDatas.MaxLength)
                            {
                                btnSave.Focus();
                            }
                            break;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private bool txtEnter(object Sender, System.EventArgs e, Control ObjControl)
        {
            try
            {
                if ((ObjControl is TextBox) || (ObjControl is ComboBox) || (ObjControl is CheckBox))
                {
                    Imagefit(ObjControl);
                    switch (ObjControl.Name)
                    {
                        case GC_FIELDS_FIRSTNAME:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.First_Name; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.First_Name; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.First_Name; }
                            }
                            break;

                        case GC_FIELDS_LASTNAME:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Last_Name; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Last_Name; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Last_Name; }
                            }
                            break;

                        case GC_FIELDS_ZIP:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Zip; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Zip; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Zip; }
                            }
                            break;

                        case GC_FIELDS_CITY:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.City; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.City; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.City; }
                            }
                            break;

                        case GC_FIELDS_STATE:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.State; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.State; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.State; }
                            }
                            break;

                        case GC_FIELDS_ADDRESS1:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Address1; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Address1; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Address1; }
                            }

                            //if (!string.IsNullOrEmpty(txtZip.Text.Trim()) && !string.IsNullOrEmpty(txtState.Text.Trim()))
                            //{
                            //    AddressList = Zipcode.AddressListBYZipCode(txtZip.Text.Trim(), txtState.Text.Trim());
                            //    if (AddressList.Count > 0)
                            //    {
                            //        txtAddress1.AutoCompleteCustomSource = AddressList;
                            //    }
                            //}

                            if (loadaddress == true)
                            {
                                loadaddress = false;
                                if (!AddressWorker.IsBusy)
                                {
                                    AddressWorker.RunWorkerAsync();
                                }
                            }
                            break;

                        case GC_FIELDS_ADDRESS2:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Address2; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Address2; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Address2; }
                            }
                            break;

                        case GC_FIELDS_PHONE:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Phone_No; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Phone_No; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Phone_No; }
                            }
                            break;

                        case GC_FIELDS_MEMBERID:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.MemberId; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.MemberId; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.MemberId; }
                            }
                            break;

                        case GC_FIELDS_BARCODE:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Barcode; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Barcode; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Barcode; }
                            }
                            break;

                        case GC_FIELDS_DOSmm:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.DOSmm; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.DOSmm; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.DOSmm; }
                            }
                            break;

                        case GC_FIELDS_DOSdd:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.DOSdd; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.DOSdd; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.DOSdd; }
                            }
                            break;

                        case GC_FIELDS_DOSyy:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.DOSyy; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.DOSyy; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.DOSyy; }
                            }
                            break;

                        case GC_FIELDS_DOBmm:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.DOBmm; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.DOBmm; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.DOBmm; }
                            }
                            break;

                        case GC_FIELDS_DOBdd:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.DOBdd; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.DOBdd; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.DOBdd; }
                            }
                            break;

                        case GC_FIELDS_DOByy:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.DOByy; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.DOByy; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.DOByy; }
                            }
                            break;

                        case GC_FIELDS_CHKADDRESSUPDATE:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.AddressUpdate; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.AddressUpdate; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.AddressUpdate; }
                            }
                            break;

                        case GC_FIELDS_CHKPROVIDERSIGNATURE:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.ProviderSignature; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.ProviderSignature; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.ProviderSignature; }
                            }
                            break;

                        case GC_FIELDS_CHKMOTOPTIN:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.MotOptin; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.MotOptin; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.MotOptin; }
                            }
                            break;

                        case GC_FIELDS_FORMSCAN:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.FormScan; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.FormScan; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.FormScan; }
                            }
                            break;

                        case GC_FIELDS_CMBFORMSCANDATAS:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.FormScanData; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.FormScanData; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.FormScanData; }
                            }
                            break;

                        case GC_FIELDS_CHKHBA1C:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.HbA1c; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.HbA1c; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.HbA1c; }
                            }
                            break;

                        case GC_FIELDS_CHKLDLC:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.LDL_C; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.LDL_C; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.LDL_C; }
                            }
                            break;

                        case GC_FIELDS_CHKMICROALBUMIN:
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Microalbumin; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Microalbumin; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Microalbumin; }
                            }
                            break;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void ClearInfo()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            txtZip.Clear();
            cmbCity.Items.Clear();
            txtState.Clear();
            txtAddress1.Clear();
            txtAddress2.Clear();
            txtPhoneNo.Clear();
            txtMemberID.Clear();
            txtDOSmm.Clear();
            txtDOSdd.Clear();
            txtDOSyy.Clear();
            txtDOBmm.Clear();
            txtDOBdd.Clear();
            txtDOByy.Clear();
            chkAddressUpdate.Checked = false;
            chkProviderSignature.Checked = false;
            chkMotOptin.Checked = false;
            txtFormScan.Clear();
            cmbFormScanDatas.Items.Clear();
            cmbFormScanDatas.Text = "";
            chkHbA1c.Checked = false;
            chkLDLC.Checked = false;
            chkMicroalbumin.Checked = false;
            txtKey1User.Clear();
            txtKey1Data.Clear();
            txtKey2User.Clear();
            txtKey2Data.Clear();
            IGImageViewer.ImageClear();
            txtBarcode.Clear();
            loadaddress = true;
        }

        private long TotalKeystrokes()
        {
            long lngCount = 0;
            lngCount = 0;

            lngCount += txtFirstName.TextLength;
            lngCount += txtLastName.TextLength;
            lngCount += txtZip.TextLength;
            lngCount += cmbCity.Text.Length;
            lngCount += txtState.TextLength;
            lngCount += txtAddress1.TextLength;
            lngCount += txtAddress2.TextLength;
            lngCount += txtPhoneNo.TextLength;
            lngCount += txtMemberID.Text.Length;
            lngCount += txtDOSmm.TextLength;
            lngCount += txtDOSdd.TextLength;
            lngCount += txtDOSyy.TextLength;
            lngCount += txtDOBmm.TextLength;
            lngCount += txtDOBdd.TextLength;
            lngCount += txtDOByy.TextLength;
            if (chkProviderSignature.Checked == true) { lngCount += 1; } else { lngCount += 0; }
            if (chkMotOptin.Checked == true) { lngCount += 1; } else { lngCount += 0; }
            if (chkAddressUpdate.Checked == true) { lngCount += 1; } else { lngCount += 0; }
            lngCount += txtFormScan.TextLength;
            lngCount += cmbFormScanDatas.Text.Length;
            if (chkHbA1c.Checked == true) { lngCount += 1; } else { lngCount += 0; }
            if (chkLDLC.Checked == true) { lngCount += 1; } else { lngCount += 0; }
            if (chkMicroalbumin.Checked == true) { lngCount += 1; } else { lngCount += 0; }
            lngCount += txtBarcode.Text.Length;
            return lngCount;
        }

        private bool LoadImage()
        {
            //bool functionReturnValue = false;
            try
            {
                ClearInfo();
                if (lngBatchID > 0)
                {

                    Image = objImagemaster.LoadImage(Process, lngBatchID, Constance.GC_USERID);
                    if (Image == null)
                    {
                        MessageBox.Show("Batch Completed");
                        objBatchmaster.UpdateBatchmaster(lngBatchID.ToInt(), Process);
                        this.Close();
                        return false;
                    }

                    lngImageID = Image.ImageID;
                    IGImageViewer.ImageName = Image.ImagePath;
                    IGImageViewer.LoadImage();
                    IGImageViewer.Refresh();

                    //if (!BarcodeWorker.IsBusy)
                    //{
                    //    BarcodeWorker.RunWorkerAsync();
                    //}

                    strImageSize = Interaction.GetSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageSize) + "";
                    if (strImageSize.LastIndexOf(",") > 0)
                    {
                        iHScrol = Convert.ToInt32((strImageSize.Substring(0, strImageSize.LastIndexOf(","))));
                        iVScrol = Convert.ToInt32(strImageSize.Substring(strImageSize.LastIndexOf(",") + 1));
                        IGImageViewer.ImageSize = new System.Drawing.Size(iHScrol, iVScrol);
                    }

                    strImageFit = Interaction.GetSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageFit) + "";
                    if (strImageFit.LastIndexOf(",") > 0)
                    {
                        iHScrol = Convert.ToInt32(strImageFit.Substring(0, strImageFit.LastIndexOf(",")));
                        iVScrol = Convert.ToInt32(strImageFit.Substring(strImageFit.LastIndexOf(",") + 1));
                    }

                    IGImageViewer.MoveImage(iHScrol, iVScrol);
                    IGImageViewer.Refresh();

                    //if (Process.ToUpper() == "COMPAREQC")
                    if (Process.ToUpper() == "KEYQC")
                    {
                        RestoreInfo();
                        grpKeyData.Visible = true;
                    }

                    Constance.ImageInTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    int TotalRecord, FinishedRecord, RemainingRecord;
                    TotalRecord = FinishedRecord = RemainingRecord = 0;

                    objImagemaster.RecordStatus(Process, lngBatchID, ref TotalRecord, ref FinishedRecord, ref RemainingRecord, intBatchType);
                    this.stsUser.Text = "User Name : " + Constance.GC_USERNAME;
                    this.stsTotRecs.Text = "Total Recs : " + TotalRecord;
                    this.stsFinRecs.Text = "Finished Rec : " + FinishedRecord;
                    this.stsRemRecs.Text = "Remine Recs: " + RemainingRecord;
                    this.stsDate.Text = "Date : " + DateAndTime.Now.ToString("dd-MMMM-yyyy");

                    txtFirstName.Focus();
                    return true;
                }
                else
                {
                    Interaction.MsgBox("Invalid Batch Selection", MsgBoxStyle.Information, Constance.gstrappTitle);
                    this.Close();
                    return false;
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            return true;
        }

        private bool ValidateInfo()
        {
            if (TotalKeystrokes() <= 0)
            {
                if (MessageBox.Show("Do you want to save Blank records?", "Healthtel MRD", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }

        private bool SaveInfo()
        {
            try
            {
                string ImageNumber;
                int iPos;
                string ImagePath = Image.ImagePath; ;
                string BarcodeVal = string.Empty;
                if (!string.IsNullOrEmpty(ImagePath))
                {
                    if (ImagePath.LastIndexOf("\\") >= ImagePath.Length - 1 & ImagePath.Length > 0)
                    {
                        ImagePath = ImagePath.Substring(0, ImagePath.Length - 1);
                    }
                    iPos = ImagePath.LastIndexOf("\\");
                    ImagePath = ImagePath.Substring(iPos + 1, ImagePath.Length - (iPos + 1));
                    BarcodeVal = ImagePath.Substring(0, ImagePath.IndexOf("."));
                }

                if (Process == Constance.GC_PROCESS_KEY1)
                {
                    key1 checkkey1 = new key1().isImageIDExists(lngImageID);
                    int Key1ID = (checkkey1 == null) ? 0 : checkkey1.Key1ID;
                    key1 objkey1 = new key1(Key1ID);
                    objkey1.ImageId = lngImageID.ToInt();
                    objkey1.Image_Number = ImagePath;
                    objkey1.First_Name = txtFirstName.Text.Trim();
                    objkey1.Last_Name = txtLastName.Text.Trim();
                    objkey1.Zip = txtZip.Text.Trim();
                    objkey1.City = cmbCity.Text.Trim();
                    objkey1.State = txtState.Text.Trim();
                    objkey1.Address1 = txtAddress1.Text.Trim();
                    objkey1.Address2 = txtAddress2.Text.Trim();
                    objkey1.Phone_No = txtPhoneNo.Text.Trim();
                    objkey1.MemberId = txtMemberID.Text.Trim();
                    objkey1.Barcode = txtBarcode.Text.Trim();
                    objkey1.DOSmm = txtDOSmm.Text.Trim();
                    objkey1.DOSdd = txtDOSdd.Text.Trim();
                    objkey1.DOSyy = txtDOSyy.Text.Trim();
                    objkey1.DOBmm = txtDOBmm.Text.Trim();
                    objkey1.DOBdd = txtDOBdd.Text.Trim();
                    objkey1.DOByy = txtDOByy.Text.Trim();
                    if (chkProviderSignature.Checked == true) { objkey1.ProviderSignature = "1"; } else { objkey1.ProviderSignature = "0"; }
                    if (chkAddressUpdate.Checked == true) { objkey1.AddressUpdate = "1"; } else { objkey1.AddressUpdate = "0"; }
                    if (chkMotOptin.Checked == true) { objkey1.MotOptin = "1"; } else { objkey1.MotOptin = "0"; }
                    objkey1.FormScan = txtFormScan.Text.Trim();
                    if (txtFormScan.Text.Trim() == "H")
                    {
                        if (chkHbA1c.Checked == true) { objkey1.HbA1c = "1"; } else { objkey1.HbA1c = "0"; }
                        if (chkLDLC.Checked == true) { objkey1.LDL_C = "1"; } else { objkey1.LDL_C = "0"; }
                        if (chkMicroalbumin.Checked == true) { objkey1.Microalbumin = "1"; } else { objkey1.Microalbumin = "0"; }
                        //objkey1.FormScanData = "";
                    }
                    else
                    {
                        objkey1.HbA1c = "";
                        objkey1.LDL_C = "";
                        objkey1.Microalbumin = "";
                        //objkey1.FormScanData = cmbFormScanDatas.Text.Trim();
                    }
                    if (cmbFormScanDatas.Text == "Amazon.com")
                    { objkey1.FormScanData = "1"; }
                    else if (cmbFormScanDatas.Text == "Burlington")
                    { objkey1.FormScanData = "2"; }
                    else if (cmbFormScanDatas.Text == "GameStop")
                    { objkey1.FormScanData = "3"; }
                    else if (cmbFormScanDatas.Text == "iTunes")
                    { objkey1.FormScanData = "4"; }
                    else if (cmbFormScanDatas.Text == "Old Navy")
                    { objkey1.FormScanData = "5"; }
                    else if (cmbFormScanDatas.Text == "Target")
                    { objkey1.FormScanData = "6"; }
                    else if (cmbFormScanDatas.Text == "Walgreens")
                    { objkey1.FormScanData = "7"; }
                    else if (cmbFormScanDatas.Text == "Walmart")
                    { objkey1.FormScanData = "8"; }
                    else if (cmbFormScanDatas.Text == "Multiple (X)" || cmbFormScanDatas.Text == "")
                    { objkey1.FormScanData = "X"; }
                    objkey1.KeyStroke = TotalKeystrokes().ToInt();

                    objkey1.Store();

                    imagemaster updateImagemasterkey1 = new imagemaster(lngImageID.ToInt());
                    updateImagemasterkey1.Key1 = 2;
                    updateImagemasterkey1.Store();

                    Constance.ImageOutTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                }
                else if (Process == Constance.GC_PROCESS_KEY2)
                {
                    key2 checkkey2 = new key2().isImageIDExists(lngImageID);
                    int Key2ID = (checkkey2 == null) ? 0 : checkkey2.Key2ID;
                    key2 objkey2 = new key2(Key2ID);
                    objkey2.ImageId = lngImageID.ToInt();
                    objkey2.Image_Number = ImagePath;
                    objkey2.First_Name = txtFirstName.Text.Trim();
                    objkey2.Last_Name = txtLastName.Text.Trim();
                    objkey2.Zip = txtZip.Text.Trim();
                    objkey2.City = cmbCity.Text.Trim();
                    objkey2.State = txtState.Text.Trim();
                    objkey2.Address1 = txtAddress1.Text.Trim();
                    objkey2.Address2 = txtAddress2.Text.Trim();
                    objkey2.Phone_No = txtPhoneNo.Text.Trim();
                    objkey2.MemberId = txtMemberID.Text.Trim();
                    objkey2.Barcode =txtBarcode.Text.Trim();
                    objkey2.DOSmm = txtDOSmm.Text.Trim();
                    objkey2.DOSdd = txtDOSdd.Text.Trim();
                    objkey2.DOSyy = txtDOSyy.Text.Trim();
                    objkey2.DOBmm = txtDOBmm.Text.Trim();
                    objkey2.DOBdd = txtDOBdd.Text.Trim();
                    objkey2.DOByy = txtDOByy.Text.Trim();
                    if (chkProviderSignature.Checked == true) { objkey2.ProviderSignature = "1"; } else { objkey2.ProviderSignature = "0"; }
                    if (chkMotOptin.Checked == true) { objkey2.MotOptin = "1"; } else { objkey2.MotOptin = "0"; }
                    if (chkAddressUpdate.Checked == true) { objkey2.AddressUpdate = "1"; } else { objkey2.AddressUpdate = "0"; }
                    objkey2.FormScan = txtFormScan.Text.Trim();
                    if (txtFormScan.Text.Trim() == "H")
                    {
                        if (chkHbA1c.Checked == true) { objkey2.HbA1c = "1"; } else { objkey2.HbA1c = "0"; }
                        if (chkLDLC.Checked == true) { objkey2.LDL_C = "1"; } else { objkey2.LDL_C = "0"; }
                        if (chkMicroalbumin.Checked == true) { objkey2.Microalbumin = "1"; } else { objkey2.Microalbumin = "0"; }
                        //objkey2.FormScanData = "";
                    }
                    else
                    {
                        objkey2.HbA1c = "";
                        objkey2.LDL_C = "";
                        objkey2.Microalbumin = "";
                        //objkey2.FormScanData = cmbFormScanDatas.Text.Trim();
                    }
                    if (cmbFormScanDatas.Text == "Amazon.com")
                    { objkey2.FormScanData = "1"; }
                    else if (cmbFormScanDatas.Text == "Burlington")
                    { objkey2.FormScanData = "2"; }
                    else if (cmbFormScanDatas.Text == "GameStop")
                    { objkey2.FormScanData = "3"; }
                    else if (cmbFormScanDatas.Text == "iTunes")
                    { objkey2.FormScanData = "4"; }
                    else if (cmbFormScanDatas.Text == "Old Navy")
                    { objkey2.FormScanData = "5"; }
                    else if (cmbFormScanDatas.Text == "Target")
                    { objkey2.FormScanData = "6"; }
                    else if (cmbFormScanDatas.Text == "Walgreens")
                    { objkey2.FormScanData = "7"; }
                    else if (cmbFormScanDatas.Text == "Walmart")
                    { objkey2.FormScanData = "8"; }
                    else if (cmbFormScanDatas.Text == "Multiple (X)" || cmbFormScanDatas.Text == "")
                    { objkey2.FormScanData = "X"; }
                    objkey2.KeyStroke = TotalKeystrokes().ToInt();

                    objkey2.Store();

                    imagemaster updateImagemasterkey2 = new imagemaster(lngImageID.ToInt());
                    updateImagemasterkey2.Key2 = 2;
                    updateImagemasterkey2.Store();

                    Constance.ImageOutTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                }
                else if (Process == Constance.GC_PROCESS_KEYQC)
                {
                    compareqc checkcompareqc = new compareqc().isImageIDExists(lngImageID);
                    int CompareQCID = (checkcompareqc == null) ? 0 : checkcompareqc.CompareQCID;
                    compareqc objcompareqc = new compareqc(CompareQCID);
                    objcompareqc.ImageId = lngImageID.ToInt();
                    objcompareqc.Image_Number = ImagePath;
                    objcompareqc.First_Name = txtFirstName.Text.Trim();
                    objcompareqc.Last_Name = txtLastName.Text.Trim();
                    objcompareqc.Zip = txtZip.Text.Trim();
                    objcompareqc.City = cmbCity.Text.Trim();
                    objcompareqc.State = txtState.Text.Trim();
                    objcompareqc.Address1 = txtAddress1.Text.Trim();
                    objcompareqc.Address2 = txtAddress2.Text.Trim();
                    objcompareqc.Phone_No = txtPhoneNo.Text.Trim();
                    objcompareqc.MemberId = txtMemberID.Text.Trim();
                    objcompareqc.Barcode = txtBarcode.Text.Trim();
                    objcompareqc.DOSmm = txtDOSmm.Text.Trim();
                    objcompareqc.DOSdd = txtDOSdd.Text.Trim();
                    objcompareqc.DOSyy = txtDOSyy.Text.Trim();
                    objcompareqc.DOBmm = txtDOBmm.Text.Trim();
                    objcompareqc.DOBdd = txtDOBdd.Text.Trim();
                    objcompareqc.DOByy = txtDOByy.Text.Trim();
                    if (chkProviderSignature.Checked == true) { objcompareqc.ProviderSignature = "1"; } else { objcompareqc.ProviderSignature = "0"; }
                    if (chkMotOptin.Checked == true) { objcompareqc.MotOptin = "1"; } else { objcompareqc.MotOptin = "0"; }
                    if (chkAddressUpdate.Checked == true) { objcompareqc.AddressUpdate = "1"; } else { objcompareqc.AddressUpdate = "0"; }
                    objcompareqc.FormScan = txtFormScan.Text.Trim();
                    objcompareqc.FormScanData = cmbFormScanDatas.Text.Trim();
                    if (txtFormScan.Text.Trim() == "H")
                    {
                        if (chkHbA1c.Checked == true) { objcompareqc.HbA1c = "1"; } else { objcompareqc.HbA1c = "0"; }
                        if (chkLDLC.Checked == true) { objcompareqc.LDL_C = "1"; } else { objcompareqc.LDL_C = "0"; }
                        if (chkMicroalbumin.Checked == true) { objcompareqc.Microalbumin = "1"; } else { objcompareqc.Microalbumin = "0"; }
                        //objcompareqc.FormScanData = "";
                    }
                    else
                    {
                        objcompareqc.HbA1c = "";
                        objcompareqc.LDL_C = "";
                        objcompareqc.Microalbumin = "";
                        //objcompareqc.FormScanData = cmbFormScanDatas.Text.Trim();
                    }
                    if (cmbFormScanDatas.Text == "Amazon.com")
                    { objcompareqc.FormScanData = "1"; }
                    else if (cmbFormScanDatas.Text == "Burlington")
                    { objcompareqc.FormScanData = "2"; }
                    else if (cmbFormScanDatas.Text == "GameStop")
                    { objcompareqc.FormScanData = "3"; }
                    else if (cmbFormScanDatas.Text == "iTunes")
                    { objcompareqc.FormScanData = "4"; }
                    else if (cmbFormScanDatas.Text == "Old Navy")
                    { objcompareqc.FormScanData = "5"; }
                    else if (cmbFormScanDatas.Text == "Target")
                    { objcompareqc.FormScanData = "6"; }
                    else if (cmbFormScanDatas.Text == "Walgreens")
                    { objcompareqc.FormScanData = "7"; }
                    else if (cmbFormScanDatas.Text == "Walmart")
                    { objcompareqc.FormScanData = "8"; }
                    else if (cmbFormScanDatas.Text == "Multiple (X)" || cmbFormScanDatas.Text == "")
                    { objcompareqc.FormScanData = "X"; }
                    objcompareqc.KeyStroke = TotalKeystrokes().ToInt();

                    objcompareqc.Store();

                    imagemaster updateImagemastercompareqc = new imagemaster(lngImageID.ToInt());
                    updateImagemastercompareqc.KeyQC = 2;
                    updateImagemastercompareqc.Store();

                    Constance.ImageOutTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                }

                worklog SaveWorklog = new worklog();
                SaveWorklog.UserID = Constance.GC_USERID;
                SaveWorklog.ImageID = lngImageID.ToInt();
                SaveWorklog.In = Convert.ToDateTime(Constance.ImageInTime);
                SaveWorklog.Out = Convert.ToDateTime(Constance.ImageOutTime);
                SaveWorklog.Process = Process;
                SaveWorklog.EXE_Status = "";
                SaveWorklog.Store();

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void RestoreInfo()
        {
            try
            {
                bool key1chkHbA1c, key1chkLDLC, key1chkMicroalbumin, key1chkAddressUpdate, key1chkProviderSignature, key1chkMotOptin, key2chkHbA1c, key2chkLDLC, key2chkMicroalbumin, key2chkAddressUpdate, key2chkProviderSignature, key2chkMotOptin;
                key1chkHbA1c = key1chkLDLC = key1chkMicroalbumin = key1chkAddressUpdate = key1chkProviderSignature = key1chkMotOptin = key2chkHbA1c = key2chkLDLC = key2chkMicroalbumin = key2chkAddressUpdate = key2chkProviderSignature = key2chkMotOptin = false;

                getCompareqcData = objCompareQC.CompareQCDatas(lngImageID.ToInt());

                if (getCompareqcData == null)
                {
                    //getkey2Data = objKey2.Key2Datas(lngImageID.ToInt());
                    getkey1Data = objKey1.Key1Datas(lngImageID.ToInt());
                }
                //getkey1Data = objKey1.Key1Datas(lngImageID.ToInt());

                if (getCompareqcData != null)
                {
                    txtFirstName.Text = getCompareqcData.First_Name;
                    txtLastName.Text = getCompareqcData.Last_Name;
                    txtZip.Text = getCompareqcData.Zip;
                    cmbCity.Text = getCompareqcData.City;
                    txtState.Text = getCompareqcData.State;
                    txtAddress1.Text = getCompareqcData.Address1;
                    txtAddress2.Text = getCompareqcData.Address2;
                    txtPhoneNo.Text = getCompareqcData.Phone_No;
                    txtMemberID.Text = getCompareqcData.MemberId;
                    txtBarcode.Text = getCompareqcData.Barcode;
                    txtDOSmm.Text = getCompareqcData.DOSmm;
                    txtDOSdd.Text = getCompareqcData.DOSdd;
                    txtDOSyy.Text = getCompareqcData.DOSyy;
                    txtDOBmm.Text = getCompareqcData.DOBmm;
                    txtDOBdd.Text = getCompareqcData.DOBdd;
                    txtDOByy.Text = getCompareqcData.DOByy;
                    if (getCompareqcData.AddressUpdate == "1") { chkAddressUpdate.Checked = true; } else { chkAddressUpdate.Checked = false; }
                    if (getCompareqcData.ProviderSignature == "1") { chkProviderSignature.Checked = true; } else { chkProviderSignature.Checked = false; }
                    if (getCompareqcData.MotOptin == "1") { chkMotOptin.Checked = true; } else { chkMotOptin.Checked = false; }
                    txtFormScan.Text = getCompareqcData.FormScan;

                    if (getCompareqcData.FormScanData == "1")
                    { cmbFormScanDatas.Text = "Amazon.com"; }
                    else if (getCompareqcData.FormScanData == "2")
                    { cmbFormScanDatas.Text = "Burlington"; }
                    else if (getCompareqcData.FormScanData == "3")
                    { cmbFormScanDatas.Text = "GameStop"; }
                    else if (getCompareqcData.FormScanData == "4")
                    { cmbFormScanDatas.Text = "iTunes"; }
                    else if (getCompareqcData.FormScanData == "5")
                    { cmbFormScanDatas.Text = "Old Navy"; }
                    else if (getCompareqcData.FormScanData == "6")
                    { cmbFormScanDatas.Text = "Target"; }
                    else if (getCompareqcData.FormScanData == "7")
                    { cmbFormScanDatas.Text = "Walgreens"; }
                    else if (getCompareqcData.FormScanData == "8")
                    { cmbFormScanDatas.Text = "Walmart"; }
                    else if (getCompareqcData.FormScanData == "X")
                    { cmbFormScanDatas.Text = ""; }

                    //cmbFormScanDatas.Text = getCompareqcData.FormScanData;

                    if (getCompareqcData.HbA1c == "1") { chkHbA1c.Checked = true; } else { chkHbA1c.Checked = false; }
                    if (getCompareqcData.LDL_C == "1") { chkLDLC.Checked = true; } else { chkLDLC.Checked = false; }
                    if (getCompareqcData.Microalbumin == "1") { chkMicroalbumin.Checked = true; } else { chkMicroalbumin.Checked = false; }
                    txtKey1User.Text = getCompareqcData.UserName;
                }
                //else if (getkey2Data != null)
                //{
                //    txtFirstName.Text = getkey2Data.First_Name;
                //    txtLastName.Text = getkey2Data.Last_Name;
                //    txtZip.Text = getkey2Data.Zip;
                //    cmbCity.Text = getkey2Data.City;
                //    txtState.Text = getkey2Data.State;
                //    txtAddress1.Text = getkey2Data.Address1;
                //    txtAddress2.Text = getkey2Data.Address2;
                //    txtPhoneNo.Text = getkey2Data.Phone_No;
                //    txtMemberID.Text = getkey2Data.MemberId;
                //    txtBarcode.Text = getkey2Data.Barcode;
                //    txtDOSmm.Text = getkey2Data.DOSmm;
                //    txtDOSdd.Text = getkey2Data.DOSdd;
                //    txtDOSyy.Text = getkey2Data.DOSyy;
                //    txtDOBmm.Text = getkey2Data.DOBmm;
                //    txtDOBdd.Text = getkey2Data.DOBdd;
                //    txtDOByy.Text = getkey2Data.DOByy;
                //    if (getkey2Data.AddressUpdate == "1") { key2chkAddressUpdate = true; } else { key2chkAddressUpdate = false; }
                //    if (getkey2Data.ProviderSignature == "1") { key2chkProviderSignature = true; } else { key2chkProviderSignature = false; }
                //    if (getkey2Data.MotOptin == "1") { key2chkMotOptin = true; } else { key2chkMotOptin = false; }
                //    txtFormScan.Text = getkey2Data.FormScan;
                //    cmbFormScanDatas.Text = getkey2Data.FormScanData;
                //    if (getkey2Data.HbA1c == "1") { key2chkHbA1c = true; } else { key2chkHbA1c = false; }
                //    if (getkey2Data.LDL_C == "1") { key2chkLDLC = true; } else { key2chkLDLC = false; }
                //    if (getkey2Data.Microalbumin == "1") { key2chkMicroalbumin = true; } else { key2chkMicroalbumin = false; }
                //    txtKey2User.Text = getkey2Data.UserName;
                //}

                //if (getkey1Data != null)
                //{
                //    txtFirstName.Tag = getkey1Data.First_Name;
                //    txtLastName.Tag = getkey1Data.Last_Name;
                //    txtZip.Tag = getkey1Data.Zip;
                //    cmbCity.Tag = getkey1Data.City;
                //    txtState.Tag = getkey1Data.State;
                //    txtAddress1.Tag = getkey1Data.Address1;
                //    txtAddress2.Tag = getkey1Data.Address2;
                //    txtPhoneNo.Tag = getkey1Data.Phone_No;
                //    txtMemberID.Tag = getkey1Data.MemberId;
                //    txtBarcode.Tag = getkey1Data.Barcode;
                //    txtDOSmm.Tag = getkey1Data.DOSmm;
                //    txtDOSdd.Tag = getkey1Data.DOSdd;
                //    txtDOSyy.Tag = getkey1Data.DOSyy;
                //    txtDOBmm.Tag = getkey1Data.DOBmm;
                //    txtDOBdd.Tag = getkey1Data.DOBdd;
                //    txtDOByy.Tag = getkey1Data.DOByy;
                //    if (getkey1Data.AddressUpdate == "1") { key1chkAddressUpdate = true; } else { key1chkAddressUpdate = false; }
                //    if (getkey1Data.ProviderSignature == "1") { key1chkProviderSignature = true; } else { key1chkProviderSignature = false; }
                //    if (getkey1Data.MotOptin == "1") { key1chkMotOptin = true; } else { key1chkMotOptin = false; }
                //    txtFormScan.Tag = getkey1Data.FormScan;
                //    cmbFormScanDatas.Tag = getkey1Data.FormScanData;
                //    if (getkey1Data.HbA1c == "1") { key1chkHbA1c = true; } else { key1chkHbA1c = false; }
                //    if (getkey1Data.LDL_C == "1") { key1chkLDLC = true; } else { key1chkLDLC = false; }
                //    if (getkey1Data.Microalbumin == "1") { key1chkMicroalbumin = true; } else { key1chkMicroalbumin = false; }
                //    txtKey1User.Text = getkey1Data.UserName;
                //}

                else if (getkey1Data != null)
                {
                    txtFirstName.Text = getkey1Data.First_Name;
                    txtLastName.Text = getkey1Data.Last_Name;
                    txtZip.Text = getkey1Data.Zip;
                    cmbCity.Text = getkey1Data.City;
                    txtState.Text = getkey1Data.State;
                    txtAddress1.Text = getkey1Data.Address1;
                    txtAddress2.Text = getkey1Data.Address2;
                    txtPhoneNo.Text = getkey1Data.Phone_No;
                    txtMemberID.Text = getkey1Data.MemberId;
                    txtBarcode.Text = getkey1Data.Barcode;
                    txtDOSmm.Text = getkey1Data.DOSmm;
                    txtDOSdd.Text = getkey1Data.DOSdd;
                    txtDOSyy.Text = getkey1Data.DOSyy;
                    txtDOBmm.Text = getkey1Data.DOBmm;
                    txtDOBdd.Text = getkey1Data.DOBdd;
                    txtDOByy.Text = getkey1Data.DOByy;
                    if (getkey1Data.AddressUpdate == "1") { chkAddressUpdate.Checked = true; } else { chkAddressUpdate.Checked = false; }
                    if (getkey1Data.ProviderSignature == "1") { chkProviderSignature.Checked = true; } else { chkProviderSignature.Checked = false; }
                    if (getkey1Data.MotOptin == "1") { chkMotOptin.Checked = true; } else { chkMotOptin.Checked = false; }
                    txtFormScan.Text = getkey1Data.FormScan;

                    if (getkey1Data.FormScanData == "1")
                    { cmbFormScanDatas.Text = "Amazon.com"; }
                    else if (getkey1Data.FormScanData == "2")
                    { cmbFormScanDatas.Text = "Burlington"; }
                    else if (getkey1Data.FormScanData == "3")
                    { cmbFormScanDatas.Text = "GameStop"; }
                    else if (getkey1Data.FormScanData == "4")
                    { cmbFormScanDatas.Text = "iTunes"; }
                    else if (getkey1Data.FormScanData == "5")
                    { cmbFormScanDatas.Text = "Old Navy"; }
                    else if (getkey1Data.FormScanData == "6")
                    { cmbFormScanDatas.Text = "Target"; }
                    else if (getkey1Data.FormScanData == "7")
                    { cmbFormScanDatas.Text = "Walgreens"; }
                    else if (getkey1Data.FormScanData == "8")
                    { cmbFormScanDatas.Text = "Walmart"; }
                    else if (getkey1Data.FormScanData == "X")
                    { cmbFormScanDatas.Text = ""; }

                    //cmbFormScanDatas.Text = getkey1Data.FormScanData;

                    if (getkey1Data.HbA1c == "1") { chkHbA1c.Checked = true; } else { chkHbA1c.Checked = false; }
                    if (getkey1Data.LDL_C == "1") { chkLDLC.Checked = true; } else { chkLDLC.Checked = false; }
                    if (getkey1Data.Microalbumin == "1") { chkMicroalbumin.Checked = true; } else { chkMicroalbumin.Checked = false; }
                    txtKey1User.Text = getkey1Data.UserName;
                }

                //if (txtFirstName.Text.ToUpper() == txtFirstName.Tag.ToString().ToUpper())
                //{
                //    txtFirstName.Enabled = false;
                //    txtFirstName.BackColor = Color.White;
                //}
                //else
                //{
                //    txtFirstName.Enabled = true;
                //    txtFirstName.Text = "";
                //    txtFirstName.BackColor = Color.PaleGoldenrod;
                //}

                //if (txtLastName.Text.ToUpper() == txtLastName.Tag.ToString().ToUpper())
                //{
                //    txtLastName.Enabled = false;
                //    txtLastName.BackColor = Color.White;
                //}
                //else
                //{
                //    txtLastName.Enabled = true;
                //    txtLastName.Text = "";
                //    txtLastName.BackColor = Color.PaleGoldenrod;
                //}

                //if (txtZip.Text.ToUpper() == txtZip.Tag.ToString().ToUpper())
                //{
                //    txtZip.Enabled = false;
                //    txtZip.BackColor = Color.White;
                //}
                //else
                //{
                //    txtZip.Enabled = true;
                //    txtZip.Text = "";
                //    txtZip.BackColor = Color.PaleGoldenrod;
                //}

                //if (cmbCity.Text.ToUpper() == cmbCity.Tag.ToString().ToUpper())
                //{
                //    cmbCity.Enabled = false;
                //    cmbCity.BackColor = Color.White;
                //}
                //else
                //{
                //    cmbCity.Enabled = true;
                //    cmbCity.Text = "";
                //    cmbCity.BackColor = Color.PaleGoldenrod;
                //}

                //if (txtState.Text.ToUpper() == txtState.Tag.ToString().ToUpper())
                //{
                //    txtState.Enabled = false;
                //    txtState.BackColor = Color.White;
                //}
                //else
                //{
                //    txtState.Enabled = true;
                //    txtState.Text = "";
                //    txtState.BackColor = Color.PaleGoldenrod;
                //}

                //if (txtAddress1.Text.ToUpper() == txtAddress1.Tag.ToString().ToUpper())
                //{
                //    txtAddress1.Enabled = false;
                //    txtAddress1.BackColor = Color.White;
                //}
                //else
                //{
                //    txtAddress1.Enabled = true;
                //    txtAddress1.Text = "";
                //    txtAddress1.BackColor = Color.PaleGoldenrod;
                //}

                //if (txtAddress2.Text.ToUpper() == txtAddress2.Tag.ToString().ToUpper())
                //{
                //    txtAddress2.Enabled = false;
                //    txtAddress2.BackColor = Color.White;
                //}
                //else
                //{
                //    txtAddress2.Enabled = true;
                //    txtAddress2.Text = "";
                //    txtAddress2.BackColor = Color.PaleGoldenrod;
                //}

                //if (txtPhoneNo.Text.ToUpper() == txtPhoneNo.Tag.ToString().ToUpper())
                //{
                //    txtPhoneNo.Enabled = false;
                //    txtPhoneNo.BackColor = Color.White;
                //}
                //else
                //{
                //    txtPhoneNo.Enabled = true;
                //    txtPhoneNo.Text = "";
                //    txtPhoneNo.BackColor = Color.PaleGoldenrod;
                //}

                //if (txtMemberID.Text.ToUpper() == txtMemberID.Tag.ToString().ToUpper())
                //{
                //    txtMemberID.Enabled = false;
                //    txtMemberID.BackColor = Color.White;
                //}
                //else
                //{
                //    txtMemberID.Enabled = true;
                //    txtMemberID.Text = "";
                //    txtMemberID.BackColor = Color.PaleGoldenrod;
                //}

                //if (txtBarcode.Text.ToUpper() == txtBarcode.Tag.ToString().ToUpper())
                //{
                //    txtBarcode.Enabled = false;
                //    txtBarcode.BackColor = Color.White;
                //}
                //else
                //{
                //    txtBarcode.Enabled = true;
                //    txtBarcode.Text = "";
                //    txtBarcode.BackColor = Color.PaleGoldenrod;
                //}

                //if (txtDOSmm.Text.ToUpper() == txtDOSmm.Tag.ToString().ToUpper())
                //{
                //    txtDOSmm.Enabled = false;
                //    txtDOSmm.BackColor = Color.White;
                //}
                //else
                //{
                //    txtDOSmm.Enabled = true;
                //    txtDOSmm.Text = "";
                //    txtDOSmm.BackColor = Color.PaleGoldenrod;
                //}

                //if (txtDOSdd.Text.ToUpper() == txtDOSdd.Tag.ToString().ToUpper())
                //{
                //    txtDOSdd.Enabled = false;
                //    txtDOSdd.BackColor = Color.White;
                //}
                //else
                //{
                //    txtDOSdd.Enabled = true;
                //    txtDOSdd.Text = "";
                //    txtDOSdd.BackColor = Color.PaleGoldenrod;
                //}

                //if (txtDOSyy.Text.ToUpper() == txtDOSyy.Tag.ToString().ToUpper())
                //{
                //    txtDOSyy.Enabled = false;
                //    txtDOSyy.BackColor = Color.White;
                //}
                //else
                //{
                //    txtDOSyy.Enabled = true;
                //    txtDOSyy.Text = "";
                //    txtDOSyy.BackColor = Color.PaleGoldenrod;
                //}

                //if (txtDOBmm.Text.ToUpper() == txtDOBmm.Tag.ToString().ToUpper())
                //{
                //    txtDOBmm.Enabled = false;
                //    txtDOBmm.BackColor = Color.White;
                //}
                //else
                //{
                //    txtDOBmm.Enabled = true;
                //    txtDOBmm.Text = "";
                //    txtDOBmm.BackColor = Color.PaleGoldenrod;
                //}

                //if (txtDOBdd.Text.ToUpper() == txtDOBdd.Tag.ToString().ToUpper())
                //{
                //    txtDOBdd.Enabled = false;
                //    txtDOBdd.BackColor = Color.White;
                //}
                //else
                //{
                //    txtDOBdd.Enabled = true;
                //    txtDOBdd.Text = "";
                //    txtDOBdd.BackColor = Color.PaleGoldenrod;
                //}

                //if (txtDOByy.Text.ToUpper() == txtDOByy.Tag.ToString().ToUpper())
                //{
                //    txtDOByy.Enabled = false;
                //    txtDOByy.BackColor = Color.White;
                //}
                //else
                //{
                //    txtDOByy.Enabled = true;
                //    txtDOByy.Text = "";
                //    txtDOByy.BackColor = Color.PaleGoldenrod;
                //}

                //if (key2chkAddressUpdate == key1chkAddressUpdate)
                //{
                //    chkAddressUpdate.Enabled = false;
                //    if (key2chkProviderSignature == true) { chkProviderSignature.Checked = true; } else { chkProviderSignature.Checked = false; }
                //}
                //else
                //{
                //    chkAddressUpdate.Enabled = true;
                //    chkAddressUpdate.Checked = false;
                //}

                //if (key2chkProviderSignature == key1chkProviderSignature)
                //{
                //    chkProviderSignature.Enabled = false;
                //    if (key2chkProviderSignature == true) { chkProviderSignature.Checked = true; } else { chkProviderSignature.Checked = false; }
                //}
                //else
                //{
                //    chkProviderSignature.Enabled = true;
                //    chkProviderSignature.Checked = false;
                //}

                //if (key2chkMotOptin == key1chkMotOptin)
                //{
                //    chkMotOptin.Enabled = false;
                //    if (key2chkMotOptin == true) { chkMotOptin.Checked = true; } else { chkMotOptin.Checked = false; }
                //}
                //else
                //{
                //    chkMotOptin.Enabled = true;
                //    chkMotOptin.Checked = false;
                //}

                //if (txtFormScan.Text.ToUpper() == txtFormScan.Tag.ToString().ToUpper())
                //{
                //    txtFormScan.Enabled = false;
                //    txtFormScan.BackColor = Color.White;
                //}
                //else
                //{
                //    txtFormScan.Enabled = true;
                //    txtFormScan.Text = "";
                //    txtFormScan.BackColor = Color.PaleGoldenrod;
                //}

                //if (key2chkHbA1c == key1chkHbA1c)
                //{
                //    chkHbA1c.Enabled = false;
                //    if (key2chkHbA1c == true) { chkHbA1c.Checked = true; } else { chkHbA1c.Checked = false; }
                //}
                //else
                //{
                //    chkHbA1c.Enabled = true;
                //    chkHbA1c.Checked = false;
                //}

                //if (key2chkLDLC == key1chkLDLC)
                //{
                //    chkLDLC.Enabled = false;
                //    if (key2chkLDLC == true) { chkLDLC.Checked = true; } else { chkLDLC.Checked = false; }
                //}
                //else
                //{
                //    chkLDLC.Enabled = true;
                //    chkLDLC.Checked = false;
                //}

                //if (key2chkMicroalbumin == key1chkMicroalbumin)
                //{
                //    chkMicroalbumin.Enabled = false;
                //    if (key2chkMicroalbumin == true) { chkMicroalbumin.Checked = true; } else { chkMicroalbumin.Checked = false; }
                //}
                //else
                //{
                //    chkMicroalbumin.Enabled = true;
                //    chkMicroalbumin.Checked = false;
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FormScanChanges()
        {
            if (txtFormScan.Text == "A")
            {
                grpFormScanDetails.Visible = false;
                cmbFormScanDatas.Items.Clear();
                cmbFormScanDatas.Items.Insert(0, "Amazon.com");
                cmbFormScanDatas.Items.Insert(1, "GameStop");
                cmbFormScanDatas.Items.Insert(2, "iTunes");
                cmbFormScanDatas.Items.Insert(3, "Old Navy");
                cmbFormScanDatas.Items.Insert(4, "Target");
                cmbFormScanDatas.Items.Insert(5, "Walmart");
                cmbFormScanDatas.Items.Insert(6, "Multiple (X)");
                cmbFormScanDatas.Visible = true;
                cmbFormScanDatas.Focus();
            }
            else if (txtFormScan.Text == "B" || txtFormScan.Text == "C" || txtFormScan.Text == "D" || txtFormScan.Text == "E" || txtFormScan.Text == "F" || txtFormScan.Text == "G")
            {
                grpFormScanDetails.Visible = false;
                cmbFormScanDatas.Items.Clear();
                cmbFormScanDatas.Items.Insert(0, "Amazon.com");
                cmbFormScanDatas.Items.Insert(1, "Burlington");
                cmbFormScanDatas.Items.Insert(2, "Old Navy");
                cmbFormScanDatas.Items.Insert(3, "Target");
                cmbFormScanDatas.Items.Insert(4, "Walgreens");
                cmbFormScanDatas.Items.Insert(5, "Walmart");
                cmbFormScanDatas.Items.Insert(6, "Multiple (X)");
                cmbFormScanDatas.Visible = true;
                cmbFormScanDatas.Focus();
            }
            else if (txtFormScan.Text == "M" || txtFormScan.Text == "L")
            {
                grpFormScanDetails.Visible = false;
                cmbFormScanDatas.Items.Clear();
                cmbFormScanDatas.Items.Insert(0, "Amazon.com");
                cmbFormScanDatas.Items.Insert(1, "GameStop");
                cmbFormScanDatas.Items.Insert(2, "iTunes");
                cmbFormScanDatas.Items.Insert(3, "Old Navy");
                cmbFormScanDatas.Items.Insert(4, "Target");
                cmbFormScanDatas.Items.Insert(5, "Walmart");
                cmbFormScanDatas.Visible = true;
                cmbFormScanDatas.Focus();
            }
            else if (txtFormScan.Text == "H")
            {
                //cmbFormScanDatas.Visible = false;
                grpFormScanDetails.Visible = true;
                chkHbA1c.Focus();
            }
        }

        private bool Imagefit(Control ObjControl)
        {
            try
            {
                if ((ObjControl is TextBox) || (ObjControl is ComboBox) || (ObjControl is CheckBox))
                {
                    switch (ObjControl.Name)
                    {
                        case GC_FIELDS_FIRSTNAME:
                        case GC_FIELDS_LASTNAME:
                        case GC_FIELDS_ZIP:
                        case GC_FIELDS_CITY:
                        case GC_FIELDS_STATE:
                        case GC_FIELDS_ADDRESS1:
                        case GC_FIELDS_ADDRESS2:
                        case GC_FIELDS_PHONE:
                        case GC_FIELDS_MEMBERID:
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 90));
                            break;

                        case GC_FIELDS_BARCODE:
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 115));
                            break;


                        case GC_FIELDS_DOSmm:
                        case GC_FIELDS_DOSdd:
                        case GC_FIELDS_DOSyy:
                        case GC_FIELDS_DOBmm:
                        case GC_FIELDS_DOBdd:
                        case GC_FIELDS_DOByy:
                        case GC_FIELDS_CHKADDRESSUPDATE:
                        case GC_FIELDS_CHKPROVIDERSIGNATURE:
                        case GC_FIELDS_CHKMOTOPTIN:
                        case GC_FIELDS_FORMSCAN:
                        case GC_FIELDS_CMBFORMSCANDATAS:
                        case GC_FIELDS_CHKHBA1C:
                        case GC_FIELDS_CHKLDLC:
                        case GC_FIELDS_CHKMICROALBUMIN:
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 60));
                            break;
                    }
                }
            }

            catch (Exception ex)
            { }
            return true;
        }

        #endregion

        #region Events

        private void FrmKeying_Load(object sender, EventArgs e)
        {
            this.Text = string.Format("Healthtel MRD :: {0}", Process);
            LoadImage();
            AutoCompleteStringCollection autocompletestring = new AutoCompleteStringCollection();
            List<namesdatabase> namelist = new List<namesdatabase>();
            namelist = new namesdatabase().List();
            string strAppend = "";
            for (int i = 0; i <= namelist.Count - 1; i++)
            {
                autocompletestring.AddRange(new string[] { strAppend + namelist[i].Names });
            }
            txtFirstName.AutoCompleteCustomSource = autocompletestring;
            txtLastName.AutoCompleteCustomSource = autocompletestring;
        }

        private void txtFirstName_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtFirstName);
        }

        private void txtLastName_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtLastName);
        }

        private void txtZip_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtZip);
        }

        private void cmbCity_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, cmbCity);
        }

        private void txtState_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtState);
        }

        private void txtAddress1_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtAddress1);
        }

        private void txtAddress2_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtAddress2);
        }

        private void txtPhoneNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtPhoneNo);
        }

        private void txtMemberID_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtMemberID);
        }

        private void txtBarcode_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtBarcode);
        }

        private void txtDOSmm_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtDOSmm);
        }

        private void txtDOSdd_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtDOSdd);
        }

        private void txtDOSyy_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtDOSyy);
        }

        private void txtDOBmm_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtDOBmm);
        }

        private void txtDOBdd_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtDOBdd);
        }

        private void txtDOByy_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtDOByy);
        }

        private void txtFormScan_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtFormScan);
        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtFirstName);
        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtLastName);
        }

        private void txtZip_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtZip);
        }

        private void txtState_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtState);
        }

        private void txtAddress1_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtAddress1);
        }

        private void txtAddress2_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtAddress2);
        }

        private void txtPhoneNo_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtPhoneNo);
        }

        private void txtMemberID_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtMemberID);
        }

        private void txtBarcode_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtBarcode);
        }

        private void txtDOSmm_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtDOSmm);
        }

        private void txtDOSdd_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtDOSdd);
        }

        private void txtDOSyy_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtDOSyy);
        }

        private void txtDOBmm_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtDOBmm);
        }

        private void txtDOBdd_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtDOBdd);
        }

        private void txtDOByy_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtDOByy);
        }

        private void chkAddressUpdate_CheckedChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, chkAddressUpdate);
        }

        private void chkProviderSignature_CheckedChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, chkProviderSignature);
        }

        private void chkMotOptin_CheckedChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, chkMotOptin);
        }

        private void txtFormScan_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtFormScan);
        }

        private void chkHbA1c_CheckedChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, chkHbA1c);
        }

        private void chkLDLC_CheckedChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, chkLDLC);
        }

        private void chkMicroalbumin_CheckedChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, chkMicroalbumin);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateInfo() == true)
            {
                if (SaveInfo() == true)
                {
                    LoadImage();
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmKeying_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Are you sure want to exit " + Process + "?", "Healthtel MRD", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                objImagemaster.ImageReset(Process, lngImageID);
                //this.Close();
            }
            else
            {
                return;
            }
        }

        private void txtZip_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtZip.Text.Trim()))
            {
                return;
            }
            else
            {
                List<city> cities = new List<city>();
                city objLoadCities = new city();
                cities = objLoadCities.getCities(txtZip.Text.Trim());
                if (cities.Count > 0)
                {
                    cmbCity.Items.Clear();
                    for (int i = 0; i <= cities.Count - 1; i++)
                    {
                        cmbCity.Items.Insert(i, cities[i].CITY1.ToUpper());
                    }
                    txtState.Text = cities[0].STATE;
                    cmbCity.Focus();
                }
            }
        }

        private void txtPhoneNo_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtPhoneNo.Text.Trim()))
            {
                string PhoneNo = IGUtilities.ValidatePhoneNo(txtPhoneNo.Text.Trim());
                if (!string.IsNullOrEmpty(PhoneNo))
                {
                    MessageBox.Show(PhoneNo);
                    txtPhoneNo.Focus();
                }
            }
        }

        private void txtDOSmm_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtDOSmm.Text.Trim()))
            {
                string month;
                month = IGUtilities.ValidateMonth(txtDOSmm.Text.Trim());
                if (month.Length == 2) { txtDOSmm.Text = month; } else { MessageBox.Show(month); txtDOSmm.Focus(); }
            }
        }

        private void txtDOSdd_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtDOSdd.Text.Trim()))
            {
                string date;
                date = IGUtilities.ValidateDate(txtDOSdd.Text.Trim(), txtDOSmm.Text.Trim());
                if (date.Length == 2) { txtDOSdd.Text = date; } else { MessageBox.Show(date); txtDOSdd.Focus(); }
            }
        }

        private void txtDOSyy_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtDOSyy.Text.Trim()))
            {
                string year = IGUtilities.ValidateYear(txtDOSmm.Text.Trim(), txtDOSdd.Text.Trim(), txtDOSyy.Text.Trim());
                if (year.Length == 4)
                {
                    //txtDOSyy.Text = year;
                }
                else
                {
                    MessageBox.Show(year);
                    txtDOSyy.Clear();
                    txtDOSyy.Focus();
                }
            }
        }

        private void txtDOBmm_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtDOBmm.Text.Trim()))
            {
                string month;
                month = IGUtilities.ValidateMonth(txtDOBmm.Text.Trim());
                if (month.Length == 2) { txtDOBmm.Text = month; } else { MessageBox.Show(month); txtDOBmm.Focus(); }
            }
        }

        private void txtDOBdd_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtDOBdd.Text.Trim()))
            {
                string date;
                date = IGUtilities.ValidateDate(txtDOBdd.Text.Trim(), txtDOBmm.Text.Trim());
                if (date.Length == 2) { txtDOBdd.Text = date; } else { MessageBox.Show(date); txtDOBdd.Focus(); }
            }
        }

        private void txtDOByy_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtDOByy.Text.Trim()))
            {
                string year = IGUtilities.ValidateYear(txtDOBmm.Text.Trim(), txtDOBdd.Text.Trim(), txtDOByy.Text.Trim());
                if (year.Length == 4)
                {
                    //txtDOByy.Text = year;
                }
                else
                {
                    MessageBox.Show(year);
                    txtDOByy.Clear();
                    txtDOByy.Focus();
                }
            }
        }

        private void txtFormScan_Leave(object sender, EventArgs e)
        {
            //FormScanChanges();
        }

        private void txtFirstName_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtFirstName);
        }

        private void txtLastName_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtLastName);
        }

        private void txtZip_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtZip);
        }

        private void cmbCity_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, cmbCity);
        }

        private void txtState_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtState);
        }

        private void txtAddress1_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtAddress1);
        }

        private void txtAddress2_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtAddress2);
        }

        private void txtPhoneNo_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtPhoneNo);
        }

        private void txtMemberID_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtMemberID);
        }

        private void txtBarcode_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtBarcode);
        }

        private void txtDOSmm_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtDOSmm);
        }

        private void txtDOSdd_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtDOSdd);
        }

        private void txtDOSyy_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtDOSyy);
        }

        private void txtDOBmm_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtDOBmm);
        }

        private void txtDOBdd_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtDOBdd);
        }

        private void txtDOByy_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtDOByy);
        }

        private void chkAddressUpdate_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, chkAddressUpdate);
        }

        private void chkProviderSignature_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, chkProviderSignature);
        }

        private void chkMotOptin_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, chkMotOptin);
        }

        private void txtFormScan_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtFormScan);
        }

        private void cmbFormScanDatas_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, cmbFormScanDatas);
        }

        private void chkHbA1c_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, chkHbA1c);
        }

        private void chkLDLC_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, chkLDLC);
        }

        private void chkMicroalbumin_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, chkMicroalbumin);
        }

        private void FrmKeying_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Alt & e.KeyCode == Keys.Right)
            {
                IGImageViewer.NextImage(sender, e);
            }
            else if (e.Alt & e.KeyCode == Keys.Left)
            {
                IGImageViewer.PrevImage(sender, e);
            }
            else if (e.Control & (e.KeyCode == Keys.Oemplus || e.KeyCode == Keys.Add))
            {
                IGImageViewer.ZoomIn(sender, e);
            }
            else if (e.Control & (e.KeyCode == Keys.OemMinus || e.KeyCode == Keys.Subtract))
            {
                IGImageViewer.ZoomOut(sender, e);
            }
            else if (e.Control == true & (e.KeyCode == Keys.D1 | e.KeyCode == Keys.NumPad1))
            {
                IGImageViewer.RotateLeft(sender, e);
            }
            else if (e.Control == true & (e.KeyCode == Keys.D2 | e.KeyCode == Keys.NumPad2))
            {
                IGImageViewer.RotateRight(sender, e);
            }
            else if (e.Control & e.KeyCode == Keys.Right)
            {
                IGImageViewer.PageRight();
            }
            else if (e.Control & e.KeyCode == Keys.Left)
            {
                IGImageViewer.PageLeft();
            }
            else if (e.Control & e.KeyCode == Keys.Down)
            {
                IGImageViewer.PageDown();
            }
            else if (e.Control & e.KeyCode == Keys.Up)
            {
                IGImageViewer.PageUp();
            }
            else if (e.Control & e.KeyCode == Keys.PageUp)
            {
                IGImageViewer.PageHome();
            }
            else if (e.Control & e.KeyCode == Keys.Next)
            {
                IGImageViewer.PageEnd();
            }
            //else if (e.Control & e.KeyCode == Keys.Home)
            //{
            //    IGImageViewer.firstpage();
            //}
            //else if (e.Control & e.KeyCode == Keys.End)
            //{
            //    IGImageViewer.lastpage();
            //}
            else if (e.KeyCode == Keys.F5)
            {
                strImageFit = IGImageViewer.ImageHorizontalScroll.Value + "," + IGImageViewer.ImageVerticalScroll.Value;
                strImageSize = IGImageViewer.ImageSize.Width + "," + IGImageViewer.ImageSize.Height;
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageFit, strImageFit);
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageSize, strImageSize);
            }
            else if (e.KeyCode == Keys.F6)
            {
                //IGImageViewer.resizeimg();
                strImageFit = IGImageViewer.ImageHorizontalScroll.Minimum + "," + IGImageViewer.ImageVerticalScroll.Minimum;
                strImageSize = "";
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageFit, strImageFit);
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageSize, strImageSize);

                IGImageViewer.ImageClear();
                IGImageViewer.ImageName = Image.ImagePath;
                IGImageViewer.LoadImage();
            }
            else if (e.Control & e.KeyCode == Keys.F7)
            {
                //IGImageViewer.imgfitwidth();
            }
            else if (e.Control & e.KeyCode == Keys.F8)
            {
                //IGImageViewer.imgfitscreen();
            }
        }

        #endregion

        #region Background Worker

        protected void BarcodeWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            //Load barcode from the image

            //bmp = new System.Drawing.Bitmap(IGImageViewer.ImageName);
            //barcodes = new System.Collections.ArrayList(); ;
            //BarcodeImaging.FullScanPage(ref barcodes, bmp, iScans);
        }

        protected void BarcodeWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //if (barcodes.Count > 0)
            //{
            //    //foreach (string bc in barcodes)
            //    //{
            //    //    barcode += bc + " ";
            //    //}
            //    txtBarcode.Text = barcodes[0].ToString().Trim();
            //    barcode = "";
            //    //barcodes = null;
            //}
            //bmp.Dispose();
        }

        protected void AddressWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtZip.Text.Trim()) && !string.IsNullOrEmpty(txtState.Text.Trim()))
            {
                AddressList = Zipcode.AddressListBYZipCode(txtZip.Text.Trim(), txtState.Text.Trim());
            }
        }

        protected void AddressWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (AddressList.Count > 0)
            {
                txtAddress1.AutoCompleteCustomSource.Clear();
                txtAddress1.AutoCompleteCustomSource = AddressList;
            }
        }

        #endregion
    }
}
