﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Healthtel_MRT
{
    public partial class Healthtel_Adult : Form
    {
        public Healthtel_Adult()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

        }

        private void Healthtel_Adult_Load(object sender, EventArgs e)
        {
            if (BatchType == 6)
            {
                this.Text = string.Format("Healthtel Adult:: {0}", Process);
            }
        
            LoadImage();
        }
    }
}
