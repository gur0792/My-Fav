﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DataAccessLayer.GlobalDB;
using DataAccessLayer.ProjectDB;
using App.Base;

namespace Healthtel_MRT
{
    public partial class frmBatchDelete : Form
    {
        public frmBatchDelete()
        {
            InitializeComponent();
        }

        batchmaster objBatchmaster = new batchmaster();
        batchmaster_audit objBatchmaster_audit = new batchmaster_audit();
        batchmaster BatchDetails = new batchmaster();

        private void LoadBatch()
        {
            List<batchmaster> BatchList = new List<batchmaster>();
            BatchList = objBatchmaster.LoadBatch("DELETE");
            lstBatch.Items.Clear();
            if (BatchList.Count > 0)
            {
                lstBatch.DisplayMember = "Name";
                lstBatch.ValueMember = "ID";
                BatchList.ForEach(x =>
                {
                    lstBatch.Items.Add(new { ID = x.ID, NAME = x.Name});
                });
                lstBatch.Refresh();
            }           
        }

        private void frmBatchDelete_Load(object sender, EventArgs e)
        {
            LoadBatch();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            int iLoop = 0;

            if (lstBatch.CheckedItems.Count <= 0)
            {
                MessageBox.Show("Select One or more Batches to Delete");
                lstBatch.Focus();
                return;
            }


            try
            {
                int id = 0;
                string selectitem = "";
                string[] imageid;
                //for (iLoop = 0; iLoop <= lstBatch.Items.Count - 1; iLoop++)
                //{
                //    if (lstBatch.GetItemChecked(iLoop) == true)
                //    {
                //        selectitem = lstBatch.SelectedItem.ToString();
                //        imageid = selectitem.Split('=');
                //        imageid = imageid[1].ToString().Split(',');
                //        id = Convert.ToInt32(imageid[0]);

                //        BatchDetails = objBatchmaster.DeleteBatch(id);

                //        objBatchmaster_audit.BatchID = BatchDetails.ID;
                //        objBatchmaster_audit.Name = BatchDetails.Name;
                //        objBatchmaster_audit.SurveyID = BatchDetails.SurveyID;
                //        objBatchmaster_audit.CreatedOn = BatchDetails.CreatedOn;
                //        objBatchmaster_audit.CreatedBy = BatchDetails.CreatedBy;
                //        objBatchmaster_audit.Key1 = BatchDetails.Key1;
                //        objBatchmaster_audit.Key2 = BatchDetails.Key2;
                //        objBatchmaster_audit.Key3 = BatchDetails.Key3;
                //        objBatchmaster_audit.KeyQC = BatchDetails.KeyQC;
                //        objBatchmaster_audit.CompareQC = BatchDetails.CompareQC;
                //        objBatchmaster_audit.FullQC = BatchDetails.FullQC;
                //        objBatchmaster_audit.AuditQC = BatchDetails.AuditQC;
                //        objBatchmaster_audit.Export = BatchDetails.Export;
                //        objBatchmaster_audit.ExportDate = BatchDetails.ExportDate;
                //        objBatchmaster_audit.BatchType = objBatchmaster_audit.BatchType;
                //        objBatchmaster_audit.Store();

                //        BatchDetails.IstoBeDeleted = true;
                //        BatchDetails.Store();
                //    }
                //}

                for (iLoop = 0; iLoop <= lstBatch.CheckedItems.Count - 1; iLoop++)
                {                    
                        selectitem = lstBatch.CheckedItems[iLoop].ToString();
                        imageid = selectitem.Split('=');
                        imageid = imageid[1].ToString().Split(',');
                        id = Convert.ToInt32(imageid[0]);

                        BatchDetails = objBatchmaster.DeleteBatch(id);

                        objBatchmaster_audit.BatchID = BatchDetails.ID;
                        objBatchmaster_audit.Name = BatchDetails.Name;
                        objBatchmaster_audit.SurveyID = BatchDetails.SurveyID;
                        objBatchmaster_audit.CreatedOn = BatchDetails.CreatedOn;
                        objBatchmaster_audit.CreatedBy = BatchDetails.CreatedBy;
                        objBatchmaster_audit.Key1 = BatchDetails.Key1;
                        objBatchmaster_audit.Key2 = BatchDetails.Key2;
                        objBatchmaster_audit.Key3 = BatchDetails.Key3;
                        objBatchmaster_audit.KeyQC = BatchDetails.KeyQC;
                        objBatchmaster_audit.CompareQC = BatchDetails.CompareQC;
                        objBatchmaster_audit.FullQC = BatchDetails.FullQC;
                        objBatchmaster_audit.AuditQC = BatchDetails.AuditQC;
                        objBatchmaster_audit.Export = BatchDetails.Export;
                        objBatchmaster_audit.ExportDate = BatchDetails.ExportDate;
                        objBatchmaster_audit.BatchType = objBatchmaster_audit.BatchType;
                        objBatchmaster_audit.DeletedUserid =Constance.GC_USERID.ToString();
                        objBatchmaster_audit.DeletedDate = DateTime.Now.ToString();   
                        objBatchmaster_audit.Store();

                        BatchDetails.IstoBeDeleted = true;
                        BatchDetails.Store();
                }

                LoadBatch();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
