﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using MySql.Data.MySqlClient;
using DataAccessLayer.ProjectDB;
using DataAccessLayer.GlobalDB;
using DataAccessLayer.ZipCodeDB;
using App.Base;
using System.Globalization;
using OnBarcode.Barcode.BarcodeScanner;

namespace Healthtel_MRT
{
    public partial class FrmKeying_HEDIS : Form
    {
        public FrmKeying_HEDIS()
        {
            InitializeComponent();
            BarcodeWorker.DoWork += new DoWorkEventHandler(BarcodeWorker_DoWork);
            BarcodeWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(BarcodeWorker_RunWorkerCompleted);
            //BarcodeWorker.ProgressChanged += new ProgressChangedEventHandler(BarcodeWorker_ProgressChanged);
            BarcodeWorker.WorkerReportsProgress = true;
            BarcodeWorker.WorkerSupportsCancellation = true;
        }

        #region Global Variables
        //login LoggedUsers = new batchmaster().getLoginUser();
        batchmaster objBatchmaster = new batchmaster();
        imagemaster objImagemaster = new imagemaster();
        key1_hedis objKey1 = new key1_hedis();
        keyqc_hedis objKeyqc = new keyqc_hedis();
        //compareqc objCompareQC = new compareqc();

        imagemaster Image = new imagemaster();
        key1 getkey1Data = new key1();
        key2 getkey2Data = new key2();
        compareqc getCompareqcData = new compareqc();
        keyqc_hedis getkeyqc_hedisData = new keyqc_hedis();
        key1_hedis getkey1_hedisData = new key1_hedis();

        long lngBatchID;
        long lngImageID;
        int intBatchType;
        string strImagePath;
        int totRecs;
        int RemRecs;
        int FinRecs;
        string ProcessType;
        string strSQL;
        DataSet dsKeyData;
        DataSet dsKey1;
        DataSet dskey;
        string strImageSize;
        string strImageFit;
        int iHScrol = 0;
        int iVScrol = 0;

        bool bCtrl = false;
        bool bAlt = false;
        bool bShift = false;
        bool bImageLoad = false;
        AutoCompleteStringCollection citycollection = new AutoCompleteStringCollection();
        bool bPreview = true;
        DataSet dsCities;
        AutoCompleteStringCollection AddressList = new AutoCompleteStringCollection();
        private BackgroundWorker BarcodeWorker = new BackgroundWorker();
        private BackgroundWorker AddressWorker = new BackgroundWorker();
        bool loadaddress = false;

        //System.Collections.ArrayList barcodes = new System.Collections.ArrayList();
        //DateTime dtStart = DateTime.Now;
        int iScans = 100;
        string barcode = "";
        System.Drawing.Bitmap bmp;
        int position;

        string[] barcodes;

        #endregion

        #region Global Fields For Controls
        public const string GC_FIELDS_Q1_1A_MM = "txtQ1_1A_mm";
        public const string GC_FIELDS_Q1_1A_DD = "txtQ1_1A_dd";
        public const string GC_FIELDS_Q1_1A_YY = "txtQ1_1A_yy";
        public const string GC_FIELDS_Q1_1B_MM = "txtQ1_1B_mm";
        public const string GC_FIELDS_Q1_1B_DD = "txtQ1_1B_dd";
        public const string GC_FIELDS_Q1_1B_YY = "txtQ1_1B_yy";
        public const string GC_FIELDS_Q1_2A_MM = "txtQ1_2A_mm";
        public const string GC_FIELDS_Q1_2A_DD = "txtQ1_2A_dd";
        public const string GC_FIELDS_Q1_2A_YY = "txtQ1_2A_yy";
        public const string GC_FIELDS_Q1_2B_MM = "txtQ1_2B_mm";
        public const string GC_FIELDS_Q1_2B_DD = "txtQ1_2B_dd";
        public const string GC_FIELDS_Q1_2B_YY = "txtQ1_2B_yy";
        public const string GC_FIELDS_Q1_3A_MM = "txtQ1_3A_mm";
        public const string GC_FIELDS_Q1_3A_DD = "txtQ1_3A_dd";
        public const string GC_FIELDS_Q1_3A_YY = "txtQ1_3A_yy";
        public const string GC_FIELDS_Q1_3B_MM = "txtQ1_3B_mm";
        public const string GC_FIELDS_Q1_3B_DD = "txtQ1_3B_dd";
        public const string GC_FIELDS_Q1_3B_YY = "txtQ1_3B_yy";
        public const string GC_FIELDS_Q1_4 = "txtQ1_4";
        public const string GC_FIELDS_Q1_5 = "txtQ1_5";
        public const string GC_FIELDS_Q2_1 = "txtQ2_1";
        public const string GC_FIELDS_Q2_2 = "txtQ2_2";
        public const string GC_FIELDS_Q2_3A_MM = "txtQ2_3A_mm";
        public const string GC_FIELDS_Q2_3A_DD = "txtQ2_3A_dd";
        public const string GC_FIELDS_Q2_3A_YY = "txtQ2_3A_yy";
        public const string GC_FIELDS_Q2_3B_MM = "txtQ2_3B_mm";
        public const string GC_FIELDS_Q2_3B_DD = "txtQ2_3B_dd";
        public const string GC_FIELDS_Q2_3B_YY = "txtQ2_3B_yy";
        public const string GC_FIELDS_Q3_1 = "txtQ3_1";
        public const string GC_FIELDS_Q3_2 = "txtQ3_2";
        public const string GC_FIELDS_Q3_3A_MM = "txtQ3_3A_mm";
        public const string GC_FIELDS_Q3_3A_DD = "txtQ3_3A_dd";
        public const string GC_FIELDS_Q3_3A_YY = "txtQ3_3A_yy";
        public const string GC_FIELDS_Q3_3B_MM = "txtQ3_3B_mm";
        public const string GC_FIELDS_Q3_3B_DD = "txtQ3_3B_dd";
        public const string GC_FIELDS_Q3_3B_YY = "txtQ3_3B_yy";
        public const string GC_FIELDS_Q3_4_MM = "txtQ3_4_mm";
        public const string GC_FIELDS_Q3_4_DD = "txtQ3_4_dd";
        public const string GC_FIELDS_Q3_4_YY = "txtQ3_4_yy";
        public const string GC_FIELDS_CHKSIGNATURE = "chksignature";
        public const string GC_FIELDS_SIGNATUREDATE_MM = "txtSign_mm";
        public const string GC_FIELDS_SIGNATUREDATE_DD = "txtSign_dd";
        public const string GC_FIELDS_SIGNATUREDATE_YY = "txtSign_yy";
        public const string GC_FIELDS_BARCODE = "txtBarcode";
        public const string GC_FIELDS_COMMENTS = "txtcomments";
        #endregion.

        #region Property Variables
        public long BatchID
        {
            get { return lngBatchID; }

            set { lngBatchID = value; }
        }

        public string Process
        {
            get { return ProcessType; }

            set { ProcessType = value; }
        }

        public int BatchType
        {
            get { return intBatchType; }

            set { intBatchType = value; }
        }
        #endregion

        #region Background Worker

        protected void BarcodeWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            //Load barcode from the image
            //barcodes = BarcodeScanner.Scan(IGImageViewer.ImageName, BarcodeType.All);
        }

        protected void BarcodeWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //if (barcodes.Length > 0)
            //{
            //    foreach (string bc in barcodes)
            //    {
            //        if (bc.ToString().StartsWith("0000"))
            //        {
            //            txtBarcode.Text = bc.ToString();
            //            barcodes = null;
            //                            //bmp.Dispose();
            //            return;
            //        }
            //    }
            //                     //txtBarcode.Text = ReplaceAtIndex(barcodes[1].ToString(), 0, '0');
            //                     //barcode = "";
            //                    //barcodes = null;
            //}
                                 //bmp.Dispose();
        }

        #endregion

        #region help Methods

        private bool txtKeyPress(object Sender, System.Windows.Forms.KeyPressEventArgs e, Control ObjControl)
        {
            try
            {
                if ((ObjControl is TextBox) || (ObjControl is ComboBox))
                {
                    e.KeyChar = char.ToUpper(e.KeyChar);

                    switch (ObjControl.Name)
                    {
                        case GC_FIELDS_Q1_1A_MM:
                        case GC_FIELDS_Q1_1A_DD:
                        case GC_FIELDS_Q1_1A_YY:
                        case GC_FIELDS_Q1_1B_MM:
                        case GC_FIELDS_Q1_1B_DD:
                        case GC_FIELDS_Q1_1B_YY:
                        case GC_FIELDS_Q1_2A_MM:
                        case GC_FIELDS_Q1_2A_DD:
                        case GC_FIELDS_Q1_2A_YY:
                        case GC_FIELDS_Q1_2B_MM:
                        case GC_FIELDS_Q1_2B_DD:
                        case GC_FIELDS_Q1_2B_YY:
                        case GC_FIELDS_Q1_3A_MM:
                        case GC_FIELDS_Q1_3A_DD:
                        case GC_FIELDS_Q1_3A_YY:
                        case GC_FIELDS_Q1_3B_MM:
                        case GC_FIELDS_Q1_3B_DD:
                        case GC_FIELDS_Q1_3B_YY:
                        case GC_FIELDS_Q2_3A_MM:
                        case GC_FIELDS_Q2_3A_DD:
                        case GC_FIELDS_Q2_3A_YY:
                        case GC_FIELDS_Q2_3B_MM:
                        case GC_FIELDS_Q2_3B_DD:
                        case GC_FIELDS_Q2_3B_YY:
                        case GC_FIELDS_Q3_3A_MM:
                        case GC_FIELDS_Q3_3A_DD:
                        case GC_FIELDS_Q3_3A_YY:
                        case GC_FIELDS_Q3_3B_MM:
                        case GC_FIELDS_Q3_3B_DD:
                        case GC_FIELDS_Q3_3B_YY:
                        case GC_FIELDS_Q3_4_MM:
                        case GC_FIELDS_Q3_4_DD:
                        case GC_FIELDS_Q3_4_YY:
                        case GC_FIELDS_SIGNATUREDATE_MM:
                        case GC_FIELDS_SIGNATUREDATE_DD:
                        case GC_FIELDS_SIGNATUREDATE_YY:
                        //case GC_FIELDS_Q1_5:
                        //case GC_FIELDS_Q2_2:
                        //case GC_FIELDS_Q3_2:
                        case GC_FIELDS_BARCODE:
                            if (char.IsDigit(e.KeyChar) || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back) || char.IsWhiteSpace(e.KeyChar))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;
                        case GC_FIELDS_Q1_5:
                        case GC_FIELDS_Q2_2:
                        case GC_FIELDS_Q3_2:
                            // case GC_FIELDS_BARCODE:
                            if (char.IsDigit(e.KeyChar) || Strings.AscW(e.KeyChar) == Strings.AscW("/") || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back) || char.IsWhiteSpace(e.KeyChar))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;

                        case GC_FIELDS_Q1_4:
                        case GC_FIELDS_Q2_1:
                        case GC_FIELDS_Q3_1:
                            if (char.IsDigit(e.KeyChar) || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back) || Strings.AscW(e.KeyChar) != Strings.AscW(",") && Strings.AscW(e.KeyChar) != Strings.AscW("&") && Strings.AscW(e.KeyChar) != Strings.AscW("*") && Strings.AscW(e.KeyChar) != Strings.AscW("#") && Strings.AscW(e.KeyChar) != Strings.AscW("@") && Strings.AscW(e.KeyChar) != Strings.AscW("!") && Strings.AscW(e.KeyChar) != Strings.AscW("-") && Strings.AscW(e.KeyChar) != Strings.AscW("(") && Strings.AscW(e.KeyChar) != Strings.AscW("'") && Strings.AscW(e.KeyChar) != Strings.AscW("/") && Strings.AscW(e.KeyChar) != Strings.AscW('"') && Strings.AscW(e.KeyChar) != Strings.AscW(".") && Strings.AscW(e.KeyChar) != Strings.AscW(")"))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            //if (char.IsLetter(e.KeyChar) || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back) || char.IsWhiteSpace(e.KeyChar))
                            //{
                            //    e.Handled = false;
                            //}
                            //else
                            //{
                            //    e.Handled = true;
                            //}
                            break;
                        case GC_FIELDS_COMMENTS:
                            if (char.IsDigit(e.KeyChar) || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back) || Strings.AscW(e.KeyChar) != Strings.AscW(",") && Strings.AscW(e.KeyChar) != Strings.AscW("&") && Strings.AscW(e.KeyChar) != Strings.AscW("*") && Strings.AscW(e.KeyChar) != Strings.AscW("#") && Strings.AscW(e.KeyChar) != Strings.AscW("@") && Strings.AscW(e.KeyChar) != Strings.AscW("!") && Strings.AscW(e.KeyChar) != Strings.AscW("-") && Strings.AscW(e.KeyChar) != Strings.AscW("(") && Strings.AscW(e.KeyChar) != Strings.AscW("'") && Strings.AscW(e.KeyChar) != Strings.AscW("/") && Strings.AscW(e.KeyChar) != Strings.AscW('"') && Strings.AscW(e.KeyChar) != Strings.AscW(".") && Strings.AscW(e.KeyChar) != Strings.AscW(")"))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            //if (char.IsLetter(e.KeyChar) || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back) || char.IsWhiteSpace(e.KeyChar))
                            //{
                            //    e.Handled = false;
                            //}
                            //else
                            //{
                            //    e.Handled = true;
                            //}
                            break;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private bool txtChanged(object Sender, System.EventArgs e, Control ObjControl)
        {
            try
            {
                if ((ObjControl is TextBox) || (ObjControl is ComboBox) || (ObjControl is CheckBox))
                {
                    switch (ObjControl.Name)
                    {
                        case GC_FIELDS_Q1_1A_MM:
                            if (txtQ1_1A_mm.TextLength == txtQ1_1A_mm.MaxLength)
                            {
                                txtQ1_1A_dd.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_1A_DD:
                            if (txtQ1_1A_dd.TextLength == txtQ1_1A_dd.MaxLength)
                            {
                                txtQ1_1A_yy.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_1A_YY:
                            if (txtQ1_1A_yy.TextLength == txtQ1_1A_yy.MaxLength)
                            {
                                if (txtQ1_1B_mm.Enabled == true)
                                {
                                    txtQ1_1B_mm.Focus();
                                }
                                else
                                {
                                    txtQ1_2A_mm.Focus();
                                }
                            }
                            break;
                        case GC_FIELDS_Q1_1B_MM:
                            if (txtQ1_1B_mm.Text.Length == txtQ1_1B_mm.MaxLength)
                            {
                                txtQ1_1B_dd.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_1B_DD:
                            if (txtQ1_1B_dd.TextLength == txtQ1_1B_dd.MaxLength)
                            {
                                txtQ1_1B_yy.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_1B_YY:
                            if (txtQ1_1B_yy.TextLength == txtQ1_1B_yy.MaxLength)
                            {
                                txtQ1_2A_mm.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_2A_MM:
                            if (txtQ1_2A_mm.TextLength == txtQ1_2A_mm.MaxLength)
                            {
                                txtQ1_2A_dd.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_2A_DD:
                            if (txtQ1_2A_dd.TextLength == txtQ1_2A_dd.MaxLength)
                            {
                                txtQ1_2A_yy.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_2A_YY:
                            if (txtQ1_2A_yy.TextLength == txtQ1_2A_yy.MaxLength)
                            {
                                if (txtQ1_2B_mm.Enabled == true)
                                {
                                    txtQ1_2B_mm.Focus();
                                }
                                else
                                {
                                    txtQ1_3A_mm.Focus();
                                }
                            }
                            break;
                        case GC_FIELDS_Q1_2B_MM:
                            if (txtQ1_2B_mm.TextLength == txtQ1_2B_mm.MaxLength)
                            {
                                txtQ1_2B_dd.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_2B_DD:
                            if (txtQ1_2B_dd.Text.Length == txtQ1_2B_dd.MaxLength)
                            {
                                txtQ1_2B_yy.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_2B_YY:
                            if (txtQ1_2B_yy.TextLength == txtQ1_2B_yy.MaxLength)
                            {
                                txtQ1_3A_mm.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_3A_MM:
                            if (txtQ1_3A_mm.TextLength == txtQ1_3A_mm.MaxLength)
                            {
                                txtQ1_3A_dd.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_3A_DD:
                            if (txtQ1_3A_dd.TextLength == txtQ1_3A_dd.MaxLength)
                            {
                                txtQ1_3A_yy.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_3A_YY:
                            if (txtQ1_3A_yy.TextLength == txtQ1_3A_yy.MaxLength)
                            {
                                if (txtQ1_3B_mm.Enabled == true)
                                {
                                    txtQ1_3B_mm.Focus();
                                }
                                else
                                {
                                    txtQ1_4.Focus();
                                }
                            }
                            break;
                        case GC_FIELDS_Q1_3B_MM:
                            if (txtQ1_3B_mm.TextLength == txtQ1_3B_mm.MaxLength)
                            {
                                txtQ1_3B_dd.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_3B_DD:
                            if (txtQ1_3B_dd.TextLength == txtQ1_3B_dd.MaxLength)
                            {
                                txtQ1_3B_yy.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_3B_YY:
                            if (txtQ1_3B_yy.TextLength == txtQ1_3B_yy.MaxLength)
                            {
                                txtQ1_4.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_4:
                            if (txtQ1_4.TextLength == txtQ1_4.MaxLength)
                            {
                                txtQ1_5.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_5:
                            if (txtQ1_5.Text.Length == txtQ1_5.MaxLength)
                            {
                                txtQ2_1.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_1:
                            if (txtQ2_1.Text.Length == txtQ2_1.MaxLength)
                            {
                                txtQ2_2.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_2:
                            if (txtQ2_2.Text.Length == txtQ2_2.MaxLength)
                            {
                                txtQ2_2.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_3A_MM:
                            if (txtQ2_3A_mm.Text.Length == txtQ2_3A_mm.MaxLength)
                            {
                                txtQ2_3A_dd.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_3A_DD:
                            if (txtQ2_3A_dd.Text.Length == txtQ2_3A_dd.MaxLength)
                            {
                                txtQ2_3A_yy.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_3A_YY:
                            if (txtQ2_3A_yy.Text.Length == txtQ2_3A_yy.MaxLength)
                            {
                                if (txtQ2_3B_mm.Enabled == true)
                                {
                                    txtQ2_3B_mm.Focus();
                                }
                                else
                                {
                                    txtQ3_1.Focus();
                                }
                            }
                            break;
                        case GC_FIELDS_Q2_3B_MM:
                            if (txtQ2_3B_mm.Text.Length == txtQ2_3B_mm.MaxLength)
                            {
                                txtQ2_3B_dd.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_3B_DD:
                            if (txtQ2_3B_dd.Text.Length == txtQ2_3B_dd.MaxLength)
                            {
                                txtQ2_3B_yy.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_3B_YY:
                            if (txtQ2_3B_yy.Text.Length == txtQ2_3B_yy.MaxLength)
                            {
                                txtQ3_1.Focus();
                            }
                            break;
                        case GC_FIELDS_Q3_1:
                            if (txtQ3_1.Text.Length == txtQ3_1.MaxLength)
                            {
                                txtQ3_2.Focus();
                            }
                            break;
                        case GC_FIELDS_Q3_2:
                            if (txtQ3_2.Text.Length == txtQ3_2.MaxLength)
                            {
                                txtQ3_3A_mm.Focus();
                            }
                            break;
                        case GC_FIELDS_Q3_3A_MM:
                            if (txtQ3_3A_mm.Text.Length == txtQ3_3A_mm.MaxLength)
                            {
                                txtQ3_3A_dd.Focus();
                            }
                            break;

                        case GC_FIELDS_Q3_3A_DD:
                            if (txtQ3_3A_dd.Text.Length == txtQ3_3A_dd.MaxLength)
                            {
                                txtQ3_3A_yy.Focus();
                            }
                            break;
                        case GC_FIELDS_Q3_3A_YY:
                            if (txtQ3_3A_yy.Text.Length == txtQ3_3A_yy.MaxLength)
                            {
                                if (txtQ3_3B_mm.Enabled == true)
                                {
                                    txtQ3_3B_mm.Focus();
                                }
                                else
                                {
                                    txtQ3_4_mm.Focus();
                                }
                            }
                            break;
                        case GC_FIELDS_Q3_3B_MM:
                            if (txtQ3_3B_mm.Text.Length == txtQ3_3B_mm.MaxLength)
                            {
                                txtQ3_3B_dd.Focus();
                            }
                            break;
                        case GC_FIELDS_Q3_3B_DD:
                            if (txtQ3_3B_dd.Text.Length == txtQ3_3B_dd.MaxLength)
                            {
                                txtQ3_3B_yy.Focus();
                            }
                            break;
                        case GC_FIELDS_Q3_3B_YY:
                            if (txtQ3_3B_yy.Text.Length == txtQ3_3B_yy.MaxLength)
                            {
                                chksignature.Focus();
                            }
                            break;
                        // CHKSIGNATURE
                        case GC_FIELDS_CHKSIGNATURE:
                            if (chksignature.Checked == true)
                            {
                                txtSign_mm.Focus();
                            }
                            break;
                        case GC_FIELDS_SIGNATUREDATE_MM:
                            if (txtSign_mm.Text.Length == txtSign_mm.MaxLength)
                            {
                                txtSign_dd.Focus();
                            }
                            break;
                        case GC_FIELDS_SIGNATUREDATE_DD:
                            if (txtSign_dd.Text.Length == txtSign_dd.MaxLength)
                            {
                                txtSign_yy.Focus();
                            }
                            break;
                        case GC_FIELDS_SIGNATUREDATE_YY:
                            if (txtSign_yy.Text.Length == txtSign_yy.MaxLength)
                            {
                                txtComments.Focus();
                            }
                            break;
                        case GC_FIELDS_COMMENTS :
                            if (txtComments.Text.Length == txtComments.MaxLength)
                            {
                                btnSave.Focus();
                            }
                            break;
                        //case GC_FIELDS_BARCODE:
                        //    if (txtBarcode.Text.Length == txtBarcode.MaxLength)
                        //    {
                        //        btnSave.Focus();
                        //    }
                        //    break;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private bool txtEnter(object Sender, System.EventArgs e, Control ObjControl)
        {
            try
            {
                if ((ObjControl is TextBox) || (ObjControl is ComboBox) || (ObjControl is CheckBox))
                {
                    switch (ObjControl.Name)
                    {


                        case GC_FIELDS_Q1_1A_MM:
                            //txtDescription.Text = "Q1 [ 1=Very happy, 2=Somewhat happy, 4=Somewhat unhappy, 3=Very unhappy]";
                            //txtQ1.SelectAll();
                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_1A_MM; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_1A_MM; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_1B_MM; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;

                        case GC_FIELDS_Q1_1A_DD:
                            //txtDescription.Text = "Q1 [ 1=Very happy, 2=Somewhat happy, 4=Somewhat unhappy, 3=Very unhappy]";
                            //txtQ1.SelectAll();
                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_1A_DD; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_1A_DD; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_1B_DD; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;

                        case GC_FIELDS_Q1_1A_YY:
                            //txtDescription.Text = "Q1 [ 1=Very happy, 2=Somewhat happy, 4=Somewhat unhappy, 3=Very unhappy]";
                            //txtQ1.SelectAll();
                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_1A_YY; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_1A_YY; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_1A_YY; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;
                        case GC_FIELDS_Q1_1B_MM:
                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_1B_MM; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_1B_MM; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_1B_MM; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;

                        case GC_FIELDS_Q1_1B_DD:
                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_1B_DD; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_1B_DD; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_1B_DD; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;

                        case GC_FIELDS_Q1_1B_YY:
                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_1B_YY; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_1B_YY; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_1B_YY; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;

                        case GC_FIELDS_Q1_2A_MM:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_2A_MM; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_2A_MM; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_2A_MM; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;

                        case GC_FIELDS_Q1_2A_DD:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_2A_DD; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_2A_DD; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_2A_DD; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;

                        case GC_FIELDS_Q1_2A_YY:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_2A_YY; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_2A_YY; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_2A_YY; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;


                        case GC_FIELDS_Q1_2B_MM:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_2B_MM; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_2B_MM; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_2B_MM; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;


                        case GC_FIELDS_Q1_2B_DD:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_2B_DD; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_2B_DD; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_2B_DD; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;


                        case GC_FIELDS_Q1_2B_YY:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_2B_YY; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_2B_YY; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_2B_YY; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;

                        case GC_FIELDS_Q1_3A_MM:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_3A_MM; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_3A_MM; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_3A_MM; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;


                        case GC_FIELDS_Q1_3A_DD:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_3A_DD; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_3A_DD; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_3A_DD; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;


                        case GC_FIELDS_Q1_3A_YY:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_3A_YY; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_3A_YY; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_3A_YY; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;

                        case GC_FIELDS_Q1_3B_MM:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_3B_MM; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_3B_MM; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_3B_MM; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;


                        case GC_FIELDS_Q1_3B_DD:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_3B_DD; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_3B_DD; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_3B_YY; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;

                        case GC_FIELDS_Q1_3B_YY:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_3B_YY; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_3B_YY; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_3B_YY; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;

                        case GC_FIELDS_Q1_4:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_4; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_4; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_4; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;

                        case GC_FIELDS_Q1_5:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q1_5; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q1_5; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q1_5; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 110));
                            break;

                        case GC_FIELDS_Q2_1:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q2_1; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q2_1; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q2_1; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;

                        case GC_FIELDS_Q2_2:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q2_2; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q2_2; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q2_2; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;

                        case GC_FIELDS_Q2_3A_MM:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q2_3A_MM; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q2_3A_MM; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q2_3A_MM; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;


                        case GC_FIELDS_Q2_3A_DD:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q2_3A_DD; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q2_3A_DD; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q2_3A_DD; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;

                        case GC_FIELDS_Q2_3A_YY:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q2_3A_YY; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q2_3A_YY; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q2_3A_YY; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;




                        case GC_FIELDS_Q2_3B_MM:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q2_3B_MM; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q2_3B_MM; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q2_3B_MM; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;


                        case GC_FIELDS_Q2_3B_DD:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q2_3B_DD; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q2_3B_DD; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q2_3B_DD; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;

                        case GC_FIELDS_Q2_3B_YY:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q2_3B_YY; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q2_3B_YY; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q2_3B_YY; }

                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;


                        case GC_FIELDS_Q3_1:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q3_1; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q3_1; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q3_1; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;


                        case GC_FIELDS_Q3_2:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q3_2; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q3_2; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q3_2; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;


                        case GC_FIELDS_Q3_3A_MM:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q3_3A_MM; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q3_3A_MM; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q3_3A_MM; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;

                        case GC_FIELDS_Q3_3A_DD:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q3_3A_DD; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q3_3A_DD; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q3_3A_DD; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;

                        case GC_FIELDS_Q3_3A_YY:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q3_3A_YY; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q3_3A_YY; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q3_3A_YY; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;

                        case GC_FIELDS_Q3_4_MM:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q3_4_MM; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q3_4_MM; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q3_4_MM; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;

                        case GC_FIELDS_Q3_4_DD:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q3_4_DD; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q3_4_DD; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q3_4_DD; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;

                        case GC_FIELDS_Q3_4_YY:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Q3_4_YY; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Q3_4_YY; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Q3_4_YY; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;
                        case GC_FIELDS_CHKSIGNATURE:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Signature; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Signature; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Signature; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;

                        case GC_FIELDS_SIGNATUREDATE_MM:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.SIGNATUREDATE_MM; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.SIGNATUREDATE_MM; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.SIGNATUREDATE_MM; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;


                        case GC_FIELDS_SIGNATUREDATE_DD:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.SIGNATUREDATE_DD; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.SIGNATUREDATE_DD; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.SIGNATUREDATE_DD; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;

                        case GC_FIELDS_SIGNATUREDATE_YY:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.SIGNATUREDATE_YY; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.SIGNATUREDATE_YY; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.SIGNATUREDATE_YY; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;


                        case GC_FIELDS_BARCODE:

                            if (Process.ToUpper() == "KEYQC")
                            {
                                if (getkey1_hedisData != null) { txtKey1Data.Text = getkey1_hedisData.Barcode; }

                                if (getkeyqc_hedisData != null) { txtKey2Data.Text = getkeyqc_hedisData.Barcode; }
                                else if (getkey1_hedisData != null) { txtKey2Data.Text = getkey1_hedisData.Barcode; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 62));
                            break;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void ClearInfo()
        {
            txtQ1_1A_mm.Clear();
            txtQ1_1A_dd.Clear();
            txtQ1_1A_yy.Clear();

            txtQ1_1B_mm.Clear();
            txtQ1_1B_dd.Clear();
            txtQ1_1B_yy.Clear();

            txtQ1_2A_mm.Clear();
            txtQ1_2A_dd.Clear();
            txtQ1_2A_yy.Clear();

            txtQ1_2B_mm.Clear();
            txtQ1_2B_dd.Clear();
            txtQ1_2B_yy.Clear();

            txtQ1_3A_mm.Clear();
            txtQ1_3A_dd.Clear();
            txtQ1_3A_yy.Clear();

            txtQ1_3B_mm.Clear();
            txtQ1_3B_dd.Clear();
            txtQ1_3B_yy.Clear();

            txtQ1_4.Clear();
            txtQ1_5.Clear();
            txtQ2_1.Clear();
            txtQ2_2.Clear();

            txtQ2_3A_mm.Clear();
            txtQ2_3A_dd.Clear();
            txtQ2_3A_yy.Clear();

            txtQ2_3B_mm.Clear();
            txtQ2_3B_dd.Clear();
            txtQ2_3B_yy.Clear();

            txtQ3_1.Clear();
            txtQ3_2.Clear();

            txtQ3_3A_mm.Clear();
            txtQ3_3A_dd.Clear();
            txtQ3_3A_yy.Clear();


            txtQ3_3B_mm.Clear();
            txtQ3_3B_dd.Clear();
            txtQ3_3B_yy.Clear();

            txtQ3_4_mm.Clear();
            txtQ3_4_dd.Clear();
            txtQ3_4_yy.Clear();

            chksignature.Checked = false;

            txtSign_mm.Clear();
            txtSign_dd.Clear();
            txtSign_yy.Clear();
            txtComments.Clear();  


            //txtBarcode.Clear();
            txtKey1User.Clear();
            txtKey1Data.Clear();
            txtKey2User.Clear();
            txtKey2Data.Clear();
            IGImageViewer.ImageClear();
        }

        private long TotalKeystrokes()
        {
            long lngCount = 0;
            lngCount = 0;

            lngCount += txtQ1_1A_mm.Text.Length;
            lngCount += txtQ1_1A_dd.Text.Length;
            lngCount += txtQ1_1A_yy.Text.Length;

            lngCount += txtQ1_1B_mm.Text.Length;
            lngCount += txtQ1_1B_dd.Text.Length;
            lngCount += txtQ1_1B_yy.Text.Length;

            lngCount += txtQ1_2A_mm.Text.Length;
            lngCount += txtQ1_2A_dd.Text.Length;
            lngCount += txtQ1_2A_yy.Text.Length;

            lngCount += txtQ1_2B_mm.TextLength;
            lngCount += txtQ1_2B_dd.TextLength;
            lngCount += txtQ1_2B_yy.TextLength;


            lngCount += txtQ1_3A_mm.TextLength;
            lngCount += txtQ1_3A_dd.TextLength;
            lngCount += txtQ1_3A_yy.TextLength;


            lngCount += txtQ1_3B_mm.TextLength;
            lngCount += txtQ1_3B_dd.TextLength;
            lngCount += txtQ1_3B_yy.TextLength;


            lngCount += txtQ1_4.TextLength;
            lngCount += txtQ1_5.TextLength;
            lngCount += txtQ2_1.TextLength;
            lngCount += txtQ2_2.TextLength;


            lngCount += txtQ2_3A_mm.TextLength;
            lngCount += txtQ2_3A_dd.TextLength;
            lngCount += txtQ2_3A_yy.TextLength;

            lngCount += txtQ2_3B_mm.TextLength;
            lngCount += txtQ2_3B_dd.TextLength;
            lngCount += txtQ2_3B_yy.TextLength;
            lngCount += txtQ3_1.TextLength;
            lngCount += txtQ3_2.TextLength;
            lngCount += txtQ3_3A_mm.TextLength;
            lngCount += txtQ3_3A_dd.TextLength;
            lngCount += txtQ3_3A_yy.TextLength;
            lngCount += txtQ3_3B_mm.TextLength;
            lngCount += txtQ3_3B_dd.TextLength;
            lngCount += txtQ3_3B_yy.TextLength;

            lngCount += txtQ3_4_mm.TextLength;
            lngCount += txtQ3_4_dd.TextLength;
            lngCount += txtQ3_4_yy.TextLength;
            lngCount += chksignature.Checked ? 1 : 0;
            lngCount += txtSign_mm.TextLength;
            lngCount += txtSign_dd.TextLength;
            lngCount += txtSign_yy.TextLength;
            //lngCount += txtBarcode.TextLength; //For new requirement no need add keystroke
            return lngCount;
        }

        private bool LoadImage()
        {
            //bool functionReturnValue = false;
            try
            {
                ClearInfo();
                if (lngBatchID > 0)
                {

                    Image = objImagemaster.LoadImage_HEDIS(Process, lngBatchID, Constance.GC_USERID);
                    if (Image == null)
                    {
                        MessageBox.Show("Batch Completed");
                        objBatchmaster.UpdateBatchmaster(lngBatchID.ToInt(), Process);
                        this.Close();
                        return false;
                    }

                    lngImageID = Image.ImageID;
                    IGImageViewer.ImageName = Image.ImagePath;
                    IGImageViewer.LoadImage();

                    if (Process == Constance.GC_PROCESS_KEY1)
                    {
                        if (!BarcodeWorker.IsBusy)
                        {
                            BarcodeWorker.RunWorkerAsync();
                        }
                    }

                    strImageSize = Interaction.GetSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageSize) + "";
                    if (strImageSize.LastIndexOf(",") > 0)
                    {
                        iHScrol = Convert.ToInt32((strImageSize.Substring(0, strImageSize.LastIndexOf(","))));
                        iVScrol = Convert.ToInt32(strImageSize.Substring(strImageSize.LastIndexOf(",") + 1));
                        IGImageViewer.ImageSize = new System.Drawing.Size(iHScrol, iVScrol);
                    }

                    strImageFit = Interaction.GetSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageFit) + "";
                    if (strImageFit.LastIndexOf(",") > 0)
                    {
                        iHScrol = Convert.ToInt32(strImageFit.Substring(0, strImageFit.LastIndexOf(",")));
                        iVScrol = Convert.ToInt32(strImageFit.Substring(strImageFit.LastIndexOf(",") + 1));
                    }

                    IGImageViewer.MoveImage(iHScrol, iVScrol);
                    IGImageViewer.Refresh();

                    if (Process.ToUpper() == "KEYQC")
                    {
                        RestoreInfo();
                        grpKeyData.Visible = true;
                    }

                    Constance.ImageInTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    int TotalRecord, FinishedRecord, RemainingRecord;
                    TotalRecord = FinishedRecord = RemainingRecord = 0;

                    objImagemaster.RecordStatus(Process, lngBatchID, ref TotalRecord, ref FinishedRecord, ref RemainingRecord, intBatchType);
                    this.stsUser.Text = "User Name : " + Constance.GC_USERNAME;
                    this.stsTotRecs.Text = "Total Recs : " + TotalRecord;
                    this.stsFinRecs.Text = "Finished Rec : " + FinishedRecord;
                    this.stsRemRecs.Text = "Remine Recs: " + RemainingRecord;
                    this.stsDate.Text = "Date : " + DateAndTime.Now.ToString("dd-MMMM-yyyy");

                    txtQ1_1A_mm.Focus();
                    return true;
                }
                else
                {
                    Interaction.MsgBox("Invalid Batch Selection", MsgBoxStyle.Information, Constance.gstrappTitle);
                    this.Close();
                    return false;
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            return true;
        }

        private bool ValidateInfo()
        {
            if (TotalKeystrokes() <= 0)
            {
                if (MessageBox.Show("Do you want to save Blank records?", "Healthtel", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }

        private bool SaveInfo()
        {
            try
            {
                string ImageNumber;
                int iPos;
                string ImagePath = Image.ImagePath;
                string BarcodeVal = string.Empty;

                if (!string.IsNullOrEmpty(ImagePath))
                {
                    if (ImagePath.LastIndexOf("\\") >= ImagePath.Length - 1 & ImagePath.Length > 0)
                    {
                        ImagePath = ImagePath.Substring(0, ImagePath.Length - 1);
                    }
                    iPos = ImagePath.LastIndexOf("\\");
                    ImagePath = ImagePath.Substring(iPos + 1, ImagePath.Length - (iPos + 1));
                    BarcodeVal = ImagePath.Substring(0, ImagePath.IndexOf("."));

                }

                if (Process == Constance.GC_PROCESS_KEY1)
                {
                    key1_hedis checkkey1 = new key1_hedis().isImageIDExists(lngImageID);
                    int Key1_ID = (checkkey1 == null) ? 0 : checkkey1.Key1_ID;
                    key1_hedis objkey1_HEDIS = new key1_hedis(Key1_ID);
                    objkey1_HEDIS.ImageId = lngImageID.ToInt();
                    objkey1_HEDIS.Image_Number = ImagePath;

                    objkey1_HEDIS.Q1_1A_MM = txtQ1_1A_mm.Text.Trim();
                    objkey1_HEDIS.Q1_1A_DD = txtQ1_1A_dd.Text.Trim();
                    objkey1_HEDIS.Q1_1A_YY = txtQ1_1A_yy.Text.Trim();

                    objkey1_HEDIS.Q1_1B_MM = txtQ1_1B_mm.Text.Trim();
                    objkey1_HEDIS.Q1_1B_DD = txtQ1_1B_dd.Text.Trim();
                    objkey1_HEDIS.Q1_1B_YY = txtQ1_1B_yy.Text.Trim();


                    objkey1_HEDIS.Q1_2A_MM = txtQ1_2A_mm.Text.Trim();
                    objkey1_HEDIS.Q1_2A_DD = txtQ1_2A_dd.Text.Trim();
                    objkey1_HEDIS.Q1_2A_YY = txtQ1_2A_yy.Text.Trim();

                    objkey1_HEDIS.Q1_2B_MM = txtQ1_2B_mm.Text.Trim();
                    objkey1_HEDIS.Q1_2B_DD = txtQ1_2B_dd.Text.Trim();
                    objkey1_HEDIS.Q1_2B_YY = txtQ1_2B_yy.Text.Trim();


                    objkey1_HEDIS.Q1_3A_MM = txtQ1_3A_mm.Text.Trim();
                    objkey1_HEDIS.Q1_3A_DD = txtQ1_3A_dd.Text.Trim();
                    objkey1_HEDIS.Q1_3A_YY = txtQ1_3A_yy.Text.Trim();

                    objkey1_HEDIS.Q1_3B_MM = txtQ1_3B_mm.Text.Trim();
                    objkey1_HEDIS.Q1_3B_DD = txtQ1_3B_dd.Text.Trim();
                    objkey1_HEDIS.Q1_3B_YY = txtQ1_3B_yy.Text.Trim();


                    objkey1_HEDIS.Q1_4 = txtQ1_4.Text.Trim();
                    objkey1_HEDIS.Q1_5 = txtQ1_5.Text.Trim();
                    objkey1_HEDIS.Q2_1 = txtQ2_1.Text.Trim();
                    objkey1_HEDIS.Q2_2 = txtQ2_2.Text.Trim();

                    objkey1_HEDIS.Q2_3A_MM = txtQ2_3A_mm.Text.Trim();
                    objkey1_HEDIS.Q2_3A_DD = txtQ2_3A_dd.Text.Trim();
                    objkey1_HEDIS.Q2_3A_YY = txtQ2_3A_yy.Text.Trim();

                    objkey1_HEDIS.Q2_3B_MM = txtQ2_3B_mm.Text.Trim();
                    objkey1_HEDIS.Q2_3B_DD = txtQ2_3B_dd.Text.Trim();
                    objkey1_HEDIS.Q2_3B_YY = txtQ2_3B_yy.Text.Trim();


                    objkey1_HEDIS.Q3_1 = txtQ3_1.Text.Trim();
                    objkey1_HEDIS.Q3_2 = txtQ3_2.Text.Trim();
                    objkey1_HEDIS.Q3_3A_MM = txtQ3_3A_mm.Text.Trim();
                    objkey1_HEDIS.Q3_3A_DD = txtQ3_3A_dd.Text.Trim();
                    objkey1_HEDIS.Q3_3A_YY = txtQ3_3A_yy.Text.Trim();

                    objkey1_HEDIS.Q3_3B_MM = txtQ3_3B_mm.Text.Trim();
                    objkey1_HEDIS.Q3_3B_DD = txtQ3_3B_dd.Text.Trim();
                    objkey1_HEDIS.Q3_3B_YY = txtQ3_3B_yy.Text.Trim();


                    objkey1_HEDIS.Q3_4_MM = txtQ3_4_mm.Text.Trim();
                    objkey1_HEDIS.Q3_4_DD = txtQ3_4_dd.Text.Trim();
                    objkey1_HEDIS.Q3_4_YY = txtQ3_4_yy.Text.Trim();

                    objkey1_HEDIS.Signature = chksignature.Checked ? "1" : "0";
                    objkey1_HEDIS.SIGNATUREDATE_MM = txtSign_mm.Text.Trim();
                    objkey1_HEDIS.SIGNATUREDATE_DD = txtSign_dd.Text.Trim();
                    objkey1_HEDIS.SIGNATUREDATE_YY = txtSign_yy.Text.Trim();

                    //added by sakthi for new requirement,getting barcode value from imagepath
                    objkey1_HEDIS.Barcode = BarcodeVal; //txtBarcode.Text.Trim();
                    objkey1_HEDIS.KeyStroke = TotalKeystrokes().ToInt();

                    objkey1_HEDIS.Comments = txtComments.Text.Trim();

                    objkey1_HEDIS.Store();

                    imagemaster updateImagemasterkey1 = new imagemaster(lngImageID.ToInt());
                    updateImagemasterkey1.Key1 = 2;
                    updateImagemasterkey1.Store();

                    Constance.ImageOutTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                }
                else if (Process == Constance.GC_PROCESS_KEYQC)
                {
                    keyqc_hedis checkkey1 = new keyqc_hedis().isImageIDExists(lngImageID);
                    int keyqc_ID = (checkkey1 == null) ? 0 : checkkey1.Keyqc_ID;
                    keyqc_hedis objkeyqc_HEDIS = new keyqc_hedis(keyqc_ID);
                    objkeyqc_HEDIS.ImageId = lngImageID.ToInt();
                    objkeyqc_HEDIS.Image_Number = ImagePath;

                    objkeyqc_HEDIS.Q1_1A_MM = txtQ1_1A_mm.Text.Trim();
                    objkeyqc_HEDIS.Q1_1A_DD = txtQ1_1A_dd.Text.Trim();
                    objkeyqc_HEDIS.Q1_1A_YY = txtQ1_1A_yy.Text.Trim();

                    objkeyqc_HEDIS.Q1_1B_MM = txtQ1_1B_mm.Text.Trim();
                    objkeyqc_HEDIS.Q1_1B_DD = txtQ1_1B_dd.Text.Trim();
                    objkeyqc_HEDIS.Q1_1B_YY = txtQ1_1B_yy.Text.Trim();


                    objkeyqc_HEDIS.Q1_2A_MM = txtQ1_2A_mm.Text.Trim();
                    objkeyqc_HEDIS.Q1_2A_DD = txtQ1_2A_dd.Text.Trim();
                    objkeyqc_HEDIS.Q1_2A_YY = txtQ1_2A_yy.Text.Trim();


                    objkeyqc_HEDIS.Q1_2B_MM = txtQ1_2B_mm.Text.Trim();
                    objkeyqc_HEDIS.Q1_2B_DD = txtQ1_2B_dd.Text.Trim();
                    objkeyqc_HEDIS.Q1_2B_YY = txtQ1_2B_yy.Text.Trim();


                    objkeyqc_HEDIS.Q1_3A_MM = txtQ1_3A_mm.Text.Trim();
                    objkeyqc_HEDIS.Q1_3A_DD = txtQ1_3A_dd.Text.Trim();
                    objkeyqc_HEDIS.Q1_3A_YY = txtQ1_3A_yy.Text.Trim();


                    objkeyqc_HEDIS.Q1_3B_MM = txtQ1_3B_mm.Text.Trim();
                    objkeyqc_HEDIS.Q1_3B_DD = txtQ1_3B_dd.Text.Trim();
                    objkeyqc_HEDIS.Q1_3B_YY = txtQ1_3B_yy.Text.Trim();


                    objkeyqc_HEDIS.Q1_4 = txtQ1_4.Text.Trim();
                    objkeyqc_HEDIS.Q1_5 = txtQ1_5.Text.Trim();
                    objkeyqc_HEDIS.Q2_1 = txtQ2_1.Text.Trim();
                    objkeyqc_HEDIS.Q2_2 = txtQ2_2.Text.Trim();

                    objkeyqc_HEDIS.Q2_3A_MM = txtQ2_3A_mm.Text.Trim();
                    objkeyqc_HEDIS.Q2_3A_DD = txtQ2_3A_dd.Text.Trim();
                    objkeyqc_HEDIS.Q2_3A_YY = txtQ2_3A_yy.Text.Trim();



                    objkeyqc_HEDIS.Q2_3B_MM = txtQ2_3B_mm.Text.Trim();
                    objkeyqc_HEDIS.Q2_3B_DD = txtQ2_3B_dd.Text.Trim();
                    objkeyqc_HEDIS.Q2_3B_YY = txtQ2_3B_yy.Text.Trim();


                    objkeyqc_HEDIS.Q3_1 = txtQ3_1.Text.Trim();
                    objkeyqc_HEDIS.Q3_2 = txtQ3_2.Text.Trim();


                    objkeyqc_HEDIS.Q3_3A_MM = txtQ3_3A_mm.Text.Trim();
                    objkeyqc_HEDIS.Q3_3A_DD = txtQ3_3A_dd.Text.Trim();
                    objkeyqc_HEDIS.Q3_3A_YY = txtQ3_3A_yy.Text.Trim();


                    objkeyqc_HEDIS.Q3_3B_MM = txtQ3_3B_mm.Text.Trim();
                    objkeyqc_HEDIS.Q3_3B_DD = txtQ3_3B_dd.Text.Trim();
                    objkeyqc_HEDIS.Q3_3B_YY = txtQ3_3B_yy.Text.Trim();


                    objkeyqc_HEDIS.Q3_4_MM = txtQ3_4_mm.Text.Trim();
                    objkeyqc_HEDIS.Q3_4_DD = txtQ3_4_dd.Text.Trim();
                    objkeyqc_HEDIS.Q3_4_YY = txtQ3_4_yy.Text.Trim();

                    objkeyqc_HEDIS.Signature = chksignature.Checked ? "1" : "0";
                    objkeyqc_HEDIS.SIGNATUREDATE_MM = txtSign_mm.Text.Trim();
                    objkeyqc_HEDIS.SIGNATUREDATE_DD = txtSign_dd.Text.Trim();
                    objkeyqc_HEDIS.SIGNATUREDATE_YY = txtSign_yy.Text.Trim();


                    objkeyqc_HEDIS.Barcode = BarcodeVal;// txtBarcode.Text.Trim();
                    objkeyqc_HEDIS.KeyStroke = TotalKeystrokes().ToInt();

                    objkeyqc_HEDIS.Comments = txtComments.Text.Trim();

                    objkeyqc_HEDIS.Store();

                    imagemaster updateImagemastercompareqc = new imagemaster(lngImageID.ToInt());
                    updateImagemastercompareqc.KeyQC = 2;
                    updateImagemastercompareqc.Store();

                    Constance.ImageOutTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                }

                worklog SaveWorklog = new worklog();
                SaveWorklog.UserID = Constance.GC_USERID;
                SaveWorklog.ImageID = lngImageID.ToInt();
                SaveWorklog.In = Convert.ToDateTime(Constance.ImageInTime);
                SaveWorklog.Out = Convert.ToDateTime(Constance.ImageOutTime);
                SaveWorklog.Process = Process;
                SaveWorklog.EXE_Status = Constance.GC_PROJ_VERSIONSTATUS;
                SaveWorklog.Store();

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void RestoreInfo()
        {
            try
            {
                getkeyqc_hedisData = objKeyqc.KeyQCDatas(lngImageID.ToInt());

                if (getkeyqc_hedisData == null)
                {
                    getkey1_hedisData = objKey1.Key1Datas(lngImageID.ToInt());
                }


                if (getkeyqc_hedisData != null)
                {
                    txtQ1_1A_mm.Text = getkeyqc_hedisData.Q1_1A_MM;
                    txtQ1_1A_dd.Text = getkeyqc_hedisData.Q1_1A_DD;
                    txtQ1_1A_yy.Text = getkeyqc_hedisData.Q1_1A_YY;

                    txtQ1_1B_mm.Text = getkeyqc_hedisData.Q1_1B_MM;
                    txtQ1_1B_dd.Text = getkeyqc_hedisData.Q1_1B_DD;
                    txtQ1_1B_yy.Text = getkeyqc_hedisData.Q1_1B_YY;

                    txtQ1_2A_mm.Text = getkeyqc_hedisData.Q1_2A_MM;
                    txtQ1_2A_dd.Text = getkeyqc_hedisData.Q1_2A_DD;
                    txtQ1_2A_yy.Text = getkeyqc_hedisData.Q1_2A_YY;

                    txtQ1_2B_mm.Text = getkeyqc_hedisData.Q1_2B_MM;
                    txtQ1_2B_dd.Text = getkeyqc_hedisData.Q1_2B_DD;
                    txtQ1_2B_yy.Text = getkeyqc_hedisData.Q1_2B_YY;

                    txtQ1_3A_mm.Text = getkeyqc_hedisData.Q1_3A_MM;
                    txtQ1_3A_dd.Text = getkeyqc_hedisData.Q1_3A_DD;
                    txtQ1_3A_yy.Text = getkeyqc_hedisData.Q1_3A_YY;


                    txtQ1_3B_mm.Text = getkeyqc_hedisData.Q1_3B_MM;
                    txtQ1_3B_dd.Text = getkeyqc_hedisData.Q1_3B_DD;
                    txtQ1_3B_yy.Text = getkeyqc_hedisData.Q1_3B_YY;

                    txtQ1_4.Text = getkeyqc_hedisData.Q1_4;
                    txtQ1_5.Text = getkeyqc_hedisData.Q1_5;
                    txtQ2_1.Text = getkeyqc_hedisData.Q2_1;
                    txtQ2_2.Text = getkeyqc_hedisData.Q2_2;

                    txtQ2_3A_mm.Text = getkeyqc_hedisData.Q2_3A_MM;
                    txtQ2_3A_dd.Text = getkeyqc_hedisData.Q2_3A_DD;
                    txtQ2_3A_yy.Text = getkeyqc_hedisData.Q2_3A_YY;

                    txtQ2_3B_mm.Text = getkeyqc_hedisData.Q2_3B_MM;
                    txtQ2_3B_dd.Text = getkeyqc_hedisData.Q2_3B_DD;
                    txtQ2_3B_yy.Text = getkeyqc_hedisData.Q2_3B_YY;

                    txtQ3_1.Text = getkeyqc_hedisData.Q3_1;
                    txtQ3_2.Text = getkeyqc_hedisData.Q3_2;

                    txtQ3_3A_mm.Text = getkeyqc_hedisData.Q3_3A_MM;
                    txtQ3_3A_dd.Text = getkeyqc_hedisData.Q3_3A_DD;
                    txtQ3_3A_yy.Text = getkeyqc_hedisData.Q3_3A_YY;

                    txtQ3_3B_mm.Text = getkeyqc_hedisData.Q3_3B_MM;
                    txtQ3_3B_dd.Text = getkeyqc_hedisData.Q3_3B_DD;
                    txtQ3_3B_yy.Text = getkeyqc_hedisData.Q3_3B_YY;

                    txtQ3_4_mm.Text = getkeyqc_hedisData.Q3_4_MM;
                    txtQ3_4_dd.Text = getkeyqc_hedisData.Q3_4_DD;
                    txtQ3_4_yy.Text = getkeyqc_hedisData.Q3_4_YY;

                    if (getkeyqc_hedisData.Signature == "1") { chksignature.Checked = true; } else { chksignature.Checked = false; }
                    txtSign_mm.Text = getkeyqc_hedisData.SIGNATUREDATE_MM;
                    txtSign_dd.Text = getkeyqc_hedisData.SIGNATUREDATE_DD;
                    txtSign_yy.Text = getkeyqc_hedisData.SIGNATUREDATE_YY;

                    txtBarcode.Text = getkeyqc_hedisData.Barcode;
                    txtComments.Text = getkeyqc_hedisData.Comments;

                    txtKey1User.Text = getkeyqc_hedisData.UserName;
                }
                else if (getkey1_hedisData != null)
                {
                    txtQ1_1A_mm.Text = getkey1_hedisData.Q1_1A_MM;
                    txtQ1_1A_dd.Text = getkey1_hedisData.Q1_1A_DD;
                    txtQ1_1A_yy.Text = getkey1_hedisData.Q1_1A_YY;

                    txtQ1_1B_mm.Text = getkey1_hedisData.Q1_1B_MM;
                    txtQ1_1B_dd.Text = getkey1_hedisData.Q1_1B_DD;
                    txtQ1_1B_yy.Text = getkey1_hedisData.Q1_1B_YY;

                    txtQ1_2A_mm.Text = getkey1_hedisData.Q1_2A_MM;
                    txtQ1_2A_dd.Text = getkey1_hedisData.Q1_2A_DD;
                    txtQ1_2A_yy.Text = getkey1_hedisData.Q1_2A_YY;

                    txtQ1_2B_mm.Text = getkey1_hedisData.Q1_2B_MM;
                    txtQ1_2B_dd.Text = getkey1_hedisData.Q1_2B_DD;
                    txtQ1_2B_yy.Text = getkey1_hedisData.Q1_2B_YY;

                    txtQ1_3A_mm.Text = getkey1_hedisData.Q1_3A_MM;
                    txtQ1_3A_dd.Text = getkey1_hedisData.Q1_3A_DD;
                    txtQ1_3A_yy.Text = getkey1_hedisData.Q1_3A_YY;


                    txtQ1_3B_mm.Text = getkey1_hedisData.Q1_3B_MM;
                    txtQ1_3B_dd.Text = getkey1_hedisData.Q1_3B_DD;
                    txtQ1_3B_yy.Text = getkey1_hedisData.Q1_3B_YY;

                    txtQ1_4.Text = getkey1_hedisData.Q1_4;
                    txtQ1_5.Text = getkey1_hedisData.Q1_5;
                    txtQ2_1.Text = getkey1_hedisData.Q2_1;
                    txtQ2_2.Text = getkey1_hedisData.Q2_2;

                    txtQ2_3A_mm.Text = getkey1_hedisData.Q2_3A_MM;
                    txtQ2_3A_dd.Text = getkey1_hedisData.Q2_3A_DD;
                    txtQ2_3A_yy.Text = getkey1_hedisData.Q2_3A_YY;

                    txtQ2_3B_mm.Text = getkey1_hedisData.Q2_3B_MM;
                    txtQ2_3B_dd.Text = getkey1_hedisData.Q2_3B_DD;
                    txtQ2_3B_yy.Text = getkey1_hedisData.Q2_3B_YY;

                    txtQ3_1.Text = getkey1_hedisData.Q3_1;
                    txtQ3_2.Text = getkey1_hedisData.Q3_2;

                    txtQ3_3A_mm.Text = getkey1_hedisData.Q3_3A_MM;
                    txtQ3_3A_dd.Text = getkey1_hedisData.Q3_3A_DD;
                    txtQ3_3A_yy.Text = getkey1_hedisData.Q3_3A_YY;

                    txtQ3_3B_mm.Text = getkey1_hedisData.Q3_3B_MM;
                    txtQ3_3B_dd.Text = getkey1_hedisData.Q3_3B_DD;
                    txtQ3_3B_yy.Text = getkey1_hedisData.Q3_3B_YY;

                    txtQ3_4_mm.Text = getkey1_hedisData.Q3_4_MM;
                    txtQ3_4_dd.Text = getkey1_hedisData.Q3_4_DD;
                    txtQ3_4_yy.Text = getkey1_hedisData.Q3_4_YY;

                    if (getkey1_hedisData.Signature == "1") { chksignature.Checked = true; } else { chksignature.Checked = false; }

                    txtSign_mm.Text = getkey1_hedisData.SIGNATUREDATE_MM;
                    txtSign_dd.Text = getkey1_hedisData.SIGNATUREDATE_DD;
                    txtSign_yy.Text = getkey1_hedisData.SIGNATUREDATE_YY;

                    //txtBarcode.Text = getkey1_hedisData.Barcode;
                    txtComments.Text = getkey1_hedisData.Comments;

                    txtKey1User.Text = getkey1_hedisData.UserName;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SaveandLoad()
        {
            if (ValidateInfo() == true)
            {
                if (SaveInfo() == true)
                {
                    LoadImage();
                }
            }
        }

        private void EnableFields()
        {
            txtQ1_1A_mm.Enabled = true;
            txtQ1_1A_dd.Enabled = true;
            txtQ1_1A_yy.Enabled = true;
            txtQ1_1B_mm.Enabled = true;
            txtQ1_1B_dd.Enabled = true;
            txtQ1_1B_yy.Enabled = true;
            txtQ1_2A_mm.Enabled = true;
            txtQ1_2A_dd.Enabled = true;
            txtQ1_2A_yy.Enabled = true;
            txtQ1_2B_mm.Enabled = true;
            txtQ1_2B_dd.Enabled = true;
            txtQ1_2B_yy.Enabled = true;
            txtQ1_3A_mm.Enabled = true;
            txtQ1_3A_dd.Enabled = true;
            txtQ1_3A_yy.Enabled = true;
            txtQ1_3B_mm.Enabled = true;
            txtQ1_3B_dd.Enabled = true;
            txtQ1_3B_yy.Enabled = true;
            txtQ1_4.Enabled = true;
            txtQ1_5.Enabled = true;
            txtQ2_1.Enabled = true;
            txtQ2_2.Enabled = true;
            txtQ2_3A_mm.Enabled = true;
            txtQ2_3A_dd.Enabled = true;
            txtQ2_3A_yy.Enabled = true;
            txtQ2_3B_mm.Enabled = true;
            txtQ2_3B_dd.Enabled = true;
            txtQ2_3B_yy.Enabled = true;
            txtQ3_1.Enabled = true;
            txtQ3_2.Enabled = true;
            txtQ3_3A_mm.Enabled = true;
            txtQ3_3A_dd.Enabled = true;
            txtQ3_3A_yy.Enabled = true;
            txtQ3_3B_mm.Enabled = true;
            txtQ3_3B_dd.Enabled = true;
            txtQ3_3B_yy.Enabled = true;
            txtQ3_4_mm.Enabled = true;
            txtQ3_4_dd.Enabled = true;
            txtQ3_4_yy.Enabled = true;

            chksignature.Enabled = true;
            txtSign_mm.Enabled = true;
            txtSign_dd.Enabled = true;
            txtSign_yy.Enabled = true;
            txtBarcode.Enabled = true;
        }

        #endregion

        #region Events

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveandLoad();
        }

        private void FrmKeying_HEDIS_Load(object sender, EventArgs e)
        {
            LoadImage();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void FrmKeying_HEDIS_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.Alt & e.KeyCode == Keys.Right)
            {
                IGImageViewer.NextImage(sender, e);
            }
            else if (e.Alt & e.KeyCode == Keys.Left)
            {
                IGImageViewer.PrevImage(sender, e);
            }
            else if (e.Control & (e.KeyCode == Keys.Oemplus || e.KeyCode == Keys.Add))
            {
                IGImageViewer.ZoomIn(sender, e);
            }
            else if (e.Control & (e.KeyCode == Keys.OemMinus || e.KeyCode == Keys.Subtract))
            {
                IGImageViewer.ZoomOut(sender, e);
            }
            else if (e.Control == true & (e.KeyCode == Keys.D1 | e.KeyCode == Keys.NumPad1))
            {
                IGImageViewer.RotateLeft(sender, e);
            }
            else if (e.Control == true & (e.KeyCode == Keys.D2 | e.KeyCode == Keys.NumPad2))
            {
                IGImageViewer.RotateRight(sender, e);
            }
            else if (e.Control & e.KeyCode == Keys.Right)
            {
                IGImageViewer.PageRight();
            }
            else if (e.Control & e.KeyCode == Keys.Left)
            {
                IGImageViewer.PageLeft();
            }
            else if (e.Control & e.KeyCode == Keys.Down)
            {
                IGImageViewer.PageDown();
            }
            else if (e.Control & e.KeyCode == Keys.Up)
            {
                IGImageViewer.PageUp();
            }
            else if (e.Control & e.KeyCode == Keys.PageUp)
            {
                IGImageViewer.PageHome();
            }
            else if (e.Control & e.KeyCode == Keys.Next)
            {
                IGImageViewer.PageEnd();
            }
            //else if (e.Control & e.KeyCode == Keys.Home)
            //{
            //    IGImageViewer.firstpage();
            //}
            //else if (e.Control & e.KeyCode == Keys.End)
            //{
            //    IGImageViewer.lastpage();
            //}
            else if (e.KeyCode == Keys.F5)
            {
                strImageFit = IGImageViewer.ImageHorizontalScroll.Value + "," + IGImageViewer.ImageVerticalScroll.Value;
                strImageSize = IGImageViewer.ImageSize.Width + "," + IGImageViewer.ImageSize.Height;
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageFit, strImageFit);
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageSize, strImageSize);
            }
            else if (e.KeyCode == Keys.F6)
            {
                //IGImageViewer.resizeimg();
                strImageFit = IGImageViewer.ImageHorizontalScroll.Minimum + "," + IGImageViewer.ImageVerticalScroll.Minimum;
                strImageSize = "";
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageFit, strImageFit);
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageSize, strImageSize);

                IGImageViewer.ImageClear();
                IGImageViewer.ImageName = Image.ImagePath;
                IGImageViewer.LoadImage();
            }
            else if (e.Control & e.KeyCode == Keys.F7)
            {
                //IGImageViewer.imgfitwidth();
            }
            else if (e.Control & e.KeyCode == Keys.F8)
            {
                //IGImageViewer.imgfitscreen();
            }
            else if (e.KeyCode == Keys.F1)
            {
                EnableFields();
            }
            else if (e.KeyCode == Keys.F4)
            {
                if (this.ActiveControl.Name == "txtQ1_1A_mm" || this.ActiveControl.Name == "txtQ1_1A_dd" || this.ActiveControl.Name == "txtQ1_1A_yy")
                {
                    if (grpbxQ1_1B.Enabled == true)
                    {
                        grpbxQ1_1B.Enabled = false;
                    }
                    else if (grpbxQ1_1B.Enabled == false)
                    {
                        grpbxQ1_1B.Enabled = true;
                    }
                }
                else if (this.ActiveControl.Name == "txtQ1_2A_mm" || this.ActiveControl.Name == "txtQ1_2A_dd" || this.ActiveControl.Name == "txtQ1_2A_yy")
                {
                    if (grpbxQ1_2B.Enabled == true)
                    {
                        grpbxQ1_2B.Enabled = false;
                    }
                    else if (grpbxQ1_2B.Enabled == false)
                    {
                        grpbxQ1_2B.Enabled = true;
                    }
                }
                else if (this.ActiveControl.Name == "txtQ1_3A_mm" || this.ActiveControl.Name == "txtQ1_3A_dd" || this.ActiveControl.Name == "txtQ1_3A_yy")
                {
                    if (grpbxQ1_3B.Enabled == true)
                    {
                        grpbxQ1_3B.Enabled = false;
                    }
                    else if (grpbxQ1_3B.Enabled == false)
                    {
                        grpbxQ1_3B.Enabled = true;
                    }
                }
                else if (this.ActiveControl.Name == "txtQ2_3A_mm" || this.ActiveControl.Name == "txtQ2_3A_dd" || this.ActiveControl.Name == "txtQ2_3A_yy")
                {
                    if (grpbxQ2_3B.Enabled == true)
                    {
                        grpbxQ2_3B.Enabled = false;
                    }
                    else if (grpbxQ2_3B.Enabled == false)
                    {
                        grpbxQ2_3B.Enabled = true;
                    }
                }
                else if (this.ActiveControl.Name == "txtQ3_3A_mm" || this.ActiveControl.Name == "txtQ3_3A_dd" || this.ActiveControl.Name == "txtQ3_3A_yy")
                {
                    if (grpbxQ3_3B.Enabled == true)
                    {
                        grpbxQ3_3B.Enabled = false;
                    }
                    else if (grpbxQ3_3B.Enabled == false)
                    {
                        grpbxQ3_3B.Enabled = true;
                    }
                }
                //else if (this.ActiveControl.Name == "txtQ3_3B_mm" || this.ActiveControl.Name == "txtQ3_3B_dd" || this.ActiveControl.Name == "txtQ3_3B_yy")
                //{
                //    if (grpbxQ3_4.Enabled == true)
                //    {
                //        grpbxQ3_4.Enabled = false;
                //    }
                //    else if (grpbxQ3_4.Enabled == false)
                //    {
                //        grpbxQ3_4.Enabled = true;
                //    }
                //}
            }

        }

        private void FrmKeying_HEDIS_FormClosing_1(object sender, FormClosingEventArgs e)
        {
            objImagemaster.ImageReset(Process, lngImageID);
        }

        private void txtQ1_1A_mm_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_1A_mm);
        }

        private void txtQ1_1A_dd_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_1A_dd);
        }

        private void txtQ1_1A_yy_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_1A_yy);
        }

        private void txtQ1_1B_mm_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_1B_mm);
        }

        private void txtQ1_1B_dd_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_1B_dd);
        }

        private void txtQ1_1B_yy_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_1B_yy);
        }

        private void txtQ1_2A_mm_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_2A_mm);
        }

        private void txtQ1_2A_dd_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_2A_dd);
        }

        private void txtQ1_2A_yy_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_2A_yy);
        }

        private void txtQ1_2B_mm_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_2B_mm);
        }

        private void txtQ1_2B_dd_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_2B_dd);
        }

        private void txtQ1_2B_yy_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_2B_yy);
        }

        private void txtQ1_3A_mm_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_3A_mm);
        }

        private void txtQ1_3A_dd_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_3A_dd);
        }

        private void txtQ1_3A_yy_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_3A_yy);
        }

        private void txtQ1_3B_mm_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_3B_mm);
        }

        private void txtQ1_3B_dd_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_3B_dd);
        }

        private void txtQ1_3B_yy_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_3B_yy);
        }

        private void txtQ1_4_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_4);
        }

        private void txtQ1_5_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_5);
        }

        private void txtQ2_1_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_1);
        }

        private void txtQ2_2_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_2);
        }

        private void txtQ2_3A_mm_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_3A_mm);
        }

        private void txtQ2_3A_dd_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_3A_dd);
        }

        private void txtQ2_3A_yy_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_3A_yy);
        }

        private void txtQ2_3B_mm_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_3B_mm);
        }

        private void txtQ2_3B_dd_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_3B_dd);
        }

        private void txtQ2_3B_yy_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_3B_yy);
        }

        private void txtQ3_1_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3_1);
        }

        private void txtQ3_2_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3_2);
        }

        private void txtQ3_3A_mm_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3_3A_mm);
        }

        private void txtQ3_3A_dd_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3_3A_dd);
        }

        private void txtQ3_3A_yy_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3_3A_yy);
        }

        private void txtQ3_3B_mm_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3_3B_mm);
        }

        private void txtQ3_3B_dd_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3_3B_dd);
        }

        private void txtQ3_3B_yy_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3_3B_yy);
        }

        private void txtQ3_4_mm_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3_4_mm);
        }

        private void txtQ3_4_dd_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3_4_dd);
        }

        private void txtQ3_4_yy_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3_4_yy);
        }

        private void txtSign_mm_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtSign_mm);
        }

        private void txtSign_dd_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtSign_dd);
        }

        private void txtSign_yy_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtSign_yy);
        }

        private void txtBarcode_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtBarcode);
        }

        private void txtQ1_1A_mm_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_1A_mm.Text.Trim()))
            {
                string Month;
                Month = IGUtilities.ValidateMonth(txtQ1_1A_mm.Text.Trim());
                if (Month.Length == 2) { txtQ1_1A_mm.Text = Month; } else { MessageBox.Show(Month); txtQ1_1A_mm.Focus(); }
            }
        }

        private void txtQ1_1A_dd_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_1A_dd.Text.Trim()) && (!string.IsNullOrEmpty(txtQ1_1A_mm.Text.Trim())))
            {
                string date;
                date = IGUtilities.ValidateDate(txtQ1_1A_dd.Text.Trim(), txtQ1_1A_mm.Text.Trim());
                if (date.Length == 2) { txtQ1_1A_dd.Text = date; } else { MessageBox.Show(date); txtQ1_1A_dd.Focus(); }
            }
        }

        private void txtQ1_1A_yy_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_1A_yy.Text.Trim()))
            {
                string year = IGUtilities.ValidateYear(txtQ1_1A_mm.Text.Trim(), txtQ1_1A_dd.Text.Trim(), txtQ1_1A_yy.Text.Trim());
                if (year.Length == 4)
                {
                    //txtDOSyy.Text = year;
                }
                else
                {
                    MessageBox.Show(year);
                    txtQ1_1A_yy.Clear();
                    txtQ1_1A_yy.Focus();
                }
            }
        }

        private void txtQ1_1B_mm_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_1B_mm.Text.Trim()))
            {
                string Month;
                Month = IGUtilities.ValidateMonth(txtQ1_1B_mm.Text.Trim());
                if (Month.Length == 2) { txtQ1_1B_mm.Text = Month; } else { MessageBox.Show(Month); txtQ1_1B_mm.Focus(); }
            }
        }

        private void txtQ1_1B_dd_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_1B_dd.Text.Trim()) && (!string.IsNullOrEmpty(txtQ1_1B_mm.Text.Trim())))
            {
                string date;
                date = IGUtilities.ValidateDate(txtQ1_1B_dd.Text.Trim(), txtQ1_1B_mm.Text.Trim());
                if (date.Length == 2) { txtQ1_1B_dd.Text = date; } else { MessageBox.Show(date); txtQ1_1B_dd.Focus(); }
            }
        }

        private void txtQ1_1B_yy_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_1B_yy.Text.Trim()))
            {
                string year = IGUtilities.ValidateYear(txtQ1_1B_mm.Text.Trim(), txtQ1_1B_dd.Text.Trim(), txtQ1_1B_yy.Text.Trim());
                if (year.Length == 4)
                {
                    //txtDOSyy.Text = year;
                }
                else
                {
                    MessageBox.Show(year);
                    txtQ1_1B_yy.Clear();
                    txtQ1_1B_yy.Focus();
                }
            }
        }

        private void txtQ1_2A_mm_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_2A_mm.Text.Trim()))
            {
                string Month;
                Month = IGUtilities.ValidateMonth(txtQ1_2A_mm.Text.Trim());
                if (Month.Length == 2) { txtQ1_2A_mm.Text = Month; } else { MessageBox.Show(Month); txtQ1_2A_mm.Focus(); }
            }
        }

        private void txtQ1_2A_dd_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_2A_dd.Text.Trim()) && (!string.IsNullOrEmpty(txtQ1_2A_mm.Text.Trim())))
            {
                string date;
                date = IGUtilities.ValidateDate(txtQ1_2A_dd.Text.Trim(), txtQ1_2A_mm.Text.Trim());
                if (date.Length == 2) { txtQ1_2A_dd.Text = date; } else { MessageBox.Show(date); txtQ1_2A_dd.Focus(); }
            }
        }

        private void txtQ1_2A_yy_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_2A_yy.Text.Trim()))
            {
                string year = IGUtilities.ValidateYear(txtQ1_2A_mm.Text.Trim(), txtQ1_2A_dd.Text.Trim(), txtQ1_2A_yy.Text.Trim());
                if (year.Length == 4)
                {
                    //txtDOSyy.Text = year;
                }
                else
                {
                    MessageBox.Show(year);
                    txtQ1_2A_yy.Clear();
                    txtQ1_2A_yy.Focus();
                }
            }
        }

        private void txtQ1_2B_mm_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_2B_mm.Text.Trim()))
            {
                string Month;
                Month = IGUtilities.ValidateMonth(txtQ1_2B_mm.Text.Trim());
                if (Month.Length == 2) { txtQ1_2B_mm.Text = Month; } else { MessageBox.Show(Month); txtQ1_2B_mm.Focus(); }
            }
        }

        private void txtQ1_2B_dd_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_2B_dd.Text.Trim()) && (!string.IsNullOrEmpty(txtQ1_2B_mm.Text.Trim())))
            {
                string date;
                date = IGUtilities.ValidateDate(txtQ1_2B_dd.Text.Trim(), txtQ1_2B_mm.Text.Trim());
                if (date.Length == 2) { txtQ1_2B_dd.Text = date; } else { MessageBox.Show(date); txtQ1_2B_dd.Focus(); }
            }
        }

        private void txtQ1_2B_yy_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_2B_yy.Text.Trim()))
            {
                string year = IGUtilities.ValidateYear(txtQ1_2B_mm.Text.Trim(), txtQ1_2B_dd.Text.Trim(), txtQ1_2B_yy.Text.Trim());
                if (year.Length == 4)
                {
                    //txtDOSyy.Text = year;
                }
                else
                {
                    MessageBox.Show(year);
                    txtQ1_2B_yy.Clear();
                    txtQ1_2B_yy.Focus();
                }
            }
        }

        private void txtQ1_3A_mm_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_3A_mm.Text.Trim()))
            {
                string Month;
                Month = IGUtilities.ValidateMonth(txtQ1_3A_mm.Text.Trim());
                if (Month.Length == 2) { txtQ1_3A_mm.Text = Month; } else { MessageBox.Show(Month); txtQ1_3A_mm.Focus(); }
            }
        }

        private void txtQ1_3A_dd_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_3A_dd.Text.Trim()) && (!string.IsNullOrEmpty(txtQ1_3A_mm.Text.Trim())))
            {
                string date;
                date = IGUtilities.ValidateDate(txtQ1_3A_dd.Text.Trim(), txtQ1_3A_mm.Text.Trim());
                if (date.Length == 2) { txtQ1_3A_dd.Text = date; } else { MessageBox.Show(date); txtQ1_3A_dd.Focus(); }
            }
        }

        private void txtQ1_3A_yy_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_3A_yy.Text.Trim()))
            {
                string year = IGUtilities.ValidateYear(txtQ1_3A_mm.Text.Trim(), txtQ1_3A_dd.Text.Trim(), txtQ1_3A_yy.Text.Trim());
                if (year.Length == 4)
                {
                    //txtDOSyy.Text = year;
                }
                else
                {
                    MessageBox.Show(year);
                    txtQ1_3A_yy.Clear();
                    txtQ1_3A_yy.Focus();
                }
            }
        }

        private void txtQ1_3B_mm_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_3B_mm.Text.Trim()))
            {
                string Month;
                Month = IGUtilities.ValidateMonth(txtQ1_3B_mm.Text.Trim());
                if (Month.Length == 2) { txtQ1_3B_mm.Text = Month; } else { MessageBox.Show(Month); txtQ1_3B_mm.Focus(); }
            }
        }

        private void txtQ1_3B_dd_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_3B_dd.Text.Trim()) && (!string.IsNullOrEmpty(txtQ1_3B_mm.Text.Trim())))
            {
                string date;
                date = IGUtilities.ValidateDate(txtQ1_3B_dd.Text.Trim(), txtQ1_3B_mm.Text.Trim());
                if (date.Length == 2) { txtQ1_3B_dd.Text = date; } else { MessageBox.Show(date); txtQ1_3B_dd.Focus(); }
            }
        }

        private void txtQ1_3B_yy_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ1_3B_yy.Text.Trim()))
            {
                string year = IGUtilities.ValidateYear(txtQ1_3B_mm.Text.Trim(), txtQ1_3B_dd.Text.Trim(), txtQ1_3B_yy.Text.Trim());
                if (year.Length == 4)
                {
                    //txtDOSyy.Text = year;
                }
                else
                {
                    MessageBox.Show(year);
                    txtQ1_3B_yy.Clear();
                    txtQ1_3B_yy.Focus();
                }
            }
        }

        private void txtQ2_3A_mm_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ2_3A_mm.Text.Trim()))
            {
                string Month;
                Month = IGUtilities.ValidateMonth(txtQ2_3A_mm.Text.Trim());
                if (Month.Length == 2) { txtQ2_3A_mm.Text = Month; } else { MessageBox.Show(Month); txtQ2_3A_mm.Focus(); }
            }
        }

        private void txtQ2_3A_dd_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ2_3A_dd.Text.Trim()) && (!string.IsNullOrEmpty(txtQ2_3A_mm.Text.Trim())))
            {
                string date;
                date = IGUtilities.ValidateDate(txtQ2_3A_dd.Text.Trim(), txtQ2_3A_mm.Text.Trim());
                if (date.Length == 2) { txtQ2_3A_dd.Text = date; } else { MessageBox.Show(date); txtQ2_3A_dd.Focus(); }
            }
        }

        private void txtQ2_3A_yy_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ2_3A_yy.Text.Trim()))
            {
                string year = IGUtilities.ValidateYear(txtQ2_3A_mm.Text.Trim(), txtQ2_3A_dd.Text.Trim(), txtQ2_3A_yy.Text.Trim());
                if (year.Length == 4)
                {
                    //txtDOSyy.Text = year;
                }
                else
                {
                    MessageBox.Show(year);
                    txtQ2_3A_yy.Clear();
                    txtQ2_3A_yy.Focus();
                }
            }
        }

        private void txtQ2_3B_mm_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ2_3B_mm.Text.Trim()))
            {
                string Month;
                Month = IGUtilities.ValidateDate(txtQ2_3B_mm.Text.Trim(), txtQ2_3B_mm.Text.Trim());
                if (Month.Length == 2) { txtQ2_3B_mm.Text = Month; } else { MessageBox.Show(Month); txtQ2_3B_mm.Focus(); }
            }
        }

        private void txtQ2_3B_dd_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ2_3B_dd.Text.Trim()) && (!string.IsNullOrEmpty(txtQ2_3B_mm.Text.Trim())))
            {
                string date;
                date = IGUtilities.ValidateDate(txtQ2_3B_dd.Text.Trim(), txtQ2_3B_mm.Text.Trim());
                if (date.Length == 2) { txtQ2_3B_dd.Text = date; } else { MessageBox.Show(date); txtQ2_3B_dd.Focus(); }
            }
        }

        private void txtQ2_3B_yy_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ2_3B_yy.Text.Trim()))
            {
                string year = IGUtilities.ValidateYear(txtQ2_3B_mm.Text.Trim(), txtQ2_3B_dd.Text.Trim(), txtQ2_3B_yy.Text.Trim());
                if (year.Length == 4)
                {
                    //txtDOSyy.Text = year;
                }
                else
                {
                    MessageBox.Show(year);
                    txtQ2_3B_yy.Clear();
                    txtQ2_3B_yy.Focus();
                }
            }
        }

        private void txtQ3_3A_mm_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ3_3A_mm.Text.Trim()))
            {
                string Month;
                Month = IGUtilities.ValidateMonth(txtQ3_3A_mm.Text.Trim());
                if (Month.Length == 2) { txtQ3_3A_mm.Text = Month; } else { MessageBox.Show(Month); txtQ3_3A_mm.Focus(); }
            }
        }

        private void txtQ3_3A_dd_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ3_3A_dd.Text.Trim()) && (!string.IsNullOrEmpty(txtQ3_3A_mm.Text.Trim())))
            {
                string date;
                date = IGUtilities.ValidateDate(txtQ3_3A_dd.Text.Trim(), txtQ3_3A_mm.Text.Trim());
                if (date.Length == 2) { txtQ3_3A_dd.Text = date; } else { MessageBox.Show(date); txtQ3_3A_dd.Focus(); }
            }
        }

        private void txtQ3_3A_yy_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ3_3A_yy.Text.Trim()))
            {
                string year = IGUtilities.ValidateYear(txtQ3_3A_mm.Text.Trim(), txtQ3_3A_dd.Text.Trim(), txtQ3_3A_yy.Text.Trim());
                if (year.Length == 4)
                {
                    //txtDOSyy.Text = year;
                }
                else
                {
                    MessageBox.Show(year);
                    txtQ3_3A_yy.Clear();
                    txtQ3_3A_yy.Focus();
                }
            }
        }

        private void txtQ3_3B_mm_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ3_3B_mm.Text.Trim()))
            {
                string Month;
                Month = IGUtilities.ValidateDate(txtQ3_3B_mm.Text.Trim(), txtQ3_3B_mm.Text.Trim());
                if (Month.Length == 2) { txtQ3_3B_mm.Text = Month; } else { MessageBox.Show(Month); txtQ3_3B_mm.Focus(); }
            }
        }

        private void txtQ3_3B_dd_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ3_3B_dd.Text.Trim()) && (!string.IsNullOrEmpty(txtQ3_3B_mm.Text.Trim())))
            {
                string date;
                date = IGUtilities.ValidateDate(txtQ3_3B_dd.Text.Trim(), txtQ3_3B_mm.Text.Trim());
                if (date.Length == 2) { txtQ3_3B_dd.Text = date; } else { MessageBox.Show(date); txtQ3_3B_dd.Focus(); }
            }
        }

        private void txtQ3_3B_yy_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ3_3B_yy.Text.Trim()))
            {
                string year = IGUtilities.ValidateYear(txtQ3_3B_mm.Text.Trim(), txtQ3_3B_dd.Text.Trim(), txtQ3_3B_yy.Text.Trim());
                if (year.Length == 4)
                {
                    //txtDOSyy.Text = year;
                }
                else
                {
                    MessageBox.Show(year);
                    txtQ3_3B_yy.Clear();
                    txtQ3_3B_yy.Focus();
                }
            }
        }

        private void txtQ3_4_mm_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ3_4_mm.Text.Trim()))
            {
                string Month;
                Month = IGUtilities.ValidateMonth(txtQ3_4_mm.Text.Trim());
                if (Month.Length == 2) { txtQ3_4_mm.Text = Month; } else { MessageBox.Show(Month); txtQ3_4_mm.Focus(); }
            }
        }

        private void txtQ3_4_dd_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ3_4_dd.Text.Trim()) && (!string.IsNullOrEmpty(txtQ3_4_mm.Text.Trim())))
            {
                string date;
                date = IGUtilities.ValidateDate(txtQ3_4_dd.Text.Trim(), txtQ3_4_mm.Text.Trim());
                if (date.Length == 2) { txtQ3_4_dd.Text = date; } else { MessageBox.Show(date); txtQ3_4_dd.Focus(); }
            }
        }

        private void txtQ3_4_yy_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQ3_4_yy.Text.Trim()))
            {
                string year = IGUtilities.ValidateYear(txtQ3_4_mm.Text.Trim(), txtQ3_4_dd.Text.Trim(), txtQ3_4_yy.Text.Trim());
                if (year.Length == 4)
                {
                    //txtDOSyy.Text = year;
                }
                else
                {
                    MessageBox.Show(year);
                    txtQ3_4_yy.Clear();
                    txtQ3_4_yy.Focus();
                }
            }
        }

        private void txtSign_mm_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtSign_mm.Text.Trim()))
            {
                string Month;
                Month = IGUtilities.ValidateMonth(txtSign_mm.Text.Trim());
                if (Month.Length == 2) { txtSign_mm.Text = Month; } else { MessageBox.Show(Month); txtSign_mm.Focus(); }
            }
        }

        private void txtSign_dd_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtSign_dd.Text.Trim()) && (!string.IsNullOrEmpty(txtSign_mm.Text.Trim())))
            {
                string date;
                date = IGUtilities.ValidateDate(txtSign_dd.Text.Trim(), txtSign_mm.Text.Trim());
                if (date.Length == 2) { txtSign_dd.Text = date; } else { MessageBox.Show(date); txtSign_dd.Focus(); }
            }
        }

        private void txtSign_yy_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtSign_yy.Text.Trim()))
            {
                string year = IGUtilities.ValidateYear(txtSign_mm.Text.Trim(), txtSign_dd.Text.Trim(), txtSign_yy.Text.Trim());
                if (year.Length == 4)
                {
                    //txtDOSyy.Text = year;
                }
                else
                {
                    MessageBox.Show(year);
                    txtSign_yy.Clear();
                    txtSign_yy.Focus();
                }
            }
        }

        private void txtQ1_1A_mm_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_1A_mm);
        }

        private void txtQ1_1A_dd_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_1A_dd);
        }

        private void txtQ1_1A_yy_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_1A_yy);
        }

        private void txtQ1_1B_mm_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_1B_mm);
        }

        private void txtQ1_1B_dd_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_1B_dd);
        }

        private void txtQ1_1B_yy_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_1B_yy);
        }

        private void txtQ1_2A_mm_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_2A_mm);
        }

        private void txtQ1_2A_dd_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_2A_dd);
        }

        private void txtQ1_2A_yy_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_2A_yy);
        }

        private void txtQ1_2B_mm_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_2B_mm);
        }

        private void txtQ1_2B_dd_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_2B_dd);
        }

        private void txtQ1_2B_yy_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_2B_yy);
        }

        private void txtQ1_3A_mm_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_3A_mm);
        }

        private void txtQ1_3A_dd_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_3A_dd);
        }

        private void txtQ1_3A_yy_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_3A_yy);
        }

        private void txtQ1_3B_mm_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_3B_mm);
        }

        private void txtQ1_3B_dd_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_3B_dd);
        }

        private void txtQ1_3B_yy_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_3B_yy);
        }

        private void txtQ1_4_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_4);
        }

        private void txtQ1_5_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_5);
        }

        private void txtQ2_1_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_1);
        }

        private void txtQ2_2_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_2);
        }

        private void txtQ2_3A_mm_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_3A_mm);
        }

        private void txtQ2_3A_dd_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_3A_dd);
        }

        private void txtQ2_3A_yy_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_3A_yy);
        }

        private void txtQ2_3B_mm_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_3B_mm);
        }

        private void txtQ2_3B_dd_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_3B_dd);
        }

        private void txtQ2_3B_yy_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_3B_yy);
        }

        private void txtQ3_1_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3_1);
        }

        private void txtQ3_2_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3_2);
        }

        private void txtQ3_3A_mm_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3_3A_mm);
        }

        private void txtQ3_3A_dd_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3_3A_dd);
        }

        private void txtQ3_3A_yy_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3_3A_yy);
        }

        private void txtQ3_3B_mm_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3_3B_mm);
        }

        private void txtQ3_3B_dd_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3_3B_dd);
        }

        private void txtQ3_3B_yy_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3_3B_yy);
        }

        private void txtQ3_4_mm_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3_4_mm);
        }

        private void txtQ3_4_dd_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3_4_dd);
        }

        private void txtQ3_4_yy_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3_4_yy);
        }

        private void txtSign_mm_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtSign_mm);
        }

        private void txtSign_dd_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtSign_dd);
        }

        private void txtSign_yy_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtSign_yy);
        }

        private void txtBarcode_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtBarcode);
        }

        private void chksignature_CheckedChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, chksignature);
        }

        private void txtComments_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtComments);
        }

        #endregion

        private void txtQ1_1A_mm_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_1A_mm);
        }

        private void txtQ1_1A_dd_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_1A_dd);
        }

        private void txtQ1_1A_yy_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_1A_yy);
        }

        private void txtQ1_1B_mm_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_1B_mm);
        }

        private void txtQ1_1B_dd_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_1B_dd);
        }

        private void txtQ1_1B_yy_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_1B_yy);
        }

        private void txtQ1_2A_mm_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_2A_mm);
        }

        private void txtQ1_2A_dd_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_2A_dd);
        }

        private void txtQ1_2A_yy_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_2A_yy);
        }

        private void txtQ1_2B_mm_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_2B_mm);
        }

        private void txtQ1_2B_dd_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_2B_dd);
        }

        private void txtQ1_2B_yy_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_2B_yy);
        }

        private void txtQ1_3A_mm_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_3A_mm);
        }

        private void txtQ1_3A_dd_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_3A_dd);
        }

        private void txtQ1_3A_yy_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_3A_yy);
        }

        private void txtQ1_3B_mm_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_3B_mm);
        }

        private void txtQ1_3B_dd_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_3B_dd);
        }

        private void txtQ1_3B_yy_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_3B_yy);
        }

        private void txtQ1_4_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_4);
        }

        private void txtQ1_5_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_5);
        }

        private void txtQ2_1_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_1);
        }

        private void txtQ2_2_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_2);
        }

        private void txtQ2_3A_mm_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_3A_mm);
        }

        private void txtQ2_3A_dd_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_3A_dd);
        }

        private void txtQ2_3A_yy_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_3A_yy);
        }

        private void txtQ2_3B_mm_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_3B_mm);
        }

        private void txtQ2_3B_dd_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_3B_dd);
        }

        private void txtQ2_3B_yy_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_3B_yy);
        }

        private void txtQ3_1_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3_1);
        }

        private void txtQ3_2_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3_2);
        }

        private void txtQ3_3A_mm_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3_3A_mm);
        }

        private void txtQ3_3A_dd_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3_3A_dd);
        }

        private void txtQ3_3A_yy_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3_3A_yy);
        }

        private void txtQ3_3B_mm_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3_3B_mm);
        }

        private void txtQ3_3B_dd_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3_3B_dd);
        }

        private void txtQ3_3B_yy_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3_3B_yy);
        }

        private void txtQ3_4_mm_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3_4_mm);
        }

        private void txtQ3_4_dd_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3_4_dd);
        }

        private void txtQ3_4_yy_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3_4_yy);
        }

        private void chksignature_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, chksignature);
        }

        private void txtSign_mm_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtSign_mm);
        }

        private void txtSign_dd_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtSign_dd);
        }

        private void txtSign_yy_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtSign_yy);
        }
    }
}
