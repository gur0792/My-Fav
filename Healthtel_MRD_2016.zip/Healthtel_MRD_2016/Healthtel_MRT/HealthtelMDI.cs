﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using App.Base;
using Healthtel_MRD;
using DataAccessLayer.ProjectDB;
using DataAccessLayer.GlobalDB;
using DataAccessLayer.ReportsDB;

namespace Healthtel_MRT
{
    public partial class HealthtelMDI : Form
    {
        public HealthtelMDI()
        {
            New();
        }

        #region Variables

        private int childFormNumber = 0;

        #endregion

        #region Events

        private void HealthtelMDI_Load(object sender, EventArgs e)
        {
            if (Constance.GC_USERLEVEL == true)
            {
                mnuAdmin.Visible = false;
                mnuUserRpt.Visible = true;
                mnuUserRptAll.Visible = false;
            }
            else
            {
                mnuAdmin.Visible = true;
                mnuUserRpt.Visible = false;
                mnuUserRptAll.Visible = true;
            }

            this.Text = this.Text + " Ver " + ProductVersion;
            if (Constance.GC_PROJ_VERSIONSTATUS == "T")
            {
                lblversion.Visible = true;
            }

            if (!(Constance.GC_USERID == 1 || Constance.GC_USERID == 5 || Constance.GC_USERID == 61 || Constance.GC_USERID == 62 || Constance.GC_USERID == 96 || Constance.GC_USERID == 139 || Constance.GC_USERID == 375 || Constance.GC_USERID == 453 || Constance.GC_USERID == 469 || Constance.GC_USERID == 491) || Constance.GC_USERID == 4 || Constance.GC_USERID == 282)
            {
                mnuUserReset.Visible = false;
            }
           
        }

        private void mnuImport_Click(object sender, EventArgs e)
        {
            frmBatchImport Import = new frmBatchImport();
            Import.MdiParent = this;
            Import.Show();
        }

        private void mnuExport_Click(object sender, EventArgs e)
        {
            FrmExport Export = new FrmExport();
            Export.MdiParent = this;
            Export.Show();
        }

        private void mnuBatchDelete_Click(object sender, EventArgs e)
        {
            frmBatchDelete BatchDelete = new frmBatchDelete();
            BatchDelete.MdiParent = this;
            BatchDelete.Show();
        }

        private void mnuKey1_Click(object sender, EventArgs e)
        {
            frmBatchSelection BatchSelection = new frmBatchSelection();
            BatchSelection.MdiParent = this;
            BatchSelection.Process = Constance.GC_PROCESS_KEY1;
            BatchSelection.Show();
        }

        private void mnuKey2_Click(object sender, EventArgs e)
        {
            frmBatchSelection BatchSelection = new frmBatchSelection();
            BatchSelection.MdiParent = this;
            BatchSelection.Process = Constance.GC_PROCESS_KEY2;
            BatchSelection.Show();
        }

        private void mnuKeyQC_Click(object sender, EventArgs e)
        {
            frmBatchSelection BatchSelection = new frmBatchSelection();
            BatchSelection.MdiParent = this;
            BatchSelection.Process = Constance.GC_PROCESS_KEYQC;
            BatchSelection.Show();
        }

        private void mnuCompareQC_Click(object sender, EventArgs e)
        {
            frmBatchSelection BatchSelection = new frmBatchSelection();
            BatchSelection.MdiParent = this;
            BatchSelection.Process = Constance.GC_PROCESS_COMAPREQC;
            BatchSelection.Show();
        }

        private void mnuBatchRpt_Click(object sender, EventArgs e)
        {
         
            frmReport BatchwiseReport = new frmReport();
            BatchwiseReport.MdiParent = this;
            BatchwiseReport.Report = "Batchwise";
            BatchwiseReport.Show();
        }

        private void mnuUserRpt_Click(object sender, EventArgs e)
        {
            frmReport UserwiseReport = new frmReport();
            UserwiseReport.MdiParent = this;
            UserwiseReport.Report = "Userwise";
            UserwiseReport.Show();
        }

        private void mnuKey1Reset_Click(object sender, EventArgs e)
        {
            frmKeyReset KeyReset = new frmKeyReset();
            KeyReset.Process = Constance.GC_PROCESS_KEY1;
            KeyReset.MdiParent = this;
            KeyReset.Show();
        }

        private void mnuKey2Reset_Click(object sender, EventArgs e)
        {
            frmKeyReset KeyReset = new frmKeyReset();
            KeyReset.Process = Constance.GC_PROCESS_KEY2;
            KeyReset.MdiParent = this;
            KeyReset.Show();
        }

        private void mnuCompareQCReset_Click(object sender, EventArgs e)
        {
            frmKeyReset KeyReset = new frmKeyReset();
            KeyReset.Process = Constance.GC_PROCESS_COMAPREQC;
            KeyReset.MdiParent = this;
            KeyReset.Show();
        }

        private void mnukeyQCReset_Click(object sender, EventArgs e)
        {
            frmKeyReset KeyReset = new frmKeyReset();
            KeyReset.Process = Constance.GC_PROCESS_KEYQC;
            KeyReset.MdiParent = this;
            KeyReset.Show();
        }

        private void mnuExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure want to exit the application?", "Healthtel MRD", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                Application.Exit();
            }
            else
            {
                return;
            }
        }

        private void HealthtelMDI_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Constance.GC_USERID > 0)
            {
                login objLogin = new login(Constance.GC_USERID);
                objLogin.LoginStatus = false;
                objLogin.Store();
            }
            global::System.Windows.Forms.Application.Exit();
        }

        private void mnuUserReset_Click(object sender, EventArgs e)
        {
            frmUserReset UserReset = new frmUserReset();
            UserReset.MdiParent = this;
            UserReset.Show();
        }

        private void mnuAlluserwiserpt_Click(object sender, EventArgs e)
        {
            frmReport UserwiseReportAll = new frmReport();
            UserwiseReportAll.MdiParent = this;
            UserwiseReportAll.Report = "UserwiseAll";
            UserwiseReportAll.Show();
        }

        private void finalImportToolStripMenuItem_Click(object sender, EventArgs e)
        {

            FrmFinalImport FExport = new FrmFinalImport();
            FExport.MdiParent = this;
            FExport.Show();
        }
        

        private void mnuUserRptAll_Click(object sender, EventArgs e)
        {
            frmReport UserwiseReportAll = new frmReport();
            UserwiseReportAll.MdiParent = this;
            UserwiseReportAll.Report = "UserwiseAll";
            UserwiseReportAll.Show();
        }
        #endregion




    }
}
