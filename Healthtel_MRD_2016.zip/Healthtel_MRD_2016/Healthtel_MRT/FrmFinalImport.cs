﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Configuration;
using App.Base;
using DataAccessLayer.ReportsDB;
using DataAccessLayer.ProjectDB;
using DataAccessLayer.WelcareDB;
namespace Healthtel_MRD
{
    public partial class FrmFinalImport : Form
    {
        OleDbConnection Econ;
        SqlConnection con;
        string constr, Query, sqlconn, FilePath;
        DataSet dsExcelHDIS = new DataSet();
        DataTable ExcelSheetHDIS = new DataTable();
        List<string> FinalData = new List<string>();
        string batchname = null;
        int Batchid = 0;
        public FrmFinalImport()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog fbd = new OpenFileDialog();

            if (cmbBatchType.SelectedIndex == -1)
            {
                MessageBox.Show("Select Batch !!!!");
                btnBrowse.Focus();
            }
            else if ((cmbBatchType.SelectedIndex != 2) && (cmbBatchType.SelectedIndex != 5))
            {
                ///fbd.Filter = "Excel file (2003) |*.xls|Excel file (2007) |*.xlsx|All file|*.*";
                fbd.Filter = "Excel Files|*.xls;*.xlsx;*.xlsm";
                DialogResult result = fbd.ShowDialog();
                txtBatchPath.Text = fbd.FileName;
                btnImport.Focus();

            }
            else
            {
                fbd.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
                DialogResult result = fbd.ShowDialog();
                txtBatchPath.Text = fbd.FileName;
                btnImport.Focus();
            }

        }
        private void btnImport_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtBatchPath.Text) == true)
            {
                MessageBox.Show("Select Input File!!!!");
            }

            int ipos1 = txtBatchPath.Text.LastIndexOf("\\");
            int len = txtBatchPath.Text.Length - ipos1;
            string filename = txtBatchPath.Text.Substring(ipos1 + 1, len - 1);
            int ipos = 0;
            string str1 = null;

            ipos = filename.IndexOf("_");
            str1 = filename.Substring(ipos + 1, filename.Length - (ipos + 1));
            ipos = str1.LastIndexOf("_");
            str1 = str1.Substring(0, ipos);
            batchname = str1;
            if (cmbBatchType.SelectedIndex == 4)
            {
                batchname = batchname.Replace("HRA_2016_", "HRA-V1_");
            }
            else if (cmbBatchType.SelectedIndex == 7)
            {
                batchname = batchname.Replace("HRA_2016_", "HRA-V2_");
            }
            else if (cmbBatchType.SelectedIndex == 6)
            {
                batchname = batchname.Replace("OH Medical Pediatric_", "OH_Pediatric_");
            }
            else if (cmbBatchType.SelectedIndex == 8)
            {
                batchname = ValidateBatchname(str1);

            }
            Batchid = 0;
            DataAccessLayer.ProjectDB.batchmaster objimpfileinfo = new DataAccessLayer.ProjectDB.batchmaster();
            if (cmbBatchType.SelectedIndex != 8)
            {
                Batchid = objimpfileinfo.Batchid(batchname);
            }
            else
            {
                DataAccessLayer.WelcareDB.batchmaster objimpfileinfoWellcare = new DataAccessLayer.WelcareDB.batchmaster();

                Batchid = objimpfileinfoWellcare.Batchid_Wellcare(batchname);
            }
            importedfileinfo objimportedfileinfo = new importedfileinfo();
            bool ExistsFile = objimportedfileinfo.ISImportFileInfoExist(filename);

            if (Batchid == 0)
            {
                MessageBox.Show("BatchName not found!!!");
                return;
            }

            string IMPID, IMPIDHRA;
            IMPID = IMPIDHRA = string.Empty;
            try
            {
                if ((cmbBatchType.SelectedIndex == 0) || (cmbBatchType.SelectedIndex == 1) || (cmbBatchType.SelectedIndex == 7))
                {
                    DataSet dsExcelSheet = new DataSet();
                    FilePath = txtBatchPath.Text;
                    dsExcelSheet = IGUtilities.FinalExcelImport(FilePath);
                    DataTable Exceldt = dsExcelSheet.Tables[0];
                    if (ValidateTemplate(0, Exceldt, "") == false)
                    {
                        return;
                    }
                    if (ExistsFile == false)
                    {
                        objimportedfileinfo.projectid = 60;
                        objimportedfileinfo.filename = filename;
                        objimportedfileinfo.status = true;
                        objimportedfileinfo.username = Constance.GC_USERNAME;
                        objimportedfileinfo.Store();
                        int Importid = objimportedfileinfo.id;
                        IMPIDHRA = Importid.ToString();

                    }
                    else
                    {
                        DialogResult dialogResult = MessageBox.Show("Do you want to reimport the batch?", "ReImport", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            importedfileinfo objimportedfileId = new importedfileinfo();
                            int Importid = objimportedfileId.ISImportFileId(filename);
                            healthtel_mrt_hra_finaldata DELObject = new healthtel_mrt_hra_finaldata();
                            int IResult = DELObject.DeleteFileId(Importid);
                            IMPIDHRA = Importid.ToString();
                        }

                        else if (dialogResult == DialogResult.No)
                        {
                            MessageBox.Show("Final Import Canceled!!!");
                            txtBatchPath.Text = string.Empty;
                            return;
                        }
                    }

                    foreach (DataRow dr in Exceldt.Rows)
                    {
                        healthtel_mrt_hra_finaldata addObject = new healthtel_mrt_hra_finaldata();
                        addObject.Respondent_ID = (dr["RESPONDENT_ID"].ToString() == "NA" || dr["RESPONDENT_ID"].ToString() == "0" || dr["RESPONDENT_ID"].ToString() == "-1") ? "" : dr["RESPONDENT_ID"].ToString();
                        addObject.Q1 = (dr["Q9_1"].ToString() == "NA" || dr["Q9_1"].ToString() == "0" || dr["Q9_1"].ToString() == "-1") ? "" : dr["Q9_1"].ToString();
                        addObject.Q2_1 = (dr["Q2_1"].ToString() == "NA" || dr["Q2_1"].ToString() == "0" || dr["Q2_1"].ToString() == "-1") ? "" : dr["Q2_1"].ToString();
                        addObject.Q2_2 = (dr["Q1_2"].ToString() == "NA" || dr["Q1_2"].ToString() == "0" || dr["Q1_2"].ToString() == "-1") ? "" : dr["Q1_2"].ToString();
                        addObject.Q2_3 = (dr["Q1_3"].ToString() == "NA" || dr["Q1_3"].ToString() == "0" || dr["Q1_3"].ToString() == "-1") ? "" : dr["Q1_3"].ToString();
                        addObject.Q2_4 = (dr["Q1_4"].ToString() == "NA" || dr["Q1_4"].ToString() == "0" || dr["Q1_4"].ToString() == "-1") ? "" : dr["Q1_4"].ToString();
                        addObject.Q2_5 = (dr["Q1_5"].ToString() == "NA" || dr["Q1_5"].ToString() == "0" || dr["Q1_5"].ToString() == "-1") ? "" : dr["Q1_5"].ToString();
                        addObject.Q2_6 = (dr["Q1_6"].ToString() == "NA" || dr["Q1_6"].ToString() == "0" || dr["Q1_6"].ToString() == "-1") ? "" : dr["Q1_6"].ToString();
                        addObject.Q2_7 = (dr["Q1_7"].ToString() == "NA" || dr["Q1_7"].ToString() == "0" || dr["Q1_7"].ToString() == "-1") ? "" : dr["Q1_7"].ToString();
                        addObject.Q2_8 = (dr["Q1_8"].ToString() == "NA" || dr["Q1_8"].ToString() == "0" || dr["Q1_8"].ToString() == "-1") ? "" : dr["Q1_8"].ToString();
                        addObject.Q4 = (dr["Q3_2"].ToString() == "NA" || dr["Q3_2"].ToString() == "0" || dr["Q3_2"].ToString() == "-1") ? "" : dr["Q3_2"].ToString();
                        addObject.Q5 = (dr["Q3_3"].ToString() == "NA" || dr["Q3_3"].ToString() == "0" || dr["Q3_3"].ToString() == "-1") ? "" : dr["Q3_3"].ToString();
                        addObject.Q6 = (dr["Q3_4"].ToString() == "NA" || dr["Q3_4"].ToString() == "0" || dr["Q3_4"].ToString() == "-1") ? "" : dr["Q3_4"].ToString();
                        addObject.Q7 = (dr["Q3_5"].ToString() == "NA" || dr["Q3_5"].ToString() == "0" || dr["Q3_5"].ToString() == "-1") ? "" : dr["Q3_5"].ToString();
                        addObject.Q8 = (dr["Q4_1"].ToString() == "NA" || dr["Q4_1"].ToString() == "0" || dr["Q4_1"].ToString() == "-1") ? "" : dr["Q4_1"].ToString();
                        addObject.Q9 = (dr["Q4_2"].ToString() == "NA" || dr["Q4_2"].ToString() == "0" || dr["Q4_2"].ToString() == "-1") ? "" : dr["Q4_2"].ToString();
                        addObject.Q10 = (dr["Q2_1"].ToString() == "NA" || dr["Q2_1"].ToString() == "0" || dr["Q2_1"].ToString() == "-1") ? "" : dr["Q2_1"].ToString();
                        addObject.Q11 = (dr["Q2_TTL#1"].ToString() == "NA" || dr["Q2_TTL#1"].ToString() == "0" || dr["Q2_TTL#1"].ToString() == "-1") ? "" : dr["Q2_TTL#1"].ToString();
                        addObject.Q12 = (dr["Q5_1"].ToString() == "NA" || dr["Q5_1"].ToString() == "0" || dr["Q5_1"].ToString() == "NA") ? "" : dr["Q5_1"].ToString();
                        //addObject.Q13 = (dr["Q5_2"].ToString() == "NA") ? "" : dr["Q5_2"].ToString();
                        addObject.Q14 = (dr["Q6_1"].ToString() == "NA" || dr["Q6_1"].ToString() == "0" || dr["Q6_1"].ToString() == "-1") ? "" : dr["Q6_1"].ToString();
                        addObject.Q15 = (dr["Q7_2"].ToString() == "NA" || dr["Q7_2"].ToString() == "0" || dr["Q7_2"].ToString() == "-1") ? "" : dr["Q7_2"].ToString();
                        addObject.Q16 = (dr["Q7_1"].ToString() == "NA" || dr["Q7_1"].ToString() == "0" || dr["Q7_1"].ToString() == "-1") ? "" : dr["Q7_1"].ToString();
                        addObject.Q17 = (dr["Q8_1"].ToString() == "NA" || dr["Q8_1"].ToString() == "0" || dr["Q8_1"].ToString() == "-1") ? "" : dr["Q8_1"].ToString();
                        addObject.Language = (dr["LANGUAGE"].ToString() == "NA" || dr["LANGUAGE"].ToString() == "0" || dr["LANGUAGE"].ToString() == "-1") ? "" : dr["LANGUAGE"].ToString();
                        addObject.Q3 = (dr["Q3_1"].ToString() == "NA" || dr["Q3_1"].ToString() == "0" || dr["Q3_1"].ToString() == "-1") ? "" : dr["Q3_1"].ToString();
                        addObject.Batch_Number = dr["BATCH NUMBER"].ToString();
                        addObject.Image_Number = dr["IMAGE FILE NAME"].ToString();
                        addObject.BatchName = batchname;
                        addObject.importfileid = IMPIDHRA;
                        addObject.batchid = Batchid.ToString();
                        addObject.Store();
                    }
                    MessageBox.Show("Final Import completed!!!");
                    txtBatchPath.Text = string.Empty;
                }

                if (cmbBatchType.SelectedIndex == 2)
                {
                    DataTable ExcelSheet = new DataTable();
                    FilePath = txtBatchPath.Text;

                    FinalData = IGUtilities.ReadTxtFile(FilePath);
                    if (ValidateTemplate(cmbBatchType.SelectedIndex, ExcelSheet, "") == false)
                    {
                        return;
                    }
                    if (ExistsFile == false)
                    {
                        objimportedfileinfo.projectid = 60;
                        objimportedfileinfo.filename = filename;
                        objimportedfileinfo.status = true;
                        objimportedfileinfo.username = Constance.GC_USERNAME;
                        objimportedfileinfo.Store();
                        int Importid = objimportedfileinfo.id;
                        IMPID = Importid.ToString();
                    }
                    else
                    {
                        DialogResult dialogResult = MessageBox.Show("Do you want to reimport the batch?", "ReImport", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            importedfileinfo objimportedfileId = new importedfileinfo();
                            int Importid = objimportedfileId.ISImportFileId(filename);
                            healthtel_mrt_finaldata DelObject = new healthtel_mrt_finaldata();
                            int IResult = DelObject.DeleteFileId(Importid);
                            IMPID = Importid.ToString();
                        }
                        else if (dialogResult == DialogResult.No)
                        {
                            MessageBox.Show("Final Import Canceled!!!");
                            txtBatchPath.Text = string.Empty;
                        }
                    }
                    foreach (string item in FinalData)
                    {
                        string[] dr = item.ToString().Split('|');
                        int i = 1;
                        if (dr.Length < 22)
                        {
                            MessageBox.Show("Template column not matched!!!");
                            return;
                        }
                        if (!dr[0].ToString().Contains("IMAGE_NAME") && (!dr[0].ToString().Contains("SNO")))
                        {
                            healthtel_mrt_finaldata addObject = new healthtel_mrt_finaldata();
                            addObject.RECORD_NUMBER = i.ToString();
                            addObject.BatchName = batchname;
                            string ImageNo = dr[0].ToString();
                            addObject.Image_Number = ImageNo.Split('\\').Last();
                            addObject.MemberId = dr[1].ToString();
                            addObject.Barcode = dr[2].ToString();
                            addObject.First_Name = dr[3].ToString();
                            addObject.Last_Name = dr[4].ToString();
                            addObject.Phone_No = dr[5].ToString();
                            addObject.addressupdate = dr[6].ToString();
                            addObject.Address1 = dr[7].ToString();
                            addObject.Address2 = dr[8].ToString();
                            addObject.City = dr[9].ToString();
                            addObject.State = dr[10].ToString();
                            addObject.Zip = dr[11].ToString();
                            addObject.DOB = dr[12].ToString();
                            addObject.DOS = dr[13].ToString();
                            addObject.ProviderSignature = dr[14].ToString();
                            addObject.MotOptin = dr[15].ToString();
                            addObject.HbA1c = dr[16].ToString();
                            addObject.LDL_c = dr[17].ToString();
                            addObject.Microalbumin = dr[18].ToString();
                            addObject.formscandata = dr[19].ToString();
                            addObject.FormScan = dr[20].ToString();
                            addObject.createdon = dr[21].ToString();
                            addObject.importfileid = IMPID;
                            addObject.batchid = Batchid.ToString();
                            addObject.Store();
                            i = i + 1;
                        }
                    }
                    MessageBox.Show("Final Import Completed");
                    txtBatchPath.Text = string.Empty;
                }
                if (cmbBatchType.SelectedIndex == 3)
                {

                    FilePath = txtBatchPath.Text;
                    dsExcelHDIS = IGUtilities.FinalExcelImport(FilePath);
                    ExcelSheetHDIS = dsExcelHDIS.Tables[0];
                    if (ValidateTemplate(cmbBatchType.SelectedIndex, ExcelSheetHDIS, "") == false)
                    {
                        return;
                    }
                    if (ExistsFile == false)
                    {
                        objimportedfileinfo.projectid = 60;
                        objimportedfileinfo.filename = filename;
                        objimportedfileinfo.status = true;
                        objimportedfileinfo.username = Constance.GC_USERNAME;
                        objimportedfileinfo.Store();
                        int Importid = objimportedfileinfo.id;
                        IMPIDHRA = Importid.ToString();
                    }
                    else
                    {
                        DialogResult dialogResult = MessageBox.Show("Do you want to reimport the batch?", "ReImport", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            importedfileinfo objimportedfileId = new importedfileinfo();
                            int Importid = objimportedfileId.ISImportFileId(filename);
                            hedis_finaldata DELObject = new hedis_finaldata();
                            int IResult = DELObject.DeleteFileId(Importid);
                            IMPIDHRA = Importid.ToString();
                        }

                        else if (dialogResult == DialogResult.No)
                        {
                            MessageBox.Show("Final Import Canceled!!!");
                            txtBatchPath.Text = string.Empty;
                            return;
                        }

                    }
                    foreach (DataRow dr in ExcelSheetHDIS.Rows)
                    {
                        hedis_finaldata addObject = new hedis_finaldata();
                        addObject.Image_Number = (dr["IMAGE_NAME"].ToString() == "NA") ? "" : dr["IMAGE_NAME"].ToString();
                        addObject.Barcode = (dr["BAR_CODE"].ToString() == "NA") ? "" : dr["BAR_CODE"].ToString();
                        addObject.Q1_1 = (dr["Q1_1"].ToString() == "NA") ? "" : dr["Q1_1"].ToString();
                        addObject.Q1_2 = (dr["Q1_2"].ToString() == "NA") ? "" : dr["Q1_2"].ToString();
                        addObject.Q1_3 = (dr["Q1_3"].ToString() == "NA") ? "" : dr["Q1_3"].ToString();
                        addObject.Q1_4 = (dr["Q1_4"].ToString() == "NA") ? "" : dr["Q1_4"].ToString();
                        addObject.Q1_5 = (dr["Q1_5"].ToString() == "NA") ? "" : dr["Q1_5"].ToString();
                        addObject.Q2_1 = (dr["Q2_1"].ToString() == "NA") ? "" : dr["Q2_1"].ToString();
                        addObject.Q2_2 = (dr["Q2_2"].ToString() == "NA") ? "" : dr["Q2_2"].ToString();
                        addObject.Q2_3 = (dr["Q2_3"].ToString() == "NA") ? "" : dr["Q2_3"].ToString();
                        addObject.Q3_1 = (dr["Q3_1"].ToString() == "NA") ? "" : dr["Q3_1"].ToString();
                        addObject.Q3_2 = (dr["Q3_2"].ToString() == "NA") ? "" : dr["Q3_2"].ToString();
                        addObject.Q3_3 = (dr["Q3_3"].ToString() == "NA") ? "" : dr["Q3_3"].ToString();
                        addObject.Q3_4 = (dr["Q3_4"].ToString() == "NA") ? "" : dr["Q3_4"].ToString();
                        addObject.Signature = (dr["Signature"].ToString() == "NA") ? "" : dr["Signature"].ToString();
                        addObject.Signature_Date = (dr["SIGNATURE_DATE"].ToString() == "NA") ? "" : dr["SIGNATURE_DATE"].ToString();
                        addObject.createdon = (dr["INTERACTION_DATE_TIME"].ToString() == "NA") ? "" : dr["INTERACTION_DATE_TIME"].ToString();
                        addObject.BatchName = batchname;
                        addObject.importfileid = IMPIDHRA;
                        addObject.batchid = Batchid.ToString();
                        addObject.Store();
                    }
                    MessageBox.Show("Final Import completed!!!");
                    txtBatchPath.Text = string.Empty;
                }

                if (cmbBatchType.SelectedIndex == 4)
                {
                    DataSet dsExcelSheet = new DataSet();
                    FilePath = txtBatchPath.Text;
                    dsExcelSheet = IGUtilities.FinalExcelImport(FilePath);
                    DataTable Exceldt = dsExcelSheet.Tables[0];
                    if (ValidateTemplate(cmbBatchType.SelectedIndex, Exceldt, "") == false)
                    {
                        return;
                    }
                    if (ExistsFile == false)
                    {
                        objimportedfileinfo.projectid = 60;
                        objimportedfileinfo.filename = filename;
                        objimportedfileinfo.status = true;
                        objimportedfileinfo.username = Constance.GC_USERNAME;
                        objimportedfileinfo.Store();
                        int Importid = objimportedfileinfo.id;
                        IMPIDHRA = Importid.ToString();
                    }
                    else
                    {
                        DialogResult dialogResult = MessageBox.Show("Do you want to reimport the batch?", "ReImport", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            importedfileinfo objimportedfileId = new importedfileinfo();
                            int Importid = objimportedfileId.ISImportFileId(filename);
                            DataAccessLayer.ReportsDB.healthtel_mrt_hra_v1_finaldata DELObject = new DataAccessLayer.ReportsDB.healthtel_mrt_hra_v1_finaldata();
                            int IResult = DELObject.DeleteFileId(Importid);
                            IMPIDHRA = Importid.ToString();
                        }

                        else if (dialogResult == DialogResult.No)
                        {
                            MessageBox.Show("Final Import Canceled!!!");
                            txtBatchPath.Text = string.Empty;
                            return;
                        }
                    }

                    foreach (DataRow dr in Exceldt.Rows)
                    {

                        DataAccessLayer.ReportsDB.healthtel_mrt_hra_v1_finaldata addObject = new DataAccessLayer.ReportsDB.healthtel_mrt_hra_v1_finaldata();

                        addObject.Respondent_ID = (dr["RESPONDENT_ID"].ToString() == "NA" || dr["RESPONDENT_ID"].ToString() == "0" || dr["RESPONDENT_ID"].ToString() == "-1") ? "" : dr["RESPONDENT_ID"].ToString();
                        addObject.Q1_9 = (dr["Q1_9"].ToString() == "NA" || dr["Q1_9"].ToString() == "0" || dr["Q1_9"].ToString() == "-1") ? "" : dr["Q1_9"].ToString();
                        addObject.Q1_1 = (dr["Q1_1#1"].ToString() == "NA" || dr["Q1_1#1"].ToString() == "0" || dr["Q1_1#1"].ToString() == "-1") ? "" : dr["Q1_1#1"].ToString();
                        addObject.Q1_2 = (dr["Q1_2"].ToString() == "NA" || dr["Q1_2"].ToString() == "0" || dr["Q1_2"].ToString() == "-1") ? "" : dr["Q1_2"].ToString();
                        addObject.Q1_3 = (dr["Q1_3#1"].ToString() == "NA" || dr["Q1_3#1"].ToString() == "0" || dr["Q1_3#1"].ToString() == "-1") ? "" : dr["Q1_3#1"].ToString();
                        addObject.Q1_4 = (dr["Q1_4"].ToString() == "NA" || dr["Q1_4"].ToString() == "0" || dr["Q1_4"].ToString() == "-1") ? "" : dr["Q1_4"].ToString();
                        addObject.Q1_5 = (dr["Q1_5"].ToString() == "NA" || dr["Q1_5"].ToString() == "0" || dr["Q1_5"].ToString() == "-1") ? "" : dr["Q1_5"].ToString();
                        addObject.Q1_6 = (dr["Q1_6#1"].ToString() == "NA" || dr["Q1_6#1"].ToString() == "0" || dr["Q1_6#1"].ToString() == "-1") ? "" : dr["Q1_6#1"].ToString();
                        addObject.Q1_7 = (dr["Q1_7"].ToString() == "NA" || dr["Q1_7"].ToString() == "0" || dr["Q1_7"].ToString() == "-1") ? "" : dr["Q1_7"].ToString();
                        addObject.Q1_8 = (dr["Q1_8"].ToString() == "NA" || dr["Q1_8"].ToString() == "0" || dr["Q1_8"].ToString() == "-1") ? "" : dr["Q1_8"].ToString();
                        addObject.Q3_1 = (dr["Q3_1"].ToString() == "NA" || dr["Q3_1"].ToString() == "0" || dr["Q3_1"].ToString() == "-1") ? "" : dr["Q3_1"].ToString();
                        addObject.Q3_2 = (dr["Q3_2"].ToString() == "NA" || dr["Q3_2"].ToString() == "0" || dr["Q3_2"].ToString() == "-1") ? "" : dr["Q3_2"].ToString();
                        addObject.Q3_3 = (dr["Q3_3"].ToString() == "NA" || dr["Q3_3"].ToString() == "0" || dr["Q3_3"].ToString() == "-1") ? "" : dr["Q3_3"].ToString();
                        addObject.Q3_4 = (dr["Q3_4"].ToString() == "NA" || dr["Q3_4"].ToString() == "0" || dr["Q3_4"].ToString() == "-1") ? "" : dr["Q3_4"].ToString();
                        addObject.Q3_5 = (dr["Q3_5"].ToString() == "NA" || dr["Q3_5"].ToString() == "0" || dr["Q3_5"].ToString() == "-1") ? "" : dr["Q3_5"].ToString();
                        addObject.Q4_1 = (dr["Q4_1"].ToString() == "NA" || dr["Q4_1"].ToString() == "0" || dr["Q4_1"].ToString() == "-1") ? "" : dr["Q4_1"].ToString();
                        addObject.Q4_2 = (dr["Q4_2"].ToString() == "NA" || dr["Q4_2"].ToString() == "0" || dr["Q4_2"].ToString() == "-1") ? "" : dr["Q4_2"].ToString();
                        addObject.Q4_3 = (dr["Q4_3"].ToString() == "NA" || dr["Q4_3"].ToString() == "0" || dr["Q4_3"].ToString() == "-1") ? "" : dr["Q4_3"].ToString();
                        addObject.Q2_1 = (dr["Q2_1"].ToString() == "NA" || dr["Q2_1"].ToString() == "0" || dr["Q2_1"].ToString() == "-1") ? "" : dr["Q2_1"].ToString();
                        addObject.Q2_ttl = (dr["Q2_TTL#1"].ToString() == "NA" || dr["Q2_TTL#1"].ToString() == "0" || dr["Q2_TTL#1"].ToString() == "-1") ? "" : dr["Q2_TTL#1"].ToString();
                        addObject.Q5_1 = (dr["Q5_1"].ToString() == "NA" || dr["Q5_1"].ToString() == "0" || dr["Q5_1"].ToString() == "-1") ? "" : dr["Q5_1"].ToString();
                        addObject.Q5_ttl = (dr["Q5_ttl"].ToString() == "NA" || dr["Q5_ttl"].ToString() == "0" || dr["Q5_ttl"].ToString() == "-1") ? "" : dr["Q5_ttl"].ToString();
                        addObject.Q6_1 = (dr["Q6_1"].ToString() == "NA" || dr["Q6_1"].ToString() == "0" || dr["Q6_1"].ToString() == "-1") ? "" : dr["Q6_1"].ToString();
                        addObject.Q7_2 = (dr["Q7_2"].ToString() == "NA" || dr["Q7_2"].ToString() == "0" || dr["Q7_2"].ToString() == "-1") ? "" : dr["Q7_2"].ToString();
                        addObject.Q7_1 = (dr["Q7_1"].ToString() == "NA" || dr["Q7_1"].ToString() == "0" || dr["Q7_1"].ToString() == "-1") ? "" : dr["Q7_1"].ToString();
                        addObject.Q8_1 = (dr["Q8_1"].ToString() == "NA" || dr["Q8_1"].ToString() == "0" || dr["Q8_1"].ToString() == "-1") ? "" : dr["Q8_1"].ToString();
                        addObject.Language = (dr["LANGUAGE"].ToString() == "NA" || dr["LANGUAGE"].ToString() == "0" || dr["LANGUAGE"].ToString() == "-1") ? "" : dr["LANGUAGE"].ToString();
                        addObject.Batch_Number = dr["BATCH NUMBER"].ToString();
                        addObject.Image_Number = dr["IMAGE FILE NAME"].ToString();
                        addObject.BatchName = batchname;
                        addObject.importfileid = IMPIDHRA;
                        addObject.batchid = Batchid.ToString();
                        addObject.Store();
                    }
                    MessageBox.Show("Final Import completed!!!");
                    txtBatchPath.Text = string.Empty;
                }

                if (cmbBatchType.SelectedIndex == 5)
                {
                    DataTable ExcelSheet = new DataTable();
                    FilePath = txtBatchPath.Text;
                    FinalData = IGUtilities.ReadTxtFile(FilePath);
                    if (ValidateTemplate(cmbBatchType.SelectedIndex, ExcelSheet, "") == false)
                    {
                        return;
                    }

                    if (ExistsFile == false)
                    {
                        objimportedfileinfo.projectid = 60;
                        objimportedfileinfo.filename = filename;
                        objimportedfileinfo.status = true;
                        objimportedfileinfo.username = Constance.GC_USERNAME;
                        objimportedfileinfo.Store();
                        int Importid = objimportedfileinfo.id;
                        IMPID = Importid.ToString();
                    }
                    else
                    {
                        DialogResult dialogResult = MessageBox.Show("Do you want to reimport the batch?", "ReImport", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            importedfileinfo objimportedfileId = new importedfileinfo();
                            int Importid = objimportedfileId.ISImportFileId(filename);
                            healthtel_trp_finaldata DelObject = new healthtel_trp_finaldata();
                            int IResult = DelObject.DeleteFileId(Importid);
                            IMPID = Importid.ToString();
                        }
                        else if (dialogResult == DialogResult.No)
                        {
                            MessageBox.Show("Final Import Canceled!!!");
                            txtBatchPath.Text = string.Empty;
                        }
                    }
                    foreach (string item in FinalData)
                    {
                        string[] dr = item.ToString().Split('|');
                        int i = 1;
                        if (dr.Length < 18)
                        {
                            MessageBox.Show("Template column not matched!!!");
                            return;
                        }
                        if (!dr[0].ToString().ToUpper().Contains("IMAGE_NAME") && (!dr[0].ToString().ToUpper().Contains("SNO")))
                        {
                            healthtel_trp_finaldata addObject = new healthtel_trp_finaldata();
                            addObject.RECORD_NUMBER = i.ToString();
                            addObject.BatchName = batchname;
                            string ImageNo = dr[0].ToString();
                            addObject.Image_Number = ImageNo.Split('\\').Last();
                            addObject.MemberId = dr[1].ToString();
                            addObject.Barcode = dr[2].ToString();
                            addObject.First_Name = dr[3].ToString();
                            addObject.Last_Name = dr[4].ToString();
                            addObject.Phone_No = dr[5].ToString();
                            addObject.addressupdate = dr[6].ToString();
                            addObject.Address1 = dr[7].ToString();
                            addObject.Address2 = dr[8].ToString();
                            addObject.City = dr[9].ToString();
                            addObject.State = dr[10].ToString();
                            addObject.Zip = dr[11].ToString();
                            addObject.DOB = dr[12].ToString();
                            addObject.DOS = dr[13].ToString();
                            addObject.ProviderSignature = dr[14].ToString();
                            addObject.formscandata = dr[15].ToString();
                            addObject.FormScan = dr[16].ToString();
                            addObject.createdon = dr[17].ToString();
                            addObject.importfileid = IMPID;
                            addObject.batchid = Batchid.ToString();
                            addObject.Store();
                            i = i + 1;
                        }
                    }
                    MessageBox.Show("Final Import Completed");
                    txtBatchPath.Text = string.Empty;
                }


                if (cmbBatchType.SelectedIndex == 6)
                {

                    DataSet dsExcelSheet = new DataSet();
                    FilePath = txtBatchPath.Text;
                    dsExcelSheet = IGUtilities.FinalExcelImport(FilePath);
                    DataTable Exceldt = dsExcelSheet.Tables[0];
                    if (ValidateTemplate(cmbBatchType.SelectedIndex, Exceldt, "") == false)
                    {
                        return;
                    }
                    if (ExistsFile == false)
                    {
                        objimportedfileinfo.projectid = 60;
                        objimportedfileinfo.filename = filename;
                        objimportedfileinfo.status = true;
                        objimportedfileinfo.username = Constance.GC_USERNAME;
                        objimportedfileinfo.Store();
                        int Importid = objimportedfileinfo.id;
                        IMPIDHRA = Importid.ToString();
                    }
                    else
                    {
                        DialogResult dialogResult = MessageBox.Show("Do you want to reimport the batch?", "ReImport", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            importedfileinfo objimportedfileId = new importedfileinfo();
                            int Importid = objimportedfileId.ISImportFileId(filename);
                            DataAccessLayer.ReportsDB.healthtel_mrt_pediatric_finaldata DELObject = new DataAccessLayer.ReportsDB.healthtel_mrt_pediatric_finaldata();
                            int IResult = DELObject.DeleteFileId(Importid);
                            IMPIDHRA = Importid.ToString();
                        }

                        else if (dialogResult == DialogResult.No)
                        {
                            MessageBox.Show("Final Import Canceled!!!");
                            txtBatchPath.Text = string.Empty;
                            return;
                        }
                    }

                    foreach (DataRow dr in Exceldt.Rows)
                    {
                        DataAccessLayer.ReportsDB.healthtel_mrt_pediatric_finaldata addObject = new DataAccessLayer.ReportsDB.healthtel_mrt_pediatric_finaldata();
                        addObject.Barcode = dr["BARCODE"].ToString();
                        addObject.Q1 = (dr["Q34"].ToString() == "NA") ? "" : dr["Q34"].ToString();
                        addObject.Q2 = (dr["Q33"].ToString() == "NA") ? "" : dr["Q33"].ToString();
                        addObject.Q3 = ValidateNO(dr["Q1"].ToString());
                        addObject.Q4 = (dr["Q2"].ToString() == "NA") ? "" : dr["Q2"].ToString();
                        addObject.Q5 = ValidateNO(dr["Q3"].ToString());
                        addObject.Q6 = ValidateNO(dr["Q4"].ToString());
                        addObject.Q7 = ValidateNO(dr["Q5"].ToString());
                        addObject.Q8 = ValidateNO(dr["Q6"].ToString());
                        addObject.Q9 = ValidateNO(dr["Q8"].ToString());
                        addObject.Q10 = (dr["Q9"].ToString() == "NA") ? "" : dr["Q9"].ToString();
                        addObject.Q11 = (dr["Q10"].ToString() == "NA") ? "" : dr["Q10"].ToString();
                        addObject.Q12 = (dr["Q11"].ToString() == "NA") ? "" : dr["Q11"].ToString();
                        addObject.Q13 = (dr["Q12"].ToString() == "NA") ? "" : dr["Q12"].ToString();
                        addObject.Q14 = (dr["Q13"].ToString() == "NA") ? "" : dr["Q13"].ToString();
                        addObject.Q15 = (dr["Q14"].ToString() == "NA") ? "" : dr["Q14"].ToString();
                        addObject.Q16 = (dr["Q15"].ToString() == "NA") ? "" : dr["Q15"].ToString();
                        addObject.Q17 = (dr["Q16"].ToString() == "NA") ? "" : dr["Q16"].ToString();
                        addObject.Q18 = (dr["Q17"].ToString() == "NA") ? "" : dr["Q17"].ToString();
                        addObject.Q19 = ValidateNO(dr["Q18"].ToString());
                        addObject.Q20 = ValidateNO(dr["Q32"].ToString());
                        addObject.Q21 = ValidateNO(dr["Q29"].ToString());
                        addObject.Q22 = ValidateNO(dr["Q19"].ToString());
                        addObject.Q23 = (dr["Q20"].ToString() == "NA") ? "" : dr["Q20"].ToString();
                        addObject.Q24 = (dr["Q21"].ToString() == "NA") ? "" : dr["Q21"].ToString();
                        addObject.Q25 = (dr["Q22"].ToString() == "NA") ? "" : dr["Q22"].ToString();
                        addObject.Q26 = (dr["Q23"].ToString() == "NA") ? "" : dr["Q23"].ToString();
                        addObject.Q27 = (dr["Q24"].ToString() == "NA") ? "" : dr["Q24"].ToString();
                        addObject.Q28 = (dr["Q25"].ToString() == "NA") ? "" : dr["Q25"].ToString();
                        addObject.Q29 = (dr["Q26"].ToString() == "NA") ? "" : dr["Q26"].ToString();
                        addObject.Q30 = (dr["Q27"].ToString() == "NA") ? "" : dr["Q27"].ToString();
                        addObject.Q31 = (dr["Q28"].ToString() == "NA") ? "" : dr["Q28"].ToString();
                        addObject.Q32 = ValidateNO(dr["Q7"].ToString());
                        addObject.Q33 = ValidateNO(dr["Q29"].ToString());
                        addObject.Q34 = ValidateNO(dr["Q30"].ToString());
                        addObject.Batch_Number = dr["BATCH NUMBER"].ToString();
                        addObject.Image_Number = dr["IMAGE FILE NAME"].ToString();
                        addObject.BatchName = batchname;
                        addObject.Batch_Number = dr["BATCH NUMBER"].ToString();
                        addObject.importfileid = IMPIDHRA;
                        addObject.batchid = Batchid.ToString();
                        addObject.Store();
                    }
                    MessageBox.Show("Final Import completed!!!");
                    txtBatchPath.Text = string.Empty;
                }
                //For Wellcare Type
                if (cmbBatchType.SelectedIndex == 8)
                {
                    DataSet dsExcelSheet = new DataSet();
                    FilePath = txtBatchPath.Text;
                    dsExcelSheet = IGUtilities.FinalExcelImport(FilePath);
                    DataTable Exceldt = dsExcelSheet.Tables[0];
                    if (ValidateTemplate(cmbBatchType.SelectedIndex, Exceldt, "") == false)
                    {
                        return;
                    }
                    if (ExistsFile == false)
                    {
                        objimportedfileinfo.projectid = 60;
                        objimportedfileinfo.filename = filename;
                        objimportedfileinfo.status = true;
                        objimportedfileinfo.username = Constance.GC_USERNAME;
                        objimportedfileinfo.Store();
                        int Importid = objimportedfileinfo.id;
                        IMPIDHRA = Importid.ToString();
                    }
                    else
                    {
                        DialogResult dialogResult = MessageBox.Show("Do you want to reimport the batch?", "ReImport", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            importedfileinfo objimportedfileId = new importedfileinfo();
                            int Importid = objimportedfileId.ISImportFileId(filename);
                            DataAccessLayer.ReportsDB.wellcare_finaldata DELObject = new DataAccessLayer.ReportsDB.wellcare_finaldata();
                            int IResult = DELObject.DeleteFileId(Importid);
                            IMPIDHRA = Importid.ToString();
                        }

                        else if (dialogResult == DialogResult.No)
                        {
                            MessageBox.Show("Final Import Canceled!!!");
                            txtBatchPath.Text = string.Empty;
                            return;
                        }
                    }
                    foreach (DataRow dr in Exceldt.Rows)
                    {
                        DataAccessLayer.ReportsDB.wellcare_finaldata addObject = new DataAccessLayer.ReportsDB.wellcare_finaldata();


                        addObject.RESPONDENTID = dr["RESPONDENT_ID"].ToString();
                        addObject.Q1_1 = dr["Q1_1"].ToString();
                        //addObject.Q3_2  = dr["Q2_1"].ToString();
                        //addObject.Q10_3 = dr["Q2_ADDRESS"].ToString();
                        //addObject = dr["Q3_1"].ToString();
                        addObject.Q3_2 = dr["Q3_2"].ToString();
                        addObject.Q3_3 = ValidateNO(dr["Q3_3"].ToString());
                        addObject.Q3_4 = ValidateNO(dr["Q3_4"].ToString());
                        //addObject.Q3_5= dr["Q3_5"].ToString();
                        addObject.Q_Email = dr["Q3_EMAIL"].ToString();
                        addObject.Q4_1 = ValidateNO1to5(dr["Q4_1"].ToString());
                        addObject.Q5_1 = ValidateNO(dr["Q5_1"].ToString());
                        addObject.Q6_1 = ValidateNO(dr["Q6_1"].ToString());
                        addObject.Q7_1 = ValidateNO(dr["Q7_1"].ToString());
                        addObject.Q8_1 = ValidateNO1to4(dr["Q8_1"].ToString());
                        addObject.Q8_2 = ValidateNO1to4(dr["Q8_2"].ToString());
                        addObject.Q8_3 = ValidateNO1to4(dr["Q8_3"].ToString());
                        addObject.Q9_1 = ValidateNO1to4(dr["Q9_1"].ToString());
                        addObject.Q10_1 = ValidateNO(dr["Q10_1"].ToString());
                        addObject.Q10_2 = ValidateNO(dr["Q10_2"].ToString());
                        addObject.Q10_3 = dr["Q10_3"].ToString();
                        addObject.Q10_4 = dr["Q10_4"].ToString();
                        addObject.Q10_5 = dr["Q10_5"].ToString();
                        addObject.Q10_6 = dr["Q10_6"].ToString();
                        addObject.Q10_7 = dr["Q10_7"].ToString();
                        addObject.Q10_8 = dr["Q10_8"].ToString();
                        addObject.Q10_9 = dr["Q10_9"].ToString();
                        addObject.Q10_10 = dr["Q10_10"].ToString();
                        addObject.Q10_11 = dr["Q10_11"].ToString();
                        addObject.Q10_12 = dr["Q10_12"].ToString();
                        addObject.Q11_1 = dr["Q_11_1"].ToString();
                        addObject.Q11_2 = dr["Q_11_2"].ToString();
                        addObject.Q11_3 = dr["Q_11_3"].ToString();
                        addObject.Q11_4 = dr["Q_11_4"].ToString();
                        addObject.Q12_1 = dr["Q12_1"].ToString();
                        addObject.Q12_2 = dr["Q12_2"].ToString();
                        addObject.Q12_3 = dr["Q12_3"].ToString();
                        addObject.Q12_4 = dr["Q12_4"].ToString();
                        addObject.Q12_5 = dr["Q12_5"].ToString();
                        addObject.Q12_6 = dr["Q12_6"].ToString();
                        addObject.Q12_7 = dr["Q12_7"].ToString();
                        addObject.Q13_1 = dr["Q13_1"].ToString();
                        addObject.Q14_1 = dr["Q14_1"].ToString();
                        addObject.Q15_1 = dr["Q15_1"].ToString();
                        addObject.Q_formscan = dr["FORM_SCAN"].ToString();
                        addObject.LANGUAGE = dr["LANGUAGE"].ToString();
                        addObject.BatchName = batchname;
                        addObject.importfileid = IMPIDHRA;
                        addObject.batchid = Batchid.ToString();
                        addObject.Image_Number = dr["BATCH_NUMBER"].ToString();
                        addObject.Store();
                        // "LANGUAGE", "DATEREC", "DATESCAN", "BATCH_NUMBER" };
                    }
                    MessageBox.Show("Final Import completed!!!");
                    txtBatchPath.Text = string.Empty;
                }

                //For adult type addede by sakthi on 31/01/2017
                if (cmbBatchType.SelectedIndex == 9)
                {
                    DataSet dsExcelSheet = new DataSet();
                    FilePath = txtBatchPath.Text;
                    dsExcelSheet = IGUtilities.FinalExcelImport(FilePath);
                    DataTable Exceldt = dsExcelSheet.Tables[0];
                    if (ValidateTemplate(cmbBatchType.SelectedIndex, Exceldt, "") == false)
                    {
                        return;
                    }
                    if (ExistsFile == false)
                    {
                        objimportedfileinfo.projectid = 60;
                        objimportedfileinfo.filename = filename;
                        objimportedfileinfo.status = true;
                        objimportedfileinfo.username = Constance.GC_USERNAME;
                        objimportedfileinfo.Store();
                        int Importid = objimportedfileinfo.id;
                        IMPIDHRA = Importid.ToString();
                    }
                    else
                    {
                        DialogResult dialogResult = MessageBox.Show("Do you want to reimport the batch?", "ReImport", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            importedfileinfo objimportedfileId = new importedfileinfo();
                            int Importid = objimportedfileId.ISImportFileId(filename);
                            DataAccessLayer.ReportsDB.healthteladult_finaldata DELObject = new DataAccessLayer.ReportsDB.healthteladult_finaldata();
                            int IResult = DELObject.DeleteFileId(Importid);
                            IMPIDHRA = Importid.ToString();
                        }

                        else if (dialogResult == DialogResult.No)
                        {
                            MessageBox.Show("Final Import Canceled!!!");
                            txtBatchPath.Text = string.Empty;
                            return;
                        }
                    }
                    foreach (DataRow dr in Exceldt.Rows)
                    {
                        DataAccessLayer.ReportsDB.healthteladult_finaldata addObject = new DataAccessLayer.ReportsDB.healthteladult_finaldata();

                        addObject.BARCODE = dr["Barcode"].ToString();
                        addObject.Q1 =ValidateNO(dr["Permission"].ToString());
                        addObject.Q2 =ValidateNO(dr["Q1"].ToString());
                        addObject.Q3 =ValidateNO(dr["Q1"].ToString());
                        addObject.Q4 =ValidateNO(dr["Q6"].ToString());
                        addObject.Q5 =ValidateNO(dr["Q3"].ToString());
                        addObject.Q6 =ValidateNO(dr["Q10"].ToString()); 
                        addObject.Q7 =ValidateNO(dr["Q4"].ToString());
                        addObject.Q8 =ValidateNO(dr["Q11"].ToString());
                        addObject.Q9 =ValidateNO(dr["Q5"].ToString());
                        addObject.Q10 =ValidateNO(dr["Q9"].ToString());
                        addObject.Q11 =ValidateNO(dr["Q7"].ToString());
                        addObject.Q12 =ValidateNO(dr["Q8"].ToString());
                        addObject.Q13 =ValidateNO(dr["Q44"].ToString());
                        addObject.Q14 =ValidateNO(dr["Q12"].ToString());
                        addObject.Q15 =ValidateNO(dr["Q43"].ToString());
                        addObject.Q16 =ValidateNO(dr["Q12.2"].ToString());
                        addObject.Q17 =ValidateNO(dr["Q12.1"].ToString());
                        addObject.Q18 = dr["Q13"].ToString();
                        addObject.Q19 = dr["Q42"].ToString();
                        addObject.Q20 = dr["Q41"].ToString();
                        addObject.Q21 = dr["Q14"].ToString();
                        addObject.Q22 =(dr["Q15"].ToString() == "NA") ? "" : dr["Q15"].ToString();
                        addObject.Q23 = dr["Q17"].ToString();
                        addObject.Q24 = dr["Q16"].ToString();
                        addObject.Q25 = dr["Q18"].ToString();
                        addObject.Q26 = dr["Q19"].ToString();
                        addObject.Q27 = dr["Q20"].ToString();
                        addObject.Q28 = dr["Q20.1"].ToString();
                        addObject.Q29 = dr["Q20.2"].ToString();
                        addObject.Q30 = dr["Q21"].ToString();
                        addObject.Q31 = dr["Q22"].ToString();
                        addObject.Q32 = (dr["Q23"].ToString() == "NA") ? "" : dr["Q23"].ToString();
                        addObject.Q33 = (dr["Q24"].ToString() == "NA") ? "" : dr["Q24"].ToString();
                        addObject.Q34 = dr["Q25"].ToString();
                        addObject.Q35 = dr["Q26"].ToString();
                        addObject.Q36 = dr["Q27"].ToString();
                        addObject.Q37 = (dr["Q30"].ToString() == "NA") ? "" : dr["Q30"].ToString();
                        addObject.Q38 = (dr["Q31"].ToString() == "NA") ? "" : dr["Q31"].ToString();
                        addObject.Q39 = (dr["Q32"].ToString() == "NA") ? "" : dr["Q32"].ToString();
                        addObject.Q40 = (dr["Q33"].ToString() == "NA") ? "" : dr["Q33"].ToString();
                        addObject.Q41 = (dr["Q34"].ToString() == "NA") ? "" : dr["Q34"].ToString();
                        addObject.Q42 = (dr["Q35"].ToString() == "NA") ? "" : dr["Q35"].ToString();
                        addObject.Q43 = (dr["Q36"].ToString() == "NA") ? "" : dr["Q36"].ToString();
                        addObject.Q44 = dr["Q28"].ToString();
                        addObject.Q45 = dr["Q29"].ToString();
                        addObject.Q46 = dr["Q37"].ToString();
                        addObject.Q47 = dr["Q38"].ToString();
                        addObject.Q48 = dr["Q39"].ToString();
                        addObject.Q49 = dr["Q40"].ToString();
                        addObject.BatchName = batchname;
                        addObject.importfileid = IMPIDHRA;
                        addObject.batchid = Batchid.ToString();
                        addObject.Image_Number = dr["BATCH_NUMBER"].ToString();
                        addObject.Store();
                    }
                    MessageBox.Show("Final Import completed!!!");
                    txtBatchPath.Text = string.Empty;
                }



            }



            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }


        }
        private String ValidateBatchname(string value)
        {
            String WellcareBatchName = string.Empty;
            try
            {
                //string[] words = value.ToString().Split('_');

                //for (int i = 0; i < words.Length; i++)
                //{
                //    if (i != 0)
                //    {
                //        if (i == words.Length-1)
                //        {
                //            WellcareBatchName = WellcareBatchName + words[i];
                //        }
                //        else
                //        {
                //            WellcareBatchName = WellcareBatchName + words[i] + "_";
                //        }
                //    }
                //}
                //WellcareBatchName = words[0]; 
                //return WellcareBatchName;

                WellcareBatchName = value.Replace("Wellcare_", "");
                return WellcareBatchName;
            }

            catch (Exception ex)
            {
                return "";
            }
        }
        private String ValidateNO(string Value)
        {
            try
            {
                if (Value == "1")
                {
                    Value = "1";
                }
                else if (Value == "3")
                {
                    Value = "2";
                }
                else if (Value == "4")
                {
                    Value = "3";
                }
                else if (Value == "NA")
                {
                    Value = "";
                }

            }

            catch (Exception ex)
            {
            }
            return Value;
        }

        private String ValidateNO1to5(string Value)
        {
            try
            {
                if (Value == "5")
                {
                    Value = "1";
                }
                else if (Value == "4")
                {
                    Value = "2";
                }
                else if (Value == "3")
                {
                    Value = "3";
                }
                else if (Value == "2")
                {
                    Value = "4";
                }
                else if (Value == "1")
                {
                    Value = "5";
                }
            }

            catch (Exception ex)
            {
            }
            return Value;
        }
        private String ValidateNO1to4(string Value)
        {
            try
            {
                if (Value == "0")
                {
                    Value = "1";
                }
                else if (Value == "1")
                {
                    Value = "2";
                }
                else if (Value == "2")
                {
                    Value = "3";
                }
                else if (Value == "3")
                {
                    Value = "4";
                }
            }

            catch (Exception ex)
            {
            }
            return Value;
        }



        private bool ValidateTemplate(int BatchType, DataTable TempTable, String ColumnList)
        {
            bool result = false;
            try
            {
                if (BatchType == 4)//
                {
                    if (TempTable.Columns.Count < 31)
                    {
                        MessageBox.Show("Column Count Mismatched!!!Please check input file column");
                        result = false;
                    }
                    else
                    {


                        string[] user_Name = { "RESPONDENT_ID", "Q1_9", "Q1_1#1", "Q1_2", "Q1_3#1", "Q1_4", "Q1_5", "Q1_6#1", "Q1_7", "Q1_8", "Q3_1", "Q3_2", "Q3_3", "Q3_4", "Q3_5", "Q4_1", "Q4_2", "Q4_3", "Q2_1", "Q2_TTL#1", "Q5_1", "Q5_TTL", "Q6_1", "Q7_2", "Q7_1", "Q8_1", "LANGUAGE", "DATEREC", "DATESCAN", "BATCH NUMBER", "IMAGE FILE NAME" };
                        var ColumnNames = (from DataColumn x in TempTable.Columns
                                           select x.ColumnName).ToArray();
                        var NotMatched = user_Name.Except(ColumnNames);
                        if (NotMatched.Count() == 0)
                        {
                            result = true;
                        }
                        else
                        {
                            MessageBox.Show("Template Not matched Please check and try again!!!!");
                            return false;
                        }
                    }

                }
                if (BatchType == 6)//Template checking for pediatric type
                {
                    if (TempTable.Columns.Count < 38)
                    {
                        MessageBox.Show("Column Count Mismatched!!!Please check input file column");
                        result = false;
                    }
                    else
                    {
                        string[] user_Name = { "BARCODE", "COMPLETION_DATE", "Q1", "Q2", "Q3", "Q4", "Q5", "Q6", "Q7", "Q8", "Q9", "Q10", "Q11", "Q12", "Q13", "Q14", "Q15", "Q16", "Q17", "Q18", "Q19", "Q20", "Q21", "Q22", "Q23", "Q24", "Q25", "Q26", "Q27", "Q28", "Q29", "Q30", "Q31", "Q32", "Q33", "Q34", "BATCH NUMBER", "IMAGE FILE NAME" };
                        var ColumnNames = (from DataColumn x in TempTable.Columns
                                           select x.ColumnName).ToArray();
                        var NotMatched = user_Name.Except(ColumnNames);
                        if (NotMatched.Count() == 0)
                        {
                            result = true;
                        }
                        else
                        {
                            MessageBox.Show("Template Not matched Please check and try again!!!!");
                            return false;
                        }
                    }

                }
                if (BatchType == 0 || BatchType == 1)//Template checking for pediatric type
                {
                    if (TempTable.Columns.Count < 30)
                    {
                        MessageBox.Show("Column Count Mismatched!!!Please check input file column");
                        result = false;
                    }
                    else
                    {
                        string[] user_Name = { "RESPONDENT_ID", "Q1_1", "Q1_2", "Q1_3", "Q1_4", "Q1_5", "Q1_6", "Q1_7", "Q1_8", "Q2_1", "Q2_TTL#1", "Q3_1", "Q3_2", "Q3_3", "Q3_4", "Q3_5", "Q4_1", "Q4_2", "Q5_1", "Q5_TTL", "Q6_1", "Q7_1", "Q7_2", "Q8_1", "Q9_1", "LANGUAGE", "DATEREC", "DATESCAN", "BATCH NUMBER", "IMAGE FILE NAME" };
                        var ColumnNames = (from DataColumn x in TempTable.Columns
                                           select x.ColumnName).ToArray();
                        var NotMatched = user_Name.Except(ColumnNames);
                        if (NotMatched.Count() == 0)
                        {
                            result = true;
                        }
                        else
                        {
                            MessageBox.Show("Template Not matched Please check and try again!!!!");
                            return false;
                        }
                    }

                }
                if (BatchType == 2)
                {
                    foreach (string item in FinalData)
                    {
                        string[] dr = item.ToString().Split('|');
                        string[] user_Name = { "IMAGE_NAME", "MEMBER_ID", "BAR_CODE", "FIRSTNAME", "LASTNAME", "PHONE_CAPTURE", "ADDRESS_OVERRIDE", "ADDRESS_1", "ADDRESS_2", "CITY", "STATE", "ZIP", "DOB", "DOS", "PROVIDER_SIGNATURE", "NOT_OPTIN", "COMP_EXAM1", "COMP_EXAM2", "COMP_EXAM3", "MERCH_CARD_15", "FORM_SCAN", "INTERACTION_DATE_TIME" };
                        var NotMatched = user_Name.Except(dr);
                        if (NotMatched.Count() == 0)
                        {
                            result = true;
                            return result;
                        }
                        else
                        {
                            MessageBox.Show("Template Not matched Please check and try again!!!!");
                            return false;
                        }
                    }
                }
                if (BatchType == 5)//for TRP TYPES
                {
                    foreach (string item in FinalData)
                    {
                        string[] dr = item.ToString().Split('|');
                        //string[] user_Name = { "IMAGE_NAME", "MEMBER_ID", "BAR_CODE", "FIRSTNAME", "LASTNAME", "PHONE_CAPTURE", "ADDRESS_OVERRIDE", "ADDRESS_1", "ADDRESS_2", "CITY", "STATE", "ZIP", "DOB", "DOS", "PROVIDER_SIGNATURE", "MERCH_CARD_15", "FORM_SCAN", "INTERACTION_DATE_TIME" };
                        string[] user_Name = { "Image_Name", "Member_ID", "Bar_Code", "FirstName", "LastName", "Phone_Capture", "Address_Override", "Address_1", "Address_2", "City", "State", "Zip", "DOB", "DOS", "Provider Signature", "Merch_Card", "Form_Scan", "Interaction_Date_Time" };
                        var NotMatched = user_Name.Except(dr);
                        if (NotMatched.Count() == 0)
                        {
                            result = true;
                            return result;
                        }
                        else
                        {
                            MessageBox.Show("Template Not matched Please check and try again!!!!");
                            return false;
                        }
                    }
                }
                if (BatchType == 3)
                {
                    if (TempTable.Columns.Count < 17)
                    {
                        MessageBox.Show("Column Count Mismatched!!!Please check input file column");
                        result = false;
                    }
                    else
                    {
                        string[] user_Name = { "IMAGE_NAME", "BAR_CODE", "Q1_1", "Q1_2", "Q1_3", "Q1_4", "Q1_5", "Q2_1", "Q2_2", "Q2_3", "Q3_1", "Q3_2", "Q3_3", "Q3_4", "SIGNATURE", "SIGNATURE_DATE", "INTERACTION_DATE_TIME" };
                        var ColumnNames = (from DataColumn x in TempTable.Columns
                                           select x.ColumnName).ToArray();
                        var NotMatched = user_Name.Except(ColumnNames);
                        if (NotMatched.Count() == 0)
                        {
                            result = true;
                        }
                        else
                        {
                            MessageBox.Show("Template Not matched Please check and try again!!!!");
                            return false;
                        }
                    }
                }
                if (BatchType == 8)
                {
                    if (TempTable.Columns.Count < 31)
                    {
                        MessageBox.Show("Column Count Mismatched!!!Please check input file column");
                        result = false;
                    }
                    else
                    {

                        //RESPONDENT_ID	Q1_1	Q2_1	Q2_ADDRESS	Q3_1	Q3_2	Q3_3	Q3_4	Q3_5	Q3_EMAIL	Q4_1	Q5_1	Q6_1	Q7_1	Q8_1	Q8_2	Q8_3	Q9_1	Q10_1	Q10_2	Q10_3	Q10_4	Q10_5	Q10_6	Q10_7	Q10_8	Q10_9	Q10_10	Q10_11	Q10_12	Q_11_1	Q_11_2	Q_11_3	Q_11_4	Q12_1	Q12_2	Q12_3	Q12_4	Q12_5	Q12_6	Q12_7	Q13_1	Q14_1	Q15_1	FORM_SCAN	LANGUAGE	DATEREC	DATESCAN	BATCH_NUMBER																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																															
                        string[] user_Name = { "RESPONDENT_ID", "Q1_1", "Q2_1", "Q2_ADDRESS", "Q3_1", "Q3_2", "Q3_3", "Q3_4", "Q3_5", "Q3_EMAIL", "Q4_1", "Q5_1", "Q6_1", "Q7_1", "Q8_1", "Q8_2", "Q8_3", "Q9_1", "Q10_1", "Q10_2", "Q10_3", "Q10_4", "Q10_5", "Q10_6", "Q10_7", "Q10_8", "Q10_9", "Q10_10", "Q10_11", "Q10_12", "Q_11_1", "Q_11_2", "Q_11_3", "Q_11_4", "Q12_1", "Q12_2", "Q12_3", "Q12_4", "Q12_5", "Q12_6", "Q12_7", "Q13_1", "Q14_1", "Q15_1", "FORM_SCAN", "LANGUAGE", "DATEREC", "DATESCAN", "BATCH_NUMBER" };
                        var ColumnNames = (from DataColumn x in TempTable.Columns
                                           select x.ColumnName).ToArray();
                        var NotMatched = user_Name.Except(ColumnNames);
                        if (NotMatched.Count() == 0)
                        {
                            result = true;
                        }
                        else
                        {
                            MessageBox.Show("Template Not matched Please check and try again!!!!");
                            return false;
                        }
                    }
                }
                if (BatchType == 9)
                {
                    if (TempTable.Columns.Count < 51)
                    {
                        MessageBox.Show("Column Count Mismatched!!!Please check input file column");
                        result = false;
                    }
                    else
                    {

                        string[] user_Name = { "BARCODE", "COMPLETION_DATE", "PERMISSION", "Q1", "Q2", "Q3", "Q4", "Q5", "Q6", "Q7", "Q8", "Q9", "Q10", "Q43", "Q44", "Q11", "Q12", "Q12.1", "Q12.2", "Q13", "Q14", "Q15", "Q16", "Q17", "Q18", "Q19", "Q20", "Q20.1", "Q20.2", "Q21", "Q22", "Q23", "Q24", "Q25", "Q26", "Q27", "Q28", "Q29", "Q30", "Q31", "Q32", "Q33", "Q34", "Q35", "Q36", "Q37", "Q38", "Q39", "Q40", "Q41", "Q42", "BATCH NUMBER", "IMAGE FILE NAME" };
                        var ColumnNames = (from DataColumn x in TempTable.Columns
                                           select x.ColumnName).ToArray();
                        var NotMatched = user_Name.Except(ColumnNames);
                        if (NotMatched.Count() == 0)
                        {
                            result = true;
                        }
                        else
                        {
                            MessageBox.Show("Template Not matched Please check and try again!!!!");
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                result = false;
            }
            return result;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
