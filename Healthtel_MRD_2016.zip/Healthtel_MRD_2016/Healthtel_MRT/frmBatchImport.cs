﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using DataAccessLayer.ProjectDB;
using DataAccessLayer.GlobalDB;
using App.Base;

namespace Healthtel_MRT
{
    public partial class frmBatchImport : Form
    {
        public frmBatchImport()
        {
            InitializeComponent();
        }

        #region Variables

        List<string> PathList = new List<string>();

        #endregion

        #region Help Methods

        private bool ImportBatch()
        {
            try
            {
                if (cmbBatchType.SelectedIndex < 0)
                {
                    MessageBox.Show("Select the BatchType to import.");
                    return false;
                }

                if (string.IsNullOrEmpty(txtBatchPath.Text))
                {
                    MessageBox.Show("Invalid Batchname");
                    return false;
                }

                if (new batchmaster().ISBatchNameExist(txtBatchName.Text))
                {
                    MessageBox.Show("Batchname already Exists");
                    return false;
                }

                PathList = IGUtilities.ImportFiles(txtBatchPath.Text.Trim());

                if (PathList.Count == 0)
                {
                    MessageBox.Show("No files in this folder to Import.");
                    return false;
                }

                lblImportStatus.Text = string.Format("{0}", "Importing Images...");
                lblImportStatus.Visible = true;

                //Name,Key1,Key2,Key3,KeyQC,CompareQC,FullQC,ImportDate,Export,ExportDate,Import_UserID
                batchmaster objBatchmaster = new batchmaster();
                objBatchmaster.Name = txtBatchName.Text.Trim();
                objBatchmaster.Key1 = 0;
                objBatchmaster.Key2 = 0;
                objBatchmaster.Key3 = 0;
                objBatchmaster.KeyQC = 0;
                objBatchmaster.CompareQC = 0;
                objBatchmaster.FullQC = 0;
                objBatchmaster.Export = 0;
                objBatchmaster.BatchType = cmbBatchType.SelectedIndex;
                objBatchmaster.Store();

                if (objBatchmaster.HasError)
                {
                    //MessageBox.Show("Batch Import failed");
                    return false;
                }

                foreach (string ImagePath in PathList)
                {
                    imagemaster objImagemaster = new imagemaster();
                    objImagemaster.ImagePath = ImagePath;
                    objImagemaster.Key1 = 0;
                    objImagemaster.Key2 = 0;
                    objImagemaster.Key3 = 0;
                    objImagemaster.KeyQC = 0;
                    objImagemaster.CompareQC = 0;
                    objImagemaster.FullQC = 0;
                    objImagemaster.BatchID = objBatchmaster.ID;
                    objImagemaster.Store();
                }
                //MessageBox.Show("Batch Imported");
                lblImportStatus.Visible = false;
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        #endregion

        #region Events

        private void btnImport_Click(object sender, EventArgs e)
        {
            bool IsBatchImport = false;
            IsBatchImport = ImportBatch();

            if (IsBatchImport == true)
            {
                lblImportStatus.Visible = true;
                Application.DoEvents();
                lblImportStatus.Text = string.Format("{0} Images Imported...", PathList.Count);
                MessageBox.Show("Batch Imported");
            }
            else
            {
                MessageBox.Show("Batch Import failed");
                return;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            DialogResult result = fbd.ShowDialog();

            if (result == DialogResult.OK)
            {
                if (Directory.Exists(fbd.SelectedPath))
                {
                    txtBatchPath.Text = fbd.SelectedPath;
                }
                else
                {
                    MessageBox.Show("Invalid Selection");
                }
            }
        }

        private void txtBatchPath_TextChanged(object sender, EventArgs e)
        {
            int iPos;
            string strFolderPath = txtBatchPath.Text;

            if (!string.IsNullOrEmpty(strFolderPath))
            {
                if (strFolderPath.LastIndexOf("\\") >= strFolderPath.Length - 1 & strFolderPath.Length > 0)
                {
                    strFolderPath = strFolderPath.Substring(0, strFolderPath.Length - 1);
                }
                iPos = strFolderPath.LastIndexOf("\\");

                txtBatchName.Text = strFolderPath.Substring(iPos + 1, strFolderPath.Length - (iPos + 1));
            }
        }

        #endregion
    }
}
