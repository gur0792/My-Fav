﻿namespace Healthtel_MRT
{
    partial class Healthtel_pediatric
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label8 = new System.Windows.Forms.Label();
            this.txtQ25 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtQ24 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtQ23 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtQ21 = new System.Windows.Forms.TextBox();
            this.lblKey2Data = new System.Windows.Forms.Label();
            this.txtQ22 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtQ20 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtQ19 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtQ18 = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblBarcode = new System.Windows.Forms.Label();
            this.txtbarcode = new System.Windows.Forms.TextBox();
            this.lblQ3 = new System.Windows.Forms.Label();
            this.txtQ10 = new System.Windows.Forms.TextBox();
            this.lblQ10 = new System.Windows.Forms.Label();
            this.txtQ17 = new System.Windows.Forms.TextBox();
            this.grpTxtBoxes1 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.Label();
            this.grpKeyData = new System.Windows.Forms.GroupBox();
            this.txtKey2Data = new System.Windows.Forms.TextBox();
            this.lblKey2User = new System.Windows.Forms.Label();
            this.txtKey2User = new System.Windows.Forms.TextBox();
            this.lblKey1Data = new System.Windows.Forms.Label();
            this.txtKey1Data = new System.Windows.Forms.TextBox();
            this.lblKey1User = new System.Windows.Forms.Label();
            this.txtKey1User = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtQ34 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtQ33 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtQ32 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtQ31 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtQ28 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtQ27 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtQ26 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtQ30 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtQ29 = new System.Windows.Forms.TextBox();
            this.lblQ9 = new System.Windows.Forms.Label();
            this.txtQ16 = new System.Windows.Forms.TextBox();
            this.lblQ8 = new System.Windows.Forms.Label();
            this.txtQ15 = new System.Windows.Forms.TextBox();
            this.lblQ7 = new System.Windows.Forms.Label();
            this.txtQ14 = new System.Windows.Forms.TextBox();
            this.lblQ6 = new System.Windows.Forms.Label();
            this.txtQ13 = new System.Windows.Forms.TextBox();
            this.lblQ5 = new System.Windows.Forms.Label();
            this.txtQ12 = new System.Windows.Forms.TextBox();
            this.lblQ4 = new System.Windows.Forms.Label();
            this.txtQ11 = new System.Windows.Forms.TextBox();
            this.lblQ2_8 = new System.Windows.Forms.Label();
            this.txtQ9 = new System.Windows.Forms.TextBox();
            this.lblQ2_7 = new System.Windows.Forms.Label();
            this.txtQ8 = new System.Windows.Forms.TextBox();
            this.lblQ2_6 = new System.Windows.Forms.Label();
            this.txtQ7 = new System.Windows.Forms.TextBox();
            this.lblQ2_5 = new System.Windows.Forms.Label();
            this.txtQ6 = new System.Windows.Forms.TextBox();
            this.lblQ2_4 = new System.Windows.Forms.Label();
            this.txtQ5 = new System.Windows.Forms.TextBox();
            this.lblQ2_3 = new System.Windows.Forms.Label();
            this.txtQ4 = new System.Windows.Forms.TextBox();
            this.lblQ2_2 = new System.Windows.Forms.Label();
            this.txtQ3 = new System.Windows.Forms.TextBox();
            this.lblQ2 = new System.Windows.Forms.Label();
            this.txtQ2 = new System.Windows.Forms.TextBox();
            this.lblQ1 = new System.Windows.Forms.Label();
            this.txtQ1 = new System.Windows.Forms.TextBox();
            this.stsRemRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsFinRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsTotRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.StatusStrip1 = new System.Windows.Forms.StatusStrip();
            this.stsUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.grpMain = new System.Windows.Forms.GroupBox();
            this.IGImageViewer = new InfognanaImageViewer.IGImageViewer();
            this.lblinstruction = new System.Windows.Forms.Label();
            this.txtinstruction = new System.Windows.Forms.Label();
            this.grpTxtBoxes1.SuspendLayout();
            this.grpKeyData.SuspendLayout();
            this.StatusStrip1.SuspendLayout();
            this.grpMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(513, 39);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 14);
            this.label8.TabIndex = 51;
            this.label8.Text = "Q12_4";
            // 
            // txtQ25
            // 
            this.txtQ25.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ25.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ25.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ25.Location = new System.Drawing.Point(582, 35);
            this.txtQ25.MaxLength = 1;
            this.txtQ25.Name = "txtQ25";
            this.txtQ25.Size = new System.Drawing.Size(41, 22);
            this.txtQ25.TabIndex = 26;
            this.txtQ25.TextChanged += new System.EventHandler(this.txtQ25_TextChanged);
            this.txtQ25.Enter += new System.EventHandler(this.txtQ25_Enter);
            this.txtQ25.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ25_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(398, 183);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 14);
            this.label7.TabIndex = 49;
            this.label7.Text = "Q12_3";
            // 
            // txtQ24
            // 
            this.txtQ24.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ24.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ24.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ24.Location = new System.Drawing.Point(466, 182);
            this.txtQ24.MaxLength = 1;
            this.txtQ24.Name = "txtQ24";
            this.txtQ24.Size = new System.Drawing.Size(41, 22);
            this.txtQ24.TabIndex = 25;
            this.txtQ24.TextChanged += new System.EventHandler(this.txtQ24_TextChanged);
            this.txtQ24.Enter += new System.EventHandler(this.txtQ24_Enter);
            this.txtQ24.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ24_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(404, 144);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 14);
            this.label6.TabIndex = 47;
            this.label6.Text = "Q12_2";
            // 
            // txtQ23
            // 
            this.txtQ23.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ23.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ23.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ23.Location = new System.Drawing.Point(466, 141);
            this.txtQ23.MaxLength = 1;
            this.txtQ23.Name = "txtQ23";
            this.txtQ23.Size = new System.Drawing.Size(41, 22);
            this.txtQ23.TabIndex = 24;
            this.txtQ23.TextChanged += new System.EventHandler(this.txtQ23_TextChanged);
            this.txtQ23.Enter += new System.EventHandler(this.txtQ23_Enter);
            this.txtQ23.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ23_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(405, 108);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 14);
            this.label5.TabIndex = 45;
            this.label5.Text = "Q12_1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(405, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 14);
            this.label4.TabIndex = 43;
            this.label4.Text = "Q11";
            // 
            // txtQ21
            // 
            this.txtQ21.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ21.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ21.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ21.Location = new System.Drawing.Point(466, 75);
            this.txtQ21.MaxLength = 1;
            this.txtQ21.Name = "txtQ21";
            this.txtQ21.Size = new System.Drawing.Size(41, 22);
            this.txtQ21.TabIndex = 22;
            this.txtQ21.TextChanged += new System.EventHandler(this.txtQ21_TextChanged);
            this.txtQ21.Enter += new System.EventHandler(this.txtQ21_Enter);
            this.txtQ21.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ21_KeyPress);
            // 
            // lblKey2Data
            // 
            this.lblKey2Data.AutoSize = true;
            this.lblKey2Data.Enabled = false;
            this.lblKey2Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey2Data.ForeColor = System.Drawing.Color.White;
            this.lblKey2Data.Location = new System.Drawing.Point(11, 106);
            this.lblKey2Data.Name = "lblKey2Data";
            this.lblKey2Data.Size = new System.Drawing.Size(76, 14);
            this.lblKey2Data.TabIndex = 49;
            this.lblKey2Data.Text = "Key2 Data";
            // 
            // txtQ22
            // 
            this.txtQ22.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ22.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ22.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ22.Location = new System.Drawing.Point(466, 107);
            this.txtQ22.MaxLength = 1;
            this.txtQ22.Name = "txtQ22";
            this.txtQ22.Size = new System.Drawing.Size(41, 22);
            this.txtQ22.TabIndex = 23;
            this.txtQ22.TextChanged += new System.EventHandler(this.txtQ22_TextChanged);
            this.txtQ22.Enter += new System.EventHandler(this.txtQ22_Enter);
            this.txtQ22.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ22_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(405, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 14);
            this.label3.TabIndex = 41;
            this.label3.Text = "Q10";
            // 
            // txtQ20
            // 
            this.txtQ20.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ20.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ20.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ20.Location = new System.Drawing.Point(466, 38);
            this.txtQ20.MaxLength = 1;
            this.txtQ20.Name = "txtQ20";
            this.txtQ20.Size = new System.Drawing.Size(41, 22);
            this.txtQ20.TabIndex = 21;
            this.txtQ20.TextChanged += new System.EventHandler(this.txtQ20_TextChanged);
            this.txtQ20.Enter += new System.EventHandler(this.txtQ20_Enter);
            this.txtQ20.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ20_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(305, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 14);
            this.label2.TabIndex = 39;
            this.label2.Text = "Q9_11";
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(909, 169);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(85, 37);
            this.btnExit.TabIndex = 37;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtQ19
            // 
            this.txtQ19.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ19.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ19.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ19.Location = new System.Drawing.Point(357, 181);
            this.txtQ19.MaxLength = 1;
            this.txtQ19.Name = "txtQ19";
            this.txtQ19.Size = new System.Drawing.Size(41, 22);
            this.txtQ19.TabIndex = 20;
            this.txtQ19.TextChanged += new System.EventHandler(this.txtQ19_TextChanged);
            this.txtQ19.Enter += new System.EventHandler(this.txtQ19_Enter);
            this.txtQ19.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ19_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(305, 147);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 14);
            this.label1.TabIndex = 37;
            this.label1.Text = "Q9_10";
            // 
            // txtQ18
            // 
            this.txtQ18.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ18.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ18.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ18.Location = new System.Drawing.Point(358, 141);
            this.txtQ18.MaxLength = 1;
            this.txtQ18.Name = "txtQ18";
            this.txtQ18.Size = new System.Drawing.Size(41, 22);
            this.txtQ18.TabIndex = 19;
            this.txtQ18.TextChanged += new System.EventHandler(this.txtQ18_TextChanged);
            this.txtQ18.Enter += new System.EventHandler(this.txtQ18_Enter);
            this.txtQ18.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ18_KeyPress);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.ImageKey = "(none)";
            this.btnSave.Location = new System.Drawing.Point(808, 170);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 37);
            this.btnSave.TabIndex = 36;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblBarcode
            // 
            this.lblBarcode.AutoSize = true;
            this.lblBarcode.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBarcode.ForeColor = System.Drawing.Color.White;
            this.lblBarcode.Location = new System.Drawing.Point(24, 41);
            this.lblBarcode.Name = "lblBarcode";
            this.lblBarcode.Size = new System.Drawing.Size(61, 14);
            this.lblBarcode.TabIndex = 1;
            this.lblBarcode.Text = "Barcode";
            // 
            // txtbarcode
            // 
            this.txtbarcode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtbarcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtbarcode.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtbarcode.Location = new System.Drawing.Point(11, 60);
            this.txtbarcode.MaxLength = 20;
            this.txtbarcode.Name = "txtbarcode";
            this.txtbarcode.Size = new System.Drawing.Size(101, 22);
            this.txtbarcode.TabIndex = 1;
            this.txtbarcode.TextChanged += new System.EventHandler(this.txtbarcode_TextChanged);
            this.txtbarcode.Enter += new System.EventHandler(this.txtbarcode_Enter);
            this.txtbarcode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbarcode_KeyPress);
            // 
            // lblQ3
            // 
            this.lblQ3.AutoSize = true;
            this.lblQ3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ3.ForeColor = System.Drawing.Color.White;
            this.lblQ3.Location = new System.Drawing.Point(216, 46);
            this.lblQ3.Name = "lblQ3";
            this.lblQ3.Size = new System.Drawing.Size(45, 14);
            this.lblQ3.TabIndex = 21;
            this.lblQ3.Text = "Q9_2";
            // 
            // txtQ10
            // 
            this.txtQ10.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ10.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ10.Location = new System.Drawing.Point(261, 42);
            this.txtQ10.MaxLength = 1;
            this.txtQ10.Name = "txtQ10";
            this.txtQ10.Size = new System.Drawing.Size(41, 22);
            this.txtQ10.TabIndex = 11;
            this.txtQ10.TextChanged += new System.EventHandler(this.txtQ10_TextChanged);
            this.txtQ10.Enter += new System.EventHandler(this.txtQ10_Enter);
            this.txtQ10.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ10_KeyPress);
            // 
            // lblQ10
            // 
            this.lblQ10.AutoSize = true;
            this.lblQ10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ10.ForeColor = System.Drawing.Color.White;
            this.lblQ10.Location = new System.Drawing.Point(305, 114);
            this.lblQ10.Name = "lblQ10";
            this.lblQ10.Size = new System.Drawing.Size(45, 14);
            this.lblQ10.TabIndex = 35;
            this.lblQ10.Text = "Q9_9";
            // 
            // txtQ17
            // 
            this.txtQ17.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ17.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ17.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ17.Location = new System.Drawing.Point(358, 106);
            this.txtQ17.MaxLength = 1;
            this.txtQ17.Name = "txtQ17";
            this.txtQ17.Size = new System.Drawing.Size(41, 22);
            this.txtQ17.TabIndex = 18;
            this.txtQ17.TextChanged += new System.EventHandler(this.txtQ17_TextChanged);
            this.txtQ17.Enter += new System.EventHandler(this.txtQ17_Enter);
            this.txtQ17.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ17_KeyPress);
            // 
            // grpTxtBoxes1
            // 
            this.grpTxtBoxes1.BackColor = System.Drawing.Color.Navy;
            this.grpTxtBoxes1.Controls.Add(this.txtinstruction);
            this.grpTxtBoxes1.Controls.Add(this.lblinstruction);
            this.grpTxtBoxes1.Controls.Add(this.btnExit);
            this.grpTxtBoxes1.Controls.Add(this.label18);
            this.grpTxtBoxes1.Controls.Add(this.btnSave);
            this.grpTxtBoxes1.Controls.Add(this.txtDescription);
            this.grpTxtBoxes1.Controls.Add(this.grpKeyData);
            this.grpTxtBoxes1.Controls.Add(this.label17);
            this.grpTxtBoxes1.Controls.Add(this.txtQ34);
            this.grpTxtBoxes1.Controls.Add(this.label14);
            this.grpTxtBoxes1.Controls.Add(this.txtQ33);
            this.grpTxtBoxes1.Controls.Add(this.label15);
            this.grpTxtBoxes1.Controls.Add(this.txtQ32);
            this.grpTxtBoxes1.Controls.Add(this.label16);
            this.grpTxtBoxes1.Controls.Add(this.txtQ31);
            this.grpTxtBoxes1.Controls.Add(this.label9);
            this.grpTxtBoxes1.Controls.Add(this.txtQ28);
            this.grpTxtBoxes1.Controls.Add(this.label10);
            this.grpTxtBoxes1.Controls.Add(this.txtQ27);
            this.grpTxtBoxes1.Controls.Add(this.label11);
            this.grpTxtBoxes1.Controls.Add(this.txtQ26);
            this.grpTxtBoxes1.Controls.Add(this.label12);
            this.grpTxtBoxes1.Controls.Add(this.txtQ30);
            this.grpTxtBoxes1.Controls.Add(this.label13);
            this.grpTxtBoxes1.Controls.Add(this.txtQ29);
            this.grpTxtBoxes1.Controls.Add(this.label8);
            this.grpTxtBoxes1.Controls.Add(this.txtQ25);
            this.grpTxtBoxes1.Controls.Add(this.label7);
            this.grpTxtBoxes1.Controls.Add(this.txtQ24);
            this.grpTxtBoxes1.Controls.Add(this.label6);
            this.grpTxtBoxes1.Controls.Add(this.txtQ23);
            this.grpTxtBoxes1.Controls.Add(this.label5);
            this.grpTxtBoxes1.Controls.Add(this.txtQ22);
            this.grpTxtBoxes1.Controls.Add(this.label4);
            this.grpTxtBoxes1.Controls.Add(this.txtQ21);
            this.grpTxtBoxes1.Controls.Add(this.label3);
            this.grpTxtBoxes1.Controls.Add(this.txtQ20);
            this.grpTxtBoxes1.Controls.Add(this.label2);
            this.grpTxtBoxes1.Controls.Add(this.txtQ19);
            this.grpTxtBoxes1.Controls.Add(this.label1);
            this.grpTxtBoxes1.Controls.Add(this.txtQ18);
            this.grpTxtBoxes1.Controls.Add(this.lblBarcode);
            this.grpTxtBoxes1.Controls.Add(this.txtbarcode);
            this.grpTxtBoxes1.Controls.Add(this.lblQ3);
            this.grpTxtBoxes1.Controls.Add(this.txtQ10);
            this.grpTxtBoxes1.Controls.Add(this.lblQ10);
            this.grpTxtBoxes1.Controls.Add(this.txtQ17);
            this.grpTxtBoxes1.Controls.Add(this.lblQ9);
            this.grpTxtBoxes1.Controls.Add(this.txtQ16);
            this.grpTxtBoxes1.Controls.Add(this.lblQ8);
            this.grpTxtBoxes1.Controls.Add(this.txtQ15);
            this.grpTxtBoxes1.Controls.Add(this.lblQ7);
            this.grpTxtBoxes1.Controls.Add(this.txtQ14);
            this.grpTxtBoxes1.Controls.Add(this.lblQ6);
            this.grpTxtBoxes1.Controls.Add(this.txtQ13);
            this.grpTxtBoxes1.Controls.Add(this.lblQ5);
            this.grpTxtBoxes1.Controls.Add(this.txtQ12);
            this.grpTxtBoxes1.Controls.Add(this.lblQ4);
            this.grpTxtBoxes1.Controls.Add(this.txtQ11);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_8);
            this.grpTxtBoxes1.Controls.Add(this.txtQ9);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_7);
            this.grpTxtBoxes1.Controls.Add(this.txtQ8);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_6);
            this.grpTxtBoxes1.Controls.Add(this.txtQ7);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_5);
            this.grpTxtBoxes1.Controls.Add(this.txtQ6);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_4);
            this.grpTxtBoxes1.Controls.Add(this.txtQ5);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_3);
            this.grpTxtBoxes1.Controls.Add(this.txtQ4);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_2);
            this.grpTxtBoxes1.Controls.Add(this.txtQ3);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2);
            this.grpTxtBoxes1.Controls.Add(this.txtQ2);
            this.grpTxtBoxes1.Controls.Add(this.lblQ1);
            this.grpTxtBoxes1.Controls.Add(this.txtQ1);
            this.grpTxtBoxes1.Location = new System.Drawing.Point(1, 19);
            this.grpTxtBoxes1.Name = "grpTxtBoxes1";
            this.grpTxtBoxes1.Size = new System.Drawing.Size(1033, 217);
            this.grpTxtBoxes1.TabIndex = 1;
            this.grpTxtBoxes1.TabStop = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Location = new System.Drawing.Point(12, 15);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(75, 13);
            this.label18.TabIndex = 75;
            this.label18.Text = "Description:";
            // 
            // txtDescription
            // 
            this.txtDescription.AutoSize = true;
            this.txtDescription.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtDescription.ForeColor = System.Drawing.Color.Red;
            this.txtDescription.Location = new System.Drawing.Point(118, 14);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(82, 14);
            this.txtDescription.TabIndex = 74;
            this.txtDescription.Text = "Description";
            // 
            // grpKeyData
            // 
            this.grpKeyData.BackColor = System.Drawing.Color.Navy;
            this.grpKeyData.Controls.Add(this.lblKey2Data);
            this.grpKeyData.Controls.Add(this.txtKey2Data);
            this.grpKeyData.Controls.Add(this.lblKey2User);
            this.grpKeyData.Controls.Add(this.txtKey2User);
            this.grpKeyData.Controls.Add(this.lblKey1Data);
            this.grpKeyData.Controls.Add(this.txtKey1Data);
            this.grpKeyData.Controls.Add(this.lblKey1User);
            this.grpKeyData.Controls.Add(this.txtKey1User);
            this.grpKeyData.Location = new System.Drawing.Point(806, 35);
            this.grpKeyData.Name = "grpKeyData";
            this.grpKeyData.Size = new System.Drawing.Size(214, 128);
            this.grpKeyData.TabIndex = 45;
            this.grpKeyData.TabStop = false;
            this.grpKeyData.Visible = false;
            // 
            // txtKey2Data
            // 
            this.txtKey2Data.Enabled = false;
            this.txtKey2Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey2Data.Location = new System.Drawing.Point(90, 101);
            this.txtKey2Data.Name = "txtKey2Data";
            this.txtKey2Data.Size = new System.Drawing.Size(118, 22);
            this.txtKey2Data.TabIndex = 50;
            // 
            // lblKey2User
            // 
            this.lblKey2User.AutoSize = true;
            this.lblKey2User.Enabled = false;
            this.lblKey2User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey2User.ForeColor = System.Drawing.Color.White;
            this.lblKey2User.Location = new System.Drawing.Point(7, 78);
            this.lblKey2User.Name = "lblKey2User";
            this.lblKey2User.Size = new System.Drawing.Size(76, 14);
            this.lblKey2User.TabIndex = 47;
            this.lblKey2User.Text = "Key2 User";
            // 
            // txtKey2User
            // 
            this.txtKey2User.Enabled = false;
            this.txtKey2User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey2User.Location = new System.Drawing.Point(90, 73);
            this.txtKey2User.Name = "txtKey2User";
            this.txtKey2User.Size = new System.Drawing.Size(118, 22);
            this.txtKey2User.TabIndex = 48;
            // 
            // lblKey1Data
            // 
            this.lblKey1Data.AutoSize = true;
            this.lblKey1Data.Enabled = false;
            this.lblKey1Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey1Data.ForeColor = System.Drawing.Color.White;
            this.lblKey1Data.Location = new System.Drawing.Point(5, 40);
            this.lblKey1Data.Name = "lblKey1Data";
            this.lblKey1Data.Size = new System.Drawing.Size(76, 14);
            this.lblKey1Data.TabIndex = 45;
            this.lblKey1Data.Text = "Key1 Data";
            // 
            // txtKey1Data
            // 
            this.txtKey1Data.Enabled = false;
            this.txtKey1Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey1Data.Location = new System.Drawing.Point(90, 38);
            this.txtKey1Data.Name = "txtKey1Data";
            this.txtKey1Data.Size = new System.Drawing.Size(118, 22);
            this.txtKey1Data.TabIndex = 46;
            // 
            // lblKey1User
            // 
            this.lblKey1User.AutoSize = true;
            this.lblKey1User.Enabled = false;
            this.lblKey1User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey1User.ForeColor = System.Drawing.Color.White;
            this.lblKey1User.Location = new System.Drawing.Point(10, 13);
            this.lblKey1User.Name = "lblKey1User";
            this.lblKey1User.Size = new System.Drawing.Size(76, 14);
            this.lblKey1User.TabIndex = 43;
            this.lblKey1User.Text = "Key1 User";
            // 
            // txtKey1User
            // 
            this.txtKey1User.Enabled = false;
            this.txtKey1User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey1User.Location = new System.Drawing.Point(90, 14);
            this.txtKey1User.Name = "txtKey1User";
            this.txtKey1User.Size = new System.Drawing.Size(118, 22);
            this.txtKey1User.TabIndex = 44;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(645, 177);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(36, 14);
            this.label17.TabIndex = 73;
            this.label17.Text = "Q15";
            // 
            // txtQ34
            // 
            this.txtQ34.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ34.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ34.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ34.Location = new System.Drawing.Point(711, 177);
            this.txtQ34.MaxLength = 1;
            this.txtQ34.Name = "txtQ34";
            this.txtQ34.Size = new System.Drawing.Size(41, 22);
            this.txtQ34.TabIndex = 35;
            this.txtQ34.TextChanged += new System.EventHandler(this.txtQ34_TextChanged);
            this.txtQ34.Enter += new System.EventHandler(this.txtQ34_Enter);
            this.txtQ34.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ34_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(645, 134);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(36, 14);
            this.label14.TabIndex = 71;
            this.label14.Text = "Q14";
            // 
            // txtQ33
            // 
            this.txtQ33.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ33.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ33.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ33.Location = new System.Drawing.Point(711, 134);
            this.txtQ33.MaxLength = 1;
            this.txtQ33.Name = "txtQ33";
            this.txtQ33.Size = new System.Drawing.Size(41, 22);
            this.txtQ33.TabIndex = 34;
            this.txtQ33.TextChanged += new System.EventHandler(this.txtQ33_TextChanged);
            this.txtQ33.Enter += new System.EventHandler(this.txtQ33_Enter);
            this.txtQ33.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ33_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(644, 98);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(36, 14);
            this.label15.TabIndex = 69;
            this.label15.Text = "Q13";
            // 
            // txtQ32
            // 
            this.txtQ32.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ32.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ32.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ32.Location = new System.Drawing.Point(711, 98);
            this.txtQ32.MaxLength = 1;
            this.txtQ32.Name = "txtQ32";
            this.txtQ32.Size = new System.Drawing.Size(41, 22);
            this.txtQ32.TabIndex = 33;
            this.txtQ32.TextChanged += new System.EventHandler(this.txtQ32_TextChanged);
            this.txtQ32.Enter += new System.EventHandler(this.txtQ32_Enter);
            this.txtQ32.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ32_KeyPress);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(645, 67);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(63, 14);
            this.label16.TabIndex = 67;
            this.label16.Text = "Q12_10";
            // 
            // txtQ31
            // 
            this.txtQ31.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ31.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ31.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ31.Location = new System.Drawing.Point(711, 67);
            this.txtQ31.MaxLength = 1;
            this.txtQ31.Name = "txtQ31";
            this.txtQ31.Size = new System.Drawing.Size(41, 22);
            this.txtQ31.TabIndex = 32;
            this.txtQ31.TextChanged += new System.EventHandler(this.txtQ31_TextChanged);
            this.txtQ31.Enter += new System.EventHandler(this.txtQ31_Enter);
            this.txtQ31.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ31_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(513, 144);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 14);
            this.label9.TabIndex = 65;
            this.label9.Text = "Q12_7";
            // 
            // txtQ28
            // 
            this.txtQ28.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ28.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ28.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ28.Location = new System.Drawing.Point(582, 135);
            this.txtQ28.MaxLength = 1;
            this.txtQ28.Name = "txtQ28";
            this.txtQ28.Size = new System.Drawing.Size(41, 22);
            this.txtQ28.TabIndex = 29;
            this.txtQ28.TextChanged += new System.EventHandler(this.txtQ28_TextChanged);
            this.txtQ28.Enter += new System.EventHandler(this.txtQ28_Enter);
            this.txtQ28.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ28_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(513, 106);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 14);
            this.label10.TabIndex = 63;
            this.label10.Text = "Q12_6";
            // 
            // txtQ27
            // 
            this.txtQ27.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ27.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ27.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ27.Location = new System.Drawing.Point(582, 99);
            this.txtQ27.MaxLength = 1;
            this.txtQ27.Name = "txtQ27";
            this.txtQ27.Size = new System.Drawing.Size(41, 22);
            this.txtQ27.TabIndex = 28;
            this.txtQ27.TextChanged += new System.EventHandler(this.txtQ27_TextChanged);
            this.txtQ27.Enter += new System.EventHandler(this.txtQ27_Enter);
            this.txtQ27.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ27_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(513, 78);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 14);
            this.label11.TabIndex = 61;
            this.label11.Text = "Q12_5";
            // 
            // txtQ26
            // 
            this.txtQ26.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ26.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ26.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ26.Location = new System.Drawing.Point(582, 68);
            this.txtQ26.MaxLength = 1;
            this.txtQ26.Name = "txtQ26";
            this.txtQ26.Size = new System.Drawing.Size(41, 22);
            this.txtQ26.TabIndex = 27;
            this.txtQ26.TextChanged += new System.EventHandler(this.txtQ26_TextChanged);
            this.txtQ26.Enter += new System.EventHandler(this.txtQ26_Enter);
            this.txtQ26.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ26_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(647, 36);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 14);
            this.label12.TabIndex = 59;
            this.label12.Text = "Q12_9";
            // 
            // txtQ30
            // 
            this.txtQ30.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ30.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ30.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ30.Location = new System.Drawing.Point(711, 36);
            this.txtQ30.MaxLength = 1;
            this.txtQ30.Name = "txtQ30";
            this.txtQ30.Size = new System.Drawing.Size(41, 22);
            this.txtQ30.TabIndex = 31;
            this.txtQ30.TextChanged += new System.EventHandler(this.txtQ30_TextChanged);
            this.txtQ30.Enter += new System.EventHandler(this.txtQ30_Enter);
            this.txtQ30.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ30_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(513, 183);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 14);
            this.label13.TabIndex = 57;
            this.label13.Text = "Q12_8";
            // 
            // txtQ29
            // 
            this.txtQ29.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ29.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ29.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ29.Location = new System.Drawing.Point(582, 179);
            this.txtQ29.MaxLength = 1;
            this.txtQ29.Name = "txtQ29";
            this.txtQ29.Size = new System.Drawing.Size(41, 22);
            this.txtQ29.TabIndex = 30;
            this.txtQ29.TextChanged += new System.EventHandler(this.txtQ29_TextChanged);
            this.txtQ29.Enter += new System.EventHandler(this.txtQ29_Enter);
            this.txtQ29.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ29_KeyPress);
            // 
            // lblQ9
            // 
            this.lblQ9.AutoSize = true;
            this.lblQ9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ9.ForeColor = System.Drawing.Color.White;
            this.lblQ9.Location = new System.Drawing.Point(305, 75);
            this.lblQ9.Name = "lblQ9";
            this.lblQ9.Size = new System.Drawing.Size(45, 14);
            this.lblQ9.TabIndex = 33;
            this.lblQ9.Text = "Q9_8";
            // 
            // txtQ16
            // 
            this.txtQ16.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ16.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ16.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ16.Location = new System.Drawing.Point(353, 70);
            this.txtQ16.MaxLength = 1;
            this.txtQ16.Name = "txtQ16";
            this.txtQ16.Size = new System.Drawing.Size(41, 22);
            this.txtQ16.TabIndex = 17;
            this.txtQ16.TextChanged += new System.EventHandler(this.txtQ16_TextChanged);
            this.txtQ16.Enter += new System.EventHandler(this.txtQ16_Enter);
            this.txtQ16.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ16_KeyPress);
            // 
            // lblQ8
            // 
            this.lblQ8.AutoSize = true;
            this.lblQ8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ8.ForeColor = System.Drawing.Color.White;
            this.lblQ8.Location = new System.Drawing.Point(305, 42);
            this.lblQ8.Name = "lblQ8";
            this.lblQ8.Size = new System.Drawing.Size(45, 14);
            this.lblQ8.TabIndex = 31;
            this.lblQ8.Text = "Q9_7";
            // 
            // txtQ15
            // 
            this.txtQ15.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ15.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ15.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ15.Location = new System.Drawing.Point(353, 37);
            this.txtQ15.MaxLength = 1;
            this.txtQ15.Name = "txtQ15";
            this.txtQ15.Size = new System.Drawing.Size(41, 22);
            this.txtQ15.TabIndex = 16;
            this.txtQ15.TextChanged += new System.EventHandler(this.txtQ15_TextChanged);
            this.txtQ15.Enter += new System.EventHandler(this.txtQ15_Enter);
            this.txtQ15.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ15_KeyPress);
            // 
            // lblQ7
            // 
            this.lblQ7.AutoSize = true;
            this.lblQ7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ7.ForeColor = System.Drawing.Color.White;
            this.lblQ7.Location = new System.Drawing.Point(216, 192);
            this.lblQ7.Name = "lblQ7";
            this.lblQ7.Size = new System.Drawing.Size(45, 14);
            this.lblQ7.TabIndex = 29;
            this.lblQ7.Text = "Q9_6";
            // 
            // txtQ14
            // 
            this.txtQ14.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ14.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ14.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ14.Location = new System.Drawing.Point(261, 186);
            this.txtQ14.MaxLength = 1;
            this.txtQ14.Name = "txtQ14";
            this.txtQ14.Size = new System.Drawing.Size(41, 22);
            this.txtQ14.TabIndex = 15;
            this.txtQ14.TextChanged += new System.EventHandler(this.txtQ14_TextChanged);
            this.txtQ14.Enter += new System.EventHandler(this.txtQ14_Enter);
            this.txtQ14.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ14_KeyPress);
            // 
            // lblQ6
            // 
            this.lblQ6.AutoSize = true;
            this.lblQ6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ6.ForeColor = System.Drawing.Color.White;
            this.lblQ6.Location = new System.Drawing.Point(216, 151);
            this.lblQ6.Name = "lblQ6";
            this.lblQ6.Size = new System.Drawing.Size(45, 14);
            this.lblQ6.TabIndex = 27;
            this.lblQ6.Text = "Q9_5";
            // 
            // txtQ13
            // 
            this.txtQ13.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ13.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ13.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ13.Location = new System.Drawing.Point(261, 151);
            this.txtQ13.MaxLength = 1;
            this.txtQ13.Name = "txtQ13";
            this.txtQ13.Size = new System.Drawing.Size(41, 22);
            this.txtQ13.TabIndex = 14;
            this.txtQ13.TextChanged += new System.EventHandler(this.txtQ13_TextChanged);
            this.txtQ13.Enter += new System.EventHandler(this.txtQ13_Enter);
            this.txtQ13.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ13_KeyPress);
            // 
            // lblQ5
            // 
            this.lblQ5.AutoSize = true;
            this.lblQ5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ5.ForeColor = System.Drawing.Color.White;
            this.lblQ5.Location = new System.Drawing.Point(216, 116);
            this.lblQ5.Name = "lblQ5";
            this.lblQ5.Size = new System.Drawing.Size(45, 14);
            this.lblQ5.TabIndex = 25;
            this.lblQ5.Text = "Q9_4";
            // 
            // txtQ12
            // 
            this.txtQ12.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ12.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ12.Location = new System.Drawing.Point(261, 114);
            this.txtQ12.MaxLength = 1;
            this.txtQ12.Name = "txtQ12";
            this.txtQ12.Size = new System.Drawing.Size(41, 22);
            this.txtQ12.TabIndex = 13;
            this.txtQ12.TextChanged += new System.EventHandler(this.txtQ12_TextChanged);
            this.txtQ12.Enter += new System.EventHandler(this.txtQ12_Enter);
            this.txtQ12.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ12_KeyPress);
            // 
            // lblQ4
            // 
            this.lblQ4.AutoSize = true;
            this.lblQ4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ4.ForeColor = System.Drawing.Color.White;
            this.lblQ4.Location = new System.Drawing.Point(216, 80);
            this.lblQ4.Name = "lblQ4";
            this.lblQ4.Size = new System.Drawing.Size(45, 14);
            this.lblQ4.TabIndex = 23;
            this.lblQ4.Text = "Q9_3";
            // 
            // txtQ11
            // 
            this.txtQ11.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ11.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ11.Location = new System.Drawing.Point(261, 75);
            this.txtQ11.MaxLength = 1;
            this.txtQ11.Name = "txtQ11";
            this.txtQ11.Size = new System.Drawing.Size(41, 22);
            this.txtQ11.TabIndex = 12;
            this.txtQ11.TextChanged += new System.EventHandler(this.txtQ11_TextChanged);
            this.txtQ11.Enter += new System.EventHandler(this.txtQ11_Enter);
            this.txtQ11.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ11_KeyPress);
            // 
            // lblQ2_8
            // 
            this.lblQ2_8.AutoSize = true;
            this.lblQ2_8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_8.ForeColor = System.Drawing.Color.White;
            this.lblQ2_8.Location = new System.Drawing.Point(118, 193);
            this.lblQ2_8.Name = "lblQ2_8";
            this.lblQ2_8.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_8.TabIndex = 19;
            this.lblQ2_8.Text = "Q9_1";
            // 
            // txtQ9
            // 
            this.txtQ9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ9.Location = new System.Drawing.Point(170, 189);
            this.txtQ9.MaxLength = 1;
            this.txtQ9.Name = "txtQ9";
            this.txtQ9.Size = new System.Drawing.Size(41, 22);
            this.txtQ9.TabIndex = 10;
            this.txtQ9.TextChanged += new System.EventHandler(this.txtQ9_TextChanged);
            this.txtQ9.Enter += new System.EventHandler(this.txtQ9_Enter);
            this.txtQ9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ9_KeyPress);
            // 
            // lblQ2_7
            // 
            this.lblQ2_7.AutoSize = true;
            this.lblQ2_7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_7.ForeColor = System.Drawing.Color.White;
            this.lblQ2_7.Location = new System.Drawing.Point(137, 154);
            this.lblQ2_7.Name = "lblQ2_7";
            this.lblQ2_7.Size = new System.Drawing.Size(27, 14);
            this.lblQ2_7.TabIndex = 17;
            this.lblQ2_7.Text = "Q8";
            // 
            // txtQ8
            // 
            this.txtQ8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ8.Location = new System.Drawing.Point(170, 152);
            this.txtQ8.MaxLength = 1;
            this.txtQ8.Name = "txtQ8";
            this.txtQ8.Size = new System.Drawing.Size(41, 22);
            this.txtQ8.TabIndex = 9;
            this.txtQ8.TextChanged += new System.EventHandler(this.txtQ8_TextChanged);
            this.txtQ8.Enter += new System.EventHandler(this.txtQ8_Enter);
            this.txtQ8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ8_KeyPress);
            // 
            // lblQ2_6
            // 
            this.lblQ2_6.AutoSize = true;
            this.lblQ2_6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_6.ForeColor = System.Drawing.Color.White;
            this.lblQ2_6.Location = new System.Drawing.Point(136, 114);
            this.lblQ2_6.Name = "lblQ2_6";
            this.lblQ2_6.Size = new System.Drawing.Size(27, 14);
            this.lblQ2_6.TabIndex = 15;
            this.lblQ2_6.Text = "Q7";
            // 
            // txtQ7
            // 
            this.txtQ7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ7.Location = new System.Drawing.Point(169, 114);
            this.txtQ7.MaxLength = 1;
            this.txtQ7.Name = "txtQ7";
            this.txtQ7.Size = new System.Drawing.Size(41, 22);
            this.txtQ7.TabIndex = 8;
            this.txtQ7.TextChanged += new System.EventHandler(this.txtQ7_TextChanged);
            this.txtQ7.Enter += new System.EventHandler(this.txtQ7_Enter);
            this.txtQ7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ7_KeyPress);
            // 
            // lblQ2_5
            // 
            this.lblQ2_5.AutoSize = true;
            this.lblQ2_5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_5.ForeColor = System.Drawing.Color.White;
            this.lblQ2_5.Location = new System.Drawing.Point(136, 78);
            this.lblQ2_5.Name = "lblQ2_5";
            this.lblQ2_5.Size = new System.Drawing.Size(27, 14);
            this.lblQ2_5.TabIndex = 13;
            this.lblQ2_5.Text = "Q6";
            // 
            // txtQ6
            // 
            this.txtQ6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ6.Location = new System.Drawing.Point(170, 78);
            this.txtQ6.MaxLength = 1;
            this.txtQ6.Name = "txtQ6";
            this.txtQ6.Size = new System.Drawing.Size(41, 22);
            this.txtQ6.TabIndex = 7;
            this.txtQ6.TextChanged += new System.EventHandler(this.txtQ6_TextChanged);
            this.txtQ6.Enter += new System.EventHandler(this.txtQ6_Enter);
            this.txtQ6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ6_KeyPress);
            // 
            // lblQ2_4
            // 
            this.lblQ2_4.AutoSize = true;
            this.lblQ2_4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_4.ForeColor = System.Drawing.Color.White;
            this.lblQ2_4.Location = new System.Drawing.Point(136, 46);
            this.lblQ2_4.Name = "lblQ2_4";
            this.lblQ2_4.Size = new System.Drawing.Size(27, 14);
            this.lblQ2_4.TabIndex = 11;
            this.lblQ2_4.Text = "Q5";
            // 
            // txtQ5
            // 
            this.txtQ5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ5.Location = new System.Drawing.Point(169, 43);
            this.txtQ5.MaxLength = 1;
            this.txtQ5.Name = "txtQ5";
            this.txtQ5.Size = new System.Drawing.Size(41, 22);
            this.txtQ5.TabIndex = 6;
            this.txtQ5.TextChanged += new System.EventHandler(this.txtQ5_TextChanged);
            this.txtQ5.Enter += new System.EventHandler(this.txtQ5_Enter);
            this.txtQ5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ5_KeyPress);
            // 
            // lblQ2_3
            // 
            this.lblQ2_3.AutoSize = true;
            this.lblQ2_3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_3.ForeColor = System.Drawing.Color.White;
            this.lblQ2_3.Location = new System.Drawing.Point(11, 193);
            this.lblQ2_3.Name = "lblQ2_3";
            this.lblQ2_3.Size = new System.Drawing.Size(27, 14);
            this.lblQ2_3.TabIndex = 9;
            this.lblQ2_3.Text = "Q4";
            // 
            // txtQ4
            // 
            this.txtQ4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ4.Location = new System.Drawing.Point(42, 186);
            this.txtQ4.MaxLength = 1;
            this.txtQ4.Name = "txtQ4";
            this.txtQ4.Size = new System.Drawing.Size(41, 22);
            this.txtQ4.TabIndex = 5;
            this.txtQ4.TextChanged += new System.EventHandler(this.txtQ4_TextChanged);
            this.txtQ4.Enter += new System.EventHandler(this.txtQ4_Enter);
            this.txtQ4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ4_KeyPress);
            // 
            // lblQ2_2
            // 
            this.lblQ2_2.AutoSize = true;
            this.lblQ2_2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_2.ForeColor = System.Drawing.Color.White;
            this.lblQ2_2.Location = new System.Drawing.Point(8, 161);
            this.lblQ2_2.Name = "lblQ2_2";
            this.lblQ2_2.Size = new System.Drawing.Size(27, 14);
            this.lblQ2_2.TabIndex = 7;
            this.lblQ2_2.Text = "Q3";
            // 
            // txtQ3
            // 
            this.txtQ3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ3.Location = new System.Drawing.Point(44, 152);
            this.txtQ3.MaxLength = 1;
            this.txtQ3.Name = "txtQ3";
            this.txtQ3.Size = new System.Drawing.Size(41, 22);
            this.txtQ3.TabIndex = 4;
            this.txtQ3.TextChanged += new System.EventHandler(this.txtQ3_TextChanged);
            this.txtQ3.Enter += new System.EventHandler(this.txtQ3_Enter);
            this.txtQ3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_KeyPress);
            // 
            // lblQ2
            // 
            this.lblQ2.AutoSize = true;
            this.lblQ2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2.ForeColor = System.Drawing.Color.White;
            this.lblQ2.Location = new System.Drawing.Point(8, 123);
            this.lblQ2.Name = "lblQ2";
            this.lblQ2.Size = new System.Drawing.Size(27, 14);
            this.lblQ2.TabIndex = 5;
            this.lblQ2.Text = "Q2";
            // 
            // txtQ2
            // 
            this.txtQ2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ2.Location = new System.Drawing.Point(44, 119);
            this.txtQ2.MaxLength = 5;
            this.txtQ2.Name = "txtQ2";
            this.txtQ2.Size = new System.Drawing.Size(86, 22);
            this.txtQ2.TabIndex = 3;
            this.txtQ2.TextChanged += new System.EventHandler(this.txtQ2_TextChanged);
            this.txtQ2.Enter += new System.EventHandler(this.txtQ2_Enter);
            this.txtQ2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_KeyPress);
            // 
            // lblQ1
            // 
            this.lblQ1.AutoSize = true;
            this.lblQ1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ1.ForeColor = System.Drawing.Color.White;
            this.lblQ1.Location = new System.Drawing.Point(11, 92);
            this.lblQ1.Name = "lblQ1";
            this.lblQ1.Size = new System.Drawing.Size(27, 14);
            this.lblQ1.TabIndex = 3;
            this.lblQ1.Text = "Q1";
            // 
            // txtQ1
            // 
            this.txtQ1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ1.Location = new System.Drawing.Point(44, 89);
            this.txtQ1.MaxLength = 10;
            this.txtQ1.Name = "txtQ1";
            this.txtQ1.Size = new System.Drawing.Size(86, 22);
            this.txtQ1.TabIndex = 2;
            this.txtQ1.TextChanged += new System.EventHandler(this.txtQ1_TextChanged);
            this.txtQ1.Enter += new System.EventHandler(this.txtQ1_Enter);
            this.txtQ1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_KeyPress);
            // 
            // stsRemRecs
            // 
            this.stsRemRecs.AutoSize = false;
            this.stsRemRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsRemRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsRemRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsRemRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsRemRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsRemRecs.ForeColor = System.Drawing.Color.Black;
            this.stsRemRecs.Name = "stsRemRecs";
            this.stsRemRecs.Size = new System.Drawing.Size(200, 24);
            this.stsRemRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsRemRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsDate
            // 
            this.stsDate.AutoSize = false;
            this.stsDate.BackColor = System.Drawing.Color.Transparent;
            this.stsDate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsDate.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsDate.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsDate.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsDate.ForeColor = System.Drawing.Color.Black;
            this.stsDate.Name = "stsDate";
            this.stsDate.Size = new System.Drawing.Size(200, 24);
            this.stsDate.Text = "Date : ";
            this.stsDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsDate.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsFinRecs
            // 
            this.stsFinRecs.AutoSize = false;
            this.stsFinRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsFinRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsFinRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsFinRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsFinRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsFinRecs.ForeColor = System.Drawing.Color.Black;
            this.stsFinRecs.Name = "stsFinRecs";
            this.stsFinRecs.Size = new System.Drawing.Size(200, 24);
            this.stsFinRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsFinRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsTotRecs
            // 
            this.stsTotRecs.AutoSize = false;
            this.stsTotRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsTotRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsTotRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsTotRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsTotRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsTotRecs.ForeColor = System.Drawing.Color.Black;
            this.stsTotRecs.Name = "stsTotRecs";
            this.stsTotRecs.Size = new System.Drawing.Size(200, 24);
            this.stsTotRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsTotRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // StatusStrip1
            // 
            this.StatusStrip1.AutoSize = false;
            this.StatusStrip1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StatusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stsUser,
            this.stsTotRecs,
            this.stsFinRecs,
            this.stsRemRecs,
            this.stsDate});
            this.StatusStrip1.Location = new System.Drawing.Point(3, 239);
            this.StatusStrip1.Name = "StatusStrip1";
            this.StatusStrip1.Size = new System.Drawing.Size(1033, 29);
            this.StatusStrip1.TabIndex = 46;
            this.StatusStrip1.Text = "StatusStrip1";
            // 
            // stsUser
            // 
            this.stsUser.AutoSize = false;
            this.stsUser.BackColor = System.Drawing.Color.Transparent;
            this.stsUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsUser.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsUser.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsUser.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsUser.ForeColor = System.Drawing.Color.Black;
            this.stsUser.Name = "stsUser";
            this.stsUser.Size = new System.Drawing.Size(210, 24);
            this.stsUser.Text = "User : Admin";
            this.stsUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsUser.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // grpMain
            // 
            this.grpMain.BackColor = System.Drawing.Color.Transparent;
            this.grpMain.Controls.Add(this.StatusStrip1);
            this.grpMain.Controls.Add(this.grpTxtBoxes1);
            this.grpMain.Location = new System.Drawing.Point(3, 476);
            this.grpMain.Name = "grpMain";
            this.grpMain.Size = new System.Drawing.Size(1039, 271);
            this.grpMain.TabIndex = 44;
            this.grpMain.TabStop = false;
            // 
            // IGImageViewer
            // 
            this.IGImageViewer.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.IGImageViewer.BackColor = System.Drawing.Color.Azure;
            this.IGImageViewer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.IGImageViewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IGImageViewer.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IGImageViewer.ImageData = null;
            this.IGImageViewer.ImageName = null;
            this.IGImageViewer.ImageScropping = false;
            this.IGImageViewer.ImageSize = new System.Drawing.Size(0, 0);
            this.IGImageViewer.Location = new System.Drawing.Point(3, 3);
            this.IGImageViewer.Name = "IGImageViewer";
            this.IGImageViewer.PictureBoxSize = new System.Drawing.Size(0, 0);
            this.IGImageViewer.Size = new System.Drawing.Size(1039, 477);
            this.IGImageViewer.StatusBarVisible = true;
            this.IGImageViewer.TabIndex = 46;
            // 
            // lblinstruction
            // 
            this.lblinstruction.AutoSize = true;
            this.lblinstruction.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinstruction.ForeColor = System.Drawing.Color.White;
            this.lblinstruction.Location = new System.Drawing.Point(513, 10);
            this.lblinstruction.Name = "lblinstruction";
            this.lblinstruction.Size = new System.Drawing.Size(78, 18);
            this.lblinstruction.TabIndex = 76;
            this.lblinstruction.Text = "Instruction:";
            // 
            // txtinstruction
            // 
            this.txtinstruction.AutoSize = true;
            this.txtinstruction.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinstruction.ForeColor = System.Drawing.Color.Red;
            this.txtinstruction.Location = new System.Drawing.Point(597, 10);
            this.txtinstruction.Name = "txtinstruction";
            this.txtinstruction.Size = new System.Drawing.Size(74, 18);
            this.txtinstruction.TabIndex = 77;
            this.txtinstruction.Text = "Instruction";
            // 
            // Healthtel_pediatric
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1044, 742);
            this.Controls.Add(this.grpMain);
            this.Controls.Add(this.IGImageViewer);
            this.KeyPreview = true;
            this.Name = "Healthtel_pediatric";
            this.Text = "Healthtel_pediatric";
            this.Load += new System.EventHandler(this.Healthtel_pediatric_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Healthtel_pediatric_KeyDown);
            this.grpTxtBoxes1.ResumeLayout(false);
            this.grpTxtBoxes1.PerformLayout();
            this.grpKeyData.ResumeLayout(false);
            this.grpKeyData.PerformLayout();
            this.StatusStrip1.ResumeLayout(false);
            this.StatusStrip1.PerformLayout();
            this.grpMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtQ25;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtQ24;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtQ23;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtQ21;
        private System.Windows.Forms.Label lblKey2Data;
        private System.Windows.Forms.TextBox txtQ22;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtQ20;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtQ19;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtQ18;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblBarcode;
        private System.Windows.Forms.TextBox txtbarcode;
        private System.Windows.Forms.Label lblQ3;
        private System.Windows.Forms.TextBox txtQ10;
        private System.Windows.Forms.Label lblQ10;
        private System.Windows.Forms.TextBox txtQ17;
        private System.Windows.Forms.GroupBox grpTxtBoxes1;
        private System.Windows.Forms.Label lblQ9;
        private System.Windows.Forms.TextBox txtQ16;
        private System.Windows.Forms.Label lblQ8;
        private System.Windows.Forms.TextBox txtQ15;
        private System.Windows.Forms.Label lblQ7;
        private System.Windows.Forms.TextBox txtQ14;
        private System.Windows.Forms.Label lblQ6;
        private System.Windows.Forms.TextBox txtQ13;
        private System.Windows.Forms.Label lblQ5;
        private System.Windows.Forms.TextBox txtQ12;
        private System.Windows.Forms.Label lblQ4;
        private System.Windows.Forms.TextBox txtQ11;
        private System.Windows.Forms.Label lblQ2_8;
        private System.Windows.Forms.TextBox txtQ9;
        private System.Windows.Forms.Label lblQ2_2;
        private System.Windows.Forms.TextBox txtQ3;
        private System.Windows.Forms.Label lblQ2;
        private System.Windows.Forms.TextBox txtQ2;
        private System.Windows.Forms.Label lblQ1;
        private System.Windows.Forms.TextBox txtQ1;
        private System.Windows.Forms.Label lblKey2User;
        private System.Windows.Forms.TextBox txtKey2Data;
        private System.Windows.Forms.TextBox txtKey2User;
        internal System.Windows.Forms.ToolStripStatusLabel stsRemRecs;
        internal System.Windows.Forms.ToolStripStatusLabel stsDate;
        internal System.Windows.Forms.ToolStripStatusLabel stsFinRecs;
        internal System.Windows.Forms.ToolStripStatusLabel stsTotRecs;
        private System.Windows.Forms.Label lblKey1Data;
        private System.Windows.Forms.GroupBox grpKeyData;
        private System.Windows.Forms.TextBox txtKey1Data;
        private System.Windows.Forms.Label lblKey1User;
        private System.Windows.Forms.TextBox txtKey1User;
        internal System.Windows.Forms.StatusStrip StatusStrip1;
        internal System.Windows.Forms.ToolStripStatusLabel stsUser;
        private System.Windows.Forms.GroupBox grpMain;
        private InfognanaImageViewer.IGImageViewer IGImageViewer;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtQ34;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtQ33;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtQ32;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtQ31;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtQ28;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtQ27;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtQ26;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtQ30;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtQ29;
        private System.Windows.Forms.Label lblQ2_7;
        private System.Windows.Forms.TextBox txtQ8;
        private System.Windows.Forms.Label lblQ2_6;
        private System.Windows.Forms.TextBox txtQ7;
        private System.Windows.Forms.Label lblQ2_5;
        private System.Windows.Forms.TextBox txtQ6;
        private System.Windows.Forms.Label lblQ2_4;
        private System.Windows.Forms.TextBox txtQ5;
        private System.Windows.Forms.Label lblQ2_3;
        private System.Windows.Forms.TextBox txtQ4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label txtDescription;
        private System.Windows.Forms.Label txtinstruction;
        private System.Windows.Forms.Label lblinstruction;
    }
}