﻿namespace Healthtel_MRT
{
    partial class HRAV1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblKey2Data = new System.Windows.Forms.Label();
            this.txtKey2Data = new System.Windows.Forms.TextBox();
            this.lblKey2User = new System.Windows.Forms.Label();
            this.txtKey2User = new System.Windows.Forms.TextBox();
            this.grpKeyData = new System.Windows.Forms.GroupBox();
            this.lblKey1Data = new System.Windows.Forms.Label();
            this.txtKey1Data = new System.Windows.Forms.TextBox();
            this.lblKey1User = new System.Windows.Forms.Label();
            this.txtKey1User = new System.Windows.Forms.TextBox();
            this.grpMain = new System.Windows.Forms.GroupBox();
            this.StatusStrip1 = new System.Windows.Forms.StatusStrip();
            this.stsUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsTotRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsFinRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsRemRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.grpTxtBoxes1 = new System.Windows.Forms.GroupBox();
            this.txtDescription = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtQ8_1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtQ7_1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtQ7_2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtQ6_1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtQ5_TTL = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtQ5_1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtQ2_TTL = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtQ2_1 = new System.Windows.Forms.TextBox();
            this.lblLanguage = new System.Windows.Forms.Label();
            this.txtLanguage = new System.Windows.Forms.TextBox();
            this.lblRespondentID = new System.Windows.Forms.Label();
            this.txtRespndentID = new System.Windows.Forms.TextBox();
            this.lblQ3 = new System.Windows.Forms.Label();
            this.txtQ3_1 = new System.Windows.Forms.TextBox();
            this.lblQ10 = new System.Windows.Forms.Label();
            this.txtQ4_3 = new System.Windows.Forms.TextBox();
            this.lblQ9 = new System.Windows.Forms.Label();
            this.txtQ4_2 = new System.Windows.Forms.TextBox();
            this.lblQ8 = new System.Windows.Forms.Label();
            this.txtQ4_1 = new System.Windows.Forms.TextBox();
            this.lblQ7 = new System.Windows.Forms.Label();
            this.txtQ3_5 = new System.Windows.Forms.TextBox();
            this.lblQ6 = new System.Windows.Forms.Label();
            this.txtQ3_4 = new System.Windows.Forms.TextBox();
            this.lblQ5 = new System.Windows.Forms.Label();
            this.txtQ3_3 = new System.Windows.Forms.TextBox();
            this.lblQ4 = new System.Windows.Forms.Label();
            this.txtQ3_2 = new System.Windows.Forms.TextBox();
            this.lblQ2_8 = new System.Windows.Forms.Label();
            this.txtQ1_8 = new System.Windows.Forms.TextBox();
            this.lblQ2_7 = new System.Windows.Forms.Label();
            this.txtQ1_7 = new System.Windows.Forms.TextBox();
            this.lblQ2_6 = new System.Windows.Forms.Label();
            this.txtQ1_6 = new System.Windows.Forms.TextBox();
            this.lblQ2_5 = new System.Windows.Forms.Label();
            this.txtQ1_5 = new System.Windows.Forms.TextBox();
            this.lblQ2_4 = new System.Windows.Forms.Label();
            this.txtQ1_4 = new System.Windows.Forms.TextBox();
            this.grpButtons = new System.Windows.Forms.GroupBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblQ2_3 = new System.Windows.Forms.Label();
            this.txtQ1_3 = new System.Windows.Forms.TextBox();
            this.lblQ2_2 = new System.Windows.Forms.Label();
            this.txtQ1_2 = new System.Windows.Forms.TextBox();
            this.lblQ2_1 = new System.Windows.Forms.Label();
            this.txtQ1_1 = new System.Windows.Forms.TextBox();
            this.lblQ1 = new System.Windows.Forms.Label();
            this.txtQ1_9 = new System.Windows.Forms.TextBox();
            this.IGImageViewer = new InfognanaImageViewer.IGImageViewer();
            this.lblMailType = new System.Windows.Forms.Label();
            this.txtmailtype = new System.Windows.Forms.TextBox();
            this.grpKeyData.SuspendLayout();
            this.grpMain.SuspendLayout();
            this.StatusStrip1.SuspendLayout();
            this.grpTxtBoxes1.SuspendLayout();
            this.grpButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblKey2Data
            // 
            this.lblKey2Data.AutoSize = true;
            this.lblKey2Data.Enabled = false;
            this.lblKey2Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey2Data.ForeColor = System.Drawing.Color.White;
            this.lblKey2Data.Location = new System.Drawing.Point(720, 12);
            this.lblKey2Data.Name = "lblKey2Data";
            this.lblKey2Data.Size = new System.Drawing.Size(76, 14);
            this.lblKey2Data.TabIndex = 49;
            this.lblKey2Data.Text = "Key2 Data";
            // 
            // txtKey2Data
            // 
            this.txtKey2Data.Enabled = false;
            this.txtKey2Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey2Data.Location = new System.Drawing.Point(805, 10);
            this.txtKey2Data.Name = "txtKey2Data";
            this.txtKey2Data.Size = new System.Drawing.Size(206, 22);
            this.txtKey2Data.TabIndex = 50;
            // 
            // lblKey2User
            // 
            this.lblKey2User.AutoSize = true;
            this.lblKey2User.Enabled = false;
            this.lblKey2User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey2User.ForeColor = System.Drawing.Color.White;
            this.lblKey2User.Location = new System.Drawing.Point(518, 12);
            this.lblKey2User.Name = "lblKey2User";
            this.lblKey2User.Size = new System.Drawing.Size(76, 14);
            this.lblKey2User.TabIndex = 47;
            this.lblKey2User.Text = "Key2 User";
            // 
            // txtKey2User
            // 
            this.txtKey2User.Enabled = false;
            this.txtKey2User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey2User.Location = new System.Drawing.Point(603, 10);
            this.txtKey2User.Name = "txtKey2User";
            this.txtKey2User.Size = new System.Drawing.Size(111, 22);
            this.txtKey2User.TabIndex = 48;
            // 
            // grpKeyData
            // 
            this.grpKeyData.BackColor = System.Drawing.Color.Navy;
            this.grpKeyData.Controls.Add(this.lblKey2Data);
            this.grpKeyData.Controls.Add(this.txtKey2Data);
            this.grpKeyData.Controls.Add(this.lblKey2User);
            this.grpKeyData.Controls.Add(this.txtKey2User);
            this.grpKeyData.Controls.Add(this.lblKey1Data);
            this.grpKeyData.Controls.Add(this.txtKey1Data);
            this.grpKeyData.Controls.Add(this.lblKey1User);
            this.grpKeyData.Controls.Add(this.txtKey1User);
            this.grpKeyData.Location = new System.Drawing.Point(1, 661);
            this.grpKeyData.Name = "grpKeyData";
            this.grpKeyData.Size = new System.Drawing.Size(1030, 41);
            this.grpKeyData.TabIndex = 42;
            this.grpKeyData.TabStop = false;
            this.grpKeyData.Visible = false;
            // 
            // lblKey1Data
            // 
            this.lblKey1Data.AutoSize = true;
            this.lblKey1Data.Enabled = false;
            this.lblKey1Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey1Data.ForeColor = System.Drawing.Color.White;
            this.lblKey1Data.Location = new System.Drawing.Point(207, 12);
            this.lblKey1Data.Name = "lblKey1Data";
            this.lblKey1Data.Size = new System.Drawing.Size(76, 14);
            this.lblKey1Data.TabIndex = 45;
            this.lblKey1Data.Text = "Key1 Data";
            // 
            // txtKey1Data
            // 
            this.txtKey1Data.Enabled = false;
            this.txtKey1Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey1Data.Location = new System.Drawing.Point(292, 10);
            this.txtKey1Data.Name = "txtKey1Data";
            this.txtKey1Data.Size = new System.Drawing.Size(206, 22);
            this.txtKey1Data.TabIndex = 46;
            // 
            // lblKey1User
            // 
            this.lblKey1User.AutoSize = true;
            this.lblKey1User.Enabled = false;
            this.lblKey1User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey1User.ForeColor = System.Drawing.Color.White;
            this.lblKey1User.Location = new System.Drawing.Point(10, 13);
            this.lblKey1User.Name = "lblKey1User";
            this.lblKey1User.Size = new System.Drawing.Size(76, 14);
            this.lblKey1User.TabIndex = 43;
            this.lblKey1User.Text = "Key1 User";
            // 
            // txtKey1User
            // 
            this.txtKey1User.Enabled = false;
            this.txtKey1User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey1User.Location = new System.Drawing.Point(90, 10);
            this.txtKey1User.Name = "txtKey1User";
            this.txtKey1User.Size = new System.Drawing.Size(111, 22);
            this.txtKey1User.TabIndex = 44;
            // 
            // grpMain
            // 
            this.grpMain.BackColor = System.Drawing.Color.Transparent;
            this.grpMain.Controls.Add(this.StatusStrip1);
            this.grpMain.Controls.Add(this.grpTxtBoxes1);
            this.grpMain.Location = new System.Drawing.Point(1, 460);
            this.grpMain.Name = "grpMain";
            this.grpMain.Size = new System.Drawing.Size(1039, 291);
            this.grpMain.TabIndex = 2;
            this.grpMain.TabStop = false;
            // 
            // StatusStrip1
            // 
            this.StatusStrip1.AutoSize = false;
            this.StatusStrip1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StatusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stsUser,
            this.stsTotRecs,
            this.stsFinRecs,
            this.stsRemRecs,
            this.stsDate});
            this.StatusStrip1.Location = new System.Drawing.Point(3, 259);
            this.StatusStrip1.Name = "StatusStrip1";
            this.StatusStrip1.Size = new System.Drawing.Size(1033, 29);
            this.StatusStrip1.TabIndex = 46;
            this.StatusStrip1.Text = "StatusStrip1";
            // 
            // stsUser
            // 
            this.stsUser.AutoSize = false;
            this.stsUser.BackColor = System.Drawing.Color.Transparent;
            this.stsUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsUser.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsUser.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsUser.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsUser.ForeColor = System.Drawing.Color.Black;
            this.stsUser.Name = "stsUser";
            this.stsUser.Size = new System.Drawing.Size(210, 24);
            this.stsUser.Text = "User : Admin";
            this.stsUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsUser.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsTotRecs
            // 
            this.stsTotRecs.AutoSize = false;
            this.stsTotRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsTotRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsTotRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsTotRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsTotRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsTotRecs.ForeColor = System.Drawing.Color.Black;
            this.stsTotRecs.Name = "stsTotRecs";
            this.stsTotRecs.Size = new System.Drawing.Size(200, 24);
            this.stsTotRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsTotRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsFinRecs
            // 
            this.stsFinRecs.AutoSize = false;
            this.stsFinRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsFinRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsFinRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsFinRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsFinRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsFinRecs.ForeColor = System.Drawing.Color.Black;
            this.stsFinRecs.Name = "stsFinRecs";
            this.stsFinRecs.Size = new System.Drawing.Size(200, 24);
            this.stsFinRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsFinRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsRemRecs
            // 
            this.stsRemRecs.AutoSize = false;
            this.stsRemRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsRemRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsRemRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsRemRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsRemRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsRemRecs.ForeColor = System.Drawing.Color.Black;
            this.stsRemRecs.Name = "stsRemRecs";
            this.stsRemRecs.Size = new System.Drawing.Size(200, 24);
            this.stsRemRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsRemRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsDate
            // 
            this.stsDate.AutoSize = false;
            this.stsDate.BackColor = System.Drawing.Color.Transparent;
            this.stsDate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsDate.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsDate.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsDate.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsDate.ForeColor = System.Drawing.Color.Black;
            this.stsDate.Name = "stsDate";
            this.stsDate.Size = new System.Drawing.Size(200, 24);
            this.stsDate.Text = "Date : ";
            this.stsDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsDate.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // grpTxtBoxes1
            // 
            this.grpTxtBoxes1.BackColor = System.Drawing.Color.Navy;
            this.grpTxtBoxes1.Controls.Add(this.txtmailtype);
            this.grpTxtBoxes1.Controls.Add(this.lblMailType);
            this.grpTxtBoxes1.Controls.Add(this.txtDescription);
            this.grpTxtBoxes1.Controls.Add(this.label8);
            this.grpTxtBoxes1.Controls.Add(this.txtQ8_1);
            this.grpTxtBoxes1.Controls.Add(this.label7);
            this.grpTxtBoxes1.Controls.Add(this.txtQ7_1);
            this.grpTxtBoxes1.Controls.Add(this.label6);
            this.grpTxtBoxes1.Controls.Add(this.txtQ7_2);
            this.grpTxtBoxes1.Controls.Add(this.label5);
            this.grpTxtBoxes1.Controls.Add(this.txtQ6_1);
            this.grpTxtBoxes1.Controls.Add(this.label4);
            this.grpTxtBoxes1.Controls.Add(this.txtQ5_TTL);
            this.grpTxtBoxes1.Controls.Add(this.label3);
            this.grpTxtBoxes1.Controls.Add(this.txtQ5_1);
            this.grpTxtBoxes1.Controls.Add(this.label2);
            this.grpTxtBoxes1.Controls.Add(this.txtQ2_TTL);
            this.grpTxtBoxes1.Controls.Add(this.label1);
            this.grpTxtBoxes1.Controls.Add(this.txtQ2_1);
            this.grpTxtBoxes1.Controls.Add(this.lblLanguage);
            this.grpTxtBoxes1.Controls.Add(this.txtLanguage);
            this.grpTxtBoxes1.Controls.Add(this.lblRespondentID);
            this.grpTxtBoxes1.Controls.Add(this.txtRespndentID);
            this.grpTxtBoxes1.Controls.Add(this.lblQ3);
            this.grpTxtBoxes1.Controls.Add(this.txtQ3_1);
            this.grpTxtBoxes1.Controls.Add(this.lblQ10);
            this.grpTxtBoxes1.Controls.Add(this.txtQ4_3);
            this.grpTxtBoxes1.Controls.Add(this.lblQ9);
            this.grpTxtBoxes1.Controls.Add(this.txtQ4_2);
            this.grpTxtBoxes1.Controls.Add(this.lblQ8);
            this.grpTxtBoxes1.Controls.Add(this.txtQ4_1);
            this.grpTxtBoxes1.Controls.Add(this.lblQ7);
            this.grpTxtBoxes1.Controls.Add(this.txtQ3_5);
            this.grpTxtBoxes1.Controls.Add(this.lblQ6);
            this.grpTxtBoxes1.Controls.Add(this.txtQ3_4);
            this.grpTxtBoxes1.Controls.Add(this.lblQ5);
            this.grpTxtBoxes1.Controls.Add(this.txtQ3_3);
            this.grpTxtBoxes1.Controls.Add(this.lblQ4);
            this.grpTxtBoxes1.Controls.Add(this.txtQ3_2);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_8);
            this.grpTxtBoxes1.Controls.Add(this.txtQ1_8);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_7);
            this.grpTxtBoxes1.Controls.Add(this.txtQ1_7);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_6);
            this.grpTxtBoxes1.Controls.Add(this.txtQ1_6);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_5);
            this.grpTxtBoxes1.Controls.Add(this.txtQ1_5);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_4);
            this.grpTxtBoxes1.Controls.Add(this.txtQ1_4);
            this.grpTxtBoxes1.Controls.Add(this.grpButtons);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_3);
            this.grpTxtBoxes1.Controls.Add(this.txtQ1_3);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_2);
            this.grpTxtBoxes1.Controls.Add(this.txtQ1_2);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_1);
            this.grpTxtBoxes1.Controls.Add(this.txtQ1_1);
            this.grpTxtBoxes1.Controls.Add(this.lblQ1);
            this.grpTxtBoxes1.Controls.Add(this.txtQ1_9);
            this.grpTxtBoxes1.Location = new System.Drawing.Point(0, 19);
            this.grpTxtBoxes1.Name = "grpTxtBoxes1";
            this.grpTxtBoxes1.Size = new System.Drawing.Size(1033, 223);
            this.grpTxtBoxes1.TabIndex = 1;
            this.grpTxtBoxes1.TabStop = false;
            // 
            // txtDescription
            // 
            this.txtDescription.AutoSize = true;
            this.txtDescription.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescription.ForeColor = System.Drawing.Color.Red;
            this.txtDescription.Location = new System.Drawing.Point(181, 29);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(82, 14);
            this.txtDescription.TabIndex = 57;
            this.txtDescription.Text = "Description";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(818, 89);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 14);
            this.label8.TabIndex = 51;
            this.label8.Text = "Q17";
            // 
            // txtQ8_1
            // 
            this.txtQ8_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ8_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ8_1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ8_1.Location = new System.Drawing.Point(831, 106);
            this.txtQ8_1.MaxLength = 1;
            this.txtQ8_1.Name = "txtQ8_1";
            this.txtQ8_1.Size = new System.Drawing.Size(41, 22);
            this.txtQ8_1.TabIndex = 52;
            this.txtQ8_1.TextChanged += new System.EventHandler(this.txtQ8_1_TextChanged);
            this.txtQ8_1.Enter += new System.EventHandler(this.txtQ8_1_Enter);
            this.txtQ8_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ8_1_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(687, 164);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 14);
            this.label7.TabIndex = 49;
            this.label7.Text = "Q16";
            // 
            // txtQ7_1
            // 
            this.txtQ7_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ7_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ7_1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ7_1.Location = new System.Drawing.Point(756, 156);
            this.txtQ7_1.MaxLength = 1;
            this.txtQ7_1.Name = "txtQ7_1";
            this.txtQ7_1.Size = new System.Drawing.Size(41, 22);
            this.txtQ7_1.TabIndex = 50;
            this.txtQ7_1.TextChanged += new System.EventHandler(this.txtQ7_1_TextChanged);
            this.txtQ7_1.Enter += new System.EventHandler(this.txtQ7_1_Enter);
            this.txtQ7_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ7_1_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(687, 139);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 14);
            this.label6.TabIndex = 47;
            this.label6.Text = "Q15";
            // 
            // txtQ7_2
            // 
            this.txtQ7_2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ7_2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ7_2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ7_2.Location = new System.Drawing.Point(756, 131);
            this.txtQ7_2.MaxLength = 1;
            this.txtQ7_2.Name = "txtQ7_2";
            this.txtQ7_2.Size = new System.Drawing.Size(41, 22);
            this.txtQ7_2.TabIndex = 48;
            this.txtQ7_2.TextChanged += new System.EventHandler(this.txtQ7_2_TextChanged);
            this.txtQ7_2.Enter += new System.EventHandler(this.txtQ7_2_Enter);
            this.txtQ7_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ7_2_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(687, 114);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 14);
            this.label5.TabIndex = 45;
            this.label5.Text = "Q14";
            // 
            // txtQ6_1
            // 
            this.txtQ6_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ6_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ6_1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ6_1.Location = new System.Drawing.Point(756, 106);
            this.txtQ6_1.MaxLength = 1;
            this.txtQ6_1.Name = "txtQ6_1";
            this.txtQ6_1.Size = new System.Drawing.Size(41, 22);
            this.txtQ6_1.TabIndex = 46;
            this.txtQ6_1.TextChanged += new System.EventHandler(this.txtQ6_TextChanged);
            this.txtQ6_1.Enter += new System.EventHandler(this.txtQ6_Enter);
            this.txtQ6_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ6_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(687, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 14);
            this.label4.TabIndex = 43;
            this.label4.Text = "Q13";
            // 
            // txtQ5_TTL
            // 
            this.txtQ5_TTL.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ5_TTL.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ5_TTL.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ5_TTL.Location = new System.Drawing.Point(756, 81);
            this.txtQ5_TTL.MaxLength = 1;
            this.txtQ5_TTL.Name = "txtQ5_TTL";
            this.txtQ5_TTL.Size = new System.Drawing.Size(41, 22);
            this.txtQ5_TTL.TabIndex = 44;
            this.txtQ5_TTL.TextChanged += new System.EventHandler(this.txtQ5_TTL_TextChanged);
            this.txtQ5_TTL.Enter += new System.EventHandler(this.txtQ5_TTL_Enter);
            this.txtQ5_TTL.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ5_TTL_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(556, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 14);
            this.label3.TabIndex = 41;
            this.label3.Text = "Q12";
            // 
            // txtQ5_1
            // 
            this.txtQ5_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ5_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ5_1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ5_1.Location = new System.Drawing.Point(625, 156);
            this.txtQ5_1.MaxLength = 1;
            this.txtQ5_1.Name = "txtQ5_1";
            this.txtQ5_1.Size = new System.Drawing.Size(41, 22);
            this.txtQ5_1.TabIndex = 42;
            this.txtQ5_1.TextChanged += new System.EventHandler(this.txtQ5_1_TextChanged);
            this.txtQ5_1.Enter += new System.EventHandler(this.txtQ5_1_Enter);
            this.txtQ5_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ5_1_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(556, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 14);
            this.label2.TabIndex = 39;
            this.label2.Text = "Q11";
            // 
            // txtQ2_TTL
            // 
            this.txtQ2_TTL.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ2_TTL.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ2_TTL.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ2_TTL.Location = new System.Drawing.Point(625, 131);
            this.txtQ2_TTL.MaxLength = 1;
            this.txtQ2_TTL.Name = "txtQ2_TTL";
            this.txtQ2_TTL.Size = new System.Drawing.Size(41, 22);
            this.txtQ2_TTL.TabIndex = 40;
            this.txtQ2_TTL.TextChanged += new System.EventHandler(this.txtQ2_TTL_TextChanged);
            this.txtQ2_TTL.Enter += new System.EventHandler(this.txtQ2_TTL_Enter);
            this.txtQ2_TTL.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_TTL_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(556, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 14);
            this.label1.TabIndex = 37;
            this.label1.Text = "Q10";
            // 
            // txtQ2_1
            // 
            this.txtQ2_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ2_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ2_1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ2_1.Location = new System.Drawing.Point(625, 106);
            this.txtQ2_1.MaxLength = 1;
            this.txtQ2_1.Name = "txtQ2_1";
            this.txtQ2_1.Size = new System.Drawing.Size(41, 22);
            this.txtQ2_1.TabIndex = 38;
            this.txtQ2_1.TextChanged += new System.EventHandler(this.txtQ2_1_TextChanged);
            this.txtQ2_1.Enter += new System.EventHandler(this.txtQ2_1_Enter);
            this.txtQ2_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_1_KeyPress);
            // 
            // lblLanguage
            // 
            this.lblLanguage.AutoSize = true;
            this.lblLanguage.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLanguage.ForeColor = System.Drawing.Color.White;
            this.lblLanguage.Location = new System.Drawing.Point(811, 139);
            this.lblLanguage.Name = "lblLanguage";
            this.lblLanguage.Size = new System.Drawing.Size(71, 14);
            this.lblLanguage.TabIndex = 53;
            this.lblLanguage.Text = "Language";
            // 
            // txtLanguage
            // 
            this.txtLanguage.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtLanguage.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtLanguage.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtLanguage.Location = new System.Drawing.Point(831, 156);
            this.txtLanguage.MaxLength = 1;
            this.txtLanguage.Name = "txtLanguage";
            this.txtLanguage.Size = new System.Drawing.Size(41, 22);
            this.txtLanguage.TabIndex = 54;
            this.txtLanguage.TextChanged += new System.EventHandler(this.txtLanguage_TextChanged);
            this.txtLanguage.Enter += new System.EventHandler(this.txtLanguage_Enter);
            this.txtLanguage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLanguage_KeyPress);
            // 
            // lblRespondentID
            // 
            this.lblRespondentID.AutoSize = true;
            this.lblRespondentID.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRespondentID.ForeColor = System.Drawing.Color.White;
            this.lblRespondentID.Location = new System.Drawing.Point(11, 18);
            this.lblRespondentID.Name = "lblRespondentID";
            this.lblRespondentID.Size = new System.Drawing.Size(104, 14);
            this.lblRespondentID.TabIndex = 1;
            this.lblRespondentID.Text = "Respondent ID";
            this.lblRespondentID.Visible = false;
            // 
            // txtRespndentID
            // 
            this.txtRespndentID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtRespndentID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtRespndentID.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtRespndentID.Location = new System.Drawing.Point(14, 38);
            this.txtRespndentID.MaxLength = 8;
            this.txtRespndentID.Name = "txtRespndentID";
            this.txtRespndentID.Size = new System.Drawing.Size(101, 22);
            this.txtRespndentID.TabIndex = 2;
            this.txtRespndentID.Visible = false;
            this.txtRespndentID.TextChanged += new System.EventHandler(this.txtRespndentID_TextChanged);
            this.txtRespndentID.Enter += new System.EventHandler(this.txtRespndentID_Enter);
            this.txtRespndentID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRespndentID_KeyPress);
            // 
            // lblQ3
            // 
            this.lblQ3.AutoSize = true;
            this.lblQ3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ3.ForeColor = System.Drawing.Color.White;
            this.lblQ3.Location = new System.Drawing.Point(268, 114);
            this.lblQ3.Name = "lblQ3";
            this.lblQ3.Size = new System.Drawing.Size(27, 14);
            this.lblQ3.TabIndex = 21;
            this.lblQ3.Text = "Q2";
            // 
            // txtQ3_1
            // 
            this.txtQ3_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ3_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ3_1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ3_1.Location = new System.Drawing.Point(336, 106);
            this.txtQ3_1.MaxLength = 1;
            this.txtQ3_1.Name = "txtQ3_1";
            this.txtQ3_1.Size = new System.Drawing.Size(41, 22);
            this.txtQ3_1.TabIndex = 22;
            this.txtQ3_1.TextChanged += new System.EventHandler(this.txtQ3_1_TextChanged);
            this.txtQ3_1.Enter += new System.EventHandler(this.txtQ3_1_Enter);
            this.txtQ3_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_1_KeyPress);
            // 
            // lblQ10
            // 
            this.lblQ10.AutoSize = true;
            this.lblQ10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ10.ForeColor = System.Drawing.Color.White;
            this.lblQ10.Location = new System.Drawing.Point(556, 89);
            this.lblQ10.Name = "lblQ10";
            this.lblQ10.Size = new System.Drawing.Size(27, 14);
            this.lblQ10.TabIndex = 35;
            this.lblQ10.Text = "Q9";
            // 
            // txtQ4_3
            // 
            this.txtQ4_3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ4_3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ4_3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ4_3.Location = new System.Drawing.Point(625, 81);
            this.txtQ4_3.MaxLength = 1;
            this.txtQ4_3.Name = "txtQ4_3";
            this.txtQ4_3.Size = new System.Drawing.Size(41, 22);
            this.txtQ4_3.TabIndex = 36;
            this.txtQ4_3.TextChanged += new System.EventHandler(this.txtQ4_3_TextChanged);
            this.txtQ4_3.Enter += new System.EventHandler(this.txtQ4_3_Enter);
            this.txtQ4_3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ4_3_KeyPress);
            // 
            // lblQ9
            // 
            this.lblQ9.AutoSize = true;
            this.lblQ9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ9.ForeColor = System.Drawing.Color.White;
            this.lblQ9.Location = new System.Drawing.Point(403, 164);
            this.lblQ9.Name = "lblQ9";
            this.lblQ9.Size = new System.Drawing.Size(27, 14);
            this.lblQ9.TabIndex = 33;
            this.lblQ9.Text = "Q8";
            // 
            // txtQ4_2
            // 
            this.txtQ4_2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ4_2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ4_2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ4_2.Location = new System.Drawing.Point(479, 156);
            this.txtQ4_2.MaxLength = 1;
            this.txtQ4_2.Name = "txtQ4_2";
            this.txtQ4_2.Size = new System.Drawing.Size(41, 22);
            this.txtQ4_2.TabIndex = 34;
            this.txtQ4_2.TextChanged += new System.EventHandler(this.txtQ4_2_TextChanged);
            this.txtQ4_2.Enter += new System.EventHandler(this.txtQ4_2_Enter);
            this.txtQ4_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ4_2_KeyPress);
            // 
            // lblQ8
            // 
            this.lblQ8.AutoSize = true;
            this.lblQ8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ8.ForeColor = System.Drawing.Color.White;
            this.lblQ8.Location = new System.Drawing.Point(403, 139);
            this.lblQ8.Name = "lblQ8";
            this.lblQ8.Size = new System.Drawing.Size(27, 14);
            this.lblQ8.TabIndex = 31;
            this.lblQ8.Text = "Q7";
            // 
            // txtQ4_1
            // 
            this.txtQ4_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ4_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ4_1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ4_1.Location = new System.Drawing.Point(479, 131);
            this.txtQ4_1.MaxLength = 1;
            this.txtQ4_1.Name = "txtQ4_1";
            this.txtQ4_1.Size = new System.Drawing.Size(41, 22);
            this.txtQ4_1.TabIndex = 32;
            this.txtQ4_1.TextChanged += new System.EventHandler(this.txtQ4_1_TextChanged);
            this.txtQ4_1.Enter += new System.EventHandler(this.txtQ4_1_Enter);
            this.txtQ4_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ4_1_KeyPress);
            // 
            // lblQ7
            // 
            this.lblQ7.AutoSize = true;
            this.lblQ7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ7.ForeColor = System.Drawing.Color.White;
            this.lblQ7.Location = new System.Drawing.Point(403, 114);
            this.lblQ7.Name = "lblQ7";
            this.lblQ7.Size = new System.Drawing.Size(27, 14);
            this.lblQ7.TabIndex = 29;
            this.lblQ7.Text = "Q6";
            // 
            // txtQ3_5
            // 
            this.txtQ3_5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ3_5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ3_5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ3_5.Location = new System.Drawing.Point(479, 106);
            this.txtQ3_5.MaxLength = 1;
            this.txtQ3_5.Name = "txtQ3_5";
            this.txtQ3_5.Size = new System.Drawing.Size(41, 22);
            this.txtQ3_5.TabIndex = 30;
            this.txtQ3_5.TextChanged += new System.EventHandler(this.txtQ3_5_TextChanged);
            this.txtQ3_5.Enter += new System.EventHandler(this.txtQ3_5_Enter);
            this.txtQ3_5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_5_KeyPress);
            // 
            // lblQ6
            // 
            this.lblQ6.AutoSize = true;
            this.lblQ6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ6.ForeColor = System.Drawing.Color.White;
            this.lblQ6.Location = new System.Drawing.Point(403, 89);
            this.lblQ6.Name = "lblQ6";
            this.lblQ6.Size = new System.Drawing.Size(27, 14);
            this.lblQ6.TabIndex = 27;
            this.lblQ6.Text = "Q5";
            // 
            // txtQ3_4
            // 
            this.txtQ3_4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ3_4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ3_4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ3_4.Location = new System.Drawing.Point(479, 81);
            this.txtQ3_4.MaxLength = 1;
            this.txtQ3_4.Name = "txtQ3_4";
            this.txtQ3_4.Size = new System.Drawing.Size(41, 22);
            this.txtQ3_4.TabIndex = 28;
            this.txtQ3_4.TextChanged += new System.EventHandler(this.txtQ3_4_TextChanged);
            this.txtQ3_4.Enter += new System.EventHandler(this.txtQ3_4_Enter);
            this.txtQ3_4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_4_KeyPress);
            // 
            // lblQ5
            // 
            this.lblQ5.AutoSize = true;
            this.lblQ5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ5.ForeColor = System.Drawing.Color.White;
            this.lblQ5.Location = new System.Drawing.Point(268, 164);
            this.lblQ5.Name = "lblQ5";
            this.lblQ5.Size = new System.Drawing.Size(27, 14);
            this.lblQ5.TabIndex = 25;
            this.lblQ5.Text = "Q4";
            // 
            // txtQ3_3
            // 
            this.txtQ3_3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ3_3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ3_3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ3_3.Location = new System.Drawing.Point(336, 156);
            this.txtQ3_3.MaxLength = 1;
            this.txtQ3_3.Name = "txtQ3_3";
            this.txtQ3_3.Size = new System.Drawing.Size(41, 22);
            this.txtQ3_3.TabIndex = 26;
            this.txtQ3_3.TextChanged += new System.EventHandler(this.txtQ3_3_TextChanged);
            this.txtQ3_3.Enter += new System.EventHandler(this.txtQ3_3_Enter);
            this.txtQ3_3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_3_KeyPress);
            // 
            // lblQ4
            // 
            this.lblQ4.AutoSize = true;
            this.lblQ4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ4.ForeColor = System.Drawing.Color.White;
            this.lblQ4.Location = new System.Drawing.Point(268, 139);
            this.lblQ4.Name = "lblQ4";
            this.lblQ4.Size = new System.Drawing.Size(27, 14);
            this.lblQ4.TabIndex = 23;
            this.lblQ4.Text = "Q3";
            // 
            // txtQ3_2
            // 
            this.txtQ3_2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ3_2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ3_2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ3_2.Location = new System.Drawing.Point(336, 131);
            this.txtQ3_2.MaxLength = 1;
            this.txtQ3_2.Name = "txtQ3_2";
            this.txtQ3_2.Size = new System.Drawing.Size(41, 22);
            this.txtQ3_2.TabIndex = 24;
            this.txtQ3_2.TextChanged += new System.EventHandler(this.txtQ3_2_TextChanged);
            this.txtQ3_2.Enter += new System.EventHandler(this.txtQ3_2_Enter);
            this.txtQ3_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_2_KeyPress);
            // 
            // lblQ2_8
            // 
            this.lblQ2_8.AutoSize = true;
            this.lblQ2_8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_8.ForeColor = System.Drawing.Color.White;
            this.lblQ2_8.Location = new System.Drawing.Point(268, 89);
            this.lblQ2_8.Name = "lblQ2_8";
            this.lblQ2_8.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_8.TabIndex = 19;
            this.lblQ2_8.Text = "Q1_9";
            // 
            // txtQ1_8
            // 
            this.txtQ1_8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ1_8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ1_8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ1_8.Location = new System.Drawing.Point(336, 81);
            this.txtQ1_8.MaxLength = 1;
            this.txtQ1_8.Name = "txtQ1_8";
            this.txtQ1_8.Size = new System.Drawing.Size(41, 22);
            this.txtQ1_8.TabIndex = 20;
            this.txtQ1_8.TextChanged += new System.EventHandler(this.txtQ1_8_TextChanged);
            this.txtQ1_8.Enter += new System.EventHandler(this.txtQ1_8_Enter);
            this.txtQ1_8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_8_KeyPress);
            // 
            // lblQ2_7
            // 
            this.lblQ2_7.AutoSize = true;
            this.lblQ2_7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_7.ForeColor = System.Drawing.Color.White;
            this.lblQ2_7.Location = new System.Drawing.Point(144, 164);
            this.lblQ2_7.Name = "lblQ2_7";
            this.lblQ2_7.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_7.TabIndex = 17;
            this.lblQ2_7.Text = "Q1_8";
            // 
            // txtQ1_7
            // 
            this.txtQ1_7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ1_7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ1_7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ1_7.Location = new System.Drawing.Point(211, 156);
            this.txtQ1_7.MaxLength = 1;
            this.txtQ1_7.Name = "txtQ1_7";
            this.txtQ1_7.Size = new System.Drawing.Size(41, 22);
            this.txtQ1_7.TabIndex = 18;
            this.txtQ1_7.TextChanged += new System.EventHandler(this.txtQ1_7_TextChanged);
            this.txtQ1_7.Enter += new System.EventHandler(this.txtQ1_7_Enter);
            this.txtQ1_7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_7_KeyPress);
            // 
            // lblQ2_6
            // 
            this.lblQ2_6.AutoSize = true;
            this.lblQ2_6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_6.ForeColor = System.Drawing.Color.White;
            this.lblQ2_6.Location = new System.Drawing.Point(144, 139);
            this.lblQ2_6.Name = "lblQ2_6";
            this.lblQ2_6.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_6.TabIndex = 15;
            this.lblQ2_6.Text = "Q1_7";
            // 
            // txtQ1_6
            // 
            this.txtQ1_6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ1_6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ1_6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ1_6.Location = new System.Drawing.Point(211, 131);
            this.txtQ1_6.MaxLength = 1;
            this.txtQ1_6.Name = "txtQ1_6";
            this.txtQ1_6.Size = new System.Drawing.Size(41, 22);
            this.txtQ1_6.TabIndex = 16;
            this.txtQ1_6.TextChanged += new System.EventHandler(this.txtQ1_6_TextChanged);
            this.txtQ1_6.Enter += new System.EventHandler(this.txtQ1_6_Enter);
            this.txtQ1_6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_6_KeyPress);
            // 
            // lblQ2_5
            // 
            this.lblQ2_5.AutoSize = true;
            this.lblQ2_5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_5.ForeColor = System.Drawing.Color.White;
            this.lblQ2_5.Location = new System.Drawing.Point(144, 114);
            this.lblQ2_5.Name = "lblQ2_5";
            this.lblQ2_5.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_5.TabIndex = 13;
            this.lblQ2_5.Text = "Q1_6";
            // 
            // txtQ1_5
            // 
            this.txtQ1_5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ1_5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ1_5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ1_5.Location = new System.Drawing.Point(211, 106);
            this.txtQ1_5.MaxLength = 1;
            this.txtQ1_5.Name = "txtQ1_5";
            this.txtQ1_5.Size = new System.Drawing.Size(41, 22);
            this.txtQ1_5.TabIndex = 14;
            this.txtQ1_5.TextChanged += new System.EventHandler(this.txtQ1_5_TextChanged);
            this.txtQ1_5.Enter += new System.EventHandler(this.txtQ1_5_Enter);
            this.txtQ1_5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_5_KeyPress);
            // 
            // lblQ2_4
            // 
            this.lblQ2_4.AutoSize = true;
            this.lblQ2_4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_4.ForeColor = System.Drawing.Color.White;
            this.lblQ2_4.Location = new System.Drawing.Point(144, 89);
            this.lblQ2_4.Name = "lblQ2_4";
            this.lblQ2_4.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_4.TabIndex = 11;
            this.lblQ2_4.Text = "Q1_5";
            // 
            // txtQ1_4
            // 
            this.txtQ1_4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ1_4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ1_4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ1_4.Location = new System.Drawing.Point(211, 81);
            this.txtQ1_4.MaxLength = 1;
            this.txtQ1_4.Name = "txtQ1_4";
            this.txtQ1_4.Size = new System.Drawing.Size(41, 22);
            this.txtQ1_4.TabIndex = 12;
            this.txtQ1_4.TextChanged += new System.EventHandler(this.txtQ1_4_TextChanged);
            this.txtQ1_4.Enter += new System.EventHandler(this.txtQ1_4_Enter);
            this.txtQ1_4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_4_KeyPress);
            // 
            // grpButtons
            // 
            this.grpButtons.Controls.Add(this.btnExit);
            this.grpButtons.Controls.Add(this.btnSave);
            this.grpButtons.Location = new System.Drawing.Point(905, 89);
            this.grpButtons.Name = "grpButtons";
            this.grpButtons.Size = new System.Drawing.Size(120, 104);
            this.grpButtons.TabIndex = 57;
            this.grpButtons.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(18, 57);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(85, 37);
            this.btnExit.TabIndex = 59;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.ImageKey = "(none)";
            this.btnSave.Location = new System.Drawing.Point(18, 14);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 37);
            this.btnSave.TabIndex = 58;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblQ2_3
            // 
            this.lblQ2_3.AutoSize = true;
            this.lblQ2_3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_3.ForeColor = System.Drawing.Color.White;
            this.lblQ2_3.Location = new System.Drawing.Point(11, 164);
            this.lblQ2_3.Name = "lblQ2_3";
            this.lblQ2_3.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_3.TabIndex = 9;
            this.lblQ2_3.Text = "Q1_4";
            // 
            // txtQ1_3
            // 
            this.txtQ1_3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ1_3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ1_3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ1_3.Location = new System.Drawing.Point(74, 156);
            this.txtQ1_3.MaxLength = 1;
            this.txtQ1_3.Name = "txtQ1_3";
            this.txtQ1_3.Size = new System.Drawing.Size(41, 22);
            this.txtQ1_3.TabIndex = 10;
            this.txtQ1_3.TextChanged += new System.EventHandler(this.txtQ1_3_TextChanged);
            this.txtQ1_3.Enter += new System.EventHandler(this.txtQ1_3_Enter);
            this.txtQ1_3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_3_KeyPress);
            // 
            // lblQ2_2
            // 
            this.lblQ2_2.AutoSize = true;
            this.lblQ2_2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_2.ForeColor = System.Drawing.Color.White;
            this.lblQ2_2.Location = new System.Drawing.Point(11, 139);
            this.lblQ2_2.Name = "lblQ2_2";
            this.lblQ2_2.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_2.TabIndex = 7;
            this.lblQ2_2.Text = "Q1_3";
            // 
            // txtQ1_2
            // 
            this.txtQ1_2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ1_2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ1_2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ1_2.Location = new System.Drawing.Point(74, 131);
            this.txtQ1_2.MaxLength = 1;
            this.txtQ1_2.Name = "txtQ1_2";
            this.txtQ1_2.Size = new System.Drawing.Size(41, 22);
            this.txtQ1_2.TabIndex = 8;
            this.txtQ1_2.TextChanged += new System.EventHandler(this.txtQ1_2_TextChanged);
            this.txtQ1_2.Enter += new System.EventHandler(this.txtQ1_2_Enter);
            this.txtQ1_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_2_KeyPress);
            // 
            // lblQ2_1
            // 
            this.lblQ2_1.AutoSize = true;
            this.lblQ2_1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_1.ForeColor = System.Drawing.Color.White;
            this.lblQ2_1.Location = new System.Drawing.Point(11, 114);
            this.lblQ2_1.Name = "lblQ2_1";
            this.lblQ2_1.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_1.TabIndex = 5;
            this.lblQ2_1.Text = "Q1_2";
            // 
            // txtQ1_1
            // 
            this.txtQ1_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ1_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ1_1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ1_1.Location = new System.Drawing.Point(74, 106);
            this.txtQ1_1.MaxLength = 1;
            this.txtQ1_1.Name = "txtQ1_1";
            this.txtQ1_1.Size = new System.Drawing.Size(41, 22);
            this.txtQ1_1.TabIndex = 6;
            this.txtQ1_1.TextChanged += new System.EventHandler(this.txtQ1_1_TextChanged);
            this.txtQ1_1.Enter += new System.EventHandler(this.txtQ1_1_Enter);
            this.txtQ1_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_1_KeyPress);
            // 
            // lblQ1
            // 
            this.lblQ1.AutoSize = true;
            this.lblQ1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ1.ForeColor = System.Drawing.Color.White;
            this.lblQ1.Location = new System.Drawing.Point(11, 89);
            this.lblQ1.Name = "lblQ1";
            this.lblQ1.Size = new System.Drawing.Size(45, 14);
            this.lblQ1.TabIndex = 3;
            this.lblQ1.Text = "Q1_1";
            // 
            // txtQ1_9
            // 
            this.txtQ1_9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ1_9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ1_9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ1_9.Location = new System.Drawing.Point(74, 81);
            this.txtQ1_9.MaxLength = 1;
            this.txtQ1_9.Name = "txtQ1_9";
            this.txtQ1_9.Size = new System.Drawing.Size(41, 22);
            this.txtQ1_9.TabIndex = 4;
            this.txtQ1_9.TextChanged += new System.EventHandler(this.txtQ1_9_TextChanged);
            this.txtQ1_9.Enter += new System.EventHandler(this.txtQ1_9_Enter);
            this.txtQ1_9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_9_KeyPress);
            // 
            // IGImageViewer
            // 
            this.IGImageViewer.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.IGImageViewer.BackColor = System.Drawing.Color.Azure;
            this.IGImageViewer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.IGImageViewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IGImageViewer.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IGImageViewer.ImageData = null;
            this.IGImageViewer.ImageName = null;
            this.IGImageViewer.ImageScropping = false;
            this.IGImageViewer.ImageSize = new System.Drawing.Size(0, 0);
            this.IGImageViewer.Location = new System.Drawing.Point(1, 0);
            this.IGImageViewer.Name = "IGImageViewer";
            this.IGImageViewer.PictureBoxSize = new System.Drawing.Size(0, 0);
            this.IGImageViewer.Size = new System.Drawing.Size(1052, 466);
            this.IGImageViewer.StatusBarVisible = true;
            this.IGImageViewer.TabIndex = 43;
            // 
            // lblMailType
            // 
            this.lblMailType.AutoSize = true;
            this.lblMailType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMailType.ForeColor = System.Drawing.Color.White;
            this.lblMailType.Location = new System.Drawing.Point(902, 18);
            this.lblMailType.Name = "lblMailType";
            this.lblMailType.Size = new System.Drawing.Size(66, 14);
            this.lblMailType.TabIndex = 55;
            this.lblMailType.Text = "MailType";
            // 
            // txtmailtype
            // 
            this.txtmailtype.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtmailtype.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtmailtype.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtmailtype.Location = new System.Drawing.Point(905, 38);
            this.txtmailtype.MaxLength = 5;
            this.txtmailtype.Name = "txtmailtype";
            this.txtmailtype.Size = new System.Drawing.Size(63, 22);
            this.txtmailtype.TabIndex = 56;
            this.txtmailtype.TextChanged += new System.EventHandler(this.txtmailtype_TextChanged);
            this.txtmailtype.Enter += new System.EventHandler(this.txtmailtype_Enter);
            this.txtmailtype.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmailtype_KeyPress);
            // 
            // HRAV1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1047, 742);
            this.Controls.Add(this.IGImageViewer);
            this.Controls.Add(this.grpKeyData);
            this.Controls.Add(this.grpMain);
            this.KeyPreview = true;
            this.Name = "HRAV1";
            this.Text = "HRAV1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.HRAV1_FormClosing);
            this.Load += new System.EventHandler(this.HRAV1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.HRAV1_KeyDown);
            this.grpKeyData.ResumeLayout(false);
            this.grpKeyData.PerformLayout();
            this.grpMain.ResumeLayout(false);
            this.StatusStrip1.ResumeLayout(false);
            this.StatusStrip1.PerformLayout();
            this.grpTxtBoxes1.ResumeLayout(false);
            this.grpTxtBoxes1.PerformLayout();
            this.grpButtons.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblKey2Data;
        private System.Windows.Forms.TextBox txtKey2Data;
        private System.Windows.Forms.Label lblKey2User;
        private System.Windows.Forms.TextBox txtKey2User;
        private System.Windows.Forms.GroupBox grpKeyData;
        private System.Windows.Forms.Label lblKey1Data;
        private System.Windows.Forms.TextBox txtKey1Data;
        private System.Windows.Forms.Label lblKey1User;
        private System.Windows.Forms.TextBox txtKey1User;
        private System.Windows.Forms.GroupBox grpMain;
        private InfognanaImageViewer.IGImageViewer IGImageViewer;
        internal System.Windows.Forms.StatusStrip StatusStrip1;
        internal System.Windows.Forms.ToolStripStatusLabel stsUser;
        internal System.Windows.Forms.ToolStripStatusLabel stsTotRecs;
        internal System.Windows.Forms.ToolStripStatusLabel stsFinRecs;
        internal System.Windows.Forms.ToolStripStatusLabel stsRemRecs;
        internal System.Windows.Forms.ToolStripStatusLabel stsDate;
        private System.Windows.Forms.GroupBox grpTxtBoxes1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtQ8_1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtQ7_1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtQ7_2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtQ6_1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtQ5_TTL;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtQ5_1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtQ2_TTL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtQ2_1;
        private System.Windows.Forms.Label lblLanguage;
        private System.Windows.Forms.TextBox txtLanguage;
        private System.Windows.Forms.Label lblRespondentID;
        private System.Windows.Forms.TextBox txtRespndentID;
        private System.Windows.Forms.Label lblQ3;
        private System.Windows.Forms.TextBox txtQ3_1;
        private System.Windows.Forms.Label lblQ10;
        private System.Windows.Forms.TextBox txtQ4_3;
        private System.Windows.Forms.Label lblQ9;
        private System.Windows.Forms.TextBox txtQ4_2;
        private System.Windows.Forms.Label lblQ8;
        private System.Windows.Forms.TextBox txtQ4_1;
        private System.Windows.Forms.Label lblQ7;
        private System.Windows.Forms.TextBox txtQ3_5;
        private System.Windows.Forms.Label lblQ6;
        private System.Windows.Forms.TextBox txtQ3_4;
        private System.Windows.Forms.Label lblQ5;
        private System.Windows.Forms.TextBox txtQ3_3;
        private System.Windows.Forms.Label lblQ4;
        private System.Windows.Forms.TextBox txtQ3_2;
        private System.Windows.Forms.Label lblQ2_8;
        private System.Windows.Forms.TextBox txtQ1_8;
        private System.Windows.Forms.Label lblQ2_7;
        private System.Windows.Forms.TextBox txtQ1_7;
        private System.Windows.Forms.Label lblQ2_6;
        private System.Windows.Forms.TextBox txtQ1_6;
        private System.Windows.Forms.Label lblQ2_5;
        private System.Windows.Forms.TextBox txtQ1_5;
        private System.Windows.Forms.Label lblQ2_4;
        private System.Windows.Forms.TextBox txtQ1_4;
        private System.Windows.Forms.GroupBox grpButtons;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblQ2_3;
        private System.Windows.Forms.TextBox txtQ1_3;
        private System.Windows.Forms.Label lblQ2_2;
        private System.Windows.Forms.TextBox txtQ1_2;
        private System.Windows.Forms.Label lblQ2_1;
        private System.Windows.Forms.TextBox txtQ1_1;
        private System.Windows.Forms.Label lblQ1;
        private System.Windows.Forms.TextBox txtQ1_9;
        private System.Windows.Forms.Label txtDescription;
        private System.Windows.Forms.TextBox txtmailtype;
        private System.Windows.Forms.Label lblMailType;

    }
}