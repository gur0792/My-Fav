﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using MySql.Data.MySqlClient;
using DataAccessLayer.ProjectDB;
using DataAccessLayer.GlobalDB;
using DataAccessLayer.ZipCodeDB;
using App.Base;
using System.Collections;

namespace Healthtel_MRT
{
    public partial class Healthtel_pediatric : Form
    {
        public Healthtel_pediatric()
        {
            InitializeComponent();
        }

        batchmaster objBatchmaster = new batchmaster();
        imagemaster objImagemaster = new imagemaster();
        key1_pediatric objKey1 = new key1_pediatric();
        key2_pediatric objKey2 = new key2_pediatric();
        compareqc_pediatric objCompareQC = new compareqc_pediatric();

        imagemaster Image = new imagemaster();
        key1_pediatric getkey1Data = new key1_pediatric();
        key2_pediatric getkey2Data = new key2_pediatric();
        compareqc_pediatric getCompareqcData = new compareqc_pediatric();
        public string UserName { get; set; }
        private Control _focusedControl;

        #region Global Fields For Controls
        public const string GC_FIELDS_BARCODE = "txtbarcode";
        public const string GC_FIELDS_Q1 = "txtQ1";
        public const string GC_FIELDS_Q2 = "txtQ2";
        public const string GC_FIELDS_Q3 = "txtQ3";
        public const string GC_FIELDS_Q4 = "txtQ4";
        public const string GC_FIELDS_Q5 = "txtQ5";
        public const string GC_FIELDS_Q6 = "txtQ6";
        public const string GC_FIELDS_Q7 = "txtQ7";
        public const string GC_FIELDS_Q8 = "txtQ8";
        public const string GC_FIELDS_Q9 = "txtQ9";
        public const string GC_FIELDS_Q10 = "txtQ10";
        public const string GC_FIELDS_Q11 = "txtQ11";
        public const string GC_FIELDS_Q12 = "txtQ12";
        public const string GC_FIELDS_Q13 = "txtQ13";
        public const string GC_FIELDS_Q14 = "txtQ14";
        public const string GC_FIELDS_Q15 = "txtQ15";
        public const string GC_FIELDS_Q16 = "txtQ16";
        public const string GC_FIELDS_Q17 = "txtQ17";
        public const string GC_FIELDS_Q18 = "txtQ18";
        public const string GC_FIELDS_Q19 = "txtQ19";
        public const string GC_FIELDS_Q20 = "txtQ20";
        public const string GC_FIELDS_Q21 = "txtQ21";
        public const string GC_FIELDS_Q22 = "txtQ22";
        public const string GC_FIELDS_Q23 = "txtQ23";
        public const string GC_FIELDS_Q24 = "txtQ24";
        public const string GC_FIELDS_Q25 = "txtQ25";
        public const string GC_FIELDS_Q26 = "txtQ26";
        public const string GC_FIELDS_Q27 = "txtQ27";
        public const string GC_FIELDS_Q28 = "txtQ28";
        public const string GC_FIELDS_Q29 = "txtQ29";
        public const string GC_FIELDS_Q30 = "txtQ30";
        public const string GC_FIELDS_Q31 = "txtQ31";
        public const string GC_FIELDS_Q32 = "txtQ32";
        public const string GC_FIELDS_Q33 = "txtQ33";
        public const string GC_FIELDS_Q34 = "txtQ34";
        #endregion

        long lngBatchID;
        long lngImageID;
        int intBatchType;
        string strImagePath;
        int totRecs;
        int RemRecs;
        int FinRecs;
        string ProcessType;
        string strSQL;
        DataSet dsKeyData;
        DataSet dsKey1;
        DataSet dskey;
        string strImageSize;
        string strImageFit;
        int iHScrol = 0;
        int iVScrol = 0;

        bool bCtrl = false;
        bool bAlt = false;
        bool bShift = false;
        bool bImageLoad = false;

        #region Property Variables
        public long BatchID
        {
            get { return lngBatchID; }

            set { lngBatchID = value; }
        }

        public string Process
        {
            get { return ProcessType; }

            set { ProcessType = value; }
        }

        public int BatchType
        {
            get { return intBatchType; }

            set { intBatchType = value; }
        }
        #endregion



        private void Healthtel_pediatric_Load(object sender, EventArgs e)
        {

            if (BatchType == 5)
            {
                this.Text = string.Format("Healthtel pediatric :: {0}", Process);
            }
            LoadImage();
        }

        private bool LoadImage()
        {
            //bool functionReturnValue = false;
            try
            {
                ClearInfo();
                if (lngBatchID > 0)
                {

                    Image = objImagemaster.LoadImage_HRA_v1(Process, lngBatchID, Constance.GC_USERID);
                    if (Image == null)
                    {
                        MessageBox.Show("Batch Completed");
                        objBatchmaster.UpdateBatchmaster(lngBatchID.ToInt(), Process);
                        this.Close();
                        return false;
                    }

                    lngImageID = Image.ImageID;
                    IGImageViewer.ImageName = Image.ImagePath;
                    IGImageViewer.LoadImage();

                    //if (!BarcodeWorker.IsBusy)
                    //{
                    //    BarcodeWorker.RunWorkerAsync();
                    //}

                    strImageSize = Interaction.GetSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageSize) + "";
                    if (strImageSize.LastIndexOf(",") > 0)
                    {
                        iHScrol = Convert.ToInt32((strImageSize.Substring(0, strImageSize.LastIndexOf(","))));
                        iVScrol = Convert.ToInt32(strImageSize.Substring(strImageSize.LastIndexOf(",") + 1));
                        IGImageViewer.ImageSize = new System.Drawing.Size(iHScrol, iVScrol);
                    }

                    strImageFit = Interaction.GetSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageFit) + "";
                    if (strImageFit.LastIndexOf(",") > 0)
                    {
                        iHScrol = Convert.ToInt32(strImageFit.Substring(0, strImageFit.LastIndexOf(",")));
                        iVScrol = Convert.ToInt32(strImageFit.Substring(strImageFit.LastIndexOf(",") + 1));
                    }

                    IGImageViewer.MoveImage(iHScrol, iVScrol);
                    IGImageViewer.Refresh();

                    if (Process.ToUpper() == "COMPAREQC")
                    {
                        RestoreInfo();
                        grpKeyData.Visible = true;
                    }

                    Constance.ImageInTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    int TotalRecord, FinishedRecord, RemainingRecord;
                    TotalRecord = FinishedRecord = RemainingRecord = 0;

                    objImagemaster.RecordStatus(Process, lngBatchID, ref TotalRecord, ref FinishedRecord, ref RemainingRecord, intBatchType);
                    this.stsUser.Text = "User Name : " + Constance.GC_USERNAME;
                    this.stsTotRecs.Text = "Total Recs : " + TotalRecord;
                    this.stsFinRecs.Text = "Finished Rec : " + FinishedRecord;
                    this.stsRemRecs.Text = "Remine Recs: " + RemainingRecord;
                    this.stsDate.Text = "Date : " + DateAndTime.Now.ToString("dd-MMMM-yyyy");

                    txtbarcode.Focus();

                    if (Process.ToUpper() == "COMPAREQC")
                    {
                        if (txtbarcode.Enabled == true)
                        { txtbarcode.Focus(); }
                        else if (txtQ1.Enabled == true)
                        { txtQ1.Focus(); }
                        else if (txtQ2.Enabled == true)
                        { txtQ2.Focus(); }
                        else if (txtQ3.Enabled == true)
                        { txtQ3.Focus(); }
                        else if (txtQ4.Enabled == true)
                        { txtQ4.Focus(); }
                        else if (txtQ5.Enabled == true)
                        { txtQ5.Focus(); }
                        else if (txtQ6.Enabled == true)
                        { txtQ6.Focus(); }
                        else if (txtQ7.Enabled == true)
                        { txtQ7.Focus(); }
                        else if (txtQ8.Enabled == true)
                        { txtQ8.Focus(); }
                        else if (txtQ9.Enabled == true)
                        { txtQ9.Focus(); }
                        else if (txtQ10.Enabled == true)
                        { txtQ10.Focus(); }
                        else if (txtQ11.Enabled == true)
                        { txtQ11.Focus(); }
                        else if (txtQ12.Enabled == true)
                        { txtQ12.Focus(); }
                        else if (txtQ13.Enabled == true)
                        { txtQ13.Focus(); }
                        else if (txtQ14.Enabled == true)
                        { txtQ14.Focus(); }
                        else if (txtQ15.Enabled == true)
                        { txtQ15.Focus(); }
                        else if (txtQ16.Enabled == true)
                        { txtQ16.Focus(); }
                        else if (txtQ17.Enabled == true)
                        { txtQ17.Focus(); }
                        else if (txtQ18.Enabled == true)
                        { txtQ18.Focus(); }
                        else if (txtQ19.Enabled == true)
                        { txtQ19.Focus(); }
                        else if (txtQ20.Enabled == true)
                        { txtQ20.Focus(); }
                        else if (txtQ21.Enabled == true)
                        { txtQ21.Focus(); }
                        else if (txtQ22.Enabled == true)
                        { txtQ22.Focus(); }
                        else if (txtQ23.Enabled == true)
                        { txtQ23.Focus(); }
                        else if (txtQ24.Enabled == true)
                        { txtQ24.Focus(); }
                        else if (txtQ25.Enabled == true)
                        { txtQ25.Focus(); }
                        else if (txtQ26.Enabled == true)
                        { txtQ26.Focus(); }
                        else if (txtQ27.Enabled == true)
                        { txtQ27.Focus(); }
                        else if (txtQ28.Enabled == true)
                        { txtQ28.Focus(); }
                        else if (txtQ29.Enabled == true)
                        { txtQ29.Focus(); }
                        else if (txtQ30.Enabled == true)
                        { txtQ30.Focus(); }
                        else if (txtQ31.Enabled == true)
                        { txtQ31.Focus(); }
                        else if (txtQ32.Enabled == true)
                        { txtQ32.Focus(); }
                        else if (txtQ33.Enabled == true)
                        { txtQ33.Focus(); }
                        else if (txtQ34.Enabled == true)
                        { txtQ34.Focus(); }
                        else
                        {
                            SaveandLoad();
                        }
                    }


                    return true;
                }
                else
                {
                    Interaction.MsgBox("Invalid Batch Selection", MsgBoxStyle.Information, Constance.gstrappTitle);
                    this.Close();
                    return false;
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            return true;
        }
        private void TextBox_GotFocus(object sender, EventArgs e)
        {
            _focusedControl = (Control)sender;
        }
        private void ClearInfo()
        {
            txtbarcode.Clear();
            txtQ1.Clear();
            txtQ2.Clear();
            txtQ3.Clear();
            txtQ4.Clear();
            txtQ5.Clear();
            txtQ6.Clear();
            txtQ7.Clear();
            txtQ8.Clear();
            txtQ9.Clear();
            txtQ10.Clear();
            txtQ11.Clear();
            txtQ12.Clear();
            txtQ13.Clear();
            txtQ14.Clear();
            txtQ15.Clear();
            txtQ16.Clear();
            txtQ17.Clear();
            txtQ18.Clear();
            txtQ19.Clear();
            txtQ20.Clear();
            txtQ21.Clear();
            txtQ22.Clear();
            txtQ23.Clear();
            txtQ24.Clear();
            txtQ25.Clear();
            txtQ26.Clear();
            txtQ27.Clear();
            txtQ28.Clear();
            txtQ29.Clear();
            txtQ30.Clear();
            txtQ31.Clear();
            txtQ32.Clear();
            txtQ33.Clear();
            txtQ34.Clear();
            txtKey1User.Clear();
            txtKey1Data.Clear();
            txtKey2User.Clear();
            txtKey2Data.Clear();
            IGImageViewer.ImageClear();
        }

        private void RestoreInfo()
        {
            try
            {
                getCompareqcData = objCompareQC.compareqcDatas(lngImageID.ToInt());

                if (getCompareqcData == null)
                {
                    getkey2Data = objKey2.key2Datas(lngImageID.ToInt());
                }
                getkey1Data = objKey1.Key1Datas(lngImageID.ToInt());

                if (getCompareqcData != null)
                {
                    txtbarcode.Text = getCompareqcData.BARCODE;
                    txtQ1.Text = getCompareqcData.Q1;
                    txtQ2.Text = getCompareqcData.Q2;
                    txtQ3.Text = getCompareqcData.Q3;
                    txtQ4.Text = getCompareqcData.Q4;
                    txtQ5.Text = getCompareqcData.Q5;
                    txtQ6.Text = getCompareqcData.Q6;
                    txtQ7.Text = getCompareqcData.Q7;
                    txtQ8.Text = getCompareqcData.Q8;
                    txtQ9.Text = getCompareqcData.Q9;
                    txtQ10.Text = getCompareqcData.Q10;
                    txtQ11.Text = getCompareqcData.Q11;
                    txtQ12.Text = getCompareqcData.Q12;
                    txtQ13.Text = getCompareqcData.Q13;
                    txtQ14.Text = getCompareqcData.Q14;
                    txtQ15.Text = getCompareqcData.Q15;
                    txtQ16.Text = getCompareqcData.Q16;
                    txtQ17.Text = getCompareqcData.Q17;
                    txtQ18.Text = getCompareqcData.Q18;
                    txtQ19.Text = getCompareqcData.Q19;
                    txtQ20.Text = getCompareqcData.Q20;
                    txtQ21.Text = getCompareqcData.Q21;
                    txtQ22.Text = getCompareqcData.Q22;
                    txtQ23.Text = getCompareqcData.Q23;
                    txtQ24.Text = getCompareqcData.Q24;
                    txtQ25.Text = getCompareqcData.Q25;
                    txtQ26.Text = getCompareqcData.Q26;
                    txtQ27.Text = getCompareqcData.Q27;
                    txtQ28.Text = getCompareqcData.Q28;
                    txtQ29.Text = getCompareqcData.Q29;
                    txtQ30.Text = getCompareqcData.Q30;
                    txtQ31.Text = getCompareqcData.Q31;
                    txtQ32.Text = getCompareqcData.Q32;
                    txtQ33.Text = getCompareqcData.Q33;
                    txtQ34.Text = getCompareqcData.Q34;
                    txtKey2User.Text = getCompareqcData.UserName;
                }
                else if (getkey2Data != null)
                {
                    txtbarcode.Text = getkey2Data.BARCODE;
                    txtQ1.Text = getkey2Data.Q1;
                    txtQ2.Text = getkey2Data.Q2;
                    txtQ3.Text = getkey2Data.Q3;
                    txtQ4.Text = getkey2Data.Q4;
                    txtQ5.Text = getkey2Data.Q5;
                    txtQ6.Text = getkey2Data.Q6;
                    txtQ7.Text = getkey2Data.Q7;
                    txtQ8.Text = getkey2Data.Q8;
                    txtQ9.Text = getkey2Data.Q9;
                    txtQ10.Text = getkey2Data.Q10;
                    txtQ11.Text = getkey2Data.Q11;
                    txtQ12.Text = getkey2Data.Q12;
                    txtQ13.Text = getkey2Data.Q13;
                    txtQ14.Text = getkey2Data.Q14;
                    txtQ15.Text = getkey2Data.Q15;
                    txtQ16.Text = getkey2Data.Q16;
                    txtQ17.Text = getkey2Data.Q17;
                    txtQ18.Text = getkey2Data.Q18;
                    txtQ19.Text = getkey2Data.Q19;
                    txtQ20.Text = getkey2Data.Q20;
                    txtQ21.Text = getkey2Data.Q21;
                    txtQ22.Text = getkey2Data.Q22;
                    txtQ23.Text = getkey2Data.Q23;
                    txtQ24.Text = getkey2Data.Q24;
                    txtQ25.Text = getkey2Data.Q25;
                    txtQ26.Text = getkey2Data.Q26;
                    txtQ27.Text = getkey2Data.Q27;
                    txtQ28.Text = getkey2Data.Q28;
                    txtQ29.Text = getkey2Data.Q29;
                    txtQ30.Text = getkey2Data.Q30;
                    txtQ31.Text = getkey2Data.Q31;
                    txtQ32.Text = getkey2Data.Q32;
                    txtQ33.Text = getkey2Data.Q33;
                    txtQ34.Text = getkey2Data.Q34;
                    txtKey2User.Text = getkey2Data.UserName;

                }

                if (getkey1Data != null)
                {
                    txtbarcode.Tag = getkey1Data.BARCODE;
                    txtQ1.Tag = getkey1Data.Q1;
                    txtQ2.Tag = getkey1Data.Q2;
                    txtQ3.Tag = getkey1Data.Q3;
                    txtQ4.Tag = getkey1Data.Q4;
                    txtQ5.Tag = getkey1Data.Q5;
                    txtQ6.Tag = getkey1Data.Q6;
                    txtQ7.Tag = getkey1Data.Q7;
                    txtQ8.Tag = getkey1Data.Q8;
                    txtQ9.Tag = getkey1Data.Q9;
                    txtQ10.Tag = getkey1Data.Q10;
                    txtQ11.Tag = getkey1Data.Q11;
                    txtQ12.Tag = getkey1Data.Q12;
                    txtQ13.Tag = getkey1Data.Q13;
                    txtQ14.Tag = getkey1Data.Q14;
                    txtQ15.Tag = getkey1Data.Q15;
                    txtQ16.Tag = getkey1Data.Q16;
                    txtQ17.Tag = getkey1Data.Q17;
                    txtQ18.Tag = getkey1Data.Q18;
                    txtQ19.Tag = getkey1Data.Q19;
                    txtQ20.Tag = getkey1Data.Q20;
                    txtQ21.Tag = getkey1Data.Q21;
                    txtQ22.Tag = getkey1Data.Q22;
                    txtQ23.Tag = getkey1Data.Q23;
                    txtQ24.Tag = getkey1Data.Q24;
                    txtQ25.Tag = getkey1Data.Q25;
                    txtQ26.Tag = getkey1Data.Q26;
                    txtQ27.Tag = getkey1Data.Q27;
                    txtQ28.Tag = getkey1Data.Q28;
                    txtQ29.Tag = getkey1Data.Q29;
                    txtQ30.Tag = getkey1Data.Q30;
                    txtQ31.Tag = getkey1Data.Q31;
                    txtQ32.Tag = getkey1Data.Q32;
                    txtQ33.Tag = getkey1Data.Q33;
                    txtQ34.Tag = getkey1Data.Q34;
                    txtKey1User.Text = getkey1Data.UserName;

                }
               
                if (txtbarcode.Text == txtbarcode.Tag.ToString())
                {
                    txtbarcode.Enabled = false;
                    txtbarcode.BackColor = Color.White;
                }
                else
                {
                    txtbarcode.Enabled = true;
                    txtbarcode.Text = "";
                    txtbarcode.BackColor = Color.Yellow;
                }

                if (txtQ1.Text.ToUpper() == txtQ1.Tag.ToString().ToUpper())
                {
                    txtQ1.Enabled = false;
                    txtQ1.BackColor = Color.White;
                }
                else
                {
                    txtQ1.Enabled = true;
                    txtQ1.Text = "";
                    txtQ1.BackColor = Color.Yellow;
                }

                if (txtQ2.Text.ToUpper() == txtQ2.Tag.ToString().ToUpper())
                {
                    txtQ2.Enabled = false;
                    txtQ2.BackColor = Color.White;
                }
                else
                {
                    txtQ2.Enabled = true;
                    txtQ2.Text = "";
                    txtQ2.BackColor = Color.Yellow;
                }

                if (txtQ3.Text.ToUpper() == txtQ3.Tag.ToString().ToUpper())
                {
                    txtQ3.Enabled = false;
                    txtQ3.BackColor = Color.White;
                }
                else
                {
                    txtQ3.Enabled = true;
                    txtQ3.Text = "";
                    txtQ3.BackColor = Color.Yellow;
                }

                if (txtQ4.Text.ToUpper() == txtQ4.Tag.ToString().ToUpper())
                {
                    txtQ4.Enabled = false;
                    txtQ4.BackColor = Color.White;
                }
                else
                {
                    txtQ4.Enabled = true;
                    txtQ4.Text = "";
                    txtQ4.BackColor = Color.Yellow;
                }

                if (txtQ5.Text.ToUpper() == txtQ5.Tag.ToString().ToUpper())
                {
                    txtQ5.Enabled = false;
                    txtQ5.BackColor = Color.White;
                }
                else
                {
                    txtQ5.Enabled = true;
                    txtQ5.Text = "";
                    txtQ5.BackColor = Color.Yellow;
                }

                if (txtQ6.Text.ToUpper() == txtQ6.Tag.ToString().ToUpper())
                {
                    txtQ6.Enabled = false;
                    txtQ6.BackColor = Color.White;
                }
                else
                {
                    txtQ6.Enabled = true;
                    txtQ6.Text = "";
                    txtQ6.BackColor = Color.Yellow;
                }

                if (txtQ7.Text.ToUpper() == txtQ7.Tag.ToString().ToUpper())
                {
                    txtQ7.Enabled = false;
                    txtQ7.BackColor = Color.White;
                }
                else
                {
                    txtQ7.Enabled = true;
                    txtQ7.Text = "";
                    txtQ7.BackColor = Color.Yellow;
                }

                if (txtQ8.Text.ToUpper() == txtQ8.Tag.ToString().ToUpper())
                {
                    txtQ8.Enabled = false;
                    txtQ8.BackColor = Color.White;
                }
                else
                {
                    txtQ8.Enabled = true;
                    txtQ8.Text = "";
                    txtQ8.BackColor = Color.Yellow;
                }

                if (txtQ9.Text.ToUpper() == txtQ9.Tag.ToString().ToUpper())
                {
                    txtQ9.Enabled = false;
                    txtQ9.BackColor = Color.White;
                }
                else
                {
                    txtQ9.Enabled = true;
                    txtQ9.Text = "";
                    txtQ9.BackColor = Color.Yellow;
                }

                if (txtQ10.Text.ToUpper() == txtQ10.Tag.ToString().ToUpper())
                {
                    txtQ10.Enabled = false;
                    txtQ10.BackColor = Color.White;
                }
                else
                {
                    txtQ10.Enabled = true;
                    txtQ10.Text = "";
                    txtQ10.BackColor = Color.Yellow;
                }

                if (txtQ11.Text.ToUpper() == txtQ11.Tag.ToString().ToUpper())
                {
                    txtQ11.Enabled = false;
                    txtQ11.BackColor = Color.White;
                }
                else
                {
                    txtQ11.Enabled = true;
                    txtQ11.Text = "";
                    txtQ11.BackColor = Color.Yellow;
                }

                if (txtQ12.Text.ToUpper() == txtQ12.Tag.ToString().ToUpper())
                {
                    txtQ12.Enabled = false;
                    txtQ12.BackColor = Color.White;
                }
                else
                {
                    txtQ12.Enabled = true;
                    txtQ12.Text = "";
                    txtQ12.BackColor = Color.Yellow;
                }

                if (txtQ13.Text.ToUpper() == txtQ13.Tag.ToString().ToUpper())
                {
                    txtQ13.Enabled = false;
                    txtQ13.BackColor = Color.White;
                }
                else
                {
                    txtQ13.Enabled = true;
                    txtQ13.Text = "";
                    txtQ13.BackColor = Color.Yellow;
                }

                if (txtQ14.Text.ToUpper() == txtQ14.Tag.ToString().ToUpper())
                {
                    txtQ14.Enabled = false;
                    txtQ14.BackColor = Color.White;
                }
                else
                {
                    txtQ14.Enabled = true;
                    txtQ14.Text = "";
                    txtQ14.BackColor = Color.Yellow;
                }

                if (txtQ15.Text.ToUpper() == txtQ15.Tag.ToString().ToUpper())
                {
                    txtQ15.Enabled = false;
                    txtQ15.BackColor = Color.White;
                }
                else
                {
                    txtQ15.Enabled = true;
                    txtQ15.Text = "";
                    txtQ15.BackColor = Color.Yellow;
                }

                if (txtQ16.Text.ToUpper() == txtQ16.Tag.ToString().ToUpper())
                {
                    txtQ16.Enabled = false;
                    txtQ16.BackColor = Color.White;
                }
                else
                {
                    txtQ16.Enabled = true;
                    txtQ16.Text = "";
                    txtQ16.BackColor = Color.Yellow;
                }

                if (txtQ17.Text.ToUpper() == txtQ17.Tag.ToString().ToUpper())
                {
                    txtQ17.Enabled = false;
                    txtQ17.BackColor = Color.White;
                }
                else
                {
                    txtQ17.Enabled = true;
                    txtQ17.Text = "";
                    txtQ17.BackColor = Color.Yellow;
                }

                if (txtQ18.Text.ToUpper() == txtQ18.Tag.ToString().ToUpper())
                {
                    txtQ18.Enabled = false;
                    txtQ18.BackColor = Color.White;
                }
                else
                {
                    txtQ18.Enabled = true;
                    txtQ18.Text = "";
                    txtQ18.BackColor = Color.Yellow;
                }

                if (txtQ19.Text.ToUpper() == txtQ19.Tag.ToString().ToUpper())
                {
                    txtQ19.Enabled = false;
                    txtQ19.BackColor = Color.White;
                }
                else
                {
                    txtQ19.Enabled = true;
                    txtQ19.Text = "";
                    txtQ19.BackColor = Color.Yellow;
                }

                if (txtQ20.Text.ToUpper() == txtQ20.Tag.ToString().ToUpper())
                {
                    txtQ20.Enabled = false;
                    txtQ20.BackColor = Color.White;
                }
                else
                {
                    txtQ20.Enabled = true;
                    txtQ20.Text = "";
                    txtQ20.BackColor = Color.Yellow;
                }

                if (txtQ21.Text.ToUpper() == txtQ21.Tag.ToString().ToUpper())
                {
                    txtQ21.Enabled = false;
                    txtQ21.BackColor = Color.White;
                }
                else
                {
                    txtQ21.Enabled = true;
                    txtQ21.Text = "";
                    txtQ21.BackColor = Color.Yellow;
                }

                if (txtQ22.Text.ToUpper() == txtQ22.Tag.ToString().ToUpper())
                {
                    txtQ22.Enabled = false;
                    txtQ22.BackColor = Color.White;
                }
                else
                {
                    txtQ22.Enabled = true;
                    txtQ22.Text = "";
                    txtQ22.BackColor = Color.Yellow;
                }

                if (txtQ23.Text.ToUpper() == txtQ23.Tag.ToString().ToUpper())
                {
                    txtQ23.Enabled = false;
                    txtQ23.BackColor = Color.White;
                }
                else
                {
                    txtQ23.Enabled = true;
                    txtQ23.Text = "";
                    txtQ23.BackColor = Color.Yellow;
                }

                if (txtQ24.Text.ToUpper() == txtQ24.Tag.ToString().ToUpper())
                {
                    txtQ24.Enabled = false;
                    txtQ24.BackColor = Color.White;
                }
                else
                {
                    txtQ24.Enabled = true;
                    txtQ24.Text = "";
                    txtQ24.BackColor = Color.Yellow;
                }
                if (txtQ25.Text.ToUpper() == txtQ25.Tag.ToString().ToUpper())
                {
                    txtQ25.Enabled = false;
                    txtQ25.BackColor = Color.White;
                }
                else
                {
                    txtQ25.Enabled = true;
                    txtQ25.Text = "";
                    txtQ25.BackColor = Color.Yellow;
                }
                if (txtQ26.Text.ToUpper() == txtQ26.Tag.ToString().ToUpper())
                {
                    txtQ26.Enabled = false;
                    txtQ26.BackColor = Color.White;
                }
                else
                {
                    txtQ26.Enabled = true;
                    txtQ26.Text = "";
                    txtQ26.BackColor = Color.Yellow;
                }

                if (txtQ27.Text.ToUpper() == txtQ27.Tag.ToString().ToUpper())
                {
                    txtQ27.Enabled = false;
                    txtQ27.BackColor = Color.White;
                }
                else
                {
                    txtQ27.Enabled = true;
                    txtQ27.Text = "";
                    txtQ27.BackColor = Color.Yellow;
                }

                if (txtQ28.Text.ToUpper() == txtQ28.Tag.ToString().ToUpper())
                {
                    txtQ28.Enabled = false;
                    txtQ28.BackColor = Color.White;
                }
                else
                {
                    txtQ28.Enabled = true;
                    txtQ28.Text = "";
                    txtQ28.BackColor = Color.Yellow;
                }

                if (txtQ29.Text.ToUpper() == txtQ29.Tag.ToString().ToUpper())
                {
                    txtQ29.Enabled = false;
                    txtQ29.BackColor = Color.White;
                }
                else
                {
                    txtQ29.Enabled = true;
                    txtQ29.Text = "";
                    txtQ29.BackColor = Color.Yellow;
                }

                if (txtQ30.Text.ToUpper() == txtQ30.Tag.ToString().ToUpper())
                {
                    txtQ30.Enabled = false;
                    txtQ30.BackColor = Color.White;
                }
                else
                {
                    txtQ30.Enabled = true;
                    txtQ30.Text = "";
                    txtQ30.BackColor = Color.Yellow;
                }

                if (txtQ31.Text.ToUpper() == txtQ31.Tag.ToString().ToUpper())
                {
                    txtQ31.Enabled = false;
                    txtQ31.BackColor = Color.White;
                }
                else
                {
                    txtQ31.Enabled = true;
                    txtQ31.Text = "";
                    txtQ31.BackColor = Color.Yellow;
                }

                if (txtQ32.Text.ToUpper() == txtQ32.Tag.ToString().ToUpper())
                {
                    txtQ32.Enabled = false;
                    txtQ32.BackColor = Color.White;
                }
                else
                {
                    txtQ32.Enabled = true;
                    txtQ32.Text = "";
                    txtQ32.BackColor = Color.Yellow;
                }

                if (txtQ33.Text.ToUpper() == txtQ33.Tag.ToString().ToUpper())
                {
                    txtQ33.Enabled = false;
                    txtQ33.BackColor = Color.White;
                }
                else
                {
                    txtQ33.Enabled = true;
                    txtQ33.Text = "";
                    txtQ33.BackColor = Color.Yellow;

                }

                if (txtQ34.Text.ToUpper() == txtQ34.Tag.ToString().ToUpper())
                {
                    txtQ34.Enabled = false;
                    txtQ34.BackColor = Color.White;
                }
                else
                {
                    txtQ34.Enabled = true;
                    txtQ34.Text = "";
                    txtQ34.BackColor = Color.Yellow;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        private void SaveandLoad()
        {
            if (ValidateInfo() == true)
            {
                if (SaveInfo() == true)
                {
                    LoadImage();
                }
            }
        }

        private bool ValidateInfo()
        {
            if (TotalKeystrokes() <= 0)
            {
                if (MessageBox.Show("Do you want to save Blank records?", "Healthtel", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }

        private long TotalKeystrokes()
        {
            long lngCount = 0;
            lngCount = 0;

            lngCount += txtbarcode.TextLength;
            lngCount += txtQ1.TextLength;
            lngCount += txtQ2.TextLength;
            lngCount += txtQ3.Text.Length;
            lngCount += txtQ4.TextLength;
            lngCount += txtQ5.TextLength;
            lngCount += txtQ6.TextLength;
            lngCount += txtQ7.TextLength;
            lngCount += txtQ8.Text.Length;
            lngCount += txtQ9.TextLength;
            lngCount += txtQ10.TextLength;
            lngCount += txtQ11.TextLength;
            lngCount += txtQ12.TextLength;
            lngCount += txtQ13.TextLength;
            lngCount += txtQ14.TextLength;
            lngCount += txtQ15.TextLength;
            lngCount += txtQ16.TextLength;
            lngCount += txtQ17.TextLength;
            lngCount += txtQ18.TextLength;
            lngCount += txtQ19.TextLength;
            lngCount += txtQ20.TextLength;
            lngCount += txtQ21.TextLength;
            lngCount += txtQ22.TextLength;
            lngCount += txtQ23.TextLength;
            lngCount += txtQ24.TextLength;
            lngCount += txtQ25.TextLength;
            lngCount += txtQ26.TextLength;
            lngCount += txtQ27.TextLength;
            lngCount += txtQ28.TextLength;
            lngCount += txtQ29.TextLength;
            lngCount += txtQ30.TextLength;
            lngCount += txtQ31.TextLength;
            lngCount += txtQ32.TextLength;
            lngCount += txtQ33.TextLength;
            lngCount += txtQ34.TextLength;
            return lngCount;
        }

        private bool SaveInfo()
        {
            try
            {
                string ImageNumber;
                int iPos;
                string ImagePath = Image.ImagePath; ;

                if (!string.IsNullOrEmpty(ImagePath))
                {
                    if (ImagePath.LastIndexOf("\\") >= ImagePath.Length - 1 & ImagePath.Length > 0)
                    {
                        ImagePath = ImagePath.Substring(0, ImagePath.Length - 1);
                    }
                    iPos = ImagePath.LastIndexOf("\\");
                    ImagePath = ImagePath.Substring(iPos + 1, ImagePath.Length - (iPos + 1));
                }

                if (Process == Constance.GC_PROCESS_KEY1)
                {
                    key1_pediatric checkkey1 = new key1_pediatric().isImageIDExists(lngImageID);
                    int Key1_PEDIATRICID = (checkkey1 == null) ? 0 : checkkey1.Key1_PEDIATRICID;
                    key1_pediatric objkey1_pediatric = new key1_pediatric(Key1_PEDIATRICID);
                    objkey1_pediatric.ImageId = lngImageID.ToInt();
                    objkey1_pediatric.Image_Number = ImagePath;
                    objkey1_pediatric.BARCODE = txtbarcode.Text.Trim();
                    objkey1_pediatric.Q1 = txtQ1.Text.Trim();
                    objkey1_pediatric.Q2 = txtQ2.Text.Trim();
                    objkey1_pediatric.Q3 = txtQ3.Text.Trim();
                    objkey1_pediatric.Q4 = txtQ4.Text.Trim();
                    objkey1_pediatric.Q5 = txtQ5.Text.Trim();
                    objkey1_pediatric.Q6 = txtQ6.Text.Trim();
                    objkey1_pediatric.Q7 = txtQ7.Text.Trim();
                    objkey1_pediatric.Q8 = txtQ8.Text.Trim();
                    objkey1_pediatric.Q9 = txtQ9.Text.Trim();
                    objkey1_pediatric.Q10 = txtQ10.Text.Trim();
                    objkey1_pediatric.Q11 = txtQ11.Text.Trim();
                    objkey1_pediatric.Q12 = txtQ12.Text.Trim();
                    objkey1_pediatric.Q13 = txtQ13.Text.Trim();
                    objkey1_pediatric.Q14 = txtQ14.Text.Trim();
                    objkey1_pediatric.Q15 = txtQ15.Text.Trim();
                    objkey1_pediatric.Q16 = txtQ16.Text.Trim();
                    objkey1_pediatric.Q17 = txtQ17.Text.Trim();
                    objkey1_pediatric.Q18 = txtQ18.Text.Trim();
                    objkey1_pediatric.Q19 = txtQ19.Text.Trim();
                    objkey1_pediatric.Q20 = txtQ20.Text.Trim();
                    objkey1_pediatric.Q21 = txtQ21.Text.Trim();
                    objkey1_pediatric.Q22 = txtQ22.Text.Trim();
                    objkey1_pediatric.Q23 = txtQ23.Text.Trim();
                    objkey1_pediatric.Q24 = txtQ24.Text.Trim();
                    objkey1_pediatric.Q25 = txtQ25.Text.Trim();
                    objkey1_pediatric.Q26 = txtQ26.Text.Trim();
                    objkey1_pediatric.Q27 = txtQ27.Text.Trim();
                    objkey1_pediatric.Q28 = txtQ28.Text.Trim();
                    objkey1_pediatric.Q29 = txtQ29.Text.Trim();
                    objkey1_pediatric.Q30 = txtQ30.Text.Trim();
                    objkey1_pediatric.Q31 = txtQ31.Text.Trim();
                    objkey1_pediatric.Q32 = txtQ32.Text.Trim();
                    objkey1_pediatric.Q33 = txtQ33.Text.Trim();
                    objkey1_pediatric.Q34 = txtQ34.Text.Trim();
                    objkey1_pediatric.KeyStroke = TotalKeystrokes().ToInt();
                    objkey1_pediatric.userid = Constance.GC_USERID;
                    objkey1_pediatric.Store();
                    imagemaster updateImagemasterkey1 = new imagemaster(lngImageID.ToInt());
                    updateImagemasterkey1.Key1 = 2;
                    updateImagemasterkey1.Store();

                    Constance.ImageOutTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                }
                else if (Process == Constance.GC_PROCESS_KEY2)
                {
                    key2_pediatric checkkey2 = new key2_pediatric().isImageIDExists(lngImageID);
                    int Key2_PEDIATRICID = (checkkey2 == null) ? 0 : checkkey2.Key2_PEDIATRICID;
                    key2_pediatric objkey2_pediatric = new key2_pediatric(Key2_PEDIATRICID);
                    objkey2_pediatric.ImageId = lngImageID.ToInt();
                    objkey2_pediatric.Image_Number = ImagePath;
                    objkey2_pediatric.BARCODE = txtbarcode.Text.Trim();
                    objkey2_pediatric.Q1 = txtQ1.Text.Trim();
                    objkey2_pediatric.Q2 = txtQ2.Text.Trim();
                    objkey2_pediatric.Q3 = txtQ3.Text.Trim();
                    objkey2_pediatric.Q4 = txtQ4.Text.Trim();
                    objkey2_pediatric.Q5 = txtQ5.Text.Trim();
                    objkey2_pediatric.Q6 = txtQ6.Text.Trim();
                    objkey2_pediatric.Q7 = txtQ7.Text.Trim();
                    objkey2_pediatric.Q8 = txtQ8.Text.Trim();
                    objkey2_pediatric.Q9 = txtQ9.Text.Trim();
                    objkey2_pediatric.Q10 = txtQ10.Text.Trim();
                    objkey2_pediatric.Q11 = txtQ11.Text.Trim();
                    objkey2_pediatric.Q12 = txtQ12.Text.Trim();
                    objkey2_pediatric.Q13 = txtQ13.Text.Trim();
                    objkey2_pediatric.Q14 = txtQ14.Text.Trim();
                    objkey2_pediatric.Q15 = txtQ15.Text.Trim();
                    objkey2_pediatric.Q16 = txtQ16.Text.Trim();
                    objkey2_pediatric.Q17 = txtQ17.Text.Trim();
                    objkey2_pediatric.Q18 = txtQ18.Text.Trim();
                    objkey2_pediatric.Q19 = txtQ19.Text.Trim();
                    objkey2_pediatric.Q20 = txtQ20.Text.Trim();
                    objkey2_pediatric.Q21 = txtQ21.Text.Trim();
                    objkey2_pediatric.Q22 = txtQ22.Text.Trim();
                    objkey2_pediatric.Q23 = txtQ23.Text.Trim();
                    objkey2_pediatric.Q24 = txtQ24.Text.Trim();
                    objkey2_pediatric.Q25 = txtQ25.Text.Trim();
                    objkey2_pediatric.Q26 = txtQ26.Text.Trim();
                    objkey2_pediatric.Q27 = txtQ27.Text.Trim();
                    objkey2_pediatric.Q28 = txtQ28.Text.Trim();
                    objkey2_pediatric.Q29 = txtQ29.Text.Trim();
                    objkey2_pediatric.Q30 = txtQ30.Text.Trim();
                    objkey2_pediatric.Q31 = txtQ31.Text.Trim();
                    objkey2_pediatric.Q32 = txtQ32.Text.Trim();
                    objkey2_pediatric.Q33 = txtQ33.Text.Trim();
                    objkey2_pediatric.Q34 = txtQ34.Text.Trim();
                    objkey2_pediatric.KeyStroke = TotalKeystrokes().ToInt();
                    objkey2_pediatric.userid = Constance.GC_USERID;
                    objkey2_pediatric.Store();
                    imagemaster updateImagemasterkey2 = new imagemaster(lngImageID.ToInt());
                    updateImagemasterkey2.Key2 = 2;
                    updateImagemasterkey2.Store();

                    Constance.ImageOutTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                }
                else if (Process == Constance.GC_PROCESS_COMAPREQC)
                {
                    compareqc_pediatric checkkeyqc = new compareqc_pediatric().isImageIDExists(lngImageID);
                    int Compareqc_PEDIATRICID = (checkkeyqc == null) ? 0 : checkkeyqc.Compareqc_PEDIATRICID;
                    compareqc_pediatric objkeyqc_pediatric = new compareqc_pediatric(Compareqc_PEDIATRICID);
                    objkeyqc_pediatric.ImageId = lngImageID.ToInt();
                    objkeyqc_pediatric.Image_Number = ImagePath;
                    objkeyqc_pediatric.BARCODE = txtbarcode.Text.Trim();
                    objkeyqc_pediatric.Q1 = txtQ1.Text.Trim();
                    objkeyqc_pediatric.Q2 = txtQ2.Text.Trim();
                    objkeyqc_pediatric.Q3 = txtQ3.Text.Trim();
                    objkeyqc_pediatric.Q4 = txtQ4.Text.Trim();
                    objkeyqc_pediatric.Q5 = txtQ5.Text.Trim();
                    objkeyqc_pediatric.Q6 = txtQ6.Text.Trim();
                    objkeyqc_pediatric.Q7 = txtQ7.Text.Trim();
                    objkeyqc_pediatric.Q8 = txtQ8.Text.Trim();
                    objkeyqc_pediatric.Q9 = txtQ9.Text.Trim();
                    objkeyqc_pediatric.Q10 = txtQ10.Text.Trim();
                    objkeyqc_pediatric.Q11 = txtQ11.Text.Trim();
                    objkeyqc_pediatric.Q12 = txtQ12.Text.Trim();
                    objkeyqc_pediatric.Q13 = txtQ13.Text.Trim();
                    objkeyqc_pediatric.Q14 = txtQ14.Text.Trim();
                    objkeyqc_pediatric.Q15 = txtQ15.Text.Trim();
                    objkeyqc_pediatric.Q16 = txtQ16.Text.Trim();
                    objkeyqc_pediatric.Q17 = txtQ17.Text.Trim();
                    objkeyqc_pediatric.Q18 = txtQ18.Text.Trim();
                    objkeyqc_pediatric.Q19 = txtQ19.Text.Trim();
                    objkeyqc_pediatric.Q20 = txtQ20.Text.Trim();
                    objkeyqc_pediatric.Q21 = txtQ21.Text.Trim();
                    objkeyqc_pediatric.Q22 = txtQ22.Text.Trim();
                    objkeyqc_pediatric.Q23 = txtQ23.Text.Trim();
                    objkeyqc_pediatric.Q24 = txtQ24.Text.Trim();
                    objkeyqc_pediatric.Q25 = txtQ25.Text.Trim();
                    objkeyqc_pediatric.Q26 = txtQ26.Text.Trim();
                    objkeyqc_pediatric.Q27 = txtQ27.Text.Trim();
                    objkeyqc_pediatric.Q28 = txtQ28.Text.Trim();
                    objkeyqc_pediatric.Q29 = txtQ29.Text.Trim();
                    objkeyqc_pediatric.Q30 = txtQ30.Text.Trim();
                    objkeyqc_pediatric.Q31 = txtQ31.Text.Trim();
                    objkeyqc_pediatric.Q32 = txtQ32.Text.Trim();
                    objkeyqc_pediatric.Q33 = txtQ33.Text.Trim();
                    objkeyqc_pediatric.Q34 = txtQ34.Text.Trim();
                    objkeyqc_pediatric.KeyStroke = TotalKeystrokes().ToInt();
                    objkeyqc_pediatric.userid = Constance.GC_USERID;
                    objkeyqc_pediatric.Store();
                    imagemaster updateImagemasterkeyqc = new imagemaster(lngImageID.ToInt());
                    updateImagemasterkeyqc.CompareQC = 2;
                    updateImagemasterkeyqc.Store();

                    Constance.ImageOutTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                }

                worklog SaveWorklog = new worklog();
                SaveWorklog.UserID = Constance.GC_USERID;
                SaveWorklog.ImageID = lngImageID.ToInt();
                SaveWorklog.In = Convert.ToDateTime(Constance.ImageInTime);
                SaveWorklog.Out = Convert.ToDateTime(Constance.ImageOutTime);
                SaveWorklog.Process = Process;
                SaveWorklog.EXE_Status = Constance.GC_PROJ_VERSIONSTATUS;
                SaveWorklog.Store();

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveandLoad();
        }

        private bool txtChanged(object Sender, System.EventArgs e, Control ObjControl)
        {
            try
            {
                if ((ObjControl is TextBox) || (ObjControl is ComboBox) || (ObjControl is CheckBox))
                {
                    switch (ObjControl.Name)
                    {
                        case GC_FIELDS_BARCODE:
                            if (txtbarcode.TextLength == txtbarcode.MaxLength)
                            {
                                txtQ1.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1:

                            if (txtQ1.TextLength == txtQ1.MaxLength)
                            {
                                txtQ1.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2:

                            if (txtQ2.TextLength == txtQ2.MaxLength)
                            {
                                txtQ3.Focus();
                            }
                            break;
                        case GC_FIELDS_Q3:
                            if (txtQ3.TextLength == txtQ3.MaxLength)
                            {
                                txtQ4.Focus();
                            }
                            break;
                        case GC_FIELDS_Q4:
                            if (txtQ4.Text.Length == txtQ4.MaxLength)
                            {
                                txtQ5.Focus();
                            }
                            break;
                        case GC_FIELDS_Q5:
                            if (txtQ5.TextLength == txtQ5.MaxLength)
                            {
                                txtQ6.Focus();
                            }
                            break;
                        case GC_FIELDS_Q6:
                            if (txtQ6.TextLength == txtQ6.MaxLength)
                            {
                                txtQ7.Focus();
                            }
                            break;
                        case GC_FIELDS_Q7:
                            if (txtQ7.TextLength == txtQ7.MaxLength)
                            {
                                txtQ8.Focus();
                            }
                            break;
                        case GC_FIELDS_Q8:
                            if (txtQ8.TextLength == txtQ8.MaxLength)
                            {
                                txtQ9.Focus();
                            }
                            break;
                        case GC_FIELDS_Q9:
                            if (txtQ9.TextLength == txtQ9.MaxLength)
                            {
                                txtQ10.Focus();
                            }
                            break;
                        case GC_FIELDS_Q10:
                            if (txtQ10.TextLength == txtQ10.MaxLength)
                            {
                                txtQ11.Focus();
                            }
                            break;
                        case GC_FIELDS_Q11:
                            if (txtQ11.TextLength == txtQ11.MaxLength)
                            {
                                txtQ12.Focus();
                            }
                            break;
                        case GC_FIELDS_Q12:
                            if (txtQ12.TextLength == txtQ12.MaxLength)
                            {
                                txtQ13.Focus();
                            }
                            break;
                        case GC_FIELDS_Q13:
                            if (txtQ13.Text.Length == txtQ13.MaxLength)
                            {
                                txtQ14.Focus();
                            }
                            break;
                        case GC_FIELDS_Q14:
                            if (txtQ14.TextLength == txtQ14.MaxLength)
                            {
                                txtQ15.Focus();
                            }
                            break;
                        case GC_FIELDS_Q15:
                            if (txtQ15.TextLength == txtQ15.MaxLength)
                            {
                                txtQ16.Focus();
                            }
                            break;
                        case GC_FIELDS_Q16:
                            if (txtQ16.TextLength == txtQ16.MaxLength)
                            {
                                txtQ17.Focus();
                            }
                            break;
                        case GC_FIELDS_Q17:
                            if (txtQ17.TextLength == txtQ17.MaxLength)
                            {
                                txtQ18.Focus();
                            }
                            break;
                        case GC_FIELDS_Q18:
                            if (txtQ18.TextLength == txtQ18.MaxLength)
                            {
                                txtQ19.Focus();
                            }
                            break;
                        case GC_FIELDS_Q19:
                            if (txtQ19.TextLength == txtQ19.MaxLength)
                            {
                                txtQ20.Focus();
                            }
                            break;
                        case GC_FIELDS_Q20:
                            if (txtQ20.TextLength == txtQ20.MaxLength)
                            {
                                txtQ21.Focus();
                            }
                            break;
                        case GC_FIELDS_Q21:
                            if (txtQ21.TextLength == txtQ21.MaxLength)
                            {
                                txtQ22.Focus();
                            }
                            break;
                        case GC_FIELDS_Q22:
                            if (txtQ22.Text.Length == txtQ22.MaxLength)
                            {
                                txtQ23.Focus();
                            }
                            break;
                        case GC_FIELDS_Q23:
                            if (txtQ23.Text.Length == txtQ23.MaxLength)
                            {
                                txtQ24.Focus();
                            }
                            break;
                        case GC_FIELDS_Q24:
                            if (txtQ24.Text.Length == txtQ24.MaxLength)
                            {
                                txtQ25.Focus();
                            }
                            break;
                        case GC_FIELDS_Q25:
                            if (txtQ25.Text.Length == txtQ25.MaxLength)
                            {
                                txtQ26.Focus();
                            }
                            break;
                        case GC_FIELDS_Q26:
                            if (txtQ26.Text.Length == txtQ26.MaxLength)
                            {
                                txtQ27.Focus();
                            }
                            break;
                        case GC_FIELDS_Q27:
                            if (txtQ27.Text.Length == txtQ27.MaxLength)
                            {
                                txtQ28.Focus();
                            }
                            break;
                        case GC_FIELDS_Q28:
                            if (txtQ28.Text.Length == txtQ28.MaxLength)
                            {
                                txtQ29.Focus();
                            }
                            break;
                        case GC_FIELDS_Q29:
                            if (txtQ29.Text.Length == txtQ29.MaxLength)
                            {
                                txtQ30.Focus();
                            }
                            break;
                        case GC_FIELDS_Q30:
                            if (txtQ30.Text.Length == txtQ30.MaxLength)
                            {
                                txtQ31.Focus();
                            }
                            break;
                        case GC_FIELDS_Q31:
                            if (txtQ31.Text.Length == txtQ31.MaxLength)
                            {
                                txtQ32.Focus();
                            }
                            break;
                        case GC_FIELDS_Q32:
                            if (txtQ32.Text.Length == txtQ32.MaxLength)
                            {
                                txtQ33.Focus();
                            }
                            break;
                        case GC_FIELDS_Q33:
                            if (txtQ33.Text.Length == txtQ33.MaxLength)
                            {
                                txtQ34.Focus();
                            }
                            break;
                        case GC_FIELDS_Q34:
                            if (txtQ34.Text.Length == txtQ34.MaxLength)
                            {
                                btnSave.Focus();
                            }
                            break;


                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        private bool txtEnter(object Sender, System.EventArgs e, Control ObjControl)
        {
            try
            {
                if ((ObjControl is TextBox) || (ObjControl is ComboBox) || (ObjControl is CheckBox))
                {
                    switch (ObjControl.Name)
                    {
                        case GC_FIELDS_BARCODE:
                            txtDescription.Text = "[Unique ID provided in barcode file]";
                            lblinstruction.Visible = false;
                            txtinstruction.Visible = false;
                            txtbarcode.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.BARCODE; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.BARCODE; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.BARCODE; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 100));
                            break;

                        case GC_FIELDS_Q1:
                            lblinstruction.Visible = false;
                            txtinstruction.Visible = false;
                            txtDescription.Text = "[Proceed with zero where appropriate (include your decimal: 6.9 or 0.9)]";

                            txtQ1.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q1; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q1; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q1; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 100));
                            break;

                        case GC_FIELDS_Q2:
                              lblinstruction.Visible = false;
                            txtinstruction.Visible = false;
                            txtDescription.Text = "[Number member entered. Proceed with zero where appropriate]";
                            txtQ2.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q2; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q2; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q2; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 100));
                            break;

                        case GC_FIELDS_Q3:
                              lblinstruction.Visible = false;
                            txtinstruction.Visible = false;
                            txtDescription.Text = "[1= yes, 2= no, 3= Don’t Know]";
                            txtQ3.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q3; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q3; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q3; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 100));
                            break;

                        case GC_FIELDS_Q4:
                              lblinstruction.Visible = false;
                            txtinstruction.Visible = false;
                            txtDescription.Text = "[1= 1 , 2= 2-3, 3= 4 or more]";
                            txtQ4.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q4; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q4; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q4; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q5:
                              lblinstruction.Visible = false;
                            txtinstruction.Visible = false;
                            txtDescription.Text = "[1= yes, 2= no]";
                            txtQ5.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q5; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q5; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q5; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q6:
                              lblinstruction.Visible = false;
                            txtinstruction.Visible = false;
                            txtDescription.Text = "[1= yes, 2= no]";
                            txtQ6.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q6; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q6; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q6; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q7:
                              lblinstruction.Visible = false;
                            txtinstruction.Visible = false;
                            txtDescription.Text = "[1= yes, 2= no]";
                            txtQ7.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q7; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q7; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q7; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q8:
                              lblinstruction.Visible = false;
                            txtinstruction.Visible = false;
                            txtDescription.Text = "[1= yes, 2= no]";
                            txtQ8.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q8; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q8; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q8; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q9:

                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[Asthma]";
                            txtQ9.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q9; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q9; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q9; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 10));
                            break;

                        case GC_FIELDS_Q10:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[cerebral palsy or Developement Delay]";
                            txtQ10.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q10; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q10; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q10; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 10));
                            break;

                        case GC_FIELDS_Q11:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                            txtinstruction.Text = "[Diabetes or other blood sugar problems]";
                            txtQ11.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q11; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q11; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q11; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 10));
                            break;

                        case GC_FIELDS_Q12:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[sickle cell Disease]";
                            txtQ12.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q12; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q12; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q12; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 10));
                            break;

                        case GC_FIELDS_Q13:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[Cancer]";
                            txtQ13.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q13; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q13; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q13; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 10));
                            break;

                        case GC_FIELDS_Q14:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[HIV/AIDS]";
                            txtQ14.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q14; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q14; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q14; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 10));
                            break;

                        case GC_FIELDS_Q15:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[Cogential Deformalities or Birth Defects]";
                            txtQ15.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q15; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q15; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q15; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 10));
                            break;

                        case GC_FIELDS_Q16:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[Depression]";
                            txtQ16.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q16; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q16; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q16; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 10));
                            break;

                        case GC_FIELDS_Q17:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[Bi-Polar Disorder]";
                            txtQ17.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q17; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q17; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q17; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 10));
                            break;

                        case GC_FIELDS_Q18:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[Schizophernia]";
                            txtQ18.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q18; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q18; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q18; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 10));
                            break;

                        case GC_FIELDS_Q19:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[other Condition]";
                            txtQ19.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q19; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q19; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q19; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 10));
                            break;

                        case GC_FIELDS_Q20:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = false;
                            txtinstruction.Visible = false;
                            txtQ20.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q20; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q20; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q20; }
                            }

                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 100));
                            break;

                        case GC_FIELDS_Q21:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = false;
                            txtinstruction.Visible = false;
                            txtQ21.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q21; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q21; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q21; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 100));
                            break;

                        case GC_FIELDS_Q22:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[Private Nurse]";
                            txtQ22.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q22; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q22; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q22; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q23:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[Home HealthAid]";

                            txtQ23.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q23; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q23; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q23; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q24:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[Speach Therapy]";
                            txtQ24.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q24; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q24; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q24; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q25:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[Physical Therapy]";
                            txtQ25.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q25; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q25; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q25; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q26:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[Occupational Thetapy]";
                            txtQ25.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q26; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q26; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q26; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q27:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[Other Therapy]";
                            txtQ25.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q27; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q27; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q27; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q28:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[Bottled Oxygen]";
                            txtQ25.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q28; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q28; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q28; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q29:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[Wheel Chair]";
                            txtQ25.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q29; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q29; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q29; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q30:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[Apnea Monitor]";
                            txtQ25.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q30; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q30; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q30; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q31:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = true;
                            txtinstruction.Visible = true;
                            txtinstruction.Text = "[Other MedicalEquipment]";
                            txtQ25.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q31; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q31; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q31; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q32:
                            txtDescription.Text = "[ 1= yes, 2= no, 3= Unknown ]";
                              lblinstruction.Visible = false;
                            txtinstruction.Visible = false;

                            txtQ25.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q32; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q32; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q32; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 50));
                            break;

                        case GC_FIELDS_Q33:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = false;
                            txtinstruction.Visible = false;
                            txtQ25.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q33; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q33; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q33; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 50));
                            break;

                        case GC_FIELDS_Q34:
                            txtDescription.Text = "[ 1= yes, 2= no]";
                              lblinstruction.Visible = false;
                            txtinstruction.Visible = false;
                            txtQ25.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q34; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q34; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q34; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 50));
                            break;

                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private bool txtKeyPress(object Sender, System.Windows.Forms.KeyPressEventArgs e, Control ObjControl)
        {
            try
            {
                if ((ObjControl is TextBox) || (ObjControl is ComboBox))
                {
                    e.KeyChar = char.ToUpper(e.KeyChar);

                    switch (ObjControl.Name)
                    {
                        case GC_FIELDS_BARCODE:
                            if (char.IsDigit(e.KeyChar) || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;
                        case GC_FIELDS_Q1:
                        case GC_FIELDS_Q2:
                            if (char.IsDigit(e.KeyChar) || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back) || char.IsWhiteSpace(e.KeyChar) || char.IsPunctuation(e.KeyChar) || char.IsSymbol(e.KeyChar))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;
                        case GC_FIELDS_Q5:
                        case GC_FIELDS_Q6:
                        case GC_FIELDS_Q7:
                        case GC_FIELDS_Q8:                

                        case GC_FIELDS_Q20:
                        case GC_FIELDS_Q21:                      
                 
                     
                        case GC_FIELDS_Q33:
                        case GC_FIELDS_Q34:
                            if (e.KeyChar == '1' || e.KeyChar == '2' || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;

                        case GC_FIELDS_Q9:
                        case GC_FIELDS_Q10:
                        case GC_FIELDS_Q11:
                        case GC_FIELDS_Q12:
                        case GC_FIELDS_Q13:
                        case GC_FIELDS_Q14:
                        case GC_FIELDS_Q15:
                        case GC_FIELDS_Q16:
                        case GC_FIELDS_Q17:
                        case GC_FIELDS_Q18:
                        case GC_FIELDS_Q19:
                        case GC_FIELDS_Q22:
                        case GC_FIELDS_Q23:
                        case GC_FIELDS_Q24:
                        case GC_FIELDS_Q25:
                        case GC_FIELDS_Q26:
                        case GC_FIELDS_Q27:
                        case GC_FIELDS_Q28:
                        case GC_FIELDS_Q29:
                        case GC_FIELDS_Q30:
                        case GC_FIELDS_Q31:
                             if (e.KeyChar == '1' || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;

                        case GC_FIELDS_Q32:
                        case GC_FIELDS_Q3:
                            if (e.KeyChar == '1' || e.KeyChar == '2' || e.KeyChar == '3' || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;
                        case GC_FIELDS_Q4:
                            if (e.KeyChar == '1' || e.KeyChar == '2' || e.KeyChar == '3' || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;



                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void txtbarcode_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtbarcode);
        }

        private void txtbarcode_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtbarcode);
        }

        private void txtbarcode_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtbarcode);
        }

        private void txtQ1_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1);
        }

        private void txtQ1_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1);
        }

        private void txtQ1_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ1);
        }

        private void txtQ2_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2);
        }

        private void txtQ2_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2);
        }

        private void txtQ2_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ2);
        }

        private void txtQ3_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3);
        }

        private void txtQ3_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3);
        }

        private void txtQ3_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ3);
        }

        private void txtQ4_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ4);
        }

        private void txtQ4_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ4);
        }

        private void txtQ4_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ4);
        }

        private void txtQ5_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ5);
        }

        private void txtQ5_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ5);
        }

        private void txtQ5_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ5);
        }

        private void txtQ6_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ6);
        }

        private void txtQ6_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ6);
        }

        private void txtQ6_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ6);
        }

        private void txtQ7_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ7);
        }

        private void txtQ7_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ7);
        }

        private void txtQ7_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ7);
        }

        private void txtQ8_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ8);
        }

        private void txtQ8_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ8);
        }

        private void txtQ8_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ8);
        }

        private void txtQ9_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ9);
        }

        private void txtQ9_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ9);
        }

        private void txtQ9_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ9);
        }

        private void txtQ10_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ10);
        }

        private void txtQ10_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ10);
        }

        private void txtQ10_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ10);
        }

        private void txtQ11_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ11);
        }

        private void txtQ11_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ11);
        }

        private void txtQ11_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ11);
        }

        private void txtQ12_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ12);
        }

        private void txtQ12_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ12);
        }

        private void txtQ12_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ12);
        }

        private void txtQ13_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ13);
        }

        private void txtQ13_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ13);
        }

        private void txtQ13_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ13);
        }

        private void txtQ14_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ14);
        }

        private void txtQ14_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ14);
        }

        private void txtQ14_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ14);
        }

        private void txtQ15_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ15);
        }

        private void txtQ15_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ15);
        }

        private void txtQ15_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ15);
        }

        private void txtQ16_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ16);
        }

        private void txtQ16_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ16);
        }

        private void txtQ16_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ16);
        }

        private void txtQ17_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ17);
        }

        private void txtQ17_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ17);
        }

        private void txtQ17_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ17);
        }

        private void txtQ18_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ18);
        }

        private void txtQ18_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ18);
        }

        private void txtQ18_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ18);
        }

        private void txtQ19_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ19);
        }

        private void txtQ19_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ19);
        }

        private void txtQ19_Enter(object sender, EventArgs e)
        {
            IGImageViewer.PrevImage(sender, e);
            txtEnter(sender, e, txtQ19);
        }

        private void txtQ20_TextChanged(object sender, EventArgs e)
        {

            txtChanged(sender, e, txtQ20);
        }

        private void txtQ20_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ20);
        }

        private void txtQ20_Enter(object sender, EventArgs e)
        {
            IGImageViewer.NextImage(sender, e);
            txtEnter(sender, e, txtQ20);
        }

        private void txtQ21_TextChanged(object sender, EventArgs e)
        {
            IGImageViewer.NextImage(sender, e);
            txtChanged(sender, e, txtQ21);
        }

        private void txtQ21_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ21);
        }

        private void txtQ21_Enter(object sender, EventArgs e)
        {
            IGImageViewer.NextImage(sender, e);
            txtEnter(sender, e, txtQ21);
        }

        private void txtQ22_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ22);
        }

        private void txtQ22_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ22);
        }

        private void txtQ22_Enter(object sender, EventArgs e)
        {
            IGImageViewer.NextImage(sender, e);
            txtEnter(sender, e, txtQ22);
        }

        private void txtQ23_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ23);
        }

        private void txtQ23_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ23);
        }

        private void txtQ23_Enter(object sender, EventArgs e)
        {
            IGImageViewer.NextImage(sender, e);
            txtEnter(sender, e, txtQ23);
        }

        private void txtQ24_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ24);
        }

        private void txtQ24_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ24);
        }

        private void txtQ24_Enter(object sender, EventArgs e)
        {
            IGImageViewer.NextImage(sender, e);
            txtEnter(sender, e, txtQ24);
        }

        private void txtQ25_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ25);
        }

        private void txtQ25_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ25);
        }

        private void txtQ25_Enter(object sender, EventArgs e)
        {
            IGImageViewer.NextImage(sender, e);
            txtEnter(sender, e, txtQ25);
        }

        private void txtQ26_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ26);
        }

        private void txtQ26_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ26);
        }

        private void txtQ26_Enter(object sender, EventArgs e)
        {
            IGImageViewer.NextImage(sender, e);
            txtEnter(sender, e, txtQ26);
        }

        private void txtQ27_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ27);
        }

        private void txtQ27_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ27);
        }

        private void txtQ27_Enter(object sender, EventArgs e)
        {
            IGImageViewer.NextImage(sender, e);
            txtEnter(sender, e, txtQ27);
        }

        private void txtQ28_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ28);
        }

        private void txtQ28_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ28);
        }

        private void txtQ28_Enter(object sender, EventArgs e)
        {
            IGImageViewer.NextImage(sender, e);
            txtEnter(sender, e, txtQ28);
        }

        private void txtQ29_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ29);
        }

        private void txtQ29_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ29);
        }

        private void txtQ29_Enter(object sender, EventArgs e)
        {
            IGImageViewer.NextImage(sender, e);
            txtEnter(sender, e, txtQ29);
        }

        private void txtQ30_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ30);
        }

        private void txtQ30_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ30);
        }

        private void txtQ30_Enter(object sender, EventArgs e)
        {
            IGImageViewer.NextImage(sender, e);
            txtEnter(sender, e, txtQ30);
        }

        private void txtQ31_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ31);
        }

        private void txtQ31_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ31);
        }

        private void txtQ31_Enter(object sender, EventArgs e)
        {
            IGImageViewer.NextImage(sender, e);
            txtEnter(sender, e, txtQ31);
        }

        private void txtQ32_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ32);
        }

        private void txtQ32_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ32);
        }

        private void txtQ32_Enter(object sender, EventArgs e)
        {
            IGImageViewer.NextImage(sender, e);
            txtEnter(sender, e, txtQ32);
        }

        private void txtQ33_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ33);
        }

        private void txtQ33_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ33);
        }

        private void txtQ33_Enter(object sender, EventArgs e)
        {
            IGImageViewer.NextImage(sender, e);
            txtEnter(sender, e, txtQ33);
        }

        private void txtQ34_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ34);
        }

        private void txtQ34_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ34);
        }

        private void txtQ34_Enter(object sender, EventArgs e)
        {
            IGImageViewer.NextImage(sender, e);
            txtEnter(sender, e, txtQ34);
        }

        private void Healthtel_pediatric_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Alt & e.KeyCode == Keys.Right)
            {
                IGImageViewer.NextImage(sender, e);
            }
            else if (e.Alt & e.KeyCode == Keys.Left)
            {
                IGImageViewer.PrevImage(sender, e);
            }
            else if (e.Control & (e.KeyCode == Keys.Oemplus || e.KeyCode == Keys.Add))
            {
                IGImageViewer.ZoomIn(sender, e);
            }
            else if (e.Control & (e.KeyCode == Keys.OemMinus || e.KeyCode == Keys.Subtract))
            {
                IGImageViewer.ZoomOut(sender, e);
            }
            else if (e.Control == true & (e.KeyCode == Keys.D1 | e.KeyCode == Keys.NumPad1))
            {
                IGImageViewer.RotateLeft(sender, e);
            }
            else if (e.Control == true & (e.KeyCode == Keys.D2 | e.KeyCode == Keys.NumPad2))
            {
                IGImageViewer.RotateRight(sender, e);
            }
            else if (e.Control & e.KeyCode == Keys.Right)
            {
                IGImageViewer.PageRight();
            }
            else if (e.Control & e.KeyCode == Keys.Left)
            {
                IGImageViewer.PageLeft();
            }
            else if (e.Control & e.KeyCode == Keys.Down)
            {
                IGImageViewer.PageDown();
            }
            else if (e.Control & e.KeyCode == Keys.Up)
            {
                IGImageViewer.PageUp();
            }
            else if (e.Control & e.KeyCode == Keys.PageUp)
            {
                IGImageViewer.PageHome();
            }
            else if (e.Control & e.KeyCode == Keys.Next)
            {
                IGImageViewer.PageEnd();
            }
            //else if (e.Control & e.KeyCode == Keys.Home)
            //{
            //    IGImageViewer.firstpage();
            //}
            //else if (e.Control & e.KeyCode == Keys.End)
            //{
            //    IGImageViewer.lastpage();
            //}
            else if (e.KeyCode == Keys.F5)
            {
                strImageFit = IGImageViewer.ImageHorizontalScroll.Value + "," + IGImageViewer.ImageVerticalScroll.Value;
                strImageSize = IGImageViewer.ImageSize.Width + "," + IGImageViewer.ImageSize.Height;
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageFit, strImageFit);
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageSize, strImageSize);
            }
            else if (e.KeyCode == Keys.F6)
            {
                //IGImageViewer.resizeimg();
                strImageFit = IGImageViewer.ImageHorizontalScroll.Minimum + "," + IGImageViewer.ImageVerticalScroll.Minimum;
                strImageSize = "";
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageFit, strImageFit);
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageSize, strImageSize);

                IGImageViewer.ImageClear();
                IGImageViewer.ImageName = Image.ImagePath;
                IGImageViewer.LoadImage();
            }
            else if (e.Control & e.KeyCode == Keys.F7)
            {
                //IGImageViewer.imgfitwidth();
            }
            else if (e.Control & e.KeyCode == Keys.F8)
            {
                //IGImageViewer.imgfitscreen();
            }
            else if (e.KeyCode == Keys.F1)
            {
                if (Process.ToUpper() == "COMPAREQC")
                {
                    EnableFields();
                }
                else
                {
                    string activetxt = ActiveControl.Name;
                    
                    if (activetxt == txtQ9.Name || activetxt == txtQ10.Name || activetxt == txtQ11.Name || activetxt == txtQ12.Name || activetxt == txtQ13.Name || activetxt == txtQ14.Name || activetxt == txtQ15.Name || activetxt == txtQ16.Name || activetxt == txtQ17.Name || activetxt == txtQ18.Name || activetxt == txtQ19.Name)
                    {
                        txtQ20.Focus();
                    }
                    if (activetxt == txtQ22.Name || activetxt == txtQ23.Name || activetxt == txtQ24.Name || activetxt == txtQ25.Name || activetxt == txtQ26.Name || activetxt == txtQ27.Name || activetxt == txtQ28.Name || activetxt == txtQ29.Name || activetxt == txtQ30.Name || activetxt == txtQ31.Name)
                    {
                        txtQ32.Focus();
                    }
                  
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void EnableFields()
        {

            txtbarcode.Enabled = true;
            txtQ1.Enabled = true;
            txtQ2.Enabled = true;
            txtQ3.Enabled = true;
            txtQ4.Enabled = true;
            txtQ5.Enabled = true;
            txtQ6.Enabled = true;
            txtQ7.Enabled = true;
            txtQ8.Enabled = true;
            txtQ9.Enabled = true;
            txtQ10.Enabled = true;
            txtQ11.Enabled = true;
            txtQ12.Enabled = true;
            txtQ13.Enabled = true;
            txtQ14.Enabled = true;
            txtQ15.Enabled = true;
            txtQ16.Enabled = true;
            txtQ17.Enabled = true;
            txtQ18.Enabled = true;
            txtQ19.Enabled = true;
            txtQ20.Enabled = true;
            txtQ21.Enabled = true;
            txtQ22.Enabled = true;
            txtQ23.Enabled = true;
            txtQ24.Enabled = true;
            txtQ25.Enabled = true;
            txtQ26.Enabled = true;
            txtQ27.Enabled = true;
            txtQ28.Enabled = true;
            txtQ29.Enabled = true;
            txtQ30.Enabled = true;
            txtQ31.Enabled = true;
            txtQ32.Enabled = true;
            txtQ33.Enabled = true;
            txtQ34.Enabled = true;
          
        }
    }

}
