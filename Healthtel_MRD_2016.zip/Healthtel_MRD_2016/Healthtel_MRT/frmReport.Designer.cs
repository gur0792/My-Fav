﻿namespace Healthtel_MRT
{
    partial class frmReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmReport));
            this.dgvBatchWiseReport = new System.Windows.Forms.DataGridView();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.lblFromDate = new System.Windows.Forms.Label();
            this.lblToDate = new System.Windows.Forms.Label();
            this.txtfromdate = new System.Windows.Forms.MaskedTextBox();
            this.txttodate = new System.Windows.Forms.MaskedTextBox();
            this.grpDate = new System.Windows.Forms.GroupBox();
            this.btnshow = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBatchWiseReport)).BeginInit();
            this.grpDate.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvBatchWiseReport
            // 
            this.dgvBatchWiseReport.BackgroundColor = System.Drawing.Color.White;
            this.dgvBatchWiseReport.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.SandyBrown;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBatchWiseReport.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvBatchWiseReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvBatchWiseReport.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvBatchWiseReport.Location = new System.Drawing.Point(23, 67);
            this.dgvBatchWiseReport.Name = "dgvBatchWiseReport";
            this.dgvBatchWiseReport.RowHeadersVisible = false;
            this.dgvBatchWiseReport.Size = new System.Drawing.Size(1215, 525);
            this.dgvBatchWiseReport.TabIndex = 0;
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.White;
            this.btnRefresh.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRefresh.BackgroundImage")));
            this.btnRefresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRefresh.ForeColor = System.Drawing.Color.White;
            this.btnRefresh.Location = new System.Drawing.Point(881, 9);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(66, 50);
            this.btnRefresh.TabIndex = 1;
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // lblFromDate
            // 
            this.lblFromDate.AutoSize = true;
            this.lblFromDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.lblFromDate.ForeColor = System.Drawing.Color.White;
            this.lblFromDate.Location = new System.Drawing.Point(20, 19);
            this.lblFromDate.Name = "lblFromDate";
            this.lblFromDate.Size = new System.Drawing.Size(76, 14);
            this.lblFromDate.TabIndex = 2;
            this.lblFromDate.Text = "From Date";
            // 
            // lblToDate
            // 
            this.lblToDate.AutoSize = true;
            this.lblToDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.lblToDate.ForeColor = System.Drawing.Color.White;
            this.lblToDate.Location = new System.Drawing.Point(270, 18);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(58, 14);
            this.lblToDate.TabIndex = 3;
            this.lblToDate.Text = "To Date";
            // 
            // txtfromdate
            // 
            this.txtfromdate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtfromdate.Location = new System.Drawing.Point(102, 15);
            this.txtfromdate.Mask = "00/00/0000 00:00";
            this.txtfromdate.Name = "txtfromdate";
            this.txtfromdate.Size = new System.Drawing.Size(162, 22);
            this.txtfromdate.TabIndex = 4;
            // 
            // txttodate
            // 
            this.txttodate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txttodate.Location = new System.Drawing.Point(334, 15);
            this.txttodate.Mask = "00/00/0000 00:00";
            this.txttodate.Name = "txttodate";
            this.txttodate.Size = new System.Drawing.Size(153, 22);
            this.txttodate.TabIndex = 5;
            // 
            // grpDate
            // 
            this.grpDate.BackColor = System.Drawing.Color.Transparent;
            this.grpDate.Controls.Add(this.btnshow);
            this.grpDate.Controls.Add(this.lblFromDate);
            this.grpDate.Controls.Add(this.txttodate);
            this.grpDate.Controls.Add(this.lblToDate);
            this.grpDate.Controls.Add(this.txtfromdate);
            this.grpDate.Location = new System.Drawing.Point(209, 9);
            this.grpDate.Name = "grpDate";
            this.grpDate.Size = new System.Drawing.Size(503, 45);
            this.grpDate.TabIndex = 6;
            this.grpDate.TabStop = false;
            this.grpDate.Visible = false;
            // 
            // btnshow
            // 
            this.btnshow.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnshow.Location = new System.Drawing.Point(503, 13);
            this.btnshow.Name = "btnshow";
            this.btnshow.Size = new System.Drawing.Size(93, 24);
            this.btnshow.TabIndex = 6;
            this.btnshow.Text = "Show";
            this.btnshow.UseVisualStyleBackColor = true;
            this.btnshow.Visible = false;
            this.btnshow.Click += new System.EventHandler(this.btnshow_Click);
            // 
            // frmReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1260, 604);
            this.Controls.Add(this.grpDate);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.dgvBatchWiseReport);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmReport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.frmBatchWiseReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBatchWiseReport)).EndInit();
            this.grpDate.ResumeLayout(false);
            this.grpDate.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvBatchWiseReport;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Label lblFromDate;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.MaskedTextBox txtfromdate;
        private System.Windows.Forms.MaskedTextBox txttodate;
        private System.Windows.Forms.GroupBox grpDate;
        private System.Windows.Forms.Button btnshow;
    }
}