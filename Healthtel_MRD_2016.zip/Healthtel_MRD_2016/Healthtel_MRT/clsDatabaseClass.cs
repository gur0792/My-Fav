﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using MySql.Data.MySqlClient;
using System.IO;
using System.Configuration;
using System.Security.Cryptography;
using System.Text;

public class DatabaseClass
{

    static MySqlConnection SqlConn = null;
    static MySqlCommand SqlComm = null;
    static MySqlDataAdapter SqlDA = null;
    static MySqlTransaction SqlTA = null;
    public static string _Conn
    {
        get
        {
            if (!File.Exists(AppDomain.CurrentDomain.BaseDirectory + "\\Connection.Inc"))
            {

                return "";
            }
             StreamReader ORead;
            string sReadLine;
            ORead = File.OpenText((AppDomain.CurrentDomain.BaseDirectory + "\\Connection.Inc"));
            // if ((ORead.Peek !=0))
            {
                sReadLine = ORead.ReadLine();
                return sReadLine;
            }
        
            ORead.Close();

        }
    }
    // Creats a collection of parameters.
    public static MySqlParameterCollection Parameters
    {
        get { return SqlComm.Parameters; }
    }

    public DatabaseClass()
    {

    }

    // Execute an insert, update, or delete.
    public static int NonQuery(string CommandText, CommandType CommandType, MySqlParameter[] Parameters = null)
    {

        int res = 0;

        try
        {
            SqlConn = new MySqlConnection(_Conn);
            SqlConn.Open();
            SqlTA = SqlConn.BeginTransaction();

            SqlComm = new MySqlCommand(CommandText, SqlConn);

            SqlComm.CommandType = CommandType.Text;

            SqlComm.Transaction = SqlTA;
            if ((Parameters != null))
            {
                for (int i = 0; i <= Parameters.Length - 1; i++)
                {
                    SqlComm.Parameters.Add(Parameters[i]);
                }
            }

            SqlComm.CommandTimeout = 0;
            res = SqlComm.ExecuteNonQuery();

            SqlTA.Commit();
            SqlTA = null;

        }
        catch (Exception ex)
        {
            if ((SqlTA != null))
                SqlTA.Rollback();
            throw ex;
        }
        finally
        {
            SqlConn.Close();
            SqlConn.Dispose();
        }
        return res;
    }
    public static int NonQuery(string SPName, params object[] ParameterValues)
    {
        int res = 0;

        try
        {
            SqlConn = new MySqlConnection(_Conn);
            SqlConn.Open();
            SqlTA = SqlConn.BeginTransaction();
            SqlComm = new MySqlCommand(SPName, SqlConn);
            SqlComm.Transaction = SqlTA;
            SqlComm.CommandType = CommandType.StoredProcedure;
            SqlComm.CommandTimeout = 0;
            MySqlCommandBuilder.DeriveParameters(SqlComm);
            for (int i = 1; i <= ParameterValues.Length; i++)
            {
                SqlComm.Parameters[i].Value = ParameterValues[i - 1];
            }
            res = SqlComm.ExecuteNonQuery();

            SqlTA.Commit();
        }
        catch (Exception ex)
        {
            if ((SqlTA != null))
                SqlTA.Rollback();
            throw ex;
        }
        finally
        {
            SqlConn.Close();
            SqlConn.Dispose();
        }
        return res;
    }
    // Returns an SqlDateReader.
    public static MySqlDataReader GetSqlDataReader(string sql)
    {
        MySqlDataReader res = null;
        try
        {
            SqlConn = new MySqlConnection(_Conn);
            SqlConn.Open();
            SqlComm = new MySqlCommand(sql, SqlConn);
            SqlComm.CommandType = CommandType.Text;

            res = SqlComm.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            SqlConn.Close();
        }
        return res;
    }
    public static MySqlDataReader GetSqlDataReader(string sql, CommandType CommandType, MySqlParameter[] Parameters = null)
    {

        MySqlDataReader res = null;
        try
        {
            SqlConn = new MySqlConnection(_Conn);
            SqlConn.Open();
            SqlComm = new MySqlCommand(sql, SqlConn);
            SqlComm.CommandType = CommandType.Text;
            SqlComm.CommandTimeout = 0;
            if ((Parameters != null))
            {
                for (int i = 0; i <= Parameters.Length - 1; i++)
                {
                    SqlComm.Parameters.Add(Parameters[i]);
                }
            }
            res = SqlComm.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            SqlConn.Close();
        }
        return res;
    }
    public static MySqlDataReader GetSqlDataReader(string SPName, params object[] ParameterValues)
    {

        MySqlDataReader res = null;
        try
        {
            SqlConn = new MySqlConnection(_Conn);
            SqlConn.Open();
            SqlComm = new MySqlCommand(SPName, SqlConn);
            SqlComm.CommandType = CommandType.StoredProcedure;
            MySqlCommandBuilder.DeriveParameters(SqlComm);
            for (int i = 1; i <= ParameterValues.Length; i++)
            {
                SqlComm.Parameters[i].Value = ParameterValues[i - 1];
            }
            res = SqlComm.ExecuteReader();

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            SqlConn.Close();
        }

        return res;

    }
    // Returns a DataSet.
    public static DataSet GetDataset(string sql)
    {
        DataSet res = new DataSet();
        try
        {
            SqlConn = new MySqlConnection(_Conn);
            SqlConn.Open();
            SqlComm = new MySqlCommand(sql, SqlConn);
            SqlComm.CommandTimeout = 0;
            SqlComm.CommandType = CommandType.Text;

            SqlDA = new MySqlDataAdapter(SqlComm);
            SqlDA.Fill(res);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            SqlConn.Close();
        }
        return res;
    }

    public static DataSet GetDataset(string SPName, object[] ParameterValues)
    {

        DataSet res = new DataSet();
        try
        {
            SqlConn = new MySqlConnection(_Conn);
            SqlConn.Open();
            SqlComm = new MySqlCommand(SPName, SqlConn);
            SqlComm.CommandTimeout = 0;
            SqlComm.CommandType = CommandType.StoredProcedure;
            MySqlCommandBuilder.DeriveParameters(SqlComm);
            for (int i = 1; i <= ParameterValues.Length; i++)
            {
                SqlComm.Parameters[i].Value = ParameterValues[i - 1];
            }
            SqlDA = new MySqlDataAdapter(SqlComm);
            SqlDA.Fill(res);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            SqlConn.Close();
        }
        return res;
    }

    public static DataSet GetDataset(string SPName, CommandType CommandType, MySqlParameter[] Parameters = null)
    {
        DataSet res = new DataSet();
        try
        {
            SqlConn = new MySqlConnection(_Conn);
            SqlConn.Open();
            SqlTA = SqlConn.BeginTransaction();

            SqlComm = new MySqlCommand(SPName, SqlConn);

            SqlComm.CommandType = CommandType.Text;

            SqlComm.Transaction = SqlTA;
            if ((Parameters != null))
            {
                for (int i = 0; i <= Parameters.Length - 1; i++)
                {
                    SqlComm.Parameters.Add(Parameters[i]);
                }
            }
            SqlComm.CommandTimeout = 0;
            SqlDA = new MySqlDataAdapter(SqlComm);
            SqlDA.Fill(res);
            SqlTA.Commit();
            SqlTA = null;
        }
        catch (Exception ex)
        {
            if ((SqlTA != null))
                SqlTA.Rollback();
            throw ex;
        }
        finally
        {
            SqlConn.Close();
            SqlConn.Dispose();
        }
        return res;
    }

    public static List<string> GetStoredProcParams(string spName)
    {
        MySqlDataReader reader = default(MySqlDataReader);
        List<string> @params = new List<string>();
        // build the SQL query
        string sql = string.Format("select parameter_name from information_schema.parameters where specific_name = '{0}'", spName);
        try
        {
            SqlConn = new MySqlConnection(_Conn);
            SqlConn.Open();
            SqlComm = new MySqlCommand(sql, SqlConn);
            SqlComm.CommandType = CommandType.Text;
            reader = SqlComm.ExecuteReader();
            while (reader.Read())
            {
                @params.Add(reader.GetString(0));
            }

            reader.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            SqlConn.Close();
        }

        return @params;
    }

    public static object ExecuteScalar(string CommandText, CommandType CommandType, MySqlParameter[] Parameters = null)
    {

        object res = null;

        try
        {
            SqlConn = new MySqlConnection(_Conn);
            SqlConn.Open();
            SqlTA = SqlConn.BeginTransaction();
            SqlComm = new MySqlCommand(CommandText, SqlConn);
            SqlComm.CommandType = CommandType;
            SqlComm.Transaction = SqlTA;
            if ((Parameters != null))
            {
                for (int i = 0; i <= Parameters.Length - 1; i++)
                {
                    SqlComm.Parameters.Add(Parameters[i]);
                }
            }
            SqlComm.CommandTimeout = 0;
            res = SqlComm.ExecuteScalar();
            SqlTA.Commit();
            SqlTA = null;

        }
        catch (Exception ex)
        {
            if ((SqlTA != null))
                SqlTA.Rollback();
            throw ex;
        }
        finally
        {
            SqlConn.Close();
            SqlConn.Dispose();
        }
        return res;
    }

    public static object ExecuteScalar(string SPName, params object[] ParameterValues)
    {
        object res = null;

        try
        {
            SqlConn = new MySqlConnection(_Conn);
            SqlConn.Open();
            SqlTA = SqlConn.BeginTransaction();
            SqlComm = new MySqlCommand(SPName, SqlConn);
            SqlComm.Transaction = SqlTA;
            SqlComm.CommandType = CommandType.StoredProcedure;
            SqlComm.CommandTimeout = 0;
            MySqlCommandBuilder.DeriveParameters(SqlComm);
            for (int i = 1; i <= ParameterValues.Length; i++)
            {
                SqlComm.Parameters[i].Value = ParameterValues[i - 1];
            }
            res = SqlComm.ExecuteScalar();

            SqlTA.Commit();
        }
        catch (Exception ex)
        {
            if ((SqlTA != null))
                SqlTA.Rollback();
            throw ex;
        }
        finally
        {
            SqlConn.Close();
            SqlConn.Dispose();
        }
        return res;
    }

    public string Encrypt(string strText)
    {
        byte[] byKey = {
		
	};
        byte[] IV = {
		0x12,
		0x34,
		0x56,
		0x78,
		0x90,
		0xab,
		0xcd,
		0xef
	};

        try
        {
            byKey = System.Text.Encoding.UTF8.GetBytes("&%#@?,:*");

            DESCryptoServiceProvider des = new DESCryptoServiceProvider();
            byte[] inputByteArray = Encoding.UTF8.GetBytes(strText);
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(byKey, IV), CryptoStreamMode.Write);
            cs.Write(inputByteArray, 0, inputByteArray.Length);
            cs.FlushFinalBlock();
            return Convert.ToBase64String(ms.ToArray());

        }
        catch (Exception ex)
        {
            return ex.Message;
        }

    }

    public string Decrypt(string strText)
    {
        byte[] byKey = {
		
	};
        byte[] IV = {
		0x12,
		0x34,
		0x56,
		0x78,
		0x90,
		0xab,
		0xcd,
		0xef
	};
        byte[] inputByteArray = new byte[strText.Length + 1];

        try
        {
            byKey = System.Text.Encoding.UTF8.GetBytes("&%#@?,:*");
            DESCryptoServiceProvider des = new DESCryptoServiceProvider();
            inputByteArray = Convert.FromBase64String(strText);
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(byKey, IV), CryptoStreamMode.Write);

            cs.Write(inputByteArray, 0, inputByteArray.Length);
            cs.FlushFinalBlock();
            System.Text.Encoding encoding = System.Text.Encoding.UTF8;

            return encoding.GetString(ms.ToArray());

        }
        catch (Exception ex)
        {
            return ex.Message;
        }

    }
}