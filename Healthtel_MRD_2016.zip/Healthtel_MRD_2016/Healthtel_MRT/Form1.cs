﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DataAccessLayer.GlobalDB;
using DataAccessLayer;
using System.Diagnostics;
using App.Base;

namespace Healthtel_MRT
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }


        #region VariableDeclaration

        List<bpo_projects> listProjects = new List<bpo_projects>();
        bpo_versioncontrol listProjectLive = new bpo_versioncontrol();
        bpo_versioncontrol listProjectTest = new bpo_versioncontrol();

        #endregion

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtUserName.Text) && !string.IsNullOrEmpty(txtPassword.Text))
            {
               login Lgn = new login().Authentication(txtUserName.Text);

                if (Lgn == null)
                {
                    MessageBox.Show("Invalid Login");
                    return;
                }
                //BaseObject.LoggedInUser += () => Lgn;
                Constance.GC_USERID = Lgn.ID;
                Constance.GC_USERLEVEL = Lgn.userLevel.ToBool();
                Constance.GC_USERNAME = Lgn.ADName;
                HealthtelMDI parent = new HealthtelMDI();
                this.Hide();
                parent.Show();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FrmLogin_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                btnLogin_Click(sender, e);
            }
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {
            listProjects = new bpo_versioncontrol().bpoprojectsList();

            int value = 0;
            string strOpenExeName = null;
            Process strcurrprocess = Process.GetCurrentProcess();
            string strcurrprocessname = strcurrprocess.MainModule.ModuleName.Replace(".exe", "");

            listProjects.ForEach(x =>
                {
                    string strExeName = x.assemblyname;
                    Process[] ArrProcesses = Process.GetProcessesByName(strExeName);
                    if (ArrProcesses.Length >= 1)
                    {
                        value = value + 1;
                        if (strExeName != strcurrprocessname)
                        {
                            strOpenExeName = strExeName;
                        }
                    }
                });

            if (value >= 2)
            {
                MessageBox.Show("Already " + strOpenExeName + " exe Opened. So please close " + strOpenExeName + " exe and reopen " + strcurrprocessname + " exe.");
                this.Close();

            }
            else
            {
                //ds = clsDB.GetDataset("select versionnumber,status,testexpirydate from globaldb.bpo_versioncontrol  where projectid=" & projectid & " and status='L' and currentlive=1 order by inserteddatetime desc limit 1;select versionnumber,status,testexpirydate from globaldb.bpo_versioncontrol where projectid=" & projectid & " and status='T' and currentlive=0 order by inserteddatetime desc limit 1")

                listProjectLive = new bpo_versioncontrol().checkversionList(60, "L", 1);
                listProjectTest = new bpo_versioncontrol().checkversionList(60, "T", 0);

                if (listProjectLive == null)
                {
                    if (listProjectTest == null)
                    {
                        App.UserControls.ExpiryDialogue frm = new App.UserControls.ExpiryDialogue();

                        frm.ShowDialog();
                        this.Close();
                    }
                    else if (listProjectTest.versionnumber.ToString() == ProductVersion)
                    {
                        Constance.GC_PROJ_VERSIONSTATUS = "T";
                    }
                    else
                    {
                        App.UserControls.ExpiryDialogue frm = new App.UserControls.ExpiryDialogue();
                        frm.ShowDialog();
                        this.Close();
                    }
                }
                else if (listProjectLive.versionnumber.ToString() != ProductVersion)
                {
                    if (listProjectTest == null)
                    {
                        App.UserControls.ExpiryDialogue frm = new App.UserControls.ExpiryDialogue();
                        frm.ShowDialog();
                        this.Close();
                    }
                    else if (listProjectTest.versionnumber.ToString() == ProductVersion)
                    {
                        string strexpdate = listProjectTest.testexpirydate.ToString();
                        System.DateTime expdate = Convert.ToDateTime(strexpdate).Date;
                        System.DateTime todate = System.DateTime.Today;

                        if (expdate >= todate)
                        {
                            Constance.GC_PROJ_VERSIONSTATUS = "T";
                        }
                        else
                        {
                            MessageBox.Show("Testing Expiry Date is completed. Please Contact Software Department.");
                            Environment.Exit(0);
                        }
                    }
                    else
                    {
                        App.UserControls.ExpiryDialogue frm = new App.UserControls.ExpiryDialogue();
                        frm.ShowDialog();
                        this.Close();
                    }
                }
                else
                {
                    Constance.GC_PROJ_VERSIONSTATUS = "L";
                }
            }
        }
    }
}
