﻿namespace Healthtel_MRT
{
    partial class FrmKeying
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmKeying));
            this.grpMain = new System.Windows.Forms.GroupBox();
            this.StatusStrip1 = new System.Windows.Forms.StatusStrip();
            this.stsUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsTotRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsFinRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsRemRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.grpButtons = new System.Windows.Forms.GroupBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.grpKeyData = new System.Windows.Forms.GroupBox();
            this.lblKey2Data = new System.Windows.Forms.Label();
            this.txtKey2Data = new System.Windows.Forms.TextBox();
            this.lblKey2User = new System.Windows.Forms.Label();
            this.txtKey2User = new System.Windows.Forms.TextBox();
            this.lblKey1Data = new System.Windows.Forms.Label();
            this.txtKey1Data = new System.Windows.Forms.TextBox();
            this.lblKey1User = new System.Windows.Forms.Label();
            this.txtKey1User = new System.Windows.Forms.TextBox();
            this.grpTxtBoxes2 = new System.Windows.Forms.GroupBox();
            this.chkAddressUpdate = new System.Windows.Forms.CheckBox();
            this.grpFormScanDetails = new System.Windows.Forms.GroupBox();
            this.chkMicroalbumin = new System.Windows.Forms.CheckBox();
            this.chkLDLC = new System.Windows.Forms.CheckBox();
            this.chkHbA1c = new System.Windows.Forms.CheckBox();
            this.chkProviderSignature = new System.Windows.Forms.CheckBox();
            this.chkMotOptin = new System.Windows.Forms.CheckBox();
            this.cmbFormScanDatas = new System.Windows.Forms.ComboBox();
            this.lblFormScan = new System.Windows.Forms.Label();
            this.txtFormScan = new System.Windows.Forms.TextBox();
            this.grpTxtBoxes1 = new System.Windows.Forms.GroupBox();
            this.txtBarcode = new System.Windows.Forms.TextBox();
            this.lblBarcode = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.cmbCity = new System.Windows.Forms.ComboBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblZip = new System.Windows.Forms.Label();
            this.txtZip = new System.Windows.Forms.TextBox();
            this.txtDOByy = new System.Windows.Forms.TextBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.txtDOBdd = new System.Windows.Forms.TextBox();
            this.txtDOBmm = new System.Windows.Forms.TextBox();
            this.lblState = new System.Windows.Forms.Label();
            this.txtDOSyy = new System.Windows.Forms.TextBox();
            this.txtState = new System.Windows.Forms.TextBox();
            this.txtDOSdd = new System.Windows.Forms.TextBox();
            this.lblAddress1 = new System.Windows.Forms.Label();
            this.lblDOB = new System.Windows.Forms.Label();
            this.txtAddress1 = new System.Windows.Forms.TextBox();
            this.txtDOSmm = new System.Windows.Forms.TextBox();
            this.lblAddress2 = new System.Windows.Forms.Label();
            this.lblDOS = new System.Windows.Forms.Label();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.txtMemberID = new System.Windows.Forms.TextBox();
            this.lblPhoneNo = new System.Windows.Forms.Label();
            this.lblMemberID = new System.Windows.Forms.Label();
            this.txtPhoneNo = new System.Windows.Forms.TextBox();
            this.IGImageViewer = new InfognanaImageViewer.IGImageViewer();
            this.grpMain.SuspendLayout();
            this.StatusStrip1.SuspendLayout();
            this.grpButtons.SuspendLayout();
            this.grpKeyData.SuspendLayout();
            this.grpTxtBoxes2.SuspendLayout();
            this.grpFormScanDetails.SuspendLayout();
            this.grpTxtBoxes1.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpMain
            // 
            this.grpMain.BackColor = System.Drawing.Color.Transparent;
            this.grpMain.Controls.Add(this.StatusStrip1);
            this.grpMain.Controls.Add(this.grpButtons);
            this.grpMain.Controls.Add(this.grpKeyData);
            this.grpMain.Controls.Add(this.grpTxtBoxes2);
            this.grpMain.Controls.Add(this.grpTxtBoxes1);
            this.grpMain.Location = new System.Drawing.Point(1, 452);
            this.grpMain.Name = "grpMain";
            this.grpMain.Size = new System.Drawing.Size(1055, 300);
            this.grpMain.TabIndex = 1;
            this.grpMain.TabStop = false;
            // 
            // StatusStrip1
            // 
            this.StatusStrip1.AutoSize = false;
            this.StatusStrip1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StatusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stsUser,
            this.stsTotRecs,
            this.stsFinRecs,
            this.stsRemRecs,
            this.stsDate});
            this.StatusStrip1.Location = new System.Drawing.Point(3, 267);
            this.StatusStrip1.Name = "StatusStrip1";
            this.StatusStrip1.Size = new System.Drawing.Size(1049, 30);
            this.StatusStrip1.TabIndex = 45;
            this.StatusStrip1.Text = "StatusStrip1";
            // 
            // stsUser
            // 
            this.stsUser.AutoSize = false;
            this.stsUser.BackColor = System.Drawing.Color.Transparent;
            this.stsUser.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("stsUser.BackgroundImage")));
            this.stsUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsUser.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsUser.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsUser.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsUser.ForeColor = System.Drawing.Color.Black;
            this.stsUser.Name = "stsUser";
            this.stsUser.Size = new System.Drawing.Size(210, 25);
            this.stsUser.Text = "User : Admin";
            this.stsUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsUser.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsTotRecs
            // 
            this.stsTotRecs.AutoSize = false;
            this.stsTotRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsTotRecs.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("stsTotRecs.BackgroundImage")));
            this.stsTotRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsTotRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsTotRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsTotRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsTotRecs.ForeColor = System.Drawing.Color.Black;
            this.stsTotRecs.Name = "stsTotRecs";
            this.stsTotRecs.Size = new System.Drawing.Size(200, 25);
            this.stsTotRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsTotRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsFinRecs
            // 
            this.stsFinRecs.AutoSize = false;
            this.stsFinRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsFinRecs.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("stsFinRecs.BackgroundImage")));
            this.stsFinRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsFinRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsFinRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsFinRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsFinRecs.ForeColor = System.Drawing.Color.Black;
            this.stsFinRecs.Name = "stsFinRecs";
            this.stsFinRecs.Size = new System.Drawing.Size(200, 25);
            this.stsFinRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsFinRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsRemRecs
            // 
            this.stsRemRecs.AutoSize = false;
            this.stsRemRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsRemRecs.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("stsRemRecs.BackgroundImage")));
            this.stsRemRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsRemRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsRemRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsRemRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsRemRecs.ForeColor = System.Drawing.Color.Black;
            this.stsRemRecs.Name = "stsRemRecs";
            this.stsRemRecs.Size = new System.Drawing.Size(200, 25);
            this.stsRemRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsRemRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsDate
            // 
            this.stsDate.AutoSize = false;
            this.stsDate.BackColor = System.Drawing.Color.Transparent;
            this.stsDate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("stsDate.BackgroundImage")));
            this.stsDate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsDate.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsDate.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsDate.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsDate.ForeColor = System.Drawing.Color.Black;
            this.stsDate.Name = "stsDate";
            this.stsDate.Size = new System.Drawing.Size(200, 25);
            this.stsDate.Text = "Date : ";
            this.stsDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsDate.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // grpButtons
            // 
            this.grpButtons.Controls.Add(this.btnExit);
            this.grpButtons.Controls.Add(this.btnSave);
            this.grpButtons.Location = new System.Drawing.Point(647, 158);
            this.grpButtons.Name = "grpButtons";
            this.grpButtons.Size = new System.Drawing.Size(397, 58);
            this.grpButtons.TabIndex = 42;
            this.grpButtons.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(209, 13);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(101, 37);
            this.btnExit.TabIndex = 44;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.ImageKey = "(none)";
            this.btnSave.Location = new System.Drawing.Point(87, 13);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(101, 37);
            this.btnSave.TabIndex = 43;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // grpKeyData
            // 
            this.grpKeyData.Controls.Add(this.lblKey2Data);
            this.grpKeyData.Controls.Add(this.txtKey2Data);
            this.grpKeyData.Controls.Add(this.lblKey2User);
            this.grpKeyData.Controls.Add(this.txtKey2User);
            this.grpKeyData.Controls.Add(this.lblKey1Data);
            this.grpKeyData.Controls.Add(this.txtKey1Data);
            this.grpKeyData.Controls.Add(this.lblKey1User);
            this.grpKeyData.Controls.Add(this.txtKey1User);
            this.grpKeyData.Location = new System.Drawing.Point(13, 215);
            this.grpKeyData.Name = "grpKeyData";
            this.grpKeyData.Size = new System.Drawing.Size(1031, 47);
            this.grpKeyData.TabIndex = 42;
            this.grpKeyData.TabStop = false;
            this.grpKeyData.Visible = false;
            // 
            // lblKey2Data
            // 
            this.lblKey2Data.AutoSize = true;
            this.lblKey2Data.Enabled = false;
            this.lblKey2Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey2Data.ForeColor = System.Drawing.Color.White;
            this.lblKey2Data.Location = new System.Drawing.Point(721, 21);
            this.lblKey2Data.Name = "lblKey2Data";
            this.lblKey2Data.Size = new System.Drawing.Size(76, 14);
            this.lblKey2Data.TabIndex = 49;
            this.lblKey2Data.Text = "Key2 Data";
            this.lblKey2Data.Visible = false;
            // 
            // txtKey2Data
            // 
            this.txtKey2Data.Enabled = false;
            this.txtKey2Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey2Data.Location = new System.Drawing.Point(806, 19);
            this.txtKey2Data.Name = "txtKey2Data";
            this.txtKey2Data.Size = new System.Drawing.Size(206, 22);
            this.txtKey2Data.TabIndex = 50;
            this.txtKey2Data.Visible = false;
            // 
            // lblKey2User
            // 
            this.lblKey2User.AutoSize = true;
            this.lblKey2User.Enabled = false;
            this.lblKey2User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey2User.ForeColor = System.Drawing.Color.White;
            this.lblKey2User.Location = new System.Drawing.Point(519, 21);
            this.lblKey2User.Name = "lblKey2User";
            this.lblKey2User.Size = new System.Drawing.Size(76, 14);
            this.lblKey2User.TabIndex = 47;
            this.lblKey2User.Text = "Key2 User";
            this.lblKey2User.Visible = false;
            // 
            // txtKey2User
            // 
            this.txtKey2User.Enabled = false;
            this.txtKey2User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey2User.Location = new System.Drawing.Point(604, 19);
            this.txtKey2User.Name = "txtKey2User";
            this.txtKey2User.Size = new System.Drawing.Size(111, 22);
            this.txtKey2User.TabIndex = 48;
            this.txtKey2User.Visible = false;
            // 
            // lblKey1Data
            // 
            this.lblKey1Data.AutoSize = true;
            this.lblKey1Data.Enabled = false;
            this.lblKey1Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey1Data.ForeColor = System.Drawing.Color.White;
            this.lblKey1Data.Location = new System.Drawing.Point(208, 21);
            this.lblKey1Data.Name = "lblKey1Data";
            this.lblKey1Data.Size = new System.Drawing.Size(76, 14);
            this.lblKey1Data.TabIndex = 45;
            this.lblKey1Data.Text = "Key1 Data";
            this.lblKey1Data.Visible = false;
            // 
            // txtKey1Data
            // 
            this.txtKey1Data.Enabled = false;
            this.txtKey1Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey1Data.Location = new System.Drawing.Point(293, 19);
            this.txtKey1Data.Name = "txtKey1Data";
            this.txtKey1Data.Size = new System.Drawing.Size(206, 22);
            this.txtKey1Data.TabIndex = 46;
            this.txtKey1Data.Visible = false;
            // 
            // lblKey1User
            // 
            this.lblKey1User.AutoSize = true;
            this.lblKey1User.Enabled = false;
            this.lblKey1User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey1User.ForeColor = System.Drawing.Color.White;
            this.lblKey1User.Location = new System.Drawing.Point(6, 21);
            this.lblKey1User.Name = "lblKey1User";
            this.lblKey1User.Size = new System.Drawing.Size(76, 14);
            this.lblKey1User.TabIndex = 43;
            this.lblKey1User.Text = "Key1 User";
            // 
            // txtKey1User
            // 
            this.txtKey1User.Enabled = false;
            this.txtKey1User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey1User.Location = new System.Drawing.Point(91, 19);
            this.txtKey1User.Name = "txtKey1User";
            this.txtKey1User.Size = new System.Drawing.Size(111, 22);
            this.txtKey1User.TabIndex = 44;
            // 
            // grpTxtBoxes2
            // 
            this.grpTxtBoxes2.Controls.Add(this.chkAddressUpdate);
            this.grpTxtBoxes2.Controls.Add(this.grpFormScanDetails);
            this.grpTxtBoxes2.Controls.Add(this.chkProviderSignature);
            this.grpTxtBoxes2.Controls.Add(this.chkMotOptin);
            this.grpTxtBoxes2.Controls.Add(this.cmbFormScanDatas);
            this.grpTxtBoxes2.Controls.Add(this.lblFormScan);
            this.grpTxtBoxes2.Controls.Add(this.txtFormScan);
            this.grpTxtBoxes2.Location = new System.Drawing.Point(647, 12);
            this.grpTxtBoxes2.Name = "grpTxtBoxes2";
            this.grpTxtBoxes2.Size = new System.Drawing.Size(395, 137);
            this.grpTxtBoxes2.TabIndex = 31;
            this.grpTxtBoxes2.TabStop = false;
            // 
            // chkAddressUpdate
            // 
            this.chkAddressUpdate.AutoSize = true;
            this.chkAddressUpdate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.chkAddressUpdate.ForeColor = System.Drawing.Color.White;
            this.chkAddressUpdate.Location = new System.Drawing.Point(6, 17);
            this.chkAddressUpdate.Name = "chkAddressUpdate";
            this.chkAddressUpdate.Size = new System.Drawing.Size(130, 18);
            this.chkAddressUpdate.TabIndex = 32;
            this.chkAddressUpdate.Text = "Address Update";
            this.chkAddressUpdate.UseVisualStyleBackColor = true;
            this.chkAddressUpdate.CheckedChanged += new System.EventHandler(this.chkAddressUpdate_CheckedChanged);
            this.chkAddressUpdate.Enter += new System.EventHandler(this.chkAddressUpdate_Enter);
            // 
            // grpFormScanDetails
            // 
            this.grpFormScanDetails.Controls.Add(this.chkMicroalbumin);
            this.grpFormScanDetails.Controls.Add(this.chkLDLC);
            this.grpFormScanDetails.Controls.Add(this.chkHbA1c);
            this.grpFormScanDetails.Location = new System.Drawing.Point(199, 51);
            this.grpFormScanDetails.Name = "grpFormScanDetails";
            this.grpFormScanDetails.Size = new System.Drawing.Size(173, 68);
            this.grpFormScanDetails.TabIndex = 37;
            this.grpFormScanDetails.TabStop = false;
            this.grpFormScanDetails.Visible = false;
            // 
            // chkMicroalbumin
            // 
            this.chkMicroalbumin.AutoSize = true;
            this.chkMicroalbumin.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.chkMicroalbumin.ForeColor = System.Drawing.Color.White;
            this.chkMicroalbumin.Location = new System.Drawing.Point(32, 41);
            this.chkMicroalbumin.Name = "chkMicroalbumin";
            this.chkMicroalbumin.Size = new System.Drawing.Size(114, 18);
            this.chkMicroalbumin.TabIndex = 40;
            this.chkMicroalbumin.Text = "Microalbumin";
            this.chkMicroalbumin.UseVisualStyleBackColor = true;
            this.chkMicroalbumin.CheckedChanged += new System.EventHandler(this.chkMicroalbumin_CheckedChanged);
            this.chkMicroalbumin.Enter += new System.EventHandler(this.chkMicroalbumin_Enter);
            // 
            // chkLDLC
            // 
            this.chkLDLC.AutoSize = true;
            this.chkLDLC.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.chkLDLC.ForeColor = System.Drawing.Color.White;
            this.chkLDLC.Location = new System.Drawing.Point(98, 14);
            this.chkLDLC.Name = "chkLDLC";
            this.chkLDLC.Size = new System.Drawing.Size(67, 18);
            this.chkLDLC.TabIndex = 39;
            this.chkLDLC.Text = "LDL-C";
            this.chkLDLC.UseVisualStyleBackColor = true;
            this.chkLDLC.CheckedChanged += new System.EventHandler(this.chkLDLC_CheckedChanged);
            this.chkLDLC.Enter += new System.EventHandler(this.chkLDLC_Enter);
            // 
            // chkHbA1c
            // 
            this.chkHbA1c.AutoSize = true;
            this.chkHbA1c.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.chkHbA1c.ForeColor = System.Drawing.Color.White;
            this.chkHbA1c.Location = new System.Drawing.Point(15, 14);
            this.chkHbA1c.Name = "chkHbA1c";
            this.chkHbA1c.Size = new System.Drawing.Size(69, 18);
            this.chkHbA1c.TabIndex = 38;
            this.chkHbA1c.Text = "HbA1c";
            this.chkHbA1c.UseVisualStyleBackColor = true;
            this.chkHbA1c.CheckedChanged += new System.EventHandler(this.chkHbA1c_CheckedChanged);
            this.chkHbA1c.Enter += new System.EventHandler(this.chkHbA1c_Enter);
            // 
            // chkProviderSignature
            // 
            this.chkProviderSignature.AutoSize = true;
            this.chkProviderSignature.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.chkProviderSignature.ForeColor = System.Drawing.Color.White;
            this.chkProviderSignature.Location = new System.Drawing.Point(141, 18);
            this.chkProviderSignature.Name = "chkProviderSignature";
            this.chkProviderSignature.Size = new System.Drawing.Size(151, 18);
            this.chkProviderSignature.TabIndex = 33;
            this.chkProviderSignature.Text = "Provider Signature";
            this.chkProviderSignature.UseVisualStyleBackColor = true;
            this.chkProviderSignature.CheckedChanged += new System.EventHandler(this.chkProviderSignature_CheckedChanged);
            this.chkProviderSignature.Enter += new System.EventHandler(this.chkProviderSignature_Enter);
            // 
            // chkMotOptin
            // 
            this.chkMotOptin.AutoSize = true;
            this.chkMotOptin.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.chkMotOptin.ForeColor = System.Drawing.Color.White;
            this.chkMotOptin.Location = new System.Drawing.Point(297, 18);
            this.chkMotOptin.Name = "chkMotOptin";
            this.chkMotOptin.Size = new System.Drawing.Size(89, 18);
            this.chkMotOptin.TabIndex = 34;
            this.chkMotOptin.Text = "Not Optin";
            this.chkMotOptin.UseVisualStyleBackColor = true;
            this.chkMotOptin.CheckedChanged += new System.EventHandler(this.chkMotOptin_CheckedChanged);
            this.chkMotOptin.Enter += new System.EventHandler(this.chkMotOptin_Enter);
            // 
            // cmbFormScanDatas
            // 
            this.cmbFormScanDatas.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.cmbFormScanDatas.FormattingEnabled = true;
            this.cmbFormScanDatas.Location = new System.Drawing.Point(21, 95);
            this.cmbFormScanDatas.Name = "cmbFormScanDatas";
            this.cmbFormScanDatas.Size = new System.Drawing.Size(167, 22);
            this.cmbFormScanDatas.TabIndex = 41;
            this.cmbFormScanDatas.Visible = false;
            this.cmbFormScanDatas.Enter += new System.EventHandler(this.cmbFormScanDatas_Enter);
            // 
            // lblFormScan
            // 
            this.lblFormScan.AutoSize = true;
            this.lblFormScan.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormScan.ForeColor = System.Drawing.Color.White;
            this.lblFormScan.Location = new System.Drawing.Point(32, 60);
            this.lblFormScan.Name = "lblFormScan";
            this.lblFormScan.Size = new System.Drawing.Size(77, 14);
            this.lblFormScan.TabIndex = 35;
            this.lblFormScan.Text = "Form Scan";
            // 
            // txtFormScan
            // 
            this.txtFormScan.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtFormScan.Location = new System.Drawing.Point(115, 58);
            this.txtFormScan.MaxLength = 1;
            this.txtFormScan.Name = "txtFormScan";
            this.txtFormScan.Size = new System.Drawing.Size(49, 22);
            this.txtFormScan.TabIndex = 36;
            this.txtFormScan.TextChanged += new System.EventHandler(this.txtFormScan_TextChanged);
            this.txtFormScan.Enter += new System.EventHandler(this.txtFormScan_Enter);
            this.txtFormScan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFormScan_KeyPress);
            this.txtFormScan.Leave += new System.EventHandler(this.txtFormScan_Leave);
            // 
            // grpTxtBoxes1
            // 
            this.grpTxtBoxes1.Controls.Add(this.txtBarcode);
            this.grpTxtBoxes1.Controls.Add(this.lblBarcode);
            this.grpTxtBoxes1.Controls.Add(this.lblFirstName);
            this.grpTxtBoxes1.Controls.Add(this.txtFirstName);
            this.grpTxtBoxes1.Controls.Add(this.cmbCity);
            this.grpTxtBoxes1.Controls.Add(this.lblLastName);
            this.grpTxtBoxes1.Controls.Add(this.txtLastName);
            this.grpTxtBoxes1.Controls.Add(this.lblZip);
            this.grpTxtBoxes1.Controls.Add(this.txtZip);
            this.grpTxtBoxes1.Controls.Add(this.txtDOByy);
            this.grpTxtBoxes1.Controls.Add(this.lblCity);
            this.grpTxtBoxes1.Controls.Add(this.txtDOBdd);
            this.grpTxtBoxes1.Controls.Add(this.txtDOBmm);
            this.grpTxtBoxes1.Controls.Add(this.lblState);
            this.grpTxtBoxes1.Controls.Add(this.txtDOSyy);
            this.grpTxtBoxes1.Controls.Add(this.txtState);
            this.grpTxtBoxes1.Controls.Add(this.txtDOSdd);
            this.grpTxtBoxes1.Controls.Add(this.lblAddress1);
            this.grpTxtBoxes1.Controls.Add(this.lblDOB);
            this.grpTxtBoxes1.Controls.Add(this.txtAddress1);
            this.grpTxtBoxes1.Controls.Add(this.txtDOSmm);
            this.grpTxtBoxes1.Controls.Add(this.lblAddress2);
            this.grpTxtBoxes1.Controls.Add(this.lblDOS);
            this.grpTxtBoxes1.Controls.Add(this.txtAddress2);
            this.grpTxtBoxes1.Controls.Add(this.txtMemberID);
            this.grpTxtBoxes1.Controls.Add(this.lblPhoneNo);
            this.grpTxtBoxes1.Controls.Add(this.lblMemberID);
            this.grpTxtBoxes1.Controls.Add(this.txtPhoneNo);
            this.grpTxtBoxes1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.grpTxtBoxes1.Location = new System.Drawing.Point(11, 13);
            this.grpTxtBoxes1.Name = "grpTxtBoxes1";
            this.grpTxtBoxes1.Size = new System.Drawing.Size(611, 201);
            this.grpTxtBoxes1.TabIndex = 2;
            this.grpTxtBoxes1.TabStop = false;
            // 
            // txtBarcode
            // 
            this.txtBarcode.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtBarcode.Location = new System.Drawing.Point(102, 168);
            this.txtBarcode.MaxLength = 9;
            this.txtBarcode.Name = "txtBarcode";
            this.txtBarcode.Size = new System.Drawing.Size(121, 22);
            this.txtBarcode.TabIndex = 22;
            this.txtBarcode.TextChanged += new System.EventHandler(this.txtBarcode_TextChanged);
            this.txtBarcode.Enter += new System.EventHandler(this.txtBarcode_Enter);
            this.txtBarcode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBarcode_KeyPress);
            // 
            // lblBarcode
            // 
            this.lblBarcode.AutoSize = true;
            this.lblBarcode.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBarcode.ForeColor = System.Drawing.Color.White;
            this.lblBarcode.Location = new System.Drawing.Point(29, 170);
            this.lblBarcode.Name = "lblBarcode";
            this.lblBarcode.Size = new System.Drawing.Size(61, 14);
            this.lblBarcode.TabIndex = 21;
            this.lblBarcode.Text = "Barcode";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstName.ForeColor = System.Drawing.Color.White;
            this.lblFirstName.Location = new System.Drawing.Point(17, 16);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(79, 14);
            this.lblFirstName.TabIndex = 3;
            this.lblFirstName.Text = "First Name";
            // 
            // txtFirstName
            // 
            this.txtFirstName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtFirstName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtFirstName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtFirstName.Location = new System.Drawing.Point(102, 14);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(181, 22);
            this.txtFirstName.TabIndex = 4;
            this.txtFirstName.Enter += new System.EventHandler(this.txtFirstName_Enter);
            this.txtFirstName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFirstName_KeyPress);
            // 
            // cmbCity
            // 
            this.cmbCity.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.cmbCity.FormattingEnabled = true;
            this.cmbCity.Location = new System.Drawing.Point(281, 51);
            this.cmbCity.Name = "cmbCity";
            this.cmbCity.Size = new System.Drawing.Size(167, 22);
            this.cmbCity.TabIndex = 10;
            this.cmbCity.Enter += new System.EventHandler(this.cmbCity_Enter);
            this.cmbCity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbCity_KeyPress);
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastName.ForeColor = System.Drawing.Color.White;
            this.lblLastName.Location = new System.Drawing.Point(314, 16);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(77, 14);
            this.lblLastName.TabIndex = 5;
            this.lblLastName.Text = "Last Name";
            // 
            // txtLastName
            // 
            this.txtLastName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtLastName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtLastName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtLastName.Location = new System.Drawing.Point(402, 14);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(181, 22);
            this.txtLastName.TabIndex = 6;
            this.txtLastName.TextChanged += new System.EventHandler(this.txtLastName_TextChanged);
            this.txtLastName.Enter += new System.EventHandler(this.txtLastName_Enter);
            this.txtLastName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLastName_KeyPress);
            // 
            // lblZip
            // 
            this.lblZip.AutoSize = true;
            this.lblZip.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblZip.ForeColor = System.Drawing.Color.White;
            this.lblZip.Location = new System.Drawing.Point(63, 54);
            this.lblZip.Name = "lblZip";
            this.lblZip.Size = new System.Drawing.Size(27, 14);
            this.lblZip.TabIndex = 7;
            this.lblZip.Text = "Zip";
            // 
            // txtZip
            // 
            this.txtZip.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtZip.Location = new System.Drawing.Point(102, 54);
            this.txtZip.MaxLength = 5;
            this.txtZip.Name = "txtZip";
            this.txtZip.Size = new System.Drawing.Size(113, 22);
            this.txtZip.TabIndex = 8;
            this.txtZip.TextChanged += new System.EventHandler(this.txtZip_TextChanged);
            this.txtZip.Enter += new System.EventHandler(this.txtZip_Enter);
            this.txtZip.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtZip_KeyPress);
            this.txtZip.Leave += new System.EventHandler(this.txtZip_Leave);
            // 
            // txtDOByy
            // 
            this.txtDOByy.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtDOByy.Location = new System.Drawing.Point(530, 168);
            this.txtDOByy.MaxLength = 4;
            this.txtDOByy.Name = "txtDOByy";
            this.txtDOByy.Size = new System.Drawing.Size(53, 22);
            this.txtDOByy.TabIndex = 30;
            this.txtDOByy.TextChanged += new System.EventHandler(this.txtDOByy_TextChanged);
            this.txtDOByy.Enter += new System.EventHandler(this.txtDOByy_Enter);
            this.txtDOByy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDOByy_KeyPress);
            this.txtDOByy.Leave += new System.EventHandler(this.txtDOByy_Leave);
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCity.ForeColor = System.Drawing.Color.White;
            this.lblCity.Location = new System.Drawing.Point(245, 56);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(33, 14);
            this.lblCity.TabIndex = 9;
            this.lblCity.Text = "City";
            // 
            // txtDOBdd
            // 
            this.txtDOBdd.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtDOBdd.Location = new System.Drawing.Point(495, 168);
            this.txtDOBdd.MaxLength = 2;
            this.txtDOBdd.Name = "txtDOBdd";
            this.txtDOBdd.Size = new System.Drawing.Size(29, 22);
            this.txtDOBdd.TabIndex = 29;
            this.txtDOBdd.TextChanged += new System.EventHandler(this.txtDOBdd_TextChanged);
            this.txtDOBdd.Enter += new System.EventHandler(this.txtDOBdd_Enter);
            this.txtDOBdd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDOBdd_KeyPress);
            this.txtDOBdd.Leave += new System.EventHandler(this.txtDOBdd_Leave);
            // 
            // txtDOBmm
            // 
            this.txtDOBmm.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtDOBmm.Location = new System.Drawing.Point(460, 168);
            this.txtDOBmm.MaxLength = 2;
            this.txtDOBmm.Name = "txtDOBmm";
            this.txtDOBmm.Size = new System.Drawing.Size(29, 22);
            this.txtDOBmm.TabIndex = 28;
            this.txtDOBmm.TextChanged += new System.EventHandler(this.txtDOBmm_TextChanged);
            this.txtDOBmm.Enter += new System.EventHandler(this.txtDOBmm_Enter);
            this.txtDOBmm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDOBmm_KeyPress);
            this.txtDOBmm.Leave += new System.EventHandler(this.txtDOBmm_Leave);
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblState.ForeColor = System.Drawing.Color.White;
            this.lblState.Location = new System.Drawing.Point(469, 55);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(42, 14);
            this.lblState.TabIndex = 11;
            this.lblState.Text = "State";
            // 
            // txtDOSyy
            // 
            this.txtDOSyy.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtDOSyy.Location = new System.Drawing.Point(342, 168);
            this.txtDOSyy.MaxLength = 4;
            this.txtDOSyy.Name = "txtDOSyy";
            this.txtDOSyy.Size = new System.Drawing.Size(53, 22);
            this.txtDOSyy.TabIndex = 26;
            this.txtDOSyy.TextChanged += new System.EventHandler(this.txtDOSyy_TextChanged);
            this.txtDOSyy.Enter += new System.EventHandler(this.txtDOSyy_Enter);
            this.txtDOSyy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDOSyy_KeyPress);
            this.txtDOSyy.Leave += new System.EventHandler(this.txtDOSyy_Leave);
            // 
            // txtState
            // 
            this.txtState.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtState.Location = new System.Drawing.Point(522, 52);
            this.txtState.MaxLength = 2;
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(61, 22);
            this.txtState.TabIndex = 12;
            this.txtState.TextChanged += new System.EventHandler(this.txtState_TextChanged);
            this.txtState.Enter += new System.EventHandler(this.txtState_Enter);
            this.txtState.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtState_KeyPress);
            // 
            // txtDOSdd
            // 
            this.txtDOSdd.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtDOSdd.Location = new System.Drawing.Point(305, 168);
            this.txtDOSdd.MaxLength = 2;
            this.txtDOSdd.Name = "txtDOSdd";
            this.txtDOSdd.Size = new System.Drawing.Size(29, 22);
            this.txtDOSdd.TabIndex = 25;
            this.txtDOSdd.TextChanged += new System.EventHandler(this.txtDOSdd_TextChanged);
            this.txtDOSdd.Enter += new System.EventHandler(this.txtDOSdd_Enter);
            this.txtDOSdd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDOSdd_KeyPress);
            this.txtDOSdd.Leave += new System.EventHandler(this.txtDOSdd_Leave);
            // 
            // lblAddress1
            // 
            this.lblAddress1.AutoSize = true;
            this.lblAddress1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress1.ForeColor = System.Drawing.Color.White;
            this.lblAddress1.Location = new System.Drawing.Point(17, 95);
            this.lblAddress1.Name = "lblAddress1";
            this.lblAddress1.Size = new System.Drawing.Size(73, 14);
            this.lblAddress1.TabIndex = 13;
            this.lblAddress1.Text = "Address 1";
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDOB.ForeColor = System.Drawing.Color.White;
            this.lblDOB.Location = new System.Drawing.Point(420, 172);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(37, 14);
            this.lblDOB.TabIndex = 27;
            this.lblDOB.Text = "DOB";
            // 
            // txtAddress1
            // 
            this.txtAddress1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtAddress1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtAddress1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtAddress1.Location = new System.Drawing.Point(102, 93);
            this.txtAddress1.Name = "txtAddress1";
            this.txtAddress1.Size = new System.Drawing.Size(201, 22);
            this.txtAddress1.TabIndex = 14;
            this.txtAddress1.TextChanged += new System.EventHandler(this.txtAddress1_TextChanged);
            this.txtAddress1.Enter += new System.EventHandler(this.txtAddress1_Enter);
            this.txtAddress1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAddress1_KeyPress);
            // 
            // txtDOSmm
            // 
            this.txtDOSmm.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtDOSmm.Location = new System.Drawing.Point(268, 168);
            this.txtDOSmm.MaxLength = 2;
            this.txtDOSmm.Name = "txtDOSmm";
            this.txtDOSmm.Size = new System.Drawing.Size(29, 22);
            this.txtDOSmm.TabIndex = 24;
            this.txtDOSmm.TextChanged += new System.EventHandler(this.txtDOSmm_TextChanged);
            this.txtDOSmm.Enter += new System.EventHandler(this.txtDOSmm_Enter);
            this.txtDOSmm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDOSmm_KeyPress);
            this.txtDOSmm.Leave += new System.EventHandler(this.txtDOSmm_Leave);
            // 
            // lblAddress2
            // 
            this.lblAddress2.AutoSize = true;
            this.lblAddress2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress2.ForeColor = System.Drawing.Color.White;
            this.lblAddress2.Location = new System.Drawing.Point(318, 96);
            this.lblAddress2.Name = "lblAddress2";
            this.lblAddress2.Size = new System.Drawing.Size(73, 14);
            this.lblAddress2.TabIndex = 15;
            this.lblAddress2.Text = "Address 2";
            // 
            // lblDOS
            // 
            this.lblDOS.AutoSize = true;
            this.lblDOS.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDOS.ForeColor = System.Drawing.Color.White;
            this.lblDOS.Location = new System.Drawing.Point(229, 172);
            this.lblDOS.Name = "lblDOS";
            this.lblDOS.Size = new System.Drawing.Size(37, 14);
            this.lblDOS.TabIndex = 23;
            this.lblDOS.Text = "DOS";
            // 
            // txtAddress2
            // 
            this.txtAddress2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtAddress2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtAddress2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtAddress2.Location = new System.Drawing.Point(395, 94);
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(188, 22);
            this.txtAddress2.TabIndex = 16;
            this.txtAddress2.TextChanged += new System.EventHandler(this.txtAddress2_TextChanged);
            this.txtAddress2.Enter += new System.EventHandler(this.txtAddress2_Enter);
            this.txtAddress2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAddress2_KeyPress);
            // 
            // txtMemberID
            // 
            this.txtMemberID.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtMemberID.Location = new System.Drawing.Point(395, 130);
            this.txtMemberID.MaxLength = 20;
            this.txtMemberID.Name = "txtMemberID";
            this.txtMemberID.Size = new System.Drawing.Size(188, 22);
            this.txtMemberID.TabIndex = 20;
            this.txtMemberID.TextChanged += new System.EventHandler(this.txtMemberID_TextChanged);
            this.txtMemberID.Enter += new System.EventHandler(this.txtMemberID_Enter);
            this.txtMemberID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMemberID_KeyPress);
            // 
            // lblPhoneNo
            // 
            this.lblPhoneNo.AutoSize = true;
            this.lblPhoneNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhoneNo.ForeColor = System.Drawing.Color.White;
            this.lblPhoneNo.Location = new System.Drawing.Point(17, 132);
            this.lblPhoneNo.Name = "lblPhoneNo";
            this.lblPhoneNo.Size = new System.Drawing.Size(70, 14);
            this.lblPhoneNo.TabIndex = 17;
            this.lblPhoneNo.Text = "Phone No";
            // 
            // lblMemberID
            // 
            this.lblMemberID.AutoSize = true;
            this.lblMemberID.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMemberID.ForeColor = System.Drawing.Color.White;
            this.lblMemberID.Location = new System.Drawing.Point(314, 132);
            this.lblMemberID.Name = "lblMemberID";
            this.lblMemberID.Size = new System.Drawing.Size(80, 14);
            this.lblMemberID.TabIndex = 19;
            this.lblMemberID.Text = "Member ID";
            // 
            // txtPhoneNo
            // 
            this.txtPhoneNo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtPhoneNo.Location = new System.Drawing.Point(102, 130);
            this.txtPhoneNo.MaxLength = 50;
            this.txtPhoneNo.Name = "txtPhoneNo";
            this.txtPhoneNo.Size = new System.Drawing.Size(201, 22);
            this.txtPhoneNo.TabIndex = 18;
            this.txtPhoneNo.TextChanged += new System.EventHandler(this.txtPhoneNo_TextChanged);
            this.txtPhoneNo.Enter += new System.EventHandler(this.txtPhoneNo_Enter);
            this.txtPhoneNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPhoneNo_KeyPress);
            this.txtPhoneNo.Leave += new System.EventHandler(this.txtPhoneNo_Leave);
            // 
            // IGImageViewer
            // 
            this.IGImageViewer.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.IGImageViewer.BackColor = System.Drawing.Color.Azure;
            this.IGImageViewer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.IGImageViewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IGImageViewer.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IGImageViewer.ImageData = null;
            this.IGImageViewer.ImageName = null;
            this.IGImageViewer.ImageScropping = false;
            this.IGImageViewer.ImageSize = new System.Drawing.Size(1366, 768);
            this.IGImageViewer.Location = new System.Drawing.Point(-1, -2);
            this.IGImageViewer.Name = "IGImageViewer";
            this.IGImageViewer.PictureBoxSize = new System.Drawing.Size(0, 0);
            this.IGImageViewer.Size = new System.Drawing.Size(1058, 455);
            this.IGImageViewer.StatusBarVisible = true;
            this.IGImageViewer.TabIndex = 2;
            // 
            // FrmKeying
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1055, 742);
            this.Controls.Add(this.IGImageViewer);
            this.Controls.Add(this.grpMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmKeying";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Healthtel MRD : : Key";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmKeying_FormClosing);
            this.Load += new System.EventHandler(this.FrmKeying_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmKeying_KeyDown);
            this.grpMain.ResumeLayout(false);
            this.StatusStrip1.ResumeLayout(false);
            this.StatusStrip1.PerformLayout();
            this.grpButtons.ResumeLayout(false);
            this.grpKeyData.ResumeLayout(false);
            this.grpKeyData.PerformLayout();
            this.grpTxtBoxes2.ResumeLayout(false);
            this.grpTxtBoxes2.PerformLayout();
            this.grpFormScanDetails.ResumeLayout(false);
            this.grpFormScanDetails.PerformLayout();
            this.grpTxtBoxes1.ResumeLayout(false);
            this.grpTxtBoxes1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpMain;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.Label lblAddress2;
        private System.Windows.Forms.TextBox txtAddress1;
        private System.Windows.Forms.Label lblAddress1;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.TextBox txtZip;
        private System.Windows.Forms.Label lblZip;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtMemberID;
        private System.Windows.Forms.Label lblMemberID;
        private System.Windows.Forms.TextBox txtPhoneNo;
        private System.Windows.Forms.Label lblPhoneNo;
        private System.Windows.Forms.TextBox txtDOByy;
        private System.Windows.Forms.TextBox txtDOBdd;
        private System.Windows.Forms.TextBox txtDOBmm;
        private System.Windows.Forms.TextBox txtDOSyy;
        private System.Windows.Forms.TextBox txtDOSdd;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.TextBox txtDOSmm;
        private System.Windows.Forms.Label lblDOS;
        private System.Windows.Forms.CheckBox chkProviderSignature;
        private System.Windows.Forms.CheckBox chkMotOptin;
        private System.Windows.Forms.TextBox txtFormScan;
        private System.Windows.Forms.Label lblFormScan;
        private System.Windows.Forms.ComboBox cmbFormScanDatas;
        private System.Windows.Forms.GroupBox grpTxtBoxes1;
        private System.Windows.Forms.GroupBox grpTxtBoxes2;
        private System.Windows.Forms.GroupBox grpKeyData;
        private System.Windows.Forms.Label lblKey2Data;
        private System.Windows.Forms.TextBox txtKey2Data;
        private System.Windows.Forms.Label lblKey2User;
        private System.Windows.Forms.TextBox txtKey2User;
        private System.Windows.Forms.Label lblKey1Data;
        private System.Windows.Forms.TextBox txtKey1Data;
        private System.Windows.Forms.Label lblKey1User;
        private System.Windows.Forms.TextBox txtKey1User;
        private System.Windows.Forms.ComboBox cmbCity;
        private System.Windows.Forms.GroupBox grpFormScanDetails;
        private System.Windows.Forms.CheckBox chkMicroalbumin;
        private System.Windows.Forms.CheckBox chkLDLC;
        private System.Windows.Forms.CheckBox chkHbA1c;
        private System.Windows.Forms.GroupBox grpButtons;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        internal System.Windows.Forms.StatusStrip StatusStrip1;
        internal System.Windows.Forms.ToolStripStatusLabel stsUser;
        internal System.Windows.Forms.ToolStripStatusLabel stsTotRecs;
        internal System.Windows.Forms.ToolStripStatusLabel stsFinRecs;
        internal System.Windows.Forms.ToolStripStatusLabel stsRemRecs;
        internal System.Windows.Forms.ToolStripStatusLabel stsDate;
        private System.Windows.Forms.TextBox txtBarcode;
        private System.Windows.Forms.Label lblBarcode;
        private System.Windows.Forms.CheckBox chkAddressUpdate;
        private InfognanaImageViewer.IGImageViewer IGImageViewer;
    }
}