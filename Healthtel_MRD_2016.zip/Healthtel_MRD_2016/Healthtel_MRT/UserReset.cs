﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DataAccessLayer.GlobalDB;

namespace Healthtel_MRT
{
    public partial class frmUserReset : Form
    {
        public frmUserReset()
        {
            InitializeComponent();
        }

        #region HelpMethods

        private void LoadUsers()
        {
            List<login> LoggedUsers = new List<login>();
            login objLogin = new login();
            LoggedUsers = objLogin.getLoggedUsers();

            lstUsers.Items.Clear();
            if (LoggedUsers.Count > 0)
            {
                lstUsers.DisplayMember = "ADName";
                lstUsers.ValueMember = "ID";
                LoggedUsers.ForEach(x =>
                {
                    lstUsers.Items.Add(new { ID = x.ID, ADName = x.ADName });
                });
                lstUsers.Refresh();
            }
        }

        #endregion

        #region Events

        private void frmUserReset_Load(object sender, EventArgs e)
        {
            LoadUsers();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstUsers.CheckedItems.Count == 0)
                {
                    MessageBox.Show("Select One or more Users to Reset");
                    lstUsers.Focus();
                    return;
                }

                int iLoop = 0;
                int id = 0;
                string selectitem = "";
                string[] imageid;
                for (iLoop = 0; iLoop <= lstUsers.CheckedItems.Count - 1; iLoop++)
                {
                    //if (lstUsers.GetItemChecked(iLoop) == true)
                    //{
                    selectitem = lstUsers.CheckedItems[iLoop].ToString();
                    imageid = selectitem.Split('=');
                    imageid = imageid[1].ToString().Split(',');
                    id = Convert.ToInt32(imageid[0]);

                    login objUserReset = new login(id);

                    objUserReset.LoginStatus = false;
                    objUserReset.Store();
                    //MessageBox.Show("Selected User(s) Reseted");
                    //}
                }
                MessageBox.Show("Selected User(s) Reseted");
                LoadUsers();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void chkCheckAll_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCheckAll.Checked == true)
            {
                for (int i = 0; i <= lstUsers.Items.Count - 1; i++)
                {
                    lstUsers.SetItemChecked(i, true);
                }
            }
            else
            {
                for (int i = 0; i <= lstUsers.Items.Count - 1; i++)
                {
                    lstUsers.SetItemChecked(i, false);
                }
            }
        }

        #endregion
    }
}
