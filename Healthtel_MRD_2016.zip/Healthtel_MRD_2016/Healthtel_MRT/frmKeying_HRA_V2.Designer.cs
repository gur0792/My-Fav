﻿namespace Healthtel_MRT
{
    partial class frmKeying_HRA_V2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKeying_HRA_V2));
            this.lblRespondentID = new System.Windows.Forms.Label();
            this.txtRespndentID = new System.Windows.Forms.TextBox();
            this.lblQ1 = new System.Windows.Forms.Label();
            this.txtQ1 = new System.Windows.Forms.TextBox();
            this.grpButtons = new System.Windows.Forms.GroupBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.grpKeyData = new System.Windows.Forms.GroupBox();
            this.lblKey2Data = new System.Windows.Forms.Label();
            this.txtKey2Data = new System.Windows.Forms.TextBox();
            this.lblKey2User = new System.Windows.Forms.Label();
            this.txtKey2User = new System.Windows.Forms.TextBox();
            this.lblKey1Data = new System.Windows.Forms.Label();
            this.txtKey1Data = new System.Windows.Forms.TextBox();
            this.lblKey1User = new System.Windows.Forms.Label();
            this.txtKey1User = new System.Windows.Forms.TextBox();
            this.stsDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsRemRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsFinRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.grpMain = new System.Windows.Forms.GroupBox();
            this.StatusStrip1 = new System.Windows.Forms.StatusStrip();
            this.stsUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsTotRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.grpTxtBoxes1 = new System.Windows.Forms.GroupBox();
            this.lblMailType = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.Label();
            this.lblQ3 = new System.Windows.Forms.Label();
            this.txtQ3 = new System.Windows.Forms.TextBox();
            this.lblLanguage = new System.Windows.Forms.Label();
            this.txtLanguage = new System.Windows.Forms.TextBox();
            this.lblQ17 = new System.Windows.Forms.Label();
            this.txtQ17 = new System.Windows.Forms.TextBox();
            this.lblQ16 = new System.Windows.Forms.Label();
            this.txtQ16 = new System.Windows.Forms.TextBox();
            this.lblQ15 = new System.Windows.Forms.Label();
            this.txtQ15 = new System.Windows.Forms.TextBox();
            this.lblQ14 = new System.Windows.Forms.Label();
            this.txtQ14 = new System.Windows.Forms.TextBox();
            this.lblQ13 = new System.Windows.Forms.Label();
            this.txtQ13 = new System.Windows.Forms.TextBox();
            this.lblQ12 = new System.Windows.Forms.Label();
            this.txtQ12 = new System.Windows.Forms.TextBox();
            this.lblQ11 = new System.Windows.Forms.Label();
            this.txtQ11 = new System.Windows.Forms.TextBox();
            this.lblQ10 = new System.Windows.Forms.Label();
            this.txtQ10 = new System.Windows.Forms.TextBox();
            this.lblQ9 = new System.Windows.Forms.Label();
            this.txtQ9 = new System.Windows.Forms.TextBox();
            this.lblQ8 = new System.Windows.Forms.Label();
            this.txtQ8 = new System.Windows.Forms.TextBox();
            this.lblQ7 = new System.Windows.Forms.Label();
            this.txtQ7 = new System.Windows.Forms.TextBox();
            this.lblQ6 = new System.Windows.Forms.Label();
            this.txtQ6 = new System.Windows.Forms.TextBox();
            this.lblQ5 = new System.Windows.Forms.Label();
            this.txtQ5 = new System.Windows.Forms.TextBox();
            this.lblQ4 = new System.Windows.Forms.Label();
            this.txtQ4 = new System.Windows.Forms.TextBox();
            this.lblQ2_8 = new System.Windows.Forms.Label();
            this.txtQ2_8 = new System.Windows.Forms.TextBox();
            this.lblQ2_7 = new System.Windows.Forms.Label();
            this.txtQ2_7 = new System.Windows.Forms.TextBox();
            this.lblQ2_6 = new System.Windows.Forms.Label();
            this.txtQ2_6 = new System.Windows.Forms.TextBox();
            this.lblQ2_5 = new System.Windows.Forms.Label();
            this.txtQ2_5 = new System.Windows.Forms.TextBox();
            this.lblQ2_4 = new System.Windows.Forms.Label();
            this.txtQ2_4 = new System.Windows.Forms.TextBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblQ2_3 = new System.Windows.Forms.Label();
            this.txtQ2_3 = new System.Windows.Forms.TextBox();
            this.lblQ2_2 = new System.Windows.Forms.Label();
            this.txtQ2_2 = new System.Windows.Forms.TextBox();
            this.lblQ2_1 = new System.Windows.Forms.Label();
            this.txtQ2_1 = new System.Windows.Forms.TextBox();
            this.IGImageViewer = new InfognanaImageViewer.IGImageViewer();
            this.txtmailType = new System.Windows.Forms.TextBox();
            this.grpButtons.SuspendLayout();
            this.grpKeyData.SuspendLayout();
            this.grpMain.SuspendLayout();
            this.StatusStrip1.SuspendLayout();
            this.grpTxtBoxes1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblRespondentID
            // 
            this.lblRespondentID.AutoSize = true;
            this.lblRespondentID.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRespondentID.ForeColor = System.Drawing.Color.White;
            this.lblRespondentID.Location = new System.Drawing.Point(11, 92);
            this.lblRespondentID.Name = "lblRespondentID";
            this.lblRespondentID.Size = new System.Drawing.Size(104, 14);
            this.lblRespondentID.TabIndex = 4;
            this.lblRespondentID.Text = "Respondent ID";
            this.lblRespondentID.Visible = false;
            // 
            // txtRespndentID
            // 
            this.txtRespndentID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtRespndentID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtRespndentID.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtRespndentID.Location = new System.Drawing.Point(14, 116);
            this.txtRespndentID.MaxLength = 8;
            this.txtRespndentID.Name = "txtRespndentID";
            this.txtRespndentID.Size = new System.Drawing.Size(101, 22);
            this.txtRespndentID.TabIndex = 5;
            this.txtRespndentID.Visible = false;
            this.txtRespndentID.TextChanged += new System.EventHandler(this.txtRespndentID_TextChanged);
            this.txtRespndentID.Enter += new System.EventHandler(this.txtRespndentID_Enter);
            this.txtRespndentID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRespndentID_KeyPress);
            // 
            // lblQ1
            // 
            this.lblQ1.AutoSize = true;
            this.lblQ1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ1.ForeColor = System.Drawing.Color.White;
            this.lblQ1.Location = new System.Drawing.Point(153, 51);
            this.lblQ1.Name = "lblQ1";
            this.lblQ1.Size = new System.Drawing.Size(27, 14);
            this.lblQ1.TabIndex = 6;
            this.lblQ1.Text = "Q1";
            // 
            // txtQ1
            // 
            this.txtQ1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ1.Location = new System.Drawing.Point(191, 49);
            this.txtQ1.MaxLength = 1;
            this.txtQ1.Name = "txtQ1";
            this.txtQ1.Size = new System.Drawing.Size(41, 22);
            this.txtQ1.TabIndex = 7;
            this.txtQ1.TextChanged += new System.EventHandler(this.txtQ1_TextChanged);
            this.txtQ1.Enter += new System.EventHandler(this.txtQ1_Enter);
            this.txtQ1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_KeyPress);
            // 
            // grpButtons
            // 
            this.grpButtons.Controls.Add(this.btnExit);
            this.grpButtons.Controls.Add(this.btnSave);
            this.grpButtons.Location = new System.Drawing.Point(911, 85);
            this.grpButtons.Name = "grpButtons";
            this.grpButtons.Size = new System.Drawing.Size(120, 104);
            this.grpButtons.TabIndex = 58;
            this.grpButtons.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(18, 57);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(85, 37);
            this.btnExit.TabIndex = 60;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.ImageKey = "(none)";
            this.btnSave.Location = new System.Drawing.Point(18, 13);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 37);
            this.btnSave.TabIndex = 59;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // grpKeyData
            // 
            this.grpKeyData.Controls.Add(this.lblKey2Data);
            this.grpKeyData.Controls.Add(this.txtKey2Data);
            this.grpKeyData.Controls.Add(this.lblKey2User);
            this.grpKeyData.Controls.Add(this.txtKey2User);
            this.grpKeyData.Controls.Add(this.lblKey1Data);
            this.grpKeyData.Controls.Add(this.txtKey1Data);
            this.grpKeyData.Controls.Add(this.lblKey1User);
            this.grpKeyData.Controls.Add(this.txtKey1User);
            this.grpKeyData.Location = new System.Drawing.Point(11, 209);
            this.grpKeyData.Name = "grpKeyData";
            this.grpKeyData.Size = new System.Drawing.Size(1031, 47);
            this.grpKeyData.TabIndex = 42;
            this.grpKeyData.TabStop = false;
            this.grpKeyData.Visible = false;
            // 
            // lblKey2Data
            // 
            this.lblKey2Data.AutoSize = true;
            this.lblKey2Data.Enabled = false;
            this.lblKey2Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey2Data.ForeColor = System.Drawing.Color.White;
            this.lblKey2Data.Location = new System.Drawing.Point(721, 21);
            this.lblKey2Data.Name = "lblKey2Data";
            this.lblKey2Data.Size = new System.Drawing.Size(76, 14);
            this.lblKey2Data.TabIndex = 49;
            this.lblKey2Data.Text = "Key2 Data";
            // 
            // txtKey2Data
            // 
            this.txtKey2Data.Enabled = false;
            this.txtKey2Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey2Data.Location = new System.Drawing.Point(806, 19);
            this.txtKey2Data.Name = "txtKey2Data";
            this.txtKey2Data.Size = new System.Drawing.Size(206, 22);
            this.txtKey2Data.TabIndex = 50;
            // 
            // lblKey2User
            // 
            this.lblKey2User.AutoSize = true;
            this.lblKey2User.Enabled = false;
            this.lblKey2User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey2User.ForeColor = System.Drawing.Color.White;
            this.lblKey2User.Location = new System.Drawing.Point(519, 21);
            this.lblKey2User.Name = "lblKey2User";
            this.lblKey2User.Size = new System.Drawing.Size(76, 14);
            this.lblKey2User.TabIndex = 47;
            this.lblKey2User.Text = "Key2 User";
            // 
            // txtKey2User
            // 
            this.txtKey2User.Enabled = false;
            this.txtKey2User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey2User.Location = new System.Drawing.Point(604, 19);
            this.txtKey2User.Name = "txtKey2User";
            this.txtKey2User.Size = new System.Drawing.Size(111, 22);
            this.txtKey2User.TabIndex = 48;
            // 
            // lblKey1Data
            // 
            this.lblKey1Data.AutoSize = true;
            this.lblKey1Data.Enabled = false;
            this.lblKey1Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey1Data.ForeColor = System.Drawing.Color.White;
            this.lblKey1Data.Location = new System.Drawing.Point(208, 21);
            this.lblKey1Data.Name = "lblKey1Data";
            this.lblKey1Data.Size = new System.Drawing.Size(76, 14);
            this.lblKey1Data.TabIndex = 45;
            this.lblKey1Data.Text = "Key1 Data";
            // 
            // txtKey1Data
            // 
            this.txtKey1Data.Enabled = false;
            this.txtKey1Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey1Data.Location = new System.Drawing.Point(293, 19);
            this.txtKey1Data.Name = "txtKey1Data";
            this.txtKey1Data.Size = new System.Drawing.Size(206, 22);
            this.txtKey1Data.TabIndex = 46;
            // 
            // lblKey1User
            // 
            this.lblKey1User.AutoSize = true;
            this.lblKey1User.Enabled = false;
            this.lblKey1User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey1User.ForeColor = System.Drawing.Color.White;
            this.lblKey1User.Location = new System.Drawing.Point(11, 22);
            this.lblKey1User.Name = "lblKey1User";
            this.lblKey1User.Size = new System.Drawing.Size(76, 14);
            this.lblKey1User.TabIndex = 43;
            this.lblKey1User.Text = "Key1 User";
            // 
            // txtKey1User
            // 
            this.txtKey1User.Enabled = false;
            this.txtKey1User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey1User.Location = new System.Drawing.Point(91, 19);
            this.txtKey1User.Name = "txtKey1User";
            this.txtKey1User.Size = new System.Drawing.Size(111, 22);
            this.txtKey1User.TabIndex = 44;
            // 
            // stsDate
            // 
            this.stsDate.AutoSize = false;
            this.stsDate.BackColor = System.Drawing.Color.Transparent;
            this.stsDate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("stsDate.BackgroundImage")));
            this.stsDate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsDate.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsDate.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsDate.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsDate.ForeColor = System.Drawing.Color.Black;
            this.stsDate.Name = "stsDate";
            this.stsDate.Size = new System.Drawing.Size(200, 25);
            this.stsDate.Text = "Date : ";
            this.stsDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsDate.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsRemRecs
            // 
            this.stsRemRecs.AutoSize = false;
            this.stsRemRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsRemRecs.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("stsRemRecs.BackgroundImage")));
            this.stsRemRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsRemRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsRemRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsRemRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsRemRecs.ForeColor = System.Drawing.Color.Black;
            this.stsRemRecs.Name = "stsRemRecs";
            this.stsRemRecs.Size = new System.Drawing.Size(200, 25);
            this.stsRemRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsRemRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsFinRecs
            // 
            this.stsFinRecs.AutoSize = false;
            this.stsFinRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsFinRecs.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("stsFinRecs.BackgroundImage")));
            this.stsFinRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsFinRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsFinRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsFinRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsFinRecs.ForeColor = System.Drawing.Color.Black;
            this.stsFinRecs.Name = "stsFinRecs";
            this.stsFinRecs.Size = new System.Drawing.Size(200, 25);
            this.stsFinRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsFinRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // grpMain
            // 
            this.grpMain.BackColor = System.Drawing.Color.Transparent;
            this.grpMain.Controls.Add(this.StatusStrip1);
            this.grpMain.Controls.Add(this.grpKeyData);
            this.grpMain.Controls.Add(this.grpTxtBoxes1);
            this.grpMain.Location = new System.Drawing.Point(0, 459);
            this.grpMain.Name = "grpMain";
            this.grpMain.Size = new System.Drawing.Size(1055, 292);
            this.grpMain.TabIndex = 0;
            this.grpMain.TabStop = false;
            // 
            // StatusStrip1
            // 
            this.StatusStrip1.AutoSize = false;
            this.StatusStrip1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StatusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stsUser,
            this.stsTotRecs,
            this.stsFinRecs,
            this.stsRemRecs,
            this.stsDate});
            this.StatusStrip1.Location = new System.Drawing.Point(3, 259);
            this.StatusStrip1.Name = "StatusStrip1";
            this.StatusStrip1.Size = new System.Drawing.Size(1049, 30);
            this.StatusStrip1.TabIndex = 45;
            this.StatusStrip1.Text = "StatusStrip1";
            // 
            // stsUser
            // 
            this.stsUser.AutoSize = false;
            this.stsUser.BackColor = System.Drawing.Color.Transparent;
            this.stsUser.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("stsUser.BackgroundImage")));
            this.stsUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsUser.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsUser.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsUser.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsUser.ForeColor = System.Drawing.Color.Black;
            this.stsUser.Name = "stsUser";
            this.stsUser.Size = new System.Drawing.Size(210, 25);
            this.stsUser.Text = "User : Admin";
            this.stsUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsUser.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsTotRecs
            // 
            this.stsTotRecs.AutoSize = false;
            this.stsTotRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsTotRecs.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("stsTotRecs.BackgroundImage")));
            this.stsTotRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsTotRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsTotRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsTotRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsTotRecs.ForeColor = System.Drawing.Color.Black;
            this.stsTotRecs.Name = "stsTotRecs";
            this.stsTotRecs.Size = new System.Drawing.Size(200, 25);
            this.stsTotRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsTotRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // grpTxtBoxes1
            // 
            this.grpTxtBoxes1.Controls.Add(this.txtmailType);
            this.grpTxtBoxes1.Controls.Add(this.lblMailType);
            this.grpTxtBoxes1.Controls.Add(this.txtDescription);
            this.grpTxtBoxes1.Controls.Add(this.lblQ3);
            this.grpTxtBoxes1.Controls.Add(this.txtQ3);
            this.grpTxtBoxes1.Controls.Add(this.lblLanguage);
            this.grpTxtBoxes1.Controls.Add(this.txtLanguage);
            this.grpTxtBoxes1.Controls.Add(this.lblQ17);
            this.grpTxtBoxes1.Controls.Add(this.txtQ17);
            this.grpTxtBoxes1.Controls.Add(this.lblQ16);
            this.grpTxtBoxes1.Controls.Add(this.txtQ16);
            this.grpTxtBoxes1.Controls.Add(this.lblQ15);
            this.grpTxtBoxes1.Controls.Add(this.txtQ15);
            this.grpTxtBoxes1.Controls.Add(this.lblQ14);
            this.grpTxtBoxes1.Controls.Add(this.txtQ14);
            this.grpTxtBoxes1.Controls.Add(this.lblQ13);
            this.grpTxtBoxes1.Controls.Add(this.txtQ13);
            this.grpTxtBoxes1.Controls.Add(this.lblQ12);
            this.grpTxtBoxes1.Controls.Add(this.txtQ12);
            this.grpTxtBoxes1.Controls.Add(this.lblQ11);
            this.grpTxtBoxes1.Controls.Add(this.txtQ11);
            this.grpTxtBoxes1.Controls.Add(this.lblQ10);
            this.grpTxtBoxes1.Controls.Add(this.txtQ10);
            this.grpTxtBoxes1.Controls.Add(this.lblQ9);
            this.grpTxtBoxes1.Controls.Add(this.txtQ9);
            this.grpTxtBoxes1.Controls.Add(this.lblQ8);
            this.grpTxtBoxes1.Controls.Add(this.txtQ8);
            this.grpTxtBoxes1.Controls.Add(this.lblQ7);
            this.grpTxtBoxes1.Controls.Add(this.txtQ7);
            this.grpTxtBoxes1.Controls.Add(this.lblQ6);
            this.grpTxtBoxes1.Controls.Add(this.txtQ6);
            this.grpTxtBoxes1.Controls.Add(this.lblQ5);
            this.grpTxtBoxes1.Controls.Add(this.txtQ5);
            this.grpTxtBoxes1.Controls.Add(this.lblQ4);
            this.grpTxtBoxes1.Controls.Add(this.txtQ4);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_8);
            this.grpTxtBoxes1.Controls.Add(this.txtQ2_8);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_7);
            this.grpTxtBoxes1.Controls.Add(this.txtQ2_7);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_6);
            this.grpTxtBoxes1.Controls.Add(this.txtQ2_6);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_5);
            this.grpTxtBoxes1.Controls.Add(this.txtQ2_5);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_4);
            this.grpTxtBoxes1.Controls.Add(this.txtQ2_4);
            this.grpTxtBoxes1.Controls.Add(this.lblDescription);
            this.grpTxtBoxes1.Controls.Add(this.grpButtons);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_3);
            this.grpTxtBoxes1.Controls.Add(this.txtQ2_3);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_2);
            this.grpTxtBoxes1.Controls.Add(this.txtQ2_2);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_1);
            this.grpTxtBoxes1.Controls.Add(this.txtQ2_1);
            this.grpTxtBoxes1.Controls.Add(this.lblRespondentID);
            this.grpTxtBoxes1.Controls.Add(this.txtRespndentID);
            this.grpTxtBoxes1.Controls.Add(this.lblQ1);
            this.grpTxtBoxes1.Controls.Add(this.txtQ1);
            this.grpTxtBoxes1.Location = new System.Drawing.Point(11, 11);
            this.grpTxtBoxes1.Name = "grpTxtBoxes1";
            this.grpTxtBoxes1.Size = new System.Drawing.Size(1038, 199);
            this.grpTxtBoxes1.TabIndex = 1;
            this.grpTxtBoxes1.TabStop = false;
            // 
            // lblMailType
            // 
            this.lblMailType.AutoSize = true;
            this.lblMailType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMailType.ForeColor = System.Drawing.Color.White;
            this.lblMailType.Location = new System.Drawing.Point(926, 43);
            this.lblMailType.Name = "lblMailType";
            this.lblMailType.Size = new System.Drawing.Size(70, 14);
            this.lblMailType.TabIndex = 56;
            this.lblMailType.Text = "Mail Type";
            // 
            // txtDescription
            // 
            this.txtDescription.AutoSize = true;
            this.txtDescription.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtDescription.ForeColor = System.Drawing.Color.Red;
            this.txtDescription.Location = new System.Drawing.Point(293, 20);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(82, 14);
            this.txtDescription.TabIndex = 57;
            this.txtDescription.Text = "Description";
            // 
            // lblQ3
            // 
            this.lblQ3.AutoSize = true;
            this.lblQ3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ3.ForeColor = System.Drawing.Color.White;
            this.lblQ3.Location = new System.Drawing.Point(386, 90);
            this.lblQ3.Name = "lblQ3";
            this.lblQ3.Size = new System.Drawing.Size(27, 14);
            this.lblQ3.TabIndex = 24;
            this.lblQ3.Text = "Q3";
            // 
            // txtQ3
            // 
            this.txtQ3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ3.Location = new System.Drawing.Point(424, 87);
            this.txtQ3.MaxLength = 1;
            this.txtQ3.Name = "txtQ3";
            this.txtQ3.Size = new System.Drawing.Size(41, 22);
            this.txtQ3.TabIndex = 25;
            this.txtQ3.TextChanged += new System.EventHandler(this.txtQ3_TextChanged);
            this.txtQ3.Enter += new System.EventHandler(this.txtQ3_Enter);
            this.txtQ3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_KeyPress);
            // 
            // lblLanguage
            // 
            this.lblLanguage.AutoSize = true;
            this.lblLanguage.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLanguage.ForeColor = System.Drawing.Color.White;
            this.lblLanguage.Location = new System.Drawing.Point(898, 16);
            this.lblLanguage.Name = "lblLanguage";
            this.lblLanguage.Size = new System.Drawing.Size(71, 14);
            this.lblLanguage.TabIndex = 54;
            this.lblLanguage.Text = "Language";
            // 
            // txtLanguage
            // 
            this.txtLanguage.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtLanguage.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtLanguage.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtLanguage.Location = new System.Drawing.Point(975, 13);
            this.txtLanguage.MaxLength = 1;
            this.txtLanguage.Name = "txtLanguage";
            this.txtLanguage.Size = new System.Drawing.Size(41, 22);
            this.txtLanguage.TabIndex = 55;
            this.txtLanguage.TextChanged += new System.EventHandler(this.txtLanguage_TextChanged);
            this.txtLanguage.Enter += new System.EventHandler(this.txtLanguage_Enter);
            this.txtLanguage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLanguage_KeyPress);
            // 
            // lblQ17
            // 
            this.lblQ17.AutoSize = true;
            this.lblQ17.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ17.ForeColor = System.Drawing.Color.White;
            this.lblQ17.Location = new System.Drawing.Point(788, 163);
            this.lblQ17.Name = "lblQ17";
            this.lblQ17.Size = new System.Drawing.Size(36, 14);
            this.lblQ17.TabIndex = 52;
            this.lblQ17.Text = "Q17";
            // 
            // txtQ17
            // 
            this.txtQ17.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ17.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ17.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ17.Location = new System.Drawing.Point(835, 161);
            this.txtQ17.MaxLength = 1;
            this.txtQ17.Name = "txtQ17";
            this.txtQ17.Size = new System.Drawing.Size(41, 22);
            this.txtQ17.TabIndex = 53;
            this.txtQ17.TextChanged += new System.EventHandler(this.txtQ17_TextChanged);
            this.txtQ17.Enter += new System.EventHandler(this.txtQ17_Enter);
            this.txtQ17.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ17_KeyPress);
            // 
            // lblQ16
            // 
            this.lblQ16.AutoSize = true;
            this.lblQ16.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ16.ForeColor = System.Drawing.Color.White;
            this.lblQ16.Location = new System.Drawing.Point(788, 125);
            this.lblQ16.Name = "lblQ16";
            this.lblQ16.Size = new System.Drawing.Size(36, 14);
            this.lblQ16.TabIndex = 50;
            this.lblQ16.Text = "Q16";
            // 
            // txtQ16
            // 
            this.txtQ16.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ16.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ16.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ16.Location = new System.Drawing.Point(835, 123);
            this.txtQ16.MaxLength = 1;
            this.txtQ16.Name = "txtQ16";
            this.txtQ16.Size = new System.Drawing.Size(41, 22);
            this.txtQ16.TabIndex = 51;
            this.txtQ16.TextChanged += new System.EventHandler(this.txtQ16_TextChanged);
            this.txtQ16.Enter += new System.EventHandler(this.txtQ16_Enter);
            this.txtQ16.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ16_KeyPress);
            // 
            // lblQ15
            // 
            this.lblQ15.AutoSize = true;
            this.lblQ15.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ15.ForeColor = System.Drawing.Color.White;
            this.lblQ15.Location = new System.Drawing.Point(788, 89);
            this.lblQ15.Name = "lblQ15";
            this.lblQ15.Size = new System.Drawing.Size(36, 14);
            this.lblQ15.TabIndex = 48;
            this.lblQ15.Text = "Q15";
            // 
            // txtQ15
            // 
            this.txtQ15.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ15.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ15.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ15.Location = new System.Drawing.Point(835, 87);
            this.txtQ15.MaxLength = 1;
            this.txtQ15.Name = "txtQ15";
            this.txtQ15.Size = new System.Drawing.Size(41, 22);
            this.txtQ15.TabIndex = 49;
            this.txtQ15.TextChanged += new System.EventHandler(this.txtQ15_TextChanged);
            this.txtQ15.Enter += new System.EventHandler(this.txtQ15_Enter);
            this.txtQ15.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ15_KeyPress);
            // 
            // lblQ14
            // 
            this.lblQ14.AutoSize = true;
            this.lblQ14.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ14.ForeColor = System.Drawing.Color.White;
            this.lblQ14.Location = new System.Drawing.Point(788, 57);
            this.lblQ14.Name = "lblQ14";
            this.lblQ14.Size = new System.Drawing.Size(36, 14);
            this.lblQ14.TabIndex = 46;
            this.lblQ14.Text = "Q14";
            // 
            // txtQ14
            // 
            this.txtQ14.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ14.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ14.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ14.Location = new System.Drawing.Point(835, 52);
            this.txtQ14.MaxLength = 1;
            this.txtQ14.Name = "txtQ14";
            this.txtQ14.Size = new System.Drawing.Size(41, 22);
            this.txtQ14.TabIndex = 47;
            this.txtQ14.TextChanged += new System.EventHandler(this.txtQ14_TextChanged);
            this.txtQ14.Enter += new System.EventHandler(this.txtQ14_Enter);
            this.txtQ14.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ14_KeyPress);
            // 
            // lblQ13
            // 
            this.lblQ13.AutoSize = true;
            this.lblQ13.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ13.ForeColor = System.Drawing.Color.White;
            this.lblQ13.Location = new System.Drawing.Point(601, 162);
            this.lblQ13.Name = "lblQ13";
            this.lblQ13.Size = new System.Drawing.Size(36, 14);
            this.lblQ13.TabIndex = 44;
            this.lblQ13.Text = "Q13";
            // 
            // txtQ13
            // 
            this.txtQ13.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ13.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ13.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ13.Location = new System.Drawing.Point(648, 160);
            this.txtQ13.MaxLength = 1;
            this.txtQ13.Name = "txtQ13";
            this.txtQ13.Size = new System.Drawing.Size(41, 22);
            this.txtQ13.TabIndex = 45;
            this.txtQ13.TextChanged += new System.EventHandler(this.txtQ13_TextChanged);
            this.txtQ13.Enter += new System.EventHandler(this.txtQ13_Enter);
            this.txtQ13.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ13_KeyPress);
            // 
            // lblQ12
            // 
            this.lblQ12.AutoSize = true;
            this.lblQ12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ12.ForeColor = System.Drawing.Color.White;
            this.lblQ12.Location = new System.Drawing.Point(601, 124);
            this.lblQ12.Name = "lblQ12";
            this.lblQ12.Size = new System.Drawing.Size(36, 14);
            this.lblQ12.TabIndex = 42;
            this.lblQ12.Text = "Q12";
            // 
            // txtQ12
            // 
            this.txtQ12.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ12.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ12.Location = new System.Drawing.Point(648, 122);
            this.txtQ12.MaxLength = 1;
            this.txtQ12.Name = "txtQ12";
            this.txtQ12.Size = new System.Drawing.Size(41, 22);
            this.txtQ12.TabIndex = 43;
            this.txtQ12.TextChanged += new System.EventHandler(this.txtQ12_TextChanged);
            this.txtQ12.Enter += new System.EventHandler(this.txtQ12_Enter);
            this.txtQ12.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ12_KeyPress);
            // 
            // lblQ11
            // 
            this.lblQ11.AutoSize = true;
            this.lblQ11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ11.ForeColor = System.Drawing.Color.White;
            this.lblQ11.Location = new System.Drawing.Point(601, 89);
            this.lblQ11.Name = "lblQ11";
            this.lblQ11.Size = new System.Drawing.Size(36, 14);
            this.lblQ11.TabIndex = 40;
            this.lblQ11.Text = "Q11";
            // 
            // txtQ11
            // 
            this.txtQ11.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ11.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ11.Location = new System.Drawing.Point(648, 86);
            this.txtQ11.MaxLength = 10;
            this.txtQ11.Name = "txtQ11";
            this.txtQ11.Size = new System.Drawing.Size(110, 22);
            this.txtQ11.TabIndex = 41;
            this.txtQ11.TextChanged += new System.EventHandler(this.txtQ11_TextChanged);
            this.txtQ11.Enter += new System.EventHandler(this.txtQ11_Enter);
            this.txtQ11.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ11_KeyPress);
            // 
            // lblQ10
            // 
            this.lblQ10.AutoSize = true;
            this.lblQ10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ10.ForeColor = System.Drawing.Color.White;
            this.lblQ10.Location = new System.Drawing.Point(601, 53);
            this.lblQ10.Name = "lblQ10";
            this.lblQ10.Size = new System.Drawing.Size(36, 14);
            this.lblQ10.TabIndex = 38;
            this.lblQ10.Text = "Q10";
            // 
            // txtQ10
            // 
            this.txtQ10.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ10.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ10.Location = new System.Drawing.Point(648, 48);
            this.txtQ10.MaxLength = 1;
            this.txtQ10.Name = "txtQ10";
            this.txtQ10.Size = new System.Drawing.Size(41, 22);
            this.txtQ10.TabIndex = 39;
            this.txtQ10.TextChanged += new System.EventHandler(this.txtQ10_TextChanged);
            this.txtQ10.Enter += new System.EventHandler(this.txtQ10_Enter);
            this.txtQ10.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ10_KeyPress);
            // 
            // lblQ9
            // 
            this.lblQ9.AutoSize = true;
            this.lblQ9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ9.ForeColor = System.Drawing.Color.White;
            this.lblQ9.Location = new System.Drawing.Point(495, 161);
            this.lblQ9.Name = "lblQ9";
            this.lblQ9.Size = new System.Drawing.Size(27, 14);
            this.lblQ9.TabIndex = 36;
            this.lblQ9.Text = "Q9";
            // 
            // txtQ9
            // 
            this.txtQ9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ9.Location = new System.Drawing.Point(533, 159);
            this.txtQ9.MaxLength = 1;
            this.txtQ9.Name = "txtQ9";
            this.txtQ9.Size = new System.Drawing.Size(41, 22);
            this.txtQ9.TabIndex = 37;
            this.txtQ9.TextChanged += new System.EventHandler(this.txtQ9_TextChanged);
            this.txtQ9.Enter += new System.EventHandler(this.txtQ9_Enter);
            this.txtQ9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ9_KeyPress);
            // 
            // lblQ8
            // 
            this.lblQ8.AutoSize = true;
            this.lblQ8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ8.ForeColor = System.Drawing.Color.White;
            this.lblQ8.Location = new System.Drawing.Point(495, 123);
            this.lblQ8.Name = "lblQ8";
            this.lblQ8.Size = new System.Drawing.Size(27, 14);
            this.lblQ8.TabIndex = 34;
            this.lblQ8.Text = "Q8";
            // 
            // txtQ8
            // 
            this.txtQ8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ8.Location = new System.Drawing.Point(533, 121);
            this.txtQ8.MaxLength = 1;
            this.txtQ8.Name = "txtQ8";
            this.txtQ8.Size = new System.Drawing.Size(41, 22);
            this.txtQ8.TabIndex = 35;
            this.txtQ8.TextChanged += new System.EventHandler(this.txtQ8_TextChanged);
            this.txtQ8.Enter += new System.EventHandler(this.txtQ8_Enter);
            this.txtQ8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ8_KeyPress);
            // 
            // lblQ7
            // 
            this.lblQ7.AutoSize = true;
            this.lblQ7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ7.ForeColor = System.Drawing.Color.White;
            this.lblQ7.Location = new System.Drawing.Point(495, 87);
            this.lblQ7.Name = "lblQ7";
            this.lblQ7.Size = new System.Drawing.Size(27, 14);
            this.lblQ7.TabIndex = 32;
            this.lblQ7.Text = "Q7";
            // 
            // txtQ7
            // 
            this.txtQ7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ7.Location = new System.Drawing.Point(533, 85);
            this.txtQ7.MaxLength = 1;
            this.txtQ7.Name = "txtQ7";
            this.txtQ7.Size = new System.Drawing.Size(41, 22);
            this.txtQ7.TabIndex = 33;
            this.txtQ7.TextChanged += new System.EventHandler(this.txtQ7_TextChanged);
            this.txtQ7.Enter += new System.EventHandler(this.txtQ7_Enter);
            this.txtQ7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ7_KeyPress);
            // 
            // lblQ6
            // 
            this.lblQ6.AutoSize = true;
            this.lblQ6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ6.ForeColor = System.Drawing.Color.White;
            this.lblQ6.Location = new System.Drawing.Point(495, 52);
            this.lblQ6.Name = "lblQ6";
            this.lblQ6.Size = new System.Drawing.Size(27, 14);
            this.lblQ6.TabIndex = 30;
            this.lblQ6.Text = "Q6";
            // 
            // txtQ6
            // 
            this.txtQ6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ6.Location = new System.Drawing.Point(533, 47);
            this.txtQ6.MaxLength = 1;
            this.txtQ6.Name = "txtQ6";
            this.txtQ6.Size = new System.Drawing.Size(41, 22);
            this.txtQ6.TabIndex = 31;
            this.txtQ6.TextChanged += new System.EventHandler(this.txtQ6_TextChanged);
            this.txtQ6.Enter += new System.EventHandler(this.txtQ6_Enter);
            this.txtQ6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ6_KeyPress);
            // 
            // lblQ5
            // 
            this.lblQ5.AutoSize = true;
            this.lblQ5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ5.ForeColor = System.Drawing.Color.White;
            this.lblQ5.Location = new System.Drawing.Point(386, 159);
            this.lblQ5.Name = "lblQ5";
            this.lblQ5.Size = new System.Drawing.Size(27, 14);
            this.lblQ5.TabIndex = 28;
            this.lblQ5.Text = "Q5";
            // 
            // txtQ5
            // 
            this.txtQ5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ5.Location = new System.Drawing.Point(424, 157);
            this.txtQ5.MaxLength = 1;
            this.txtQ5.Name = "txtQ5";
            this.txtQ5.Size = new System.Drawing.Size(41, 22);
            this.txtQ5.TabIndex = 29;
            this.txtQ5.TextChanged += new System.EventHandler(this.txtQ5_TextChanged);
            this.txtQ5.Enter += new System.EventHandler(this.txtQ5_Enter);
            this.txtQ5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ5_KeyPress);
            // 
            // lblQ4
            // 
            this.lblQ4.AutoSize = true;
            this.lblQ4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ4.ForeColor = System.Drawing.Color.White;
            this.lblQ4.Location = new System.Drawing.Point(386, 121);
            this.lblQ4.Name = "lblQ4";
            this.lblQ4.Size = new System.Drawing.Size(27, 14);
            this.lblQ4.TabIndex = 26;
            this.lblQ4.Text = "Q4";
            // 
            // txtQ4
            // 
            this.txtQ4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ4.Location = new System.Drawing.Point(424, 119);
            this.txtQ4.MaxLength = 1;
            this.txtQ4.Name = "txtQ4";
            this.txtQ4.Size = new System.Drawing.Size(41, 22);
            this.txtQ4.TabIndex = 27;
            this.txtQ4.TextChanged += new System.EventHandler(this.txtQ4_TextChanged);
            this.txtQ4.Enter += new System.EventHandler(this.txtQ4_Enter);
            this.txtQ4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ4_KeyPress);
            // 
            // lblQ2_8
            // 
            this.lblQ2_8.AutoSize = true;
            this.lblQ2_8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_8.ForeColor = System.Drawing.Color.White;
            this.lblQ2_8.Location = new System.Drawing.Point(368, 56);
            this.lblQ2_8.Name = "lblQ2_8";
            this.lblQ2_8.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_8.TabIndex = 22;
            this.lblQ2_8.Text = "Q2_8";
            // 
            // txtQ2_8
            // 
            this.txtQ2_8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ2_8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ2_8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ2_8.Location = new System.Drawing.Point(424, 50);
            this.txtQ2_8.MaxLength = 1;
            this.txtQ2_8.Name = "txtQ2_8";
            this.txtQ2_8.Size = new System.Drawing.Size(41, 22);
            this.txtQ2_8.TabIndex = 23;
            this.txtQ2_8.TextChanged += new System.EventHandler(this.txtQ2_8_TextChanged);
            this.txtQ2_8.Enter += new System.EventHandler(this.txtQ2_8_Enter);
            this.txtQ2_8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_8_KeyPress);
            // 
            // lblQ2_7
            // 
            this.lblQ2_7.AutoSize = true;
            this.lblQ2_7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_7.ForeColor = System.Drawing.Color.White;
            this.lblQ2_7.Location = new System.Drawing.Point(251, 164);
            this.lblQ2_7.Name = "lblQ2_7";
            this.lblQ2_7.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_7.TabIndex = 20;
            this.lblQ2_7.Text = "Q2_7";
            // 
            // txtQ2_7
            // 
            this.txtQ2_7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ2_7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ2_7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ2_7.Location = new System.Drawing.Point(307, 159);
            this.txtQ2_7.MaxLength = 1;
            this.txtQ2_7.Name = "txtQ2_7";
            this.txtQ2_7.Size = new System.Drawing.Size(41, 22);
            this.txtQ2_7.TabIndex = 21;
            this.txtQ2_7.TextChanged += new System.EventHandler(this.txtQ2_7_TextChanged);
            this.txtQ2_7.Enter += new System.EventHandler(this.txtQ2_7_Enter);
            this.txtQ2_7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_7_KeyPress);
            // 
            // lblQ2_6
            // 
            this.lblQ2_6.AutoSize = true;
            this.lblQ2_6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_6.ForeColor = System.Drawing.Color.White;
            this.lblQ2_6.Location = new System.Drawing.Point(251, 124);
            this.lblQ2_6.Name = "lblQ2_6";
            this.lblQ2_6.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_6.TabIndex = 18;
            this.lblQ2_6.Text = "Q2_6";
            // 
            // txtQ2_6
            // 
            this.txtQ2_6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ2_6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ2_6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ2_6.Location = new System.Drawing.Point(307, 122);
            this.txtQ2_6.MaxLength = 1;
            this.txtQ2_6.Name = "txtQ2_6";
            this.txtQ2_6.Size = new System.Drawing.Size(41, 22);
            this.txtQ2_6.TabIndex = 19;
            this.txtQ2_6.TextChanged += new System.EventHandler(this.txtQ2_6_TextChanged);
            this.txtQ2_6.Enter += new System.EventHandler(this.txtQ2_6_Enter);
            this.txtQ2_6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_6_KeyPress);
            // 
            // lblQ2_5
            // 
            this.lblQ2_5.AutoSize = true;
            this.lblQ2_5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_5.ForeColor = System.Drawing.Color.White;
            this.lblQ2_5.Location = new System.Drawing.Point(251, 86);
            this.lblQ2_5.Name = "lblQ2_5";
            this.lblQ2_5.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_5.TabIndex = 16;
            this.lblQ2_5.Text = "Q2_5";
            // 
            // txtQ2_5
            // 
            this.txtQ2_5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ2_5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ2_5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ2_5.Location = new System.Drawing.Point(307, 84);
            this.txtQ2_5.MaxLength = 1;
            this.txtQ2_5.Name = "txtQ2_5";
            this.txtQ2_5.Size = new System.Drawing.Size(41, 22);
            this.txtQ2_5.TabIndex = 17;
            this.txtQ2_5.TextChanged += new System.EventHandler(this.txtQ2_5_TextChanged);
            this.txtQ2_5.Enter += new System.EventHandler(this.txtQ2_5_Enter);
            this.txtQ2_5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_5_KeyPress);
            // 
            // lblQ2_4
            // 
            this.lblQ2_4.AutoSize = true;
            this.lblQ2_4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_4.ForeColor = System.Drawing.Color.White;
            this.lblQ2_4.Location = new System.Drawing.Point(251, 51);
            this.lblQ2_4.Name = "lblQ2_4";
            this.lblQ2_4.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_4.TabIndex = 14;
            this.lblQ2_4.Text = "Q2_4";
            // 
            // txtQ2_4
            // 
            this.txtQ2_4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ2_4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ2_4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ2_4.Location = new System.Drawing.Point(307, 48);
            this.txtQ2_4.MaxLength = 1;
            this.txtQ2_4.Name = "txtQ2_4";
            this.txtQ2_4.Size = new System.Drawing.Size(41, 22);
            this.txtQ2_4.TabIndex = 15;
            this.txtQ2_4.TextChanged += new System.EventHandler(this.txtQ2_4_TextChanged);
            this.txtQ2_4.Enter += new System.EventHandler(this.txtQ2_4_Enter);
            this.txtQ2_4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_4_KeyPress);
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescription.ForeColor = System.Drawing.Color.White;
            this.lblDescription.Location = new System.Drawing.Point(135, 17);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(82, 14);
            this.lblDescription.TabIndex = 2;
            this.lblDescription.Text = "Description";
            this.lblDescription.Visible = false;
            // 
            // lblQ2_3
            // 
            this.lblQ2_3.AutoSize = true;
            this.lblQ2_3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_3.ForeColor = System.Drawing.Color.White;
            this.lblQ2_3.Location = new System.Drawing.Point(135, 164);
            this.lblQ2_3.Name = "lblQ2_3";
            this.lblQ2_3.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_3.TabIndex = 12;
            this.lblQ2_3.Text = "Q2_3";
            // 
            // txtQ2_3
            // 
            this.txtQ2_3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ2_3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ2_3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ2_3.Location = new System.Drawing.Point(191, 159);
            this.txtQ2_3.MaxLength = 1;
            this.txtQ2_3.Name = "txtQ2_3";
            this.txtQ2_3.Size = new System.Drawing.Size(41, 22);
            this.txtQ2_3.TabIndex = 13;
            this.txtQ2_3.TextChanged += new System.EventHandler(this.txtQ2_3_TextChanged);
            this.txtQ2_3.Enter += new System.EventHandler(this.txtQ2_3_Enter);
            this.txtQ2_3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_3_KeyPress);
            // 
            // lblQ2_2
            // 
            this.lblQ2_2.AutoSize = true;
            this.lblQ2_2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_2.ForeColor = System.Drawing.Color.White;
            this.lblQ2_2.Location = new System.Drawing.Point(135, 125);
            this.lblQ2_2.Name = "lblQ2_2";
            this.lblQ2_2.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_2.TabIndex = 10;
            this.lblQ2_2.Text = "Q2_2";
            // 
            // txtQ2_2
            // 
            this.txtQ2_2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ2_2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ2_2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ2_2.Location = new System.Drawing.Point(191, 123);
            this.txtQ2_2.MaxLength = 1;
            this.txtQ2_2.Name = "txtQ2_2";
            this.txtQ2_2.Size = new System.Drawing.Size(41, 22);
            this.txtQ2_2.TabIndex = 11;
            this.txtQ2_2.TextChanged += new System.EventHandler(this.txtQ2_2_TextChanged);
            this.txtQ2_2.Enter += new System.EventHandler(this.txtQ2_2_Enter);
            this.txtQ2_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_2_KeyPress);
            // 
            // lblQ2_1
            // 
            this.lblQ2_1.AutoSize = true;
            this.lblQ2_1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_1.ForeColor = System.Drawing.Color.White;
            this.lblQ2_1.Location = new System.Drawing.Point(135, 87);
            this.lblQ2_1.Name = "lblQ2_1";
            this.lblQ2_1.Size = new System.Drawing.Size(45, 14);
            this.lblQ2_1.TabIndex = 8;
            this.lblQ2_1.Text = "Q2_1";
            // 
            // txtQ2_1
            // 
            this.txtQ2_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ2_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ2_1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ2_1.Location = new System.Drawing.Point(191, 85);
            this.txtQ2_1.MaxLength = 1;
            this.txtQ2_1.Name = "txtQ2_1";
            this.txtQ2_1.Size = new System.Drawing.Size(41, 22);
            this.txtQ2_1.TabIndex = 9;
            this.txtQ2_1.TextChanged += new System.EventHandler(this.txtQ2_1_TextChanged);
            this.txtQ2_1.Enter += new System.EventHandler(this.txtQ2_1_Enter);
            this.txtQ2_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_1_KeyPress);
            // 
            // IGImageViewer
            // 
            this.IGImageViewer.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.IGImageViewer.BackColor = System.Drawing.Color.Azure;
            this.IGImageViewer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.IGImageViewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IGImageViewer.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IGImageViewer.ImageData = null;
            this.IGImageViewer.ImageName = null;
            this.IGImageViewer.ImageScropping = false;
            this.IGImageViewer.ImageSize = new System.Drawing.Size(0, 0);
            this.IGImageViewer.Location = new System.Drawing.Point(3, -2);
            this.IGImageViewer.Name = "IGImageViewer";
            this.IGImageViewer.PictureBoxSize = new System.Drawing.Size(0, 0);
            this.IGImageViewer.Size = new System.Drawing.Size(1052, 466);
            this.IGImageViewer.StatusBarVisible = true;
            this.IGImageViewer.TabIndex = 1;
            // 
            // txtmailType
            // 
            this.txtmailType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtmailType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtmailType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtmailType.Location = new System.Drawing.Point(909, 64);
            this.txtmailType.MaxLength = 10;
            this.txtmailType.Name = "txtmailType";
            this.txtmailType.Size = new System.Drawing.Size(110, 22);
            this.txtmailType.TabIndex = 57;
            this.txtmailType.TextChanged += new System.EventHandler(this.txtmailType_TextChanged);
            this.txtmailType.Enter += new System.EventHandler(this.txtmailType_Enter);
            this.txtmailType.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmailType_KeyPress);
            // 
            // frmKeying_HRA_V2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1055, 742);
            this.Controls.Add(this.IGImageViewer);
            this.Controls.Add(this.grpMain);
            this.KeyPreview = true;
            this.Name = "frmKeying_HRA_V2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmKeying_HRA_FormClosing);
            this.Load += new System.EventHandler(this.frmKeying_HRA_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmKeying_HRA_KeyDown);
            this.grpButtons.ResumeLayout(false);
            this.grpKeyData.ResumeLayout(false);
            this.grpKeyData.PerformLayout();
            this.grpMain.ResumeLayout(false);
            this.StatusStrip1.ResumeLayout(false);
            this.StatusStrip1.PerformLayout();
            this.grpTxtBoxes1.ResumeLayout(false);
            this.grpTxtBoxes1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblRespondentID;
        private System.Windows.Forms.TextBox txtRespndentID;
        private System.Windows.Forms.Label lblQ1;
        private System.Windows.Forms.TextBox txtQ1;
        private System.Windows.Forms.GroupBox grpButtons;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.GroupBox grpKeyData;
        private System.Windows.Forms.Label lblKey2Data;
        private System.Windows.Forms.TextBox txtKey2Data;
        private System.Windows.Forms.Label lblKey2User;
        private System.Windows.Forms.TextBox txtKey2User;
        private System.Windows.Forms.Label lblKey1Data;
        private System.Windows.Forms.TextBox txtKey1Data;
        private System.Windows.Forms.Label lblKey1User;
        private System.Windows.Forms.TextBox txtKey1User;
        internal System.Windows.Forms.ToolStripStatusLabel stsDate;
        internal System.Windows.Forms.ToolStripStatusLabel stsRemRecs;
        internal System.Windows.Forms.ToolStripStatusLabel stsFinRecs;
        private System.Windows.Forms.GroupBox grpMain;
        internal System.Windows.Forms.StatusStrip StatusStrip1;
        internal System.Windows.Forms.ToolStripStatusLabel stsUser;
        internal System.Windows.Forms.ToolStripStatusLabel stsTotRecs;
        private System.Windows.Forms.GroupBox grpTxtBoxes1;
        private System.Windows.Forms.TextBox txtQ2_3;
        private System.Windows.Forms.TextBox txtQ2_2;
        private System.Windows.Forms.Label lblQ2_1;
        private System.Windows.Forms.TextBox txtQ2_1;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblQ2_3;
        private System.Windows.Forms.Label lblQ2_2;
        private System.Windows.Forms.Label lblQ10;
        private System.Windows.Forms.TextBox txtQ10;
        private System.Windows.Forms.Label lblQ9;
        private System.Windows.Forms.TextBox txtQ9;
        private System.Windows.Forms.Label lblQ8;
        private System.Windows.Forms.TextBox txtQ8;
        private System.Windows.Forms.Label lblQ7;
        private System.Windows.Forms.TextBox txtQ7;
        private System.Windows.Forms.Label lblQ6;
        private System.Windows.Forms.TextBox txtQ6;
        private System.Windows.Forms.Label lblQ5;
        private System.Windows.Forms.TextBox txtQ5;
        private System.Windows.Forms.Label lblQ4;
        private System.Windows.Forms.TextBox txtQ4;
        private System.Windows.Forms.Label lblQ2_8;
        private System.Windows.Forms.TextBox txtQ2_8;
        private System.Windows.Forms.Label lblQ2_7;
        private System.Windows.Forms.TextBox txtQ2_7;
        private System.Windows.Forms.Label lblQ2_6;
        private System.Windows.Forms.TextBox txtQ2_6;
        private System.Windows.Forms.Label lblQ2_5;
        private System.Windows.Forms.TextBox txtQ2_5;
        private System.Windows.Forms.Label lblQ2_4;
        private System.Windows.Forms.TextBox txtQ2_4;
        private System.Windows.Forms.Label lblLanguage;
        private System.Windows.Forms.TextBox txtLanguage;
        private System.Windows.Forms.Label lblQ17;
        private System.Windows.Forms.TextBox txtQ17;
        private System.Windows.Forms.Label lblQ16;
        private System.Windows.Forms.TextBox txtQ16;
        private System.Windows.Forms.Label lblQ15;
        private System.Windows.Forms.TextBox txtQ15;
        private System.Windows.Forms.Label lblQ14;
        private System.Windows.Forms.TextBox txtQ14;
        private System.Windows.Forms.Label lblQ13;
        private System.Windows.Forms.TextBox txtQ13;
        private System.Windows.Forms.Label lblQ12;
        private System.Windows.Forms.TextBox txtQ12;
        private System.Windows.Forms.Label lblQ11;
        private System.Windows.Forms.TextBox txtQ11;
        private System.Windows.Forms.Label lblQ3;
        private System.Windows.Forms.TextBox txtQ3;
        private System.Windows.Forms.Label txtDescription;
        private InfognanaImageViewer.IGImageViewer IGImageViewer;
        private System.Windows.Forms.Label lblMailType;
        private System.Windows.Forms.TextBox txtmailType;

    }
}