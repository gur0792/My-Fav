﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using MySql.Data.MySqlClient;
using DataAccessLayer.ProjectDB;
using DataAccessLayer.GlobalDB;
using DataAccessLayer.ZipCodeDB;
using App.Base;
using System.IO;

namespace Healthtel_MRT
{
    public partial class frmKeying_HRA : Form
    {
        public frmKeying_HRA()
        {
            InitializeComponent();

            //BarcodeWorker.DoWork += new DoWorkEventHandler(BarcodeWorker_DoWork);
            //BarcodeWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(BarcodeWorker_RunWorkerCompleted);
            ////BarcodeWorker.ProgressChanged += new ProgressChangedEventHandler(BarcodeWorker_ProgressChanged);
            //BarcodeWorker.WorkerReportsProgress = true;
            //BarcodeWorker.WorkerSupportsCancellation = true;
        }

        #region Global Variables
        //public string path = Application.StartupPath + "\\Import_Log_File\\ImportLog.txt";
        //login LoggedUsers = new batchmaster().getLoginUser();
        batchmaster objBatchmaster = new batchmaster();
        imagemaster objImagemaster = new imagemaster();
        key1_hra objKey1 = new key1_hra();
        key2_hra objKey2 = new key2_hra();
        compareqc_hra objCompareQC = new compareqc_hra();

        imagemaster Image = new imagemaster();
        key1_hra getkey1Data = new key1_hra();
        key2_hra getkey2Data = new key2_hra();
        compareqc_hra getCompareqcData = new compareqc_hra();

        long lngBatchID;
        long lngImageID;
        int intBatchType;
        string strImagePath;
        int totRecs;
        int RemRecs;
        int FinRecs;
        string ProcessType;
        string strSQL;
        DataSet dsKeyData;
        DataSet dsKey1;
        DataSet dskey;
        string strImageSize;
        string strImageFit;
        int iHScrol = 0;
        int iVScrol = 0;

        bool bCtrl = false;
        bool bAlt = false;
        bool bShift = false;
        bool bImageLoad = false;
        AutoCompleteStringCollection citycollection = new AutoCompleteStringCollection();
        bool bPreview = true;
        DataSet dsCities;
        AutoCompleteStringCollection AddressList = new AutoCompleteStringCollection();

        private BackgroundWorker BarcodeWorker = new BackgroundWorker();
        System.Collections.ArrayList barcodes = new System.Collections.ArrayList();
        //DateTime dtStart = DateTime.Now;
        int iScans = 300;
        string barcode = "";
        System.Drawing.Bitmap bmp;
        #endregion

        #region Global Fields For Controls
        public const string GC_FIELDS_RESPONDENTID = "txtRespndentID";
        public const string GC_FIELDS_Q1 = "txtQ1";
        public const string GC_FIELDS_Q2_1 = "txtQ2_1";
        public const string GC_FIELDS_Q2_2 = "txtQ2_2";
        public const string GC_FIELDS_Q2_3 = "txtQ2_3";
        public const string GC_FIELDS_Q2_4 = "txtQ2_4";
        public const string GC_FIELDS_Q2_5 = "txtQ2_5";
        public const string GC_FIELDS_Q2_6 = "txtQ2_6";
        public const string GC_FIELDS_Q2_7 = "txtQ2_7";
        public const string GC_FIELDS_Q2_8 = "txtQ2_8";
        public const string GC_FIELDS_Q3 = "txtQ3";
        public const string GC_FIELDS_Q4 = "txtQ4";
        public const string GC_FIELDS_Q5 = "txtQ5";
        public const string GC_FIELDS_Q6 = "txtQ6";
        public const string GC_FIELDS_Q7 = "txtQ7";
        public const string GC_FIELDS_Q8 = "txtQ8";
        public const string GC_FIELDS_Q9 = "txtQ9";
        public const string GC_FIELDS_Q10 = "txtQ10";
        public const string GC_FIELDS_Q11 = "txtQ11";
        public const string GC_FIELDS_Q12 = "txtQ12";
        public const string GC_FIELDS_Q13 = "txtQ13";
        public const string GC_FIELDS_Q14 = "txtQ14";
        public const string GC_FIELDS_Q15 = "txtQ15";
        public const string GC_FIELDS_Q16 = "txtQ16";
        public const string GC_FIELDS_Q17 = "txtQ17";
        public const string GC_FIELDS_LANGUAGE = "txtLanguage";
        #endregion

        #region Property Variables
        public long BatchID
        {
            get { return lngBatchID; }

            set { lngBatchID = value; }
        }

        public string Process
        {
            get { return ProcessType; }

            set { ProcessType = value; }
        }

        public int BatchType
        {
            get { return intBatchType; }

            set { intBatchType = value; }
        }
        #endregion

        #region help Methods

        private bool txtKeyPress(object Sender, System.Windows.Forms.KeyPressEventArgs e, Control ObjControl)
        {
            try
            {
                if ((ObjControl is TextBox) || (ObjControl is ComboBox))
                {
                    e.KeyChar = char.ToUpper(e.KeyChar);

                    switch (ObjControl.Name)
                    {
                        case GC_FIELDS_RESPONDENTID:
                        case GC_FIELDS_Q11:
                            if (char.IsDigit(e.KeyChar) || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back) || char.IsWhiteSpace(e.KeyChar) || char.IsPunctuation(e.KeyChar) || char.IsSymbol(e.KeyChar))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;

                        case GC_FIELDS_Q1:
                            if (e.KeyChar == '1' || e.KeyChar == '2' || e.KeyChar == '3' || e.KeyChar == '4' || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;



                        case GC_FIELDS_Q2_1:
                        case GC_FIELDS_Q2_2:
                        case GC_FIELDS_Q2_3:
                        case GC_FIELDS_Q2_4:
                        case GC_FIELDS_Q2_5:
                        case GC_FIELDS_Q2_6:
                        case GC_FIELDS_Q2_7:
                        case GC_FIELDS_Q2_8:
                            if (e.KeyChar == '1' || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;

                        case GC_FIELDS_Q4:
                        case GC_FIELDS_Q5:
                        case GC_FIELDS_Q6:
                        case GC_FIELDS_Q7:
                        case GC_FIELDS_Q8:
                        case GC_FIELDS_Q9:
                        case GC_FIELDS_Q10:
                        case GC_FIELDS_Q12:
                        case GC_FIELDS_Q14:
                        case GC_FIELDS_Q15:
                        case GC_FIELDS_Q16:
                        case GC_FIELDS_LANGUAGE:
                            if (e.KeyChar == '1' || e.KeyChar == '2' || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;

                        case GC_FIELDS_Q13:
                            if (e.KeyChar == '1' || e.KeyChar == '2' || e.KeyChar == '3' || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;

                        case GC_FIELDS_Q17:
                            if (e.KeyChar == '1' || e.KeyChar == '2' || e.KeyChar == '3' || e.KeyChar == '4' || e.KeyChar == '5' || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;                      
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private bool txtChanged(object Sender, System.EventArgs e, Control ObjControl)
        {
            try
            {
                if ((ObjControl is TextBox) || (ObjControl is ComboBox) || (ObjControl is CheckBox))
                {
                    switch (ObjControl.Name)
                    {
                        case GC_FIELDS_RESPONDENTID:
                            if (txtRespndentID.TextLength == txtRespndentID.MaxLength)
                            {
                                txtQ1.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1:
                            if (txtQ1.TextLength == txtQ1.MaxLength)
                            {
                                txtQ2_1.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_1:
                            if (txtQ2_1.TextLength == txtQ2_1.MaxLength)
                            {
                                txtQ2_2.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_2:
                            if (txtQ2_2.Text.Length == txtQ2_2.MaxLength)
                            {
                                txtQ2_3.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_3:
                            if (txtQ2_3.TextLength == txtQ2_3.MaxLength)
                            {
                                txtQ2_4.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_4:
                            if (txtQ2_4.TextLength == txtQ2_4.MaxLength)
                            {
                                txtQ2_5.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_5:
                            if (txtQ2_5.TextLength == txtQ2_5.MaxLength)
                            {
                                txtQ2_6.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_6:
                            if (txtQ2_6.TextLength == txtQ2_6.MaxLength)
                            {
                                txtQ2_7.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_7:
                            if (txtQ2_7.TextLength == txtQ2_7.MaxLength)
                            {
                                txtQ2_8.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_8:
                            if (txtQ2_8.TextLength == txtQ2_8.MaxLength)
                            {
                                txtQ3.Focus();
                            }
                            break;
                        case GC_FIELDS_Q3:
                            if (txtQ3.Text.Length == txtQ3.MaxLength)
                            {
                                txtQ4.Focus();
                            }
                            break;
                        case GC_FIELDS_Q4:
                            if (txtQ4.TextLength == txtQ4.MaxLength)
                            {
                                txtQ5.Focus();
                            }
                            break;
                        case GC_FIELDS_Q5:
                            if (txtQ5.TextLength == txtQ5.MaxLength)
                            {
                                txtQ6.Focus();
                            }
                            break;
                        case GC_FIELDS_Q6:
                            if (txtQ6.TextLength == txtQ6.MaxLength)
                            {
                                txtQ7.Focus();
                            }
                            break;
                        case GC_FIELDS_Q7:
                            if (txtQ7.TextLength == txtQ7.MaxLength)
                            {
                                txtQ8.Focus();
                            }
                            break;
                        case GC_FIELDS_Q8:
                            if (txtQ8.TextLength == txtQ8.MaxLength)
                            {
                                txtQ9.Focus();
                            }
                            break;
                        case GC_FIELDS_Q9:
                            if (txtQ9.TextLength == txtQ9.MaxLength)
                            {
                                txtQ10.Focus();
                            }
                            break;
                        case GC_FIELDS_Q10:
                            if (txtQ10.TextLength == txtQ10.MaxLength)
                            {
                                txtQ11.Focus();
                            }
                            break;
                        case GC_FIELDS_Q11:
                            if (txtQ11.TextLength == txtQ11.MaxLength)
                            {
                                txtQ12.Focus();
                            }
                            break;
                        case GC_FIELDS_Q12:
                            if (txtQ12.Text.Length == txtQ12.MaxLength)
                            {
                                txtQ13.Focus();
                            }
                            break;
                        case GC_FIELDS_Q13:
                            if (txtQ13.Text.Length == txtQ13.MaxLength)
                            {
                                txtQ14.Focus();
                            }
                            break;
                        case GC_FIELDS_Q14:
                            if (txtQ14.Text.Length == txtQ14.MaxLength)
                            {
                                txtQ15.Focus();
                            }
                            break;
                        case GC_FIELDS_Q15:
                            if (txtQ15.Text.Length == txtQ15.MaxLength)
                            {
                                txtQ16.Focus();
                            }
                            break;
                        case GC_FIELDS_Q16:
                            if (txtQ16.Text.Length == txtQ16.MaxLength)
                            {
                                txtQ17.Focus();
                            }
                            break;
                        case GC_FIELDS_Q17:
                            if (txtQ17.Text.Length == txtQ17.MaxLength)
                            {
                                txtLanguage.Focus();
                            }
                            break;
                        case GC_FIELDS_LANGUAGE:
                            if (txtLanguage.Text.Length == txtLanguage.MaxLength)
                            {
                                btnSave.Focus();
                            }
                            break;                       
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private bool txtEnter(object Sender, System.EventArgs e, Control ObjControl)
        {
            try
            {
                if ((ObjControl is TextBox) || (ObjControl is ComboBox) || (ObjControl is CheckBox))
                {
                    switch (ObjControl.Name)
                    {
                        case GC_FIELDS_RESPONDENTID:
                            txtDescription.Text = "Respondent ID number";
                            txtRespndentID.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Respondent_ID; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Respondent_ID; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Respondent_ID; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 115));
                            break;

                        case GC_FIELDS_Q1:
                            txtDescription.Text = "Q1 [ 1=Very happy, 2=Somewhat happy, 4=Somewhat unhappy, 3=Very unhappy]";
                            txtQ1.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q1; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q1; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q1; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 90));
                            break;

                        case GC_FIELDS_Q2_1:
                            txtDescription.Text = "Q2 [1 or Blank - 1=Heart Disease]";
                            txtQ2_1.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q2_1; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q2_1; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q2_1; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 90));
                            break;

                        case GC_FIELDS_Q2_2:
                            txtDescription.Text = "Q2 [1 or Blank - 1=Heart Failure or enlarged heart]";
                            txtQ2_2.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q2_2; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q2_2; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q2_2; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 90));
                            break;

                        case GC_FIELDS_Q2_3:
                            txtDescription.Text = "Q2 [1 or Blank - 1=Breathing problems caused by emphysema or asthma]";
                            txtQ2_3.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q2_3; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q2_3; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q2_3; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 90));
                            break;

                        case GC_FIELDS_Q2_4:
                            txtDescription.Text = "Q2 [1 or Blank - 1=Kidney Dialysis ]";
                            txtQ2_4.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q2_4; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q2_4; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q2_4; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 90));
                            break;

                        case GC_FIELDS_Q2_5:
                            txtDescription.Text = "Q2 [1 or Blank - 1=Diabetes or other blood sugar problems]";
                            txtQ2_5.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q2_5; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q2_5; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q2_5; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 90));
                            break;

                        case GC_FIELDS_Q2_6:
                            txtDescription.Text = "Q2 [1 or Blank - 1=Depression ]";
                            txtQ2_6.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q2_6; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q2_6; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q2_6; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 90));
                            break;

                        case GC_FIELDS_Q2_7:
                            txtDescription.Text = "Q2 [1 or Blank - 1=Other conditions]";
                            txtQ2_7.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q2_7; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q2_7; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q2_7; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 90));
                            break;

                        case GC_FIELDS_Q2_8:
                            txtDescription.Text = "Q2 [1 or Blank - 1=None]";
                            txtQ2_8.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q2_8; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q2_8; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q2_8; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 90));
                            break;

                        case GC_FIELDS_Q3:
                            txtDescription.Text = "Q3 [1=Yes, 2=No]";
                            txtQ3.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q3; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q3; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q3; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q4:
                            txtDescription.Text = "Q4 [1=Yes, 2=No]";
                            txtQ4.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q4; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q4; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q4; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 67));
                            break;

                        case GC_FIELDS_Q5:
                            txtDescription.Text = "Q5 [1=Yes, 2=No]";
                            txtQ5.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q5; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q5; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q5; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 67));
                            break;

                        case GC_FIELDS_Q6:
                            txtDescription.Text = "Q6 [1=Yes, 2=No]";
                            txtQ6.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q6; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q6; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q6; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 67));
                            break;

                        case GC_FIELDS_Q7:
                            txtDescription.Text = "Q7 [1=Yes, 2=No]";
                            txtQ7.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q7; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q7; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q7; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 67));
                            break;

                        case GC_FIELDS_Q8:
                            txtDescription.Text = "Q8 [1=Yes, 2=No]";
                            txtQ8.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q8; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q8; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q8; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 67));
                            break;

                        case GC_FIELDS_Q9:
                            txtDescription.Text = "Q9 [1=Yes, 2=No]";
                            txtQ9.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q9; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q9; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q9; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 67));
                            break;

                        case GC_FIELDS_Q10:
                            txtDescription.Text = "Q10 [1=Yes, 2=No]";
                            txtQ10.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q10; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q10; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q10; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 67));
                            break;

                        case GC_FIELDS_Q11:
                            txtDescription.Text = "Q11 [Number provided]";
                            txtQ11.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q11; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q11; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q11; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 67));
                            break;

                        case GC_FIELDS_Q12:
                            txtDescription.Text = "Q12 [1=Yes, 2=No]";
                            txtQ12.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q12; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q12; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q12; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 67));
                            break;

                        case GC_FIELDS_Q13:
                            txtDescription.Text = "Q13 [1=1 Time, 2=2 - 3 Times, 3=4 or more times]";
                            txtQ13.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q13; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q13; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q13; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 67));
                            break;

                        case GC_FIELDS_Q14:
                            txtDescription.Text = "Q14 [1=Yes, 2=No]";
                            txtQ14.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q14; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q14; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q14; }
                            }
                        IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 34));
                            break;

                        case GC_FIELDS_Q15:
                            txtDescription.Text = "Q15 [1=Yes, 2=No]";
                            txtQ15.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q15; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q15; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q15; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 34));
                            break;

                        case GC_FIELDS_Q16:
                            txtDescription.Text = "Q16 [1=Yes, 2=No]";
                            txtQ16.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q16; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q16; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q16; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 34));
                            break;

                        case GC_FIELDS_Q17:
                            txtDescription.Text = "Q17 [1=Not at all ,  2=A little Bit,  3=Somewhat,  4=Quite a bit, 5=Extremely]";
                            txtQ17.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q17; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q17; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q17; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 34));
                            break;

                        case GC_FIELDS_LANGUAGE:
                            txtDescription.Text = "LAUGUAGE [1=English, 2=Spanish]";
                            txtLanguage.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Language; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Language; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Language; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 34));
                            break;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void ClearInfo()
        {
            //txtRespndentID.Clear();
            txtQ1.Clear();
            txtQ2_1.Clear();
            txtQ2_2.Clear();
            txtQ2_3.Clear();
            txtQ2_4.Clear();
            txtQ2_5.Clear();
            txtQ2_6.Clear();
            txtQ2_7.Clear();
            txtQ2_8.Clear();
            txtQ3.Clear();
            txtQ4.Clear();
            txtQ5.Clear();
            txtQ6.Clear();
            txtQ7.Clear();
            txtQ8.Clear();
            txtQ9.Clear();
            txtQ10.Clear();
            txtQ11.Clear();
            txtQ12.Clear();
            txtQ13.Clear();
            txtQ14.Clear();
            txtQ15.Clear();
            txtQ16.Clear();
            txtQ17.Clear();
            txtLanguage.Clear();
            txtKey1User.Clear();
            txtKey1Data.Clear();
            txtKey2User.Clear();
            txtKey2Data.Clear();
            IGImageViewer.ImageClear();
        }

        private long TotalKeystrokes()
        {
            long lngCount = 0;
            lngCount = 0;

            lngCount += txtRespndentID.TextLength;
            lngCount += txtQ1.TextLength;
            lngCount += txtQ2_1.TextLength;
            lngCount += txtQ2_2.Text.Length;
            lngCount += txtQ2_3.TextLength;
            lngCount += txtQ2_4.TextLength;
            lngCount += txtQ2_5.TextLength;
            lngCount += txtQ2_6.TextLength;
            lngCount += txtQ2_7.Text.Length;
            lngCount += txtQ2_8.TextLength;
            lngCount += txtQ3.TextLength;
            lngCount += txtQ4.TextLength;
            lngCount += txtQ5.TextLength;
            lngCount += txtQ6.TextLength;
            lngCount += txtQ7.TextLength;
            lngCount += txtQ8.TextLength;
            lngCount += txtQ9.TextLength;
            lngCount += txtQ10.TextLength;
            lngCount += txtQ11.TextLength;
            lngCount += txtQ12.TextLength;
            lngCount += txtQ13.TextLength;
            lngCount += txtQ14.TextLength;
            lngCount += txtQ15.TextLength;
            lngCount += txtQ16.TextLength;
            lngCount += txtQ17.TextLength;
            lngCount += txtLanguage.TextLength;
            return lngCount;
        }

        private bool LoadImage()
        {
            //bool functionReturnValue = false;
            //if (!File.Exists(path))
            //{
            //    File.Create(path);
            //    TextWriter tw = new StreamWriter(path);
            //    tw.WriteLine("The very first line!");
            //    tw.Close();
            //}     
            try
            {
                ClearInfo();
                if (lngBatchID > 0)
                {
                    //File.AppendAllText(path, Environment.NewLine + "Before get imageid:" + DateTime.Now);
                    Image = objImagemaster.LoadImage_HRA(Process, lngBatchID, Constance.GC_USERID);
                    //File.AppendAllText(path, Environment.NewLine + "after get imageid:" + DateTime.Now);
                    if (Image == null)
                    {
                        MessageBox.Show("Batch Completed");
                        objBatchmaster.UpdateBatchmaster(lngBatchID.ToInt(), Process);
                        this.Close();
                        return false;
                    }
                    //File.AppendAllText(path, Environment.NewLine + "Before Loadimage:" + DateTime.Now);
                    lngImageID = Image.ImageID;
                    IGImageViewer.ImageName = Image.ImagePath;
                    IGImageViewer.LoadImage();
                   // File.AppendAllText(path, Environment.NewLine + "after Loadimage:" + DateTime.Now);
                    //if (!BarcodeWorker.IsBusy)
                    //{
                    //    BarcodeWorker.RunWorkerAsync();
                    //}

                    strImageSize = Interaction.GetSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageSize) + "";
                    if (strImageSize.LastIndexOf(",") > 0)
                    {
                        iHScrol = Convert.ToInt32((strImageSize.Substring(0, strImageSize.LastIndexOf(","))));
                        iVScrol = Convert.ToInt32(strImageSize.Substring(strImageSize.LastIndexOf(",") + 1));
                        IGImageViewer.ImageSize = new System.Drawing.Size(iHScrol, iVScrol);
                    }

                    strImageFit = Interaction.GetSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageFit) + "";
                    if (strImageFit.LastIndexOf(",") > 0)
                    {
                        iHScrol = Convert.ToInt32(strImageFit.Substring(0, strImageFit.LastIndexOf(",")));
                        iVScrol = Convert.ToInt32(strImageFit.Substring(strImageFit.LastIndexOf(",") + 1));
                    }

                    IGImageViewer.MoveImage(iHScrol, iVScrol);
                    IGImageViewer.Refresh();

                    if (Process.ToUpper() == "COMPAREQC")
                    {
                        RestoreInfo();
                        grpKeyData.Visible = true;
                    }

                    Constance.ImageInTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    int TotalRecord, FinishedRecord, RemainingRecord;
                    TotalRecord = FinishedRecord = RemainingRecord = 0;

                    objImagemaster.RecordStatus(Process, lngBatchID, ref TotalRecord, ref FinishedRecord, ref RemainingRecord, intBatchType);
                    this.stsUser.Text = "User Name : " + Constance.GC_USERNAME;
                    this.stsTotRecs.Text = "Total Recs : " + TotalRecord;
                    this.stsFinRecs.Text = "Finished Rec : " + FinishedRecord;
                    this.stsRemRecs.Text = "Remine Recs: " + RemainingRecord;
                    this.stsDate.Text = "Date : " + DateAndTime.Now.ToString("dd-MMMM-yyyy");

                    txtRespndentID.Focus();

                    if (Process.ToUpper() == "COMPAREQC")
                    {
                        //if (txtRespndentID.Enabled == true)
                        //{ txtRespndentID.Focus(); }
                         if (txtQ1.Enabled == true)
                        { txtQ1.Focus(); }
                        else if (txtQ2_1.Enabled == true)
                        { txtQ2_1.Focus(); }
                        else if (txtQ2_2.Enabled == true)
                        { txtQ2_1.Focus(); }
                        else if (txtQ2_3.Enabled == true)
                        { txtQ2_3.Focus(); }
                        else if (txtQ2_4.Enabled == true)
                        { txtQ2_4.Focus(); }
                        else if (txtQ2_5.Enabled == true)
                        { txtQ2_5.Focus(); }
                        else if (txtQ2_6.Enabled == true)
                        { txtQ2_6.Focus(); }
                        else if (txtQ2_7.Enabled == true)
                        { txtQ2_8.Focus(); }
                        else if (txtQ3.Enabled == true)
                        { txtQ3.Focus(); }
                        else if (txtQ4.Enabled == true)
                        { txtQ4.Focus(); }
                        else if (txtQ5.Enabled == true)
                        { txtQ5.Focus(); }
                        else if (txtQ6.Enabled == true)
                        { txtQ6.Focus(); }
                        else if (txtQ7.Enabled == true)
                        { txtQ7.Focus(); }
                        else if (txtQ8.Enabled == true)
                        { txtQ8.Focus(); }
                        else if (txtQ9.Enabled == true)
                        { txtQ9.Focus(); }
                        else if (txtQ10.Enabled == true)
                        { txtQ10.Focus(); }
                        else if (txtQ11.Enabled == true)
                        { txtQ11.Focus(); }
                        else if (txtQ12.Enabled == true)
                        { txtQ12.Focus(); }
                        else if (txtQ13.Enabled == true)
                        { txtQ13.Focus(); }
                        else if (txtQ14.Enabled == true)
                        { txtQ14.Focus(); }
                        else if (txtQ15.Enabled == true)
                        { txtQ15.Focus(); }
                        else if (txtQ16.Enabled == true)
                        { txtQ16.Focus(); }
                        else if (txtQ17.Enabled == true)
                        { txtQ17.Focus(); }
                        else if (txtLanguage.Enabled == true)
                        { txtLanguage.Focus(); }
                        else
                        {
                            SaveandLoad();
                        }                        
                    }


                    return true;
                }
                else
                {
                    Interaction.MsgBox("Invalid Batch Selection", MsgBoxStyle.Information, Constance.gstrappTitle);
                    this.Close();
                    return false;
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            return true;
            //File.AppendAllText(path, Environment.NewLine + "end of  Loadimage:" + DateTime.Now);
        }

        private bool ValidateInfo()
        {
            if (TotalKeystrokes() <= 0)
            {
                if (MessageBox.Show("Do you want to save Blank records?", "Healthtel", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }

        private bool SaveInfo()
        {
            try
            {
                string ImageNumber;
                int iPos;
                string ImagePath = Image.ImagePath; ;
                string BarcodeVal = string.Empty;

                if (!string.IsNullOrEmpty(ImagePath))
                {
                    if (ImagePath.LastIndexOf("\\") >= ImagePath.Length - 1 & ImagePath.Length > 0)
                    {
                        ImagePath = ImagePath.Substring(0, ImagePath.Length - 1);
                    }
                    iPos = ImagePath.LastIndexOf("\\");
                    ImagePath = ImagePath.Substring(iPos + 1, ImagePath.Length - (iPos + 1));
                    BarcodeVal = ImagePath.Substring(0, ImagePath.IndexOf("."));
                }

                if (Process == Constance.GC_PROCESS_KEY1)
                {
                    key1_hra checkkey1 = new key1_hra().isImageIDExists(lngImageID);
                    int Key1_HRAID = (checkkey1 == null) ? 0 : checkkey1.Key1_HRAID;
                    key1_hra objkey1_HRA = new key1_hra(Key1_HRAID);
                    objkey1_HRA.ImageId = lngImageID.ToInt();
                    objkey1_HRA.Image_Number = ImagePath;
                    objkey1_HRA.Respondent_ID = BarcodeVal;//txtRespndentID.Text.Trim();
                    objkey1_HRA.Q1 = txtQ1.Text.Trim();
                    objkey1_HRA.Q2_1 = txtQ2_1.Text.Trim();
                    objkey1_HRA.Q2_2 = txtQ2_2.Text.Trim();
                    objkey1_HRA.Q2_3 = txtQ2_3.Text.Trim();
                    objkey1_HRA.Q2_4 = txtQ2_4.Text.Trim();
                    objkey1_HRA.Q2_5 = txtQ2_5.Text.Trim();
                    objkey1_HRA.Q2_6 = txtQ2_6.Text.Trim();
                    objkey1_HRA.Q2_7 = txtQ2_7.Text.Trim();
                    objkey1_HRA.Q2_8 = txtQ2_8.Text.Trim();
                    objkey1_HRA.Q3 = txtQ3.Text.Trim();
                    objkey1_HRA.Q4 = txtQ4.Text.Trim();
                    objkey1_HRA.Q5 = txtQ5.Text.Trim();
                    objkey1_HRA.Q6 = txtQ6.Text.Trim();
                    objkey1_HRA.Q7 = txtQ7.Text.Trim();
                    objkey1_HRA.Q8 = txtQ8.Text.Trim();
                    objkey1_HRA.Q9 = txtQ9.Text.Trim();
                    objkey1_HRA.Q10 = txtQ10.Text.Trim();
                    objkey1_HRA.Q11 = txtQ11.Text.Trim();
                    objkey1_HRA.Q12 = txtQ12.Text.Trim();
                    objkey1_HRA.Q13 = txtQ13.Text.Trim();
                    objkey1_HRA.Q14 = txtQ14.Text.Trim();
                    objkey1_HRA.Q15 = txtQ15.Text.Trim();
                    objkey1_HRA.Q16 = txtQ16.Text.Trim();
                    objkey1_HRA.Q17 = txtQ17.Text.Trim();
                    objkey1_HRA.Language = txtLanguage.Text.Trim();
                    objkey1_HRA.KeyStroke = TotalKeystrokes().ToInt();

                    objkey1_HRA.Store();

                    imagemaster updateImagemasterkey1 = new imagemaster(lngImageID.ToInt());
                    updateImagemasterkey1.Key1 = 2;
                    updateImagemasterkey1.Store();

                    Constance.ImageOutTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                }
                else if (Process == Constance.GC_PROCESS_KEY2)
                {
                    key2_hra checkkey1 = new key2_hra().isImageIDExists(lngImageID);
                    int Key2_HRAID = (checkkey1 == null) ? 0 : checkkey1.Key2_HRAID;
                    key2_hra objkey2_HRA = new key2_hra(Key2_HRAID);
                    objkey2_HRA.ImageId = lngImageID.ToInt();
                    objkey2_HRA.Image_Number = ImagePath;
                    objkey2_HRA.Respondent_ID = BarcodeVal; //txtRespndentID.Text.Trim();
                    objkey2_HRA.Q1 = txtQ1.Text.Trim();
                    objkey2_HRA.Q2_1 = txtQ2_1.Text.Trim();
                    objkey2_HRA.Q2_2 = txtQ2_2.Text.Trim();
                    objkey2_HRA.Q2_3 = txtQ2_3.Text.Trim();
                    objkey2_HRA.Q2_4 = txtQ2_4.Text.Trim();
                    objkey2_HRA.Q2_5 = txtQ2_5.Text.Trim();
                    objkey2_HRA.Q2_6 = txtQ2_6.Text.Trim();
                    objkey2_HRA.Q2_7 = txtQ2_7.Text.Trim();
                    objkey2_HRA.Q2_8 = txtQ2_8.Text.Trim();
                    objkey2_HRA.Q3 = txtQ3.Text.Trim();
                    objkey2_HRA.Q4 = txtQ4.Text.Trim();
                    objkey2_HRA.Q5 = txtQ5.Text.Trim();
                    objkey2_HRA.Q6 = txtQ6.Text.Trim();
                    objkey2_HRA.Q7 = txtQ7.Text.Trim();
                    objkey2_HRA.Q8 = txtQ8.Text.Trim();
                    objkey2_HRA.Q9 = txtQ9.Text.Trim();
                    objkey2_HRA.Q10 = txtQ10.Text.Trim();
                    objkey2_HRA.Q11 = txtQ11.Text.Trim();
                    objkey2_HRA.Q12 = txtQ12.Text.Trim();
                    objkey2_HRA.Q13 = txtQ13.Text.Trim();
                    objkey2_HRA.Q14 = txtQ14.Text.Trim();
                    objkey2_HRA.Q15 = txtQ15.Text.Trim();
                    objkey2_HRA.Q16 = txtQ16.Text.Trim();
                    objkey2_HRA.Q17 = txtQ17.Text.Trim();
                    objkey2_HRA.Language = txtLanguage.Text.Trim();
                    objkey2_HRA.KeyStroke = TotalKeystrokes().ToInt();

                    objkey2_HRA.Store();

                    imagemaster updateImagemasterkey2 = new imagemaster(lngImageID.ToInt());
                    updateImagemasterkey2.Key2 = 2;
                    updateImagemasterkey2.Store();

                    Constance.ImageOutTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                }
                else if (Process == Constance.GC_PROCESS_COMAPREQC)
                {
                    compareqc_hra checkkey1 = new compareqc_hra().isImageIDExists(lngImageID);
                    int CompareQC_HRAID = (checkkey1 == null) ? 0 : checkkey1.ComapreQC_HRAID;
                    compareqc_hra objcompareqc_HRA = new compareqc_hra(CompareQC_HRAID);
                    objcompareqc_HRA.ImageId = lngImageID.ToInt();
                    objcompareqc_HRA.Image_Number = ImagePath;
                    objcompareqc_HRA.Respondent_ID = BarcodeVal;//txtRespndentID.Text.Trim();
                    objcompareqc_HRA.Q1 = txtQ1.Text.Trim();
                    objcompareqc_HRA.Q2_1 = txtQ2_1.Text.Trim();
                    objcompareqc_HRA.Q2_2 = txtQ2_2.Text.Trim();
                    objcompareqc_HRA.Q2_3 = txtQ2_3.Text.Trim();
                    objcompareqc_HRA.Q2_4 = txtQ2_4.Text.Trim();
                    objcompareqc_HRA.Q2_5 = txtQ2_5.Text.Trim();
                    objcompareqc_HRA.Q2_6 = txtQ2_6.Text.Trim();
                    objcompareqc_HRA.Q2_7 = txtQ2_7.Text.Trim();
                    objcompareqc_HRA.Q2_8 = txtQ2_8.Text.Trim();
                    objcompareqc_HRA.Q3 = txtQ3.Text.Trim();
                    objcompareqc_HRA.Q4 = txtQ4.Text.Trim();
                    objcompareqc_HRA.Q5 = txtQ5.Text.Trim();
                    objcompareqc_HRA.Q6 = txtQ6.Text.Trim();
                    objcompareqc_HRA.Q7 = txtQ7.Text.Trim();
                    objcompareqc_HRA.Q8 = txtQ8.Text.Trim();
                    objcompareqc_HRA.Q9 = txtQ9.Text.Trim();
                    objcompareqc_HRA.Q10 = txtQ10.Text.Trim();
                    objcompareqc_HRA.Q11 = txtQ11.Text.Trim();
                    objcompareqc_HRA.Q12 = txtQ12.Text.Trim();
                    objcompareqc_HRA.Q13 = txtQ13.Text.Trim();
                    objcompareqc_HRA.Q14 = txtQ14.Text.Trim();
                    objcompareqc_HRA.Q15 = txtQ15.Text.Trim();
                    objcompareqc_HRA.Q16 = txtQ16.Text.Trim();
                    objcompareqc_HRA.Q17 = txtQ17.Text.Trim();
                    objcompareqc_HRA.Language = txtLanguage.Text.Trim();
                    objcompareqc_HRA.KeyStroke = TotalKeystrokes().ToInt();

                    objcompareqc_HRA.Store();

                    imagemaster updateImagemastercompareqc = new imagemaster(lngImageID.ToInt());
                    updateImagemastercompareqc.CompareQC = 2;
                    updateImagemastercompareqc.Store();

                    Constance.ImageOutTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                }

                worklog SaveWorklog = new worklog();
                SaveWorklog.UserID = Constance.GC_USERID;
                SaveWorklog.ImageID = lngImageID.ToInt();
                SaveWorklog.In = Convert.ToDateTime(Constance.ImageInTime);
                SaveWorklog.Out = Convert.ToDateTime(Constance.ImageOutTime);
                SaveWorklog.Process = Process;
                SaveWorklog.EXE_Status = Constance.GC_PROJ_VERSIONSTATUS;
                SaveWorklog.Store();

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void RestoreInfo()
        {
            try
            {
                getCompareqcData = objCompareQC.CompareQCDatas(lngImageID.ToInt());

                if (getCompareqcData == null)
                {
                    getkey2Data = objKey2.Key2Datas(lngImageID.ToInt());
                }
                getkey1Data = objKey1.Key1Datas(lngImageID.ToInt());

                if (getCompareqcData != null)
                {
                    //txtRespndentID.Text = getCompareqcData.Respondent_ID;
                    txtQ1.Text = getCompareqcData.Q1;
                    txtQ2_1.Text = getCompareqcData.Q2_1;
                    txtQ2_2.Text = getCompareqcData.Q2_2;
                    txtQ2_3.Text = getCompareqcData.Q2_3;
                    txtQ2_4.Text = getCompareqcData.Q2_4;
                    txtQ2_5.Text = getCompareqcData.Q2_5;
                    txtQ2_6.Text = getCompareqcData.Q2_6;
                    txtQ2_7.Text = getCompareqcData.Q2_7;
                    txtQ2_8.Text = getCompareqcData.Q2_8;
                    txtQ3.Text = getCompareqcData.Q3;
                    txtQ4.Text = getCompareqcData.Q4;
                    txtQ5.Text = getCompareqcData.Q5;
                    txtQ6.Text = getCompareqcData.Q6;
                    txtQ7.Text = getCompareqcData.Q7;
                    txtQ8.Text = getCompareqcData.Q8;
                    txtQ9.Text = getCompareqcData.Q9;
                    txtQ10.Text = getCompareqcData.Q10;
                    txtQ11.Text = getCompareqcData.Q11;
                    txtQ12.Text = getCompareqcData.Q12;
                    txtQ13.Text = getCompareqcData.Q13;
                    txtQ14.Text = getCompareqcData.Q14;
                    txtQ15.Text = getCompareqcData.Q15;
                    txtQ16.Text = getCompareqcData.Q16;
                    txtQ17.Text = getCompareqcData.Q17;
                    txtLanguage.Text = getCompareqcData.Language;
                    txtKey2User.Text = getCompareqcData.UserName;
                }
                else if (getkey2Data != null)
                {
                    //txtRespndentID.Text = getkey2Data.Respondent_ID;
                    txtQ1.Text = getkey2Data.Q1;
                    txtQ2_1.Text = getkey2Data.Q2_1;
                    txtQ2_2.Text = getkey2Data.Q2_2;
                    txtQ2_3.Text = getkey2Data.Q2_3;
                    txtQ2_4.Text = getkey2Data.Q2_4;
                    txtQ2_5.Text = getkey2Data.Q2_5;
                    txtQ2_6.Text = getkey2Data.Q2_6;
                    txtQ2_7.Text = getkey2Data.Q2_7;
                    txtQ2_8.Text = getkey2Data.Q2_8;
                    txtQ3.Text = getkey2Data.Q3;
                    txtQ4.Text = getkey2Data.Q4;
                    txtQ5.Text = getkey2Data.Q5;
                    txtQ6.Text = getkey2Data.Q6;
                    txtQ7.Text = getkey2Data.Q7;
                    txtQ8.Text = getkey2Data.Q8;
                    txtQ9.Text = getkey2Data.Q9;
                    txtQ10.Text = getkey2Data.Q10;
                    txtQ11.Text = getkey2Data.Q11;
                    txtQ12.Text = getkey2Data.Q12;
                    txtQ13.Text = getkey2Data.Q13;
                    txtQ14.Text = getkey2Data.Q14;
                    txtQ15.Text = getkey2Data.Q15;
                    txtQ16.Text = getkey2Data.Q16;
                    txtQ17.Text = getkey2Data.Q17;
                    txtLanguage.Text = getkey2Data.Language;
                    txtKey2User.Text = getkey2Data.UserName;
                }

                if (getkey1Data != null)
                {
                   // txtRespndentID.Tag = getkey1Data.Respondent_ID;
                    txtQ1.Tag = getkey1Data.Q1;
                    txtQ2_1.Tag = getkey1Data.Q2_1;
                    txtQ2_2.Tag = getkey1Data.Q2_2;
                    txtQ2_3.Tag = getkey1Data.Q2_3;
                    txtQ2_4.Tag = getkey1Data.Q2_4;
                    txtQ2_5.Tag = getkey1Data.Q2_5;
                    txtQ2_6.Tag = getkey1Data.Q2_6;
                    txtQ2_7.Tag = getkey1Data.Q2_7;
                    txtQ2_8.Tag = getkey1Data.Q2_8;
                    txtQ3.Tag = getkey1Data.Q3;
                    txtQ4.Tag = getkey1Data.Q4;
                    txtQ5.Tag = getkey1Data.Q5;
                    txtQ6.Tag = getkey1Data.Q6;
                    txtQ7.Tag = getkey1Data.Q7;
                    txtQ8.Tag = getkey1Data.Q8;
                    txtQ9.Tag = getkey1Data.Q9;
                    txtQ10.Tag = getkey1Data.Q10;
                    txtQ11.Tag = getkey1Data.Q11;
                    txtQ12.Tag = getkey1Data.Q12;
                    txtQ13.Tag = getkey1Data.Q13;
                    txtQ14.Tag = getkey1Data.Q14;
                    txtQ15.Tag = getkey1Data.Q15;
                    txtQ16.Tag = getkey1Data.Q16;
                    txtQ17.Tag = getkey1Data.Q17;
                    txtLanguage.Tag = getkey1Data.Language;
                    txtKey1User.Text = getkey1Data.UserName;
                }

                //if (txtRespndentID.Text.ToUpper() == txtRespndentID.Tag.ToString().ToUpper())
                //{
                //    txtRespndentID.Enabled = false;
                //    txtRespndentID.BackColor = Color.White;
                //}
                //else
                //{
                //    txtRespndentID.Enabled = true;
                //    txtRespndentID.Text = "";
                //    txtRespndentID.BackColor = Color.Yellow;
                //}

                if (txtQ1.Text.ToUpper() == txtQ1.Tag.ToString().ToUpper())
                {
                    txtQ1.Enabled = false;
                    txtQ1.BackColor = Color.White;
                }
                else
                {
                    txtQ1.Enabled = true;
                    txtQ1.Text = "";
                    txtQ1.BackColor = Color.Yellow;
                }

                if (txtQ2_1.Text.ToUpper() == txtQ2_1.Tag.ToString().ToUpper())
                {
                    txtQ2_1.Enabled = false;
                    txtQ2_1.BackColor = Color.White;
                }
                else
                {
                    txtQ2_1.Enabled = true;
                    txtQ2_1.Text = "";
                    txtQ2_1.BackColor = Color.Yellow;
                }

                if (txtQ2_2.Text.ToUpper() == txtQ2_2.Tag.ToString().ToUpper())
                {
                    txtQ2_2.Enabled = false;
                    txtQ2_2.BackColor = Color.White;
                }
                else
                {
                    txtQ2_2.Enabled = true;
                    txtQ2_2.Text = "";
                    txtQ2_2.BackColor = Color.Yellow;
                }

                if (txtQ2_3.Text.ToUpper() == txtQ2_3.Tag.ToString().ToUpper())
                {
                    txtQ2_3.Enabled = false;
                    txtQ2_3.BackColor = Color.White;
                }
                else
                {
                    txtQ2_3.Enabled = true;
                    txtQ2_3.Text = "";
                    txtQ2_3.BackColor = Color.Yellow;
                }

                if (txtQ2_4.Text.ToUpper() == txtQ2_4.Tag.ToString().ToUpper())
                {
                    txtQ2_4.Enabled = false;
                    txtQ2_4.BackColor = Color.White;
                }
                else
                {
                    txtQ2_4.Enabled = true;
                    txtQ2_4.Text = "";
                    txtQ2_4.BackColor = Color.Yellow;
                }

                if (txtQ2_5.Text.ToUpper() == txtQ2_5.Tag.ToString().ToUpper())
                {
                    txtQ2_5.Enabled = false;
                    txtQ2_5.BackColor = Color.White;
                }
                else
                {
                    txtQ2_5.Enabled = true;
                    txtQ2_5.Text = "";
                    txtQ2_5.BackColor = Color.Yellow;
                }

                if (txtQ2_6.Text.ToUpper() == txtQ2_6.Tag.ToString().ToUpper())
                {
                    txtQ2_6.Enabled = false;
                    txtQ2_6.BackColor = Color.White;
                }
                else
                {
                    txtQ2_6.Enabled = true;
                    txtQ2_6.Text = "";
                    txtQ2_6.BackColor = Color.Yellow;
                }

                if (txtQ2_7.Text.ToUpper() == txtQ2_7.Tag.ToString().ToUpper())
                {
                    txtQ2_7.Enabled = false;
                    txtQ2_7.BackColor = Color.White;
                }
                else
                {
                    txtQ2_7.Enabled = true;
                    txtQ2_7.Text = "";
                    txtQ2_7.BackColor = Color.Yellow;
                }

                if (txtQ2_8.Text.ToUpper() == txtQ2_8.Tag.ToString().ToUpper())
                {
                    txtQ2_8.Enabled = false;
                    txtQ2_8.BackColor = Color.White;
                }
                else
                {
                    txtQ2_8.Enabled = true;
                    txtQ2_8.Text = "";
                    txtQ2_8.BackColor = Color.Yellow;
                }

                if (txtQ3.Text.ToUpper() == txtQ3.Tag.ToString().ToUpper())
                {
                    txtQ3.Enabled = false;
                    txtQ3.BackColor = Color.White;
                }
                else
                {
                    txtQ3.Enabled = true;
                    txtQ3.Text = "";
                    txtQ3.BackColor = Color.Yellow;
                }

                if (txtQ4.Text.ToUpper() == txtQ4.Tag.ToString().ToUpper())
                {
                    txtQ4.Enabled = false;
                    txtQ4.BackColor = Color.White;
                }
                else
                {
                    txtQ4.Enabled = true;
                    txtQ4.Text = "";
                    txtQ4.BackColor = Color.Yellow;
                }

                if (txtQ5.Text.ToUpper() == txtQ5.Tag.ToString().ToUpper())
                {
                    txtQ5.Enabled = false;
                    txtQ5.BackColor = Color.White;
                }
                else
                {
                    txtQ5.Enabled = true;
                    txtQ5.Text = "";
                    txtQ5.BackColor = Color.Yellow;
                }

                if (txtQ6.Text.ToUpper() == txtQ6.Tag.ToString().ToUpper())
                {
                    txtQ6.Enabled = false;
                    txtQ6.BackColor = Color.White;
                }
                else
                {
                    txtQ6.Enabled = true;
                    txtQ6.Text = "";
                    txtQ6.BackColor = Color.Yellow;
                }

                if (txtQ7.Text.ToUpper() == txtQ7.Tag.ToString().ToUpper())
                {
                    txtQ7.Enabled = false;
                    txtQ7.BackColor = Color.White;
                }
                else
                {
                    txtQ7.Enabled = true;
                    txtQ7.Text = "";
                    txtQ7.BackColor = Color.Yellow;
                }

                if (txtQ8.Text.ToUpper() == txtQ8.Tag.ToString().ToUpper())
                {
                    txtQ8.Enabled = false;
                    txtQ8.BackColor = Color.White;
                }
                else
                {
                    txtQ8.Enabled = true;
                    txtQ8.Text = "";
                    txtQ8.BackColor = Color.Yellow;
                }

                if (txtQ9.Text.ToUpper() == txtQ9.Tag.ToString().ToUpper())
                {
                    txtQ9.Enabled = false;
                    txtQ9.BackColor = Color.White;
                }
                else
                {
                    txtQ9.Enabled = true;
                    txtQ9.Text = "";
                    txtQ9.BackColor = Color.Yellow;
                }

                if (txtQ10.Text.ToUpper() == txtQ10.Tag.ToString().ToUpper())
                {
                    txtQ10.Enabled = false;
                    txtQ10.BackColor = Color.White;
                }
                else
                {
                    txtQ10.Enabled = true;
                    txtQ10.Text = "";
                    txtQ10.BackColor = Color.Yellow;
                }

                if (txtQ11.Text.ToUpper() == txtQ11.Tag.ToString().ToUpper())
                {
                    txtQ11.Enabled = false;
                    txtQ11.BackColor = Color.White;
                }
                else
                {
                    txtQ11.Enabled = true;
                    txtQ11.Text = "";
                    txtQ11.BackColor = Color.Yellow;
                }

                if (txtQ12.Text.ToUpper() == txtQ12.Tag.ToString().ToUpper())
                {
                    txtQ12.Enabled = false;
                    txtQ12.BackColor = Color.White;
                }
                else
                {
                    txtQ12.Enabled = true;
                    txtQ12.Text = "";
                    txtQ12.BackColor = Color.Yellow;
                }

                if (txtQ13.Text.ToUpper() == txtQ13.Tag.ToString().ToUpper())
                {
                    txtQ13.Enabled = false;
                    txtQ13.BackColor = Color.White;
                }
                else
                {
                    txtQ13.Enabled = true;
                    txtQ13.Text = "";
                    txtQ13.BackColor = Color.Yellow;
                }

                if (txtQ14.Text.ToUpper() == txtQ14.Tag.ToString().ToUpper())
                {
                    txtQ14.Enabled = false;
                    txtQ14.BackColor = Color.White;
                }
                else
                {
                    txtQ14.Enabled = true;
                    txtQ14.Text = "";
                    txtQ14.BackColor = Color.Yellow;
                }

                if (txtQ15.Text.ToUpper() == txtQ15.Tag.ToString().ToUpper())
                {
                    txtQ15.Enabled = false;
                    txtQ15.BackColor = Color.White;
                }
                else
                {
                    txtQ15.Enabled = true;
                    txtQ15.Text = "";
                    txtQ15.BackColor = Color.Yellow;
                }

                if (txtQ16.Text.ToUpper() == txtQ16.Tag.ToString().ToUpper())
                {
                    txtQ16.Enabled = false;
                    txtQ16.BackColor = Color.White;
                }
                else
                {
                    txtQ16.Enabled = true;
                    txtQ16.Text = "";
                    txtQ16.BackColor = Color.Yellow;
                }

                if (txtQ17.Text.ToUpper() == txtQ17.Tag.ToString().ToUpper())
                {
                    txtQ17.Enabled = false;
                    txtQ17.BackColor = Color.White;
                }
                else
                {
                    txtQ17.Enabled = true;
                    txtQ17.Text = "";
                    txtQ17.BackColor = Color.Yellow;
                }

                if (txtLanguage.Text.ToUpper() == txtLanguage.Tag.ToString().ToUpper())
                {
                    txtLanguage.Enabled = false;
                    txtLanguage.BackColor = Color.White;
                }
                else
                {
                    txtLanguage.Enabled = true;
                    txtLanguage.Text = "";
                    txtLanguage.BackColor = Color.Yellow;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SaveandLoad()
        {
            if (ValidateInfo() == true)
            {
                if (SaveInfo() == true)
                {
                    LoadImage();
                }
            }
        }

        private void EnableFields()
        {
            txtRespndentID.Enabled = true;
            txtQ1.Enabled = true;
            txtQ2_1.Enabled = true;
            txtQ2_2.Enabled = true;
            txtQ2_3.Enabled = true;
            txtQ2_4.Enabled = true;
            txtQ2_5.Enabled = true;
            txtQ2_6.Enabled = true;
            txtQ2_7.Enabled = true;
            txtQ2_8.Enabled = true;
            txtQ3.Enabled = true;
            txtQ4.Enabled = true;
            txtQ5.Enabled = true;
            txtQ6.Enabled = true;
            txtQ7.Enabled = true;
            txtQ8.Enabled = true;
            txtQ9.Enabled = true;
            txtQ10.Enabled = true;
            txtQ11.Enabled = true;
            txtQ12.Enabled = true;
            txtQ13.Enabled = true;
            txtQ14.Enabled = true;
            txtQ15.Enabled = true;
            txtQ16.Enabled = true;
            txtQ17.Enabled = true;
            txtLanguage.Enabled = true;
        }

        #endregion

        #region Events

        private void frmKeying_HRA_Load(object sender, EventArgs e)
        {
            if (BatchType == 0)
            {
                this.Text = string.Format("Healthtel HRA :: {0}", Process);
            }
            else if (BatchType == 1)
            {
                this.Text = string.Format("Healthtel CIP :: {0}", Process);
            }
           // File.AppendAllText(path, Environment.NewLine + "Before LoadImage:" + DateTime.Now);
            LoadImage();
        }

        private void txtRespndentID_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtRespndentID);
        }

        private void txtQ1_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1);
        }

        private void txtQ2_1_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_1);
        }

        private void txtQ2_2_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_2);
        }

        private void txtQ2_3_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_3);
        }

        private void txtQ2_4_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_4);
        }

        private void txtQ2_5_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_5);
        }

        private void txtQ2_6_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_6);
        }

        private void txtQ2_7_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_7);
        }

        private void txtQ2_8_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_8);
        }

        private void txtQ4_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ4);
        }

        private void txtQ5_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ5);
        }

        private void txtQ6_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ6);
        }

        private void txtQ7_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ7);
        }

        private void txtQ8_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ8);
        }

        private void txtQ9_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ9);
        }

        private void txtQ10_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ10);
        }

        private void txtQ11_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ11);
        }

        private void txtQ12_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ12);
        }

        private void txtQ13_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ13);
        }

        private void txtQ14_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ14);
        }

        private void txtQ15_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ15);
        }

        private void txtQ16_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ16);
        }

        private void txtQ17_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ17);
        }

        private void txtLanguage_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtLanguage);
        }

        private void txtQ3_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3);
        }

        private void txtRespndentID_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtRespndentID);
        }

        private void txtQ1_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1);
        }

        private void txtQ2_1_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_1);
        }

        private void txtQ2_2_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_2);
        }

        private void txtQ2_3_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_3);
        }

        private void txtQ2_4_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_4);
        }

        private void txtQ2_5_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_5);
        }

        private void txtQ2_6_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_6);
        }

        private void txtQ2_7_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_7);
        }

        private void txtQ2_8_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_8);
        }

        private void txtQ4_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ4);
        }

        private void txtQ5_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ5);
        }

        private void txtQ6_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ6);
        }

        private void txtQ7_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ7);
        }

        private void txtQ8_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ8);
        }

        private void txtQ9_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ9);
        }

        private void txtQ10_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ10);
        }

        private void txtQ11_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ11);
        }

        private void txtQ12_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ12);
        }

        private void txtQ13_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ13);
        }

        private void txtQ14_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ14);
        }

        private void txtQ15_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ15);
        }

        private void txtQ16_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ16);
        }

        private void txtQ17_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ17);
        }

        private void txtLanguage_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtLanguage);
        }

        private void txtQ3_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3);
        }

        private void txtRespndentID_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtRespndentID);
        }

        private void txtQ1_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1);
        }

        private void txtQ2_1_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_1);
        }

        private void txtQ2_2_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_2);
        }

        private void txtQ2_3_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_3);
        }

        private void txtQ2_4_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_4);
        }

        private void txtQ2_5_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_5);
        }

        private void txtQ2_6_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_6);
        }

        private void txtQ2_7_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_7);
        }

        private void txtQ2_8_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_8);
        }

        private void txtQ4_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ4);
        }

        private void txtQ5_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ5);
        }

        private void txtQ6_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ6);
        }

        private void txtQ7_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ7);
        }

        private void txtQ8_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ8);
        }

        private void txtQ9_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ9);
        }

        private void txtQ10_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ10);
        }

        private void txtQ11_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ11);
        }

        private void txtQ12_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ12);
        }

        private void txtQ13_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ13);
        }

        private void txtQ14_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ14);
        }

        private void txtQ15_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ15);
        }

        private void txtQ16_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ16);
        }

        private void txtQ17_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ17);
        }

        private void txtLanguage_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtLanguage);
        }

        private void txtQ3_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3);
        }
        
        private void btnSave_Click(object sender, EventArgs e)
        {
            //File.AppendAllText(path, Environment.NewLine + "Before Save function:" + DateTime.Now);
            SaveandLoad();
            //File.AppendAllText(path, Environment.NewLine + "After Save function:" + DateTime.Now);
        }        

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmKeying_HRA_FormClosing(object sender, FormClosingEventArgs e)
        {
            objImagemaster.ImageReset(Process, lngImageID);
        }

        private void frmKeying_HRA_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Alt & e.KeyCode == Keys.Right)
            {
                IGImageViewer.NextImage(sender, e);
            }
            else if (e.Alt & e.KeyCode == Keys.Left)
            {
                IGImageViewer.PrevImage(sender, e);
            }
            else if (e.Control & (e.KeyCode == Keys.Oemplus || e.KeyCode == Keys.Add))
            {
                IGImageViewer.ZoomIn(sender, e);
            }
            else if (e.Control & (e.KeyCode == Keys.OemMinus || e.KeyCode == Keys.Subtract))
            {
                IGImageViewer.ZoomOut(sender, e);
            }
            else if (e.Control == true & (e.KeyCode == Keys.D1 | e.KeyCode == Keys.NumPad1))
            {
                IGImageViewer.RotateLeft(sender, e);
            }
            else if (e.Control == true & (e.KeyCode == Keys.D2 | e.KeyCode == Keys.NumPad2))
            {
                IGImageViewer.RotateRight(sender, e);
            }
            else if (e.Control & e.KeyCode == Keys.Right)
            {
                IGImageViewer.PageRight();
            }
            else if (e.Control & e.KeyCode == Keys.Left)
            {
                IGImageViewer.PageLeft();
            }
            else if (e.Control & e.KeyCode == Keys.Down)
            {
                IGImageViewer.PageDown();
            }
            else if (e.Control & e.KeyCode == Keys.Up)
            {
                IGImageViewer.PageUp();
            }
            else if (e.Control & e.KeyCode == Keys.PageUp)
            {
                IGImageViewer.PageHome();
            }
            else if (e.Control & e.KeyCode == Keys.Next)
            {
                IGImageViewer.PageEnd();
            }
            //else if (e.Control & e.KeyCode == Keys.Home)
            //{
            //    IGImageViewer.firstpage();
            //}
            //else if (e.Control & e.KeyCode == Keys.End)
            //{
            //    IGImageViewer.lastpage();
            //}
            else if (e.KeyCode == Keys.F5)
            {
                strImageFit = IGImageViewer.ImageHorizontalScroll.Value + "," + IGImageViewer.ImageVerticalScroll.Value;
                strImageSize = IGImageViewer.ImageSize.Width + "," + IGImageViewer.ImageSize.Height;
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageFit, strImageFit);
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageSize, strImageSize);
            }
            else if (e.KeyCode == Keys.F6)
            {
                //IGImageViewer.resizeimg();
                strImageFit = IGImageViewer.ImageHorizontalScroll.Minimum + "," + IGImageViewer.ImageVerticalScroll.Minimum;
                strImageSize = "";
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageFit, strImageFit);
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageSize, strImageSize);

                IGImageViewer.ImageClear();
                IGImageViewer.ImageName = Image.ImagePath;
                IGImageViewer.LoadImage();
            }
            else if (e.Control & e.KeyCode == Keys.F7)
            {
                //IGImageViewer.imgfitwidth();
            }
            else if (e.Control & e.KeyCode == Keys.F8)
            {
                //IGImageViewer.imgfitscreen();
            }
            else if (e.KeyCode == Keys.F1)
            {
                EnableFields();
            }
        }

        #endregion

        #region Background Worker

        protected void BarcodeWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            //Load barcode from the image
            bmp = new System.Drawing.Bitmap(IGImageViewer.ImageName);
            barcodes = new System.Collections.ArrayList(); ;
            BarcodeImaging.FullScanPage(ref barcodes, bmp, iScans);
        }

        protected void BarcodeWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (barcodes.Count > 0)
            {
                //foreach (string bc in barcodes)
                //{
                //    barcode += bc + " ";
                //}
                txtRespndentID.Text = barcodes[0].ToString().Trim();
                barcode = "";
                //barcodes = null;
            }
            bmp.Dispose();
        }

        #endregion
    }
}
