﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DataAccessLayer.ProjectDB;
using DataAccessLayer.GlobalDB;
using App.Base;

namespace Healthtel_MRT
{
    public partial class frmKeyReset : Form
    {
        public frmKeyReset()
        {
            InitializeComponent();
        }

        #region Global Variables
        string ProcessType;
        List<batchmaster> BatchList = new List<batchmaster>();
        imagemaster objImagemaster = new imagemaster();
        string sel = "";

        #endregion

        #region Property Variables
        public string Process
        {
            get { return ProcessType; }

            set { ProcessType = value; }
        }
        #endregion

        #region Help Methods

        private void LoadcmbBatch()
        {
            BatchList = objImagemaster.BatchtoReset(Process);
            //cmbBatch.DataSource = null;
            //lstImages.DataSource = null;
            if (BatchList.Count > 0)
            {
                cmbBatch.DataSource = null;
                cmbBatch.DisplayMember = "Name";
                cmbBatch.ValueMember = "ID";
                cmbBatch.DataSource = BatchList;
                cmbBatch.Refresh();
                cmbBatch.SelectedIndex = 0;
            }
        }

        #endregion

        #region Events

        private void frmKeyReset_Load(object sender, EventArgs e)
        {
            LoadcmbBatch();
        }

        private void cmbBatch_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbBatch.SelectedIndex > -1)
            {
                List<ResetBatchImages> ImageList = new List<ResetBatchImages>();

                ImageList = objImagemaster.ImagestoReset(Convert.ToInt32(cmbBatch.SelectedValue), Process).ToList();
                lstImages.Items.Clear();
                if (ImageList.Count > 0)
                {
                    lstImages.DisplayMember = "IMAGENAME";
                    lstImages.ValueMember = "IMAGEID";
                    ImageList.ForEach(x =>
                    {
                        lstImages.Items.Add(new { IMAGEID = x.IMAGEID, IMAGENAME = x.IMAGENAME });
                    });
                    lstImages.Refresh();
                }
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstImages.CheckedItems.Count == 0)
                {
                    MessageBox.Show("Select One or more Images to Reset");
                    lstImages.Focus();
                    return;
                }

                int iLoop = 0;
                int id = 0;
                string selectitem = "";
                string[] imageid;

                for (iLoop = 0; iLoop <= lstImages.CheckedItems.Count - 1; iLoop++)
                {
                    //if (lstImages.GetItemChecked(iLoop) == true)
                    //{
                    selectitem = lstImages.CheckedItems[iLoop].ToString();
                    imageid = selectitem.Split('=');
                    imageid = imageid[1].ToString().Split(',');
                    id = imageid[0].ToInt();

                    imagemaster objImageReset = new imagemaster(id);

                    if (Process == Constance.GC_PROCESS_KEY1)
                    {
                        objImageReset.Key1 = 0;
                        objImageReset.Store();
                        //MessageBox.Show("Selected Image(s) Reseted");
                    }
                    else if (Process == Constance.GC_PROCESS_KEY2)
                    {
                        objImageReset.Key2 = 0;
                        objImageReset.Store();
                        //MessageBox.Show("Selected Image(s) Reseted");
                    }
                    else if (Process == Constance.GC_PROCESS_COMAPREQC)
                    {
                        objImageReset.CompareQC = 0;
                        objImageReset.Store();
                        //MessageBox.Show("Selected Image(s) Reseted");
                    }
                    else if (Process == Constance.GC_PROCESS_KEYQC)
                    {
                        objImageReset.KeyQC= 0;
                        objImageReset.Store();
                        //MessageBox.Show("Selected Image(s) Reseted");
                    }
                    //}
                }
                MessageBox.Show("Selected Image(s) Reseted");
                chkCheckAll.Checked = false;
                LoadcmbBatch();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void chkCheckAll_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCheckAll.Checked == true)
            {
                for (int i = 0; i <= lstImages.Items.Count - 1; i++)
                {
                    lstImages.SetItemChecked(i, true);
                }
            }
            else
            {
                for (int i = 0; i <= lstImages.Items.Count - 1; i++)
                {
                    lstImages.SetItemChecked(i, false);
                }
            }
        }

        #endregion
    }
}
