﻿namespace Healthtel_MRT
{
    partial class Healthtel_Adult
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.stsRemRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.txtinstruction = new System.Windows.Forms.Label();
            this.txtKey2User = new System.Windows.Forms.TextBox();
            this.stsDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblKey1Data = new System.Windows.Forms.Label();
            this.txtKey1Data = new System.Windows.Forms.TextBox();
            this.lblKey1User = new System.Windows.Forms.Label();
            this.txtKey1User = new System.Windows.Forms.TextBox();
            this.grpMain = new System.Windows.Forms.GroupBox();
            this.StatusStrip1 = new System.Windows.Forms.StatusStrip();
            this.stsUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsTotRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsFinRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.grpTxtBoxes1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.lblinstruction = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtDescription = new System.Windows.Forms.Label();
            this.grpKeyData = new System.Windows.Forms.GroupBox();
            this.lblKey2Data = new System.Windows.Forms.Label();
            this.txtKey2Data = new System.Windows.Forms.TextBox();
            this.lblKey2User = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.txtQ21 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.txtQ20 = new System.Windows.Forms.TextBox();
            this.lblpermission = new System.Windows.Forms.Label();
            this.txtbarcode = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblQ9 = new System.Windows.Forms.Label();
            this.lblq15 = new System.Windows.Forms.Label();
            this.lblQ2_7 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.txtQ8 = new System.Windows.Forms.TextBox();
            this.lblQ14 = new System.Windows.Forms.Label();
            this.lblQ2_6 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.txtQ7 = new System.Windows.Forms.TextBox();
            this.lblQ13 = new System.Windows.Forms.Label();
            this.lblQ2_5 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lbl12 = new System.Windows.Forms.Label();
            this.txtQ6 = new System.Windows.Forms.TextBox();
            this.txt = new System.Windows.Forms.TextBox();
            this.lblQ2_4 = new System.Windows.Forms.Label();
            this.txtQ5 = new System.Windows.Forms.TextBox();
            this.lblQ2_3 = new System.Windows.Forms.Label();
            this.txtQ4 = new System.Windows.Forms.TextBox();
            this.lblQ2_2 = new System.Windows.Forms.Label();
            this.txtQ3 = new System.Windows.Forms.TextBox();
            this.lblQ2 = new System.Windows.Forms.Label();
            this.txtQ2 = new System.Windows.Forms.TextBox();
            this.lblQ1 = new System.Windows.Forms.Label();
            this.txtQ1 = new System.Windows.Forms.TextBox();
            this.IGImageViewer = new InfognanaImageViewer.IGImageViewer();
            this.grpMain.SuspendLayout();
            this.StatusStrip1.SuspendLayout();
            this.grpTxtBoxes1.SuspendLayout();
            this.grpKeyData.SuspendLayout();
            this.SuspendLayout();
            // 
            // stsRemRecs
            // 
            this.stsRemRecs.AutoSize = false;
            this.stsRemRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsRemRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsRemRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsRemRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsRemRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsRemRecs.ForeColor = System.Drawing.Color.Black;
            this.stsRemRecs.Name = "stsRemRecs";
            this.stsRemRecs.Size = new System.Drawing.Size(200, 24);
            this.stsRemRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsRemRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // txtinstruction
            // 
            this.txtinstruction.AutoSize = true;
            this.txtinstruction.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinstruction.ForeColor = System.Drawing.Color.Red;
            this.txtinstruction.Location = new System.Drawing.Point(597, 10);
            this.txtinstruction.Name = "txtinstruction";
            this.txtinstruction.Size = new System.Drawing.Size(74, 18);
            this.txtinstruction.TabIndex = 77;
            this.txtinstruction.Text = "Instruction";
            // 
            // txtKey2User
            // 
            this.txtKey2User.Enabled = false;
            this.txtKey2User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey2User.Location = new System.Drawing.Point(90, 73);
            this.txtKey2User.Name = "txtKey2User";
            this.txtKey2User.Size = new System.Drawing.Size(118, 22);
            this.txtKey2User.TabIndex = 48;
            // 
            // stsDate
            // 
            this.stsDate.AutoSize = false;
            this.stsDate.BackColor = System.Drawing.Color.Transparent;
            this.stsDate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsDate.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsDate.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsDate.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsDate.ForeColor = System.Drawing.Color.Black;
            this.stsDate.Name = "stsDate";
            this.stsDate.Size = new System.Drawing.Size(200, 24);
            this.stsDate.Text = "Date : ";
            this.stsDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsDate.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // lblKey1Data
            // 
            this.lblKey1Data.AutoSize = true;
            this.lblKey1Data.Enabled = false;
            this.lblKey1Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey1Data.ForeColor = System.Drawing.Color.White;
            this.lblKey1Data.Location = new System.Drawing.Point(5, 40);
            this.lblKey1Data.Name = "lblKey1Data";
            this.lblKey1Data.Size = new System.Drawing.Size(76, 14);
            this.lblKey1Data.TabIndex = 45;
            this.lblKey1Data.Text = "Key1 Data";
            // 
            // txtKey1Data
            // 
            this.txtKey1Data.Enabled = false;
            this.txtKey1Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey1Data.Location = new System.Drawing.Point(90, 38);
            this.txtKey1Data.Name = "txtKey1Data";
            this.txtKey1Data.Size = new System.Drawing.Size(118, 22);
            this.txtKey1Data.TabIndex = 46;
            // 
            // lblKey1User
            // 
            this.lblKey1User.AutoSize = true;
            this.lblKey1User.Enabled = false;
            this.lblKey1User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey1User.ForeColor = System.Drawing.Color.White;
            this.lblKey1User.Location = new System.Drawing.Point(10, 13);
            this.lblKey1User.Name = "lblKey1User";
            this.lblKey1User.Size = new System.Drawing.Size(76, 14);
            this.lblKey1User.TabIndex = 43;
            this.lblKey1User.Text = "Key1 User";
            // 
            // txtKey1User
            // 
            this.txtKey1User.Enabled = false;
            this.txtKey1User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey1User.Location = new System.Drawing.Point(90, 14);
            this.txtKey1User.Name = "txtKey1User";
            this.txtKey1User.Size = new System.Drawing.Size(118, 22);
            this.txtKey1User.TabIndex = 44;
            // 
            // grpMain
            // 
            this.grpMain.BackColor = System.Drawing.Color.Transparent;
            this.grpMain.Controls.Add(this.StatusStrip1);
            this.grpMain.Controls.Add(this.grpTxtBoxes1);
            this.grpMain.Location = new System.Drawing.Point(1, 482);
            this.grpMain.Name = "grpMain";
            this.grpMain.Size = new System.Drawing.Size(1240, 257);
            this.grpMain.TabIndex = 47;
            this.grpMain.TabStop = false;
            // 
            // StatusStrip1
            // 
            this.StatusStrip1.AutoSize = false;
            this.StatusStrip1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StatusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stsUser,
            this.stsTotRecs,
            this.stsFinRecs,
            this.stsRemRecs,
            this.stsDate});
            this.StatusStrip1.Location = new System.Drawing.Point(3, 225);
            this.StatusStrip1.Name = "StatusStrip1";
            this.StatusStrip1.Size = new System.Drawing.Size(1234, 29);
            this.StatusStrip1.TabIndex = 46;
            this.StatusStrip1.Text = "StatusStrip1";
            // 
            // stsUser
            // 
            this.stsUser.AutoSize = false;
            this.stsUser.BackColor = System.Drawing.Color.Transparent;
            this.stsUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsUser.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsUser.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsUser.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsUser.ForeColor = System.Drawing.Color.Black;
            this.stsUser.Name = "stsUser";
            this.stsUser.Size = new System.Drawing.Size(210, 24);
            this.stsUser.Text = "User : Admin";
            this.stsUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsUser.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsTotRecs
            // 
            this.stsTotRecs.AutoSize = false;
            this.stsTotRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsTotRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsTotRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsTotRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsTotRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsTotRecs.ForeColor = System.Drawing.Color.Black;
            this.stsTotRecs.Name = "stsTotRecs";
            this.stsTotRecs.Size = new System.Drawing.Size(200, 24);
            this.stsTotRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsTotRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsFinRecs
            // 
            this.stsFinRecs.AutoSize = false;
            this.stsFinRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsFinRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsFinRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsFinRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsFinRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsFinRecs.ForeColor = System.Drawing.Color.Black;
            this.stsFinRecs.Name = "stsFinRecs";
            this.stsFinRecs.Size = new System.Drawing.Size(200, 24);
            this.stsFinRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsFinRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // grpTxtBoxes1
            // 
            this.grpTxtBoxes1.BackColor = System.Drawing.Color.Navy;
            this.grpTxtBoxes1.Controls.Add(this.label1);
            this.grpTxtBoxes1.Controls.Add(this.label2);
            this.grpTxtBoxes1.Controls.Add(this.textBox2);
            this.grpTxtBoxes1.Controls.Add(this.textBox30);
            this.grpTxtBoxes1.Controls.Add(this.label5);
            this.grpTxtBoxes1.Controls.Add(this.label6);
            this.grpTxtBoxes1.Controls.Add(this.textBox31);
            this.grpTxtBoxes1.Controls.Add(this.textBox32);
            this.grpTxtBoxes1.Controls.Add(this.label33);
            this.grpTxtBoxes1.Controls.Add(this.label34);
            this.grpTxtBoxes1.Controls.Add(this.textBox34);
            this.grpTxtBoxes1.Controls.Add(this.textBox35);
            this.grpTxtBoxes1.Controls.Add(this.label35);
            this.grpTxtBoxes1.Controls.Add(this.textBox36);
            this.grpTxtBoxes1.Controls.Add(this.label36);
            this.grpTxtBoxes1.Controls.Add(this.textBox37);
            this.grpTxtBoxes1.Controls.Add(this.label37);
            this.grpTxtBoxes1.Controls.Add(this.textBox38);
            this.grpTxtBoxes1.Controls.Add(this.label22);
            this.grpTxtBoxes1.Controls.Add(this.label23);
            this.grpTxtBoxes1.Controls.Add(this.textBox20);
            this.grpTxtBoxes1.Controls.Add(this.textBox21);
            this.grpTxtBoxes1.Controls.Add(this.label24);
            this.grpTxtBoxes1.Controls.Add(this.label25);
            this.grpTxtBoxes1.Controls.Add(this.textBox22);
            this.grpTxtBoxes1.Controls.Add(this.textBox23);
            this.grpTxtBoxes1.Controls.Add(this.label26);
            this.grpTxtBoxes1.Controls.Add(this.label27);
            this.grpTxtBoxes1.Controls.Add(this.label28);
            this.grpTxtBoxes1.Controls.Add(this.textBox24);
            this.grpTxtBoxes1.Controls.Add(this.textBox25);
            this.grpTxtBoxes1.Controls.Add(this.textBox26);
            this.grpTxtBoxes1.Controls.Add(this.label29);
            this.grpTxtBoxes1.Controls.Add(this.textBox27);
            this.grpTxtBoxes1.Controls.Add(this.label30);
            this.grpTxtBoxes1.Controls.Add(this.textBox28);
            this.grpTxtBoxes1.Controls.Add(this.label31);
            this.grpTxtBoxes1.Controls.Add(this.textBox29);
            this.grpTxtBoxes1.Controls.Add(this.label11);
            this.grpTxtBoxes1.Controls.Add(this.label12);
            this.grpTxtBoxes1.Controls.Add(this.textBox10);
            this.grpTxtBoxes1.Controls.Add(this.textBox11);
            this.grpTxtBoxes1.Controls.Add(this.label13);
            this.grpTxtBoxes1.Controls.Add(this.label14);
            this.grpTxtBoxes1.Controls.Add(this.textBox12);
            this.grpTxtBoxes1.Controls.Add(this.textBox13);
            this.grpTxtBoxes1.Controls.Add(this.label15);
            this.grpTxtBoxes1.Controls.Add(this.label16);
            this.grpTxtBoxes1.Controls.Add(this.label17);
            this.grpTxtBoxes1.Controls.Add(this.textBox14);
            this.grpTxtBoxes1.Controls.Add(this.textBox15);
            this.grpTxtBoxes1.Controls.Add(this.textBox16);
            this.grpTxtBoxes1.Controls.Add(this.label19);
            this.grpTxtBoxes1.Controls.Add(this.textBox17);
            this.grpTxtBoxes1.Controls.Add(this.label20);
            this.grpTxtBoxes1.Controls.Add(this.textBox18);
            this.grpTxtBoxes1.Controls.Add(this.label21);
            this.grpTxtBoxes1.Controls.Add(this.textBox19);
            this.grpTxtBoxes1.Controls.Add(this.txtinstruction);
            this.grpTxtBoxes1.Controls.Add(this.lblinstruction);
            this.grpTxtBoxes1.Controls.Add(this.btnExit);
            this.grpTxtBoxes1.Controls.Add(this.label18);
            this.grpTxtBoxes1.Controls.Add(this.btnSave);
            this.grpTxtBoxes1.Controls.Add(this.txtDescription);
            this.grpTxtBoxes1.Controls.Add(this.grpKeyData);
            this.grpTxtBoxes1.Controls.Add(this.label9);
            this.grpTxtBoxes1.Controls.Add(this.label4);
            this.grpTxtBoxes1.Controls.Add(this.textBox8);
            this.grpTxtBoxes1.Controls.Add(this.txtQ21);
            this.grpTxtBoxes1.Controls.Add(this.label8);
            this.grpTxtBoxes1.Controls.Add(this.label3);
            this.grpTxtBoxes1.Controls.Add(this.textBox7);
            this.grpTxtBoxes1.Controls.Add(this.txtQ20);
            this.grpTxtBoxes1.Controls.Add(this.lblpermission);
            this.grpTxtBoxes1.Controls.Add(this.txtbarcode);
            this.grpTxtBoxes1.Controls.Add(this.label10);
            this.grpTxtBoxes1.Controls.Add(this.label7);
            this.grpTxtBoxes1.Controls.Add(this.lblQ9);
            this.grpTxtBoxes1.Controls.Add(this.lblq15);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_7);
            this.grpTxtBoxes1.Controls.Add(this.textBox9);
            this.grpTxtBoxes1.Controls.Add(this.textBox6);
            this.grpTxtBoxes1.Controls.Add(this.textBox1);
            this.grpTxtBoxes1.Controls.Add(this.textBox5);
            this.grpTxtBoxes1.Controls.Add(this.txtQ8);
            this.grpTxtBoxes1.Controls.Add(this.lblQ14);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_6);
            this.grpTxtBoxes1.Controls.Add(this.textBox4);
            this.grpTxtBoxes1.Controls.Add(this.txtQ7);
            this.grpTxtBoxes1.Controls.Add(this.lblQ13);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_5);
            this.grpTxtBoxes1.Controls.Add(this.textBox3);
            this.grpTxtBoxes1.Controls.Add(this.lbl12);
            this.grpTxtBoxes1.Controls.Add(this.txtQ6);
            this.grpTxtBoxes1.Controls.Add(this.txt);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_4);
            this.grpTxtBoxes1.Controls.Add(this.txtQ5);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_3);
            this.grpTxtBoxes1.Controls.Add(this.txtQ4);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2_2);
            this.grpTxtBoxes1.Controls.Add(this.txtQ3);
            this.grpTxtBoxes1.Controls.Add(this.lblQ2);
            this.grpTxtBoxes1.Controls.Add(this.txtQ2);
            this.grpTxtBoxes1.Controls.Add(this.lblQ1);
            this.grpTxtBoxes1.Controls.Add(this.txtQ1);
            this.grpTxtBoxes1.Location = new System.Drawing.Point(6, 0);
            this.grpTxtBoxes1.Name = "grpTxtBoxes1";
            this.grpTxtBoxes1.Size = new System.Drawing.Size(1228, 227);
            this.grpTxtBoxes1.TabIndex = 1;
            this.grpTxtBoxes1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(800, 155);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 14);
            this.label1.TabIndex = 136;
            this.label1.Text = "Q41";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(800, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 14);
            this.label2.TabIndex = 137;
            this.label2.Text = "Q39";
            // 
            // textBox2
            // 
            this.textBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox2.Location = new System.Drawing.Point(842, 148);
            this.textBox2.MaxLength = 1;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(41, 22);
            this.textBox2.TabIndex = 131;
            // 
            // textBox30
            // 
            this.textBox30.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox30.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox30.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox30.Location = new System.Drawing.Point(842, 78);
            this.textBox30.MaxLength = 1;
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(41, 22);
            this.textBox30.TabIndex = 130;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(800, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 14);
            this.label5.TabIndex = 134;
            this.label5.Text = "Q40";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(800, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 14);
            this.label6.TabIndex = 135;
            this.label6.Text = "Q38";
            // 
            // textBox31
            // 
            this.textBox31.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox31.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox31.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox31.Location = new System.Drawing.Point(842, 110);
            this.textBox31.MaxLength = 1;
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(41, 22);
            this.textBox31.TabIndex = 129;
            // 
            // textBox32
            // 
            this.textBox32.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox32.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox32.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox32.Location = new System.Drawing.Point(842, 41);
            this.textBox32.MaxLength = 1;
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(41, 22);
            this.textBox32.TabIndex = 128;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(894, 151);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(36, 14);
            this.label33.TabIndex = 133;
            this.label33.Text = "Q46";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(894, 117);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(36, 14);
            this.label34.TabIndex = 127;
            this.label34.Text = "Q45";
            // 
            // textBox34
            // 
            this.textBox34.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox34.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox34.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox34.Location = new System.Drawing.Point(936, 147);
            this.textBox34.MaxLength = 1;
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(41, 22);
            this.textBox34.TabIndex = 122;
            // 
            // textBox35
            // 
            this.textBox35.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox35.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox35.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox35.Location = new System.Drawing.Point(936, 114);
            this.textBox35.MaxLength = 1;
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(41, 22);
            this.textBox35.TabIndex = 121;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(893, 79);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(36, 14);
            this.label35.TabIndex = 126;
            this.label35.Text = "Q44";
            // 
            // textBox36
            // 
            this.textBox36.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox36.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox36.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox36.Location = new System.Drawing.Point(935, 76);
            this.textBox36.MaxLength = 1;
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(41, 22);
            this.textBox36.TabIndex = 120;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(894, 40);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(36, 14);
            this.label36.TabIndex = 125;
            this.label36.Text = "Q43";
            // 
            // textBox37
            // 
            this.textBox37.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox37.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox37.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox37.Location = new System.Drawing.Point(936, 40);
            this.textBox37.MaxLength = 1;
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(41, 22);
            this.textBox37.TabIndex = 119;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Location = new System.Drawing.Point(800, 190);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(36, 14);
            this.label37.TabIndex = 124;
            this.label37.Text = "Q42";
            // 
            // textBox38
            // 
            this.textBox38.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox38.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox38.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox38.Location = new System.Drawing.Point(842, 186);
            this.textBox38.MaxLength = 1;
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(41, 22);
            this.textBox38.TabIndex = 118;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(615, 153);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(36, 14);
            this.label22.TabIndex = 116;
            this.label22.Text = "Q31";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(615, 72);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(36, 14);
            this.label23.TabIndex = 117;
            this.label23.Text = "Q29";
            // 
            // textBox20
            // 
            this.textBox20.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox20.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox20.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox20.Location = new System.Drawing.Point(657, 146);
            this.textBox20.MaxLength = 1;
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(41, 22);
            this.textBox20.TabIndex = 111;
            // 
            // textBox21
            // 
            this.textBox21.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox21.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox21.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox21.Location = new System.Drawing.Point(657, 76);
            this.textBox21.MaxLength = 1;
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(41, 22);
            this.textBox21.TabIndex = 110;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(615, 109);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(36, 14);
            this.label24.TabIndex = 114;
            this.label24.Text = "Q30";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(615, 40);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(36, 14);
            this.label25.TabIndex = 115;
            this.label25.Text = "Q28";
            // 
            // textBox22
            // 
            this.textBox22.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox22.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox22.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox22.Location = new System.Drawing.Point(657, 108);
            this.textBox22.MaxLength = 1;
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(41, 22);
            this.textBox22.TabIndex = 109;
            // 
            // textBox23
            // 
            this.textBox23.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox23.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox23.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox23.Location = new System.Drawing.Point(657, 39);
            this.textBox23.MaxLength = 1;
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(41, 22);
            this.textBox23.TabIndex = 108;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(709, 187);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(36, 14);
            this.label26.TabIndex = 112;
            this.label26.Text = "Q37";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(709, 149);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(36, 14);
            this.label27.TabIndex = 113;
            this.label27.Text = "Q36";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(709, 115);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(36, 14);
            this.label28.TabIndex = 107;
            this.label28.Text = "Q35";
            // 
            // textBox24
            // 
            this.textBox24.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox24.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox24.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox24.Location = new System.Drawing.Point(751, 184);
            this.textBox24.MaxLength = 1;
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(41, 22);
            this.textBox24.TabIndex = 103;
            // 
            // textBox25
            // 
            this.textBox25.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox25.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox25.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox25.Location = new System.Drawing.Point(751, 145);
            this.textBox25.MaxLength = 1;
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(41, 22);
            this.textBox25.TabIndex = 102;
            // 
            // textBox26
            // 
            this.textBox26.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox26.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox26.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox26.Location = new System.Drawing.Point(751, 112);
            this.textBox26.MaxLength = 1;
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(41, 22);
            this.textBox26.TabIndex = 101;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(708, 77);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(36, 14);
            this.label29.TabIndex = 106;
            this.label29.Text = "Q34";
            // 
            // textBox27
            // 
            this.textBox27.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox27.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox27.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox27.Location = new System.Drawing.Point(750, 74);
            this.textBox27.MaxLength = 1;
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(41, 22);
            this.textBox27.TabIndex = 100;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(709, 38);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(36, 14);
            this.label30.TabIndex = 105;
            this.label30.Text = "Q33";
            // 
            // textBox28
            // 
            this.textBox28.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox28.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox28.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox28.Location = new System.Drawing.Point(751, 38);
            this.textBox28.MaxLength = 1;
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(41, 22);
            this.textBox28.TabIndex = 99;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(615, 188);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(36, 14);
            this.label31.TabIndex = 104;
            this.label31.Text = "Q32";
            // 
            // textBox29
            // 
            this.textBox29.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox29.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox29.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox29.Location = new System.Drawing.Point(657, 184);
            this.textBox29.MaxLength = 1;
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(41, 22);
            this.textBox29.TabIndex = 98;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(411, 151);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 14);
            this.label11.TabIndex = 96;
            this.label11.Text = "Q20.1";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(424, 73);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 14);
            this.label12.TabIndex = 97;
            this.label12.Text = "Q19";
            // 
            // textBox10
            // 
            this.textBox10.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox10.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox10.Location = new System.Drawing.Point(466, 147);
            this.textBox10.MaxLength = 1;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(41, 22);
            this.textBox10.TabIndex = 91;
            // 
            // textBox11
            // 
            this.textBox11.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox11.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox11.Location = new System.Drawing.Point(466, 77);
            this.textBox11.MaxLength = 1;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(41, 22);
            this.textBox11.TabIndex = 90;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(424, 110);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(36, 14);
            this.label13.TabIndex = 94;
            this.label13.Text = "Q20";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(424, 41);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(36, 14);
            this.label14.TabIndex = 95;
            this.label14.Text = "Q18";
            // 
            // textBox12
            // 
            this.textBox12.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox12.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox12.Location = new System.Drawing.Point(466, 109);
            this.textBox12.MaxLength = 1;
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(41, 22);
            this.textBox12.TabIndex = 89;
            // 
            // textBox13
            // 
            this.textBox13.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox13.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox13.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox13.Location = new System.Drawing.Point(466, 40);
            this.textBox13.MaxLength = 1;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(41, 22);
            this.textBox13.TabIndex = 88;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(518, 187);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(36, 14);
            this.label15.TabIndex = 92;
            this.label15.Text = "Q27";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(518, 152);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(36, 14);
            this.label16.TabIndex = 93;
            this.label16.Text = "Q26";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(518, 115);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(36, 14);
            this.label17.TabIndex = 87;
            this.label17.Text = "Q25";
            // 
            // textBox14
            // 
            this.textBox14.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox14.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox14.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox14.Location = new System.Drawing.Point(560, 185);
            this.textBox14.MaxLength = 1;
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(41, 22);
            this.textBox14.TabIndex = 83;
            // 
            // textBox15
            // 
            this.textBox15.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox15.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox15.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox15.Location = new System.Drawing.Point(560, 146);
            this.textBox15.MaxLength = 1;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(41, 22);
            this.textBox15.TabIndex = 82;
            // 
            // textBox16
            // 
            this.textBox16.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox16.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox16.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox16.Location = new System.Drawing.Point(560, 113);
            this.textBox16.MaxLength = 1;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(41, 22);
            this.textBox16.TabIndex = 81;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(517, 82);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(36, 14);
            this.label19.TabIndex = 86;
            this.label19.Text = "Q24";
            // 
            // textBox17
            // 
            this.textBox17.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox17.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox17.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox17.Location = new System.Drawing.Point(559, 75);
            this.textBox17.MaxLength = 1;
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(41, 22);
            this.textBox17.TabIndex = 80;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(518, 43);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(36, 14);
            this.label20.TabIndex = 85;
            this.label20.Text = "Q23";
            // 
            // textBox18
            // 
            this.textBox18.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox18.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox18.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox18.Location = new System.Drawing.Point(560, 39);
            this.textBox18.MaxLength = 1;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(41, 22);
            this.textBox18.TabIndex = 79;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(411, 187);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(49, 14);
            this.label21.TabIndex = 84;
            this.label21.Text = "Q20.2";
            // 
            // textBox19
            // 
            this.textBox19.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox19.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox19.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox19.Location = new System.Drawing.Point(466, 185);
            this.textBox19.MaxLength = 1;
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(41, 22);
            this.textBox19.TabIndex = 78;
            // 
            // lblinstruction
            // 
            this.lblinstruction.AutoSize = true;
            this.lblinstruction.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinstruction.ForeColor = System.Drawing.Color.White;
            this.lblinstruction.Location = new System.Drawing.Point(513, 10);
            this.lblinstruction.Name = "lblinstruction";
            this.lblinstruction.Size = new System.Drawing.Size(78, 18);
            this.lblinstruction.TabIndex = 76;
            this.lblinstruction.Text = "Instruction:";
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(1111, 169);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(85, 37);
            this.btnExit.TabIndex = 37;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Location = new System.Drawing.Point(12, 15);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(75, 13);
            this.label18.TabIndex = 75;
            this.label18.Text = "Description:";
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.ImageKey = "(none)";
            this.btnSave.Location = new System.Drawing.Point(1010, 170);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 37);
            this.btnSave.TabIndex = 36;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtDescription
            // 
            this.txtDescription.AutoSize = true;
            this.txtDescription.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtDescription.ForeColor = System.Drawing.Color.Red;
            this.txtDescription.Location = new System.Drawing.Point(118, 14);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(82, 14);
            this.txtDescription.TabIndex = 74;
            this.txtDescription.Text = "Description";
            // 
            // grpKeyData
            // 
            this.grpKeyData.BackColor = System.Drawing.Color.Navy;
            this.grpKeyData.Controls.Add(this.lblKey2Data);
            this.grpKeyData.Controls.Add(this.txtKey2Data);
            this.grpKeyData.Controls.Add(this.lblKey2User);
            this.grpKeyData.Controls.Add(this.txtKey2User);
            this.grpKeyData.Controls.Add(this.lblKey1Data);
            this.grpKeyData.Controls.Add(this.txtKey1Data);
            this.grpKeyData.Controls.Add(this.lblKey1User);
            this.grpKeyData.Controls.Add(this.txtKey1User);
            this.grpKeyData.Location = new System.Drawing.Point(1008, 35);
            this.grpKeyData.Name = "grpKeyData";
            this.grpKeyData.Size = new System.Drawing.Size(214, 128);
            this.grpKeyData.TabIndex = 45;
            this.grpKeyData.TabStop = false;
            this.grpKeyData.Visible = false;
            // 
            // lblKey2Data
            // 
            this.lblKey2Data.AutoSize = true;
            this.lblKey2Data.Enabled = false;
            this.lblKey2Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey2Data.ForeColor = System.Drawing.Color.White;
            this.lblKey2Data.Location = new System.Drawing.Point(11, 106);
            this.lblKey2Data.Name = "lblKey2Data";
            this.lblKey2Data.Size = new System.Drawing.Size(76, 14);
            this.lblKey2Data.TabIndex = 49;
            this.lblKey2Data.Text = "Key2 Data";
            // 
            // txtKey2Data
            // 
            this.txtKey2Data.Enabled = false;
            this.txtKey2Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey2Data.Location = new System.Drawing.Point(90, 101);
            this.txtKey2Data.Name = "txtKey2Data";
            this.txtKey2Data.Size = new System.Drawing.Size(118, 22);
            this.txtKey2Data.TabIndex = 50;
            // 
            // lblKey2User
            // 
            this.lblKey2User.AutoSize = true;
            this.lblKey2User.Enabled = false;
            this.lblKey2User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey2User.ForeColor = System.Drawing.Color.White;
            this.lblKey2User.Location = new System.Drawing.Point(7, 78);
            this.lblKey2User.Name = "lblKey2User";
            this.lblKey2User.Size = new System.Drawing.Size(76, 14);
            this.lblKey2User.TabIndex = 47;
            this.lblKey2User.Text = "Key2 User";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(226, 145);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 14);
            this.label9.TabIndex = 43;
            this.label9.Text = "Q11";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(226, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 14);
            this.label4.TabIndex = 43;
            this.label4.Text = "Q11";
            // 
            // textBox8
            // 
            this.textBox8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox8.Location = new System.Drawing.Point(268, 145);
            this.textBox8.MaxLength = 1;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(41, 22);
            this.textBox8.TabIndex = 22;
            // 
            // txtQ21
            // 
            this.txtQ21.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ21.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ21.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ21.Location = new System.Drawing.Point(268, 75);
            this.txtQ21.MaxLength = 1;
            this.txtQ21.Name = "txtQ21";
            this.txtQ21.Size = new System.Drawing.Size(41, 22);
            this.txtQ21.TabIndex = 22;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(226, 108);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 14);
            this.label8.TabIndex = 41;
            this.label8.Text = "Q10";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(226, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 14);
            this.label3.TabIndex = 41;
            this.label3.Text = "Q10";
            // 
            // textBox7
            // 
            this.textBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox7.Location = new System.Drawing.Point(268, 107);
            this.textBox7.MaxLength = 1;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(41, 22);
            this.textBox7.TabIndex = 21;
            // 
            // txtQ20
            // 
            this.txtQ20.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ20.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ20.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ20.Location = new System.Drawing.Point(268, 38);
            this.txtQ20.MaxLength = 1;
            this.txtQ20.Name = "txtQ20";
            this.txtQ20.Size = new System.Drawing.Size(41, 22);
            this.txtQ20.TabIndex = 21;
            // 
            // lblpermission
            // 
            this.lblpermission.AutoSize = true;
            this.lblpermission.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpermission.ForeColor = System.Drawing.Color.White;
            this.lblpermission.Location = new System.Drawing.Point(24, 41);
            this.lblpermission.Name = "lblpermission";
            this.lblpermission.Size = new System.Drawing.Size(80, 14);
            this.lblpermission.TabIndex = 1;
            this.lblpermission.Text = "Permission";
            // 
            // txtbarcode
            // 
            this.txtbarcode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtbarcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtbarcode.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtbarcode.Location = new System.Drawing.Point(11, 60);
            this.txtbarcode.MaxLength = 20;
            this.txtbarcode.Name = "txtbarcode";
            this.txtbarcode.Size = new System.Drawing.Size(101, 22);
            this.txtbarcode.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(319, 188);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(36, 14);
            this.label10.TabIndex = 33;
            this.label10.Text = "Q17";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(320, 148);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 14);
            this.label7.TabIndex = 33;
            this.label7.Text = "Q16";
            // 
            // lblQ9
            // 
            this.lblQ9.AutoSize = true;
            this.lblQ9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ9.ForeColor = System.Drawing.Color.White;
            this.lblQ9.Location = new System.Drawing.Point(136, 189);
            this.lblQ9.Name = "lblQ9";
            this.lblQ9.Size = new System.Drawing.Size(27, 14);
            this.lblQ9.TabIndex = 33;
            this.lblQ9.Text = "Q9";
            // 
            // lblq15
            // 
            this.lblq15.AutoSize = true;
            this.lblq15.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblq15.ForeColor = System.Drawing.Color.White;
            this.lblq15.Location = new System.Drawing.Point(319, 114);
            this.lblq15.Name = "lblq15";
            this.lblq15.Size = new System.Drawing.Size(36, 14);
            this.lblq15.TabIndex = 17;
            this.lblq15.Text = "Q15";
            // 
            // lblQ2_7
            // 
            this.lblQ2_7.AutoSize = true;
            this.lblQ2_7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_7.ForeColor = System.Drawing.Color.White;
            this.lblQ2_7.Location = new System.Drawing.Point(137, 154);
            this.lblQ2_7.Name = "lblQ2_7";
            this.lblQ2_7.Size = new System.Drawing.Size(27, 14);
            this.lblQ2_7.TabIndex = 17;
            this.lblQ2_7.Text = "Q8";
            // 
            // textBox9
            // 
            this.textBox9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox9.Location = new System.Drawing.Point(362, 183);
            this.textBox9.MaxLength = 1;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(41, 22);
            this.textBox9.TabIndex = 9;
            // 
            // textBox6
            // 
            this.textBox6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox6.Location = new System.Drawing.Point(362, 144);
            this.textBox6.MaxLength = 1;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(41, 22);
            this.textBox6.TabIndex = 9;
            // 
            // textBox1
            // 
            this.textBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox1.Location = new System.Drawing.Point(170, 185);
            this.textBox1.MaxLength = 1;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(41, 22);
            this.textBox1.TabIndex = 9;
            // 
            // textBox5
            // 
            this.textBox5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox5.Location = new System.Drawing.Point(362, 111);
            this.textBox5.MaxLength = 1;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(41, 22);
            this.textBox5.TabIndex = 9;
            // 
            // txtQ8
            // 
            this.txtQ8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ8.Location = new System.Drawing.Point(170, 152);
            this.txtQ8.MaxLength = 1;
            this.txtQ8.Name = "txtQ8";
            this.txtQ8.Size = new System.Drawing.Size(41, 22);
            this.txtQ8.TabIndex = 9;
            // 
            // lblQ14
            // 
            this.lblQ14.AutoSize = true;
            this.lblQ14.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ14.ForeColor = System.Drawing.Color.White;
            this.lblQ14.Location = new System.Drawing.Point(320, 77);
            this.lblQ14.Name = "lblQ14";
            this.lblQ14.Size = new System.Drawing.Size(36, 14);
            this.lblQ14.TabIndex = 15;
            this.lblQ14.Text = "Q14";
            // 
            // lblQ2_6
            // 
            this.lblQ2_6.AutoSize = true;
            this.lblQ2_6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_6.ForeColor = System.Drawing.Color.White;
            this.lblQ2_6.Location = new System.Drawing.Point(136, 114);
            this.lblQ2_6.Name = "lblQ2_6";
            this.lblQ2_6.Size = new System.Drawing.Size(27, 14);
            this.lblQ2_6.TabIndex = 15;
            this.lblQ2_6.Text = "Q7";
            // 
            // textBox4
            // 
            this.textBox4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox4.Location = new System.Drawing.Point(361, 73);
            this.textBox4.MaxLength = 1;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(41, 22);
            this.textBox4.TabIndex = 8;
            // 
            // txtQ7
            // 
            this.txtQ7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ7.Location = new System.Drawing.Point(169, 114);
            this.txtQ7.MaxLength = 1;
            this.txtQ7.Name = "txtQ7";
            this.txtQ7.Size = new System.Drawing.Size(41, 22);
            this.txtQ7.TabIndex = 8;
            // 
            // lblQ13
            // 
            this.lblQ13.AutoSize = true;
            this.lblQ13.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ13.ForeColor = System.Drawing.Color.White;
            this.lblQ13.Location = new System.Drawing.Point(319, 40);
            this.lblQ13.Name = "lblQ13";
            this.lblQ13.Size = new System.Drawing.Size(36, 14);
            this.lblQ13.TabIndex = 13;
            this.lblQ13.Text = "Q13";
            // 
            // lblQ2_5
            // 
            this.lblQ2_5.AutoSize = true;
            this.lblQ2_5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_5.ForeColor = System.Drawing.Color.White;
            this.lblQ2_5.Location = new System.Drawing.Point(136, 78);
            this.lblQ2_5.Name = "lblQ2_5";
            this.lblQ2_5.Size = new System.Drawing.Size(27, 14);
            this.lblQ2_5.TabIndex = 13;
            this.lblQ2_5.Text = "Q6";
            // 
            // textBox3
            // 
            this.textBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.textBox3.Location = new System.Drawing.Point(362, 37);
            this.textBox3.MaxLength = 1;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(41, 22);
            this.textBox3.TabIndex = 7;
            // 
            // lbl12
            // 
            this.lbl12.AutoSize = true;
            this.lbl12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl12.ForeColor = System.Drawing.Color.White;
            this.lbl12.Location = new System.Drawing.Point(226, 189);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(36, 14);
            this.lbl12.TabIndex = 11;
            this.lbl12.Text = "Q12";
            // 
            // txtQ6
            // 
            this.txtQ6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ6.Location = new System.Drawing.Point(170, 78);
            this.txtQ6.MaxLength = 1;
            this.txtQ6.Name = "txtQ6";
            this.txtQ6.Size = new System.Drawing.Size(41, 22);
            this.txtQ6.TabIndex = 7;
            // 
            // txt
            // 
            this.txt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txt.Location = new System.Drawing.Point(268, 183);
            this.txt.MaxLength = 1;
            this.txt.Name = "txt";
            this.txt.Size = new System.Drawing.Size(41, 22);
            this.txt.TabIndex = 6;
            // 
            // lblQ2_4
            // 
            this.lblQ2_4.AutoSize = true;
            this.lblQ2_4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_4.ForeColor = System.Drawing.Color.White;
            this.lblQ2_4.Location = new System.Drawing.Point(136, 46);
            this.lblQ2_4.Name = "lblQ2_4";
            this.lblQ2_4.Size = new System.Drawing.Size(27, 14);
            this.lblQ2_4.TabIndex = 11;
            this.lblQ2_4.Text = "Q5";
            // 
            // txtQ5
            // 
            this.txtQ5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ5.Location = new System.Drawing.Point(169, 43);
            this.txtQ5.MaxLength = 1;
            this.txtQ5.Name = "txtQ5";
            this.txtQ5.Size = new System.Drawing.Size(41, 22);
            this.txtQ5.TabIndex = 6;
            // 
            // lblQ2_3
            // 
            this.lblQ2_3.AutoSize = true;
            this.lblQ2_3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_3.ForeColor = System.Drawing.Color.White;
            this.lblQ2_3.Location = new System.Drawing.Point(11, 193);
            this.lblQ2_3.Name = "lblQ2_3";
            this.lblQ2_3.Size = new System.Drawing.Size(27, 14);
            this.lblQ2_3.TabIndex = 9;
            this.lblQ2_3.Text = "Q4";
            // 
            // txtQ4
            // 
            this.txtQ4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ4.Location = new System.Drawing.Point(44, 186);
            this.txtQ4.MaxLength = 1;
            this.txtQ4.Name = "txtQ4";
            this.txtQ4.Size = new System.Drawing.Size(43, 22);
            this.txtQ4.TabIndex = 5;
            // 
            // lblQ2_2
            // 
            this.lblQ2_2.AutoSize = true;
            this.lblQ2_2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2_2.ForeColor = System.Drawing.Color.White;
            this.lblQ2_2.Location = new System.Drawing.Point(8, 161);
            this.lblQ2_2.Name = "lblQ2_2";
            this.lblQ2_2.Size = new System.Drawing.Size(27, 14);
            this.lblQ2_2.TabIndex = 7;
            this.lblQ2_2.Text = "Q3";
            // 
            // txtQ3
            // 
            this.txtQ3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ3.Location = new System.Drawing.Point(44, 152);
            this.txtQ3.MaxLength = 1;
            this.txtQ3.Name = "txtQ3";
            this.txtQ3.Size = new System.Drawing.Size(43, 22);
            this.txtQ3.TabIndex = 4;
            // 
            // lblQ2
            // 
            this.lblQ2.AutoSize = true;
            this.lblQ2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2.ForeColor = System.Drawing.Color.White;
            this.lblQ2.Location = new System.Drawing.Point(8, 123);
            this.lblQ2.Name = "lblQ2";
            this.lblQ2.Size = new System.Drawing.Size(27, 14);
            this.lblQ2.TabIndex = 5;
            this.lblQ2.Text = "Q2";
            // 
            // txtQ2
            // 
            this.txtQ2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ2.Location = new System.Drawing.Point(44, 119);
            this.txtQ2.MaxLength = 5;
            this.txtQ2.Name = "txtQ2";
            this.txtQ2.Size = new System.Drawing.Size(43, 22);
            this.txtQ2.TabIndex = 3;
            // 
            // lblQ1
            // 
            this.lblQ1.AutoSize = true;
            this.lblQ1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ1.ForeColor = System.Drawing.Color.White;
            this.lblQ1.Location = new System.Drawing.Point(11, 92);
            this.lblQ1.Name = "lblQ1";
            this.lblQ1.Size = new System.Drawing.Size(27, 14);
            this.lblQ1.TabIndex = 3;
            this.lblQ1.Text = "Q1";
            // 
            // txtQ1
            // 
            this.txtQ1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtQ1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQ1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtQ1.Location = new System.Drawing.Point(44, 89);
            this.txtQ1.MaxLength = 10;
            this.txtQ1.Name = "txtQ1";
            this.txtQ1.Size = new System.Drawing.Size(43, 22);
            this.txtQ1.TabIndex = 2;
            // 
            // IGImageViewer
            // 
            this.IGImageViewer.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.IGImageViewer.BackColor = System.Drawing.Color.Azure;
            this.IGImageViewer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.IGImageViewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IGImageViewer.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IGImageViewer.ImageData = null;
            this.IGImageViewer.ImageName = null;
            this.IGImageViewer.ImageScropping = false;
            this.IGImageViewer.ImageSize = new System.Drawing.Size(1366, 768);
            this.IGImageViewer.Location = new System.Drawing.Point(1, -1);
            this.IGImageViewer.Name = "IGImageViewer";
            this.IGImageViewer.PictureBoxSize = new System.Drawing.Size(0, 0);
            this.IGImageViewer.Size = new System.Drawing.Size(1254, 466);
            this.IGImageViewer.StatusBarVisible = true;
            this.IGImageViewer.TabIndex = 48;
            // 
            // Healthtel_Adult
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1255, 742);
            this.Controls.Add(this.grpMain);
            this.Controls.Add(this.IGImageViewer);
            this.Name = "Healthtel_Adult";
            this.Text = "Healthtel_Adult";
            this.Load += new System.EventHandler(this.Healthtel_Adult_Load);
            this.grpMain.ResumeLayout(false);
            this.StatusStrip1.ResumeLayout(false);
            this.StatusStrip1.PerformLayout();
            this.grpTxtBoxes1.ResumeLayout(false);
            this.grpTxtBoxes1.PerformLayout();
            this.grpKeyData.ResumeLayout(false);
            this.grpKeyData.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.ToolStripStatusLabel stsRemRecs;
        private System.Windows.Forms.Label txtinstruction;
        private System.Windows.Forms.TextBox txtKey2User;
        internal System.Windows.Forms.ToolStripStatusLabel stsDate;
        private System.Windows.Forms.Label lblKey1Data;
        private System.Windows.Forms.TextBox txtKey1Data;
        private System.Windows.Forms.Label lblKey1User;
        private System.Windows.Forms.TextBox txtKey1User;
        private System.Windows.Forms.GroupBox grpMain;
        internal System.Windows.Forms.StatusStrip StatusStrip1;
        internal System.Windows.Forms.ToolStripStatusLabel stsUser;
        internal System.Windows.Forms.ToolStripStatusLabel stsTotRecs;
        internal System.Windows.Forms.ToolStripStatusLabel stsFinRecs;
        private System.Windows.Forms.GroupBox grpTxtBoxes1;
        private System.Windows.Forms.Label lblinstruction;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label txtDescription;
        private System.Windows.Forms.GroupBox grpKeyData;
        private System.Windows.Forms.Label lblKey2Data;
        private System.Windows.Forms.TextBox txtKey2Data;
        private System.Windows.Forms.Label lblKey2User;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtQ21;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtQ20;
        private System.Windows.Forms.Label lblpermission;
        private System.Windows.Forms.TextBox txtbarcode;
        private System.Windows.Forms.Label lblQ9;
        private System.Windows.Forms.Label lblQ2_7;
        private System.Windows.Forms.TextBox txtQ8;
        private System.Windows.Forms.Label lblQ2_6;
        private System.Windows.Forms.TextBox txtQ7;
        private System.Windows.Forms.Label lblQ2_5;
        private System.Windows.Forms.TextBox txtQ6;
        private System.Windows.Forms.Label lblQ2_4;
        private System.Windows.Forms.TextBox txtQ5;
        private System.Windows.Forms.Label lblQ2_3;
        private System.Windows.Forms.TextBox txtQ4;
        private System.Windows.Forms.Label lblQ2_2;
        private System.Windows.Forms.TextBox txtQ3;
        private System.Windows.Forms.Label lblQ2;
        private System.Windows.Forms.TextBox txtQ2;
        private System.Windows.Forms.Label lblQ1;
        private System.Windows.Forms.TextBox txtQ1;
        private InfognanaImageViewer.IGImageViewer IGImageViewer;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblq15;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label lblQ14;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label lblQ13;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.TextBox txt;
    }
}