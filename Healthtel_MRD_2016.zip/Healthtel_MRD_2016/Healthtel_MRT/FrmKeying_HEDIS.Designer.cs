﻿namespace Healthtel_MRT
{
    partial class FrmKeying_HEDIS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpMain = new System.Windows.Forms.GroupBox();
            this.StatusStrip1 = new System.Windows.Forms.StatusStrip();
            this.stsUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsTotRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsFinRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsRemRecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.grpKeyData = new System.Windows.Forms.GroupBox();
            this.lblKey2Data = new System.Windows.Forms.Label();
            this.grpButtons = new System.Windows.Forms.GroupBox();
            this.txtKey2Data = new System.Windows.Forms.TextBox();
            this.lblKey2User = new System.Windows.Forms.Label();
            this.txtKey2User = new System.Windows.Forms.TextBox();
            this.lblKey1Data = new System.Windows.Forms.Label();
            this.txtKey1Data = new System.Windows.Forms.TextBox();
            this.lblKey1User = new System.Windows.Forms.Label();
            this.txtKey1User = new System.Windows.Forms.TextBox();
            this.grpTxtBoxes1 = new System.Windows.Forms.GroupBox();
            this.txtComments = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtBarcode = new System.Windows.Forms.TextBox();
            this.lblComments = new System.Windows.Forms.Label();
            this.lblBarcode = new System.Windows.Forms.Label();
            this.chksignature = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtQ2_1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblQ1_5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtQ1_5 = new System.Windows.Forms.TextBox();
            this.txtQ2_2 = new System.Windows.Forms.TextBox();
            this.txtQ3_2 = new System.Windows.Forms.TextBox();
            this.txtQ3_1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtQ1_4 = new System.Windows.Forms.TextBox();
            this.lblQ1_4 = new System.Windows.Forms.Label();
            this.grpbxQ1_2B = new System.Windows.Forms.GroupBox();
            this.txtQ1_2B_yy = new System.Windows.Forms.TextBox();
            this.txtQ1_2B_dd = new System.Windows.Forms.TextBox();
            this.txtQ1_2B_mm = new System.Windows.Forms.TextBox();
            this.grpbxQ1_2A = new System.Windows.Forms.GroupBox();
            this.txtQ1_2A_yy = new System.Windows.Forms.TextBox();
            this.txtQ1_2A_dd = new System.Windows.Forms.TextBox();
            this.txtQ1_2A_mm = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.txtSign_yy = new System.Windows.Forms.TextBox();
            this.txtSign_dd = new System.Windows.Forms.TextBox();
            this.txtSign_mm = new System.Windows.Forms.TextBox();
            this.grpbxQ3_4 = new System.Windows.Forms.GroupBox();
            this.txtQ3_4_yy = new System.Windows.Forms.TextBox();
            this.txtQ3_4_dd = new System.Windows.Forms.TextBox();
            this.txtQ3_4_mm = new System.Windows.Forms.TextBox();
            this.grpbxQ3_3B = new System.Windows.Forms.GroupBox();
            this.txtQ3_3B_yy = new System.Windows.Forms.TextBox();
            this.txtQ3_3B_dd = new System.Windows.Forms.TextBox();
            this.txtQ3_3B_mm = new System.Windows.Forms.TextBox();
            this.grpbxQ2_3B = new System.Windows.Forms.GroupBox();
            this.txtQ2_3B_yy = new System.Windows.Forms.TextBox();
            this.txtQ2_3B_dd = new System.Windows.Forms.TextBox();
            this.txtQ2_3B_mm = new System.Windows.Forms.TextBox();
            this.grpbxQ3_3A = new System.Windows.Forms.GroupBox();
            this.txtQ3_3A_yy = new System.Windows.Forms.TextBox();
            this.txtQ3_3A_dd = new System.Windows.Forms.TextBox();
            this.txtQ3_3A_mm = new System.Windows.Forms.TextBox();
            this.grpbxQ2_3A = new System.Windows.Forms.GroupBox();
            this.txtQ2_3A_yy = new System.Windows.Forms.TextBox();
            this.txtQ2_3A_dd = new System.Windows.Forms.TextBox();
            this.txtQ2_3A_mm = new System.Windows.Forms.TextBox();
            this.grpbxQ1_3B = new System.Windows.Forms.GroupBox();
            this.txtQ1_3B_yy = new System.Windows.Forms.TextBox();
            this.txtQ1_3B_dd = new System.Windows.Forms.TextBox();
            this.txtQ1_3B_mm = new System.Windows.Forms.TextBox();
            this.grpbxQ1_1B = new System.Windows.Forms.GroupBox();
            this.txtQ1_1B_yy = new System.Windows.Forms.TextBox();
            this.txtQ1_1B_dd = new System.Windows.Forms.TextBox();
            this.txtQ1_1B_mm = new System.Windows.Forms.TextBox();
            this.grpbxQ1_3A = new System.Windows.Forms.GroupBox();
            this.txtQ1_3A_yy = new System.Windows.Forms.TextBox();
            this.txtQ1_3A_dd = new System.Windows.Forms.TextBox();
            this.txtQ1_3A_mm = new System.Windows.Forms.TextBox();
            this.grobxQ1_1A = new System.Windows.Forms.GroupBox();
            this.txtQ1_1A_yy = new System.Windows.Forms.TextBox();
            this.txtQ1_1A_dd = new System.Windows.Forms.TextBox();
            this.txtQ1_1A_mm = new System.Windows.Forms.TextBox();
            this.IGImageViewer = new InfognanaImageViewer.IGImageViewer();
            this.grpMain.SuspendLayout();
            this.StatusStrip1.SuspendLayout();
            this.grpKeyData.SuspendLayout();
            this.grpTxtBoxes1.SuspendLayout();
            this.grpbxQ1_2B.SuspendLayout();
            this.grpbxQ1_2A.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.grpbxQ3_4.SuspendLayout();
            this.grpbxQ3_3B.SuspendLayout();
            this.grpbxQ2_3B.SuspendLayout();
            this.grpbxQ3_3A.SuspendLayout();
            this.grpbxQ2_3A.SuspendLayout();
            this.grpbxQ1_3B.SuspendLayout();
            this.grpbxQ1_1B.SuspendLayout();
            this.grpbxQ1_3A.SuspendLayout();
            this.grobxQ1_1A.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpMain
            // 
            this.grpMain.BackColor = System.Drawing.Color.Transparent;
            this.grpMain.Controls.Add(this.StatusStrip1);
            this.grpMain.Controls.Add(this.grpKeyData);
            this.grpMain.Controls.Add(this.grpTxtBoxes1);
            this.grpMain.Location = new System.Drawing.Point(1, 421);
            this.grpMain.Name = "grpMain";
            this.grpMain.Size = new System.Drawing.Size(1055, 331);
            this.grpMain.TabIndex = 1;
            this.grpMain.TabStop = false;
            // 
            // StatusStrip1
            // 
            this.StatusStrip1.AutoSize = false;
            this.StatusStrip1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StatusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stsUser,
            this.stsTotRecs,
            this.stsFinRecs,
            this.stsRemRecs,
            this.stsDate});
            this.StatusStrip1.Location = new System.Drawing.Point(3, 287);
            this.StatusStrip1.Name = "StatusStrip1";
            this.StatusStrip1.Size = new System.Drawing.Size(1049, 41);
            this.StatusStrip1.TabIndex = 45;
            this.StatusStrip1.Text = "StatusStrip1";
            // 
            // stsUser
            // 
            this.stsUser.AutoSize = false;
            this.stsUser.BackColor = System.Drawing.Color.Transparent;
            this.stsUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsUser.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsUser.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsUser.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsUser.ForeColor = System.Drawing.Color.Black;
            this.stsUser.Name = "stsUser";
            this.stsUser.Size = new System.Drawing.Size(210, 36);
            this.stsUser.Text = "User : Admin";
            this.stsUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsUser.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsTotRecs
            // 
            this.stsTotRecs.AutoSize = false;
            this.stsTotRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsTotRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsTotRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsTotRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsTotRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsTotRecs.ForeColor = System.Drawing.Color.Black;
            this.stsTotRecs.Name = "stsTotRecs";
            this.stsTotRecs.Size = new System.Drawing.Size(200, 36);
            this.stsTotRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsTotRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsFinRecs
            // 
            this.stsFinRecs.AutoSize = false;
            this.stsFinRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsFinRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsFinRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsFinRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsFinRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsFinRecs.ForeColor = System.Drawing.Color.Black;
            this.stsFinRecs.Name = "stsFinRecs";
            this.stsFinRecs.Size = new System.Drawing.Size(200, 36);
            this.stsFinRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsFinRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsRemRecs
            // 
            this.stsRemRecs.AutoSize = false;
            this.stsRemRecs.BackColor = System.Drawing.Color.Transparent;
            this.stsRemRecs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsRemRecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsRemRecs.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsRemRecs.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsRemRecs.ForeColor = System.Drawing.Color.Black;
            this.stsRemRecs.Name = "stsRemRecs";
            this.stsRemRecs.Size = new System.Drawing.Size(200, 36);
            this.stsRemRecs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsRemRecs.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // stsDate
            // 
            this.stsDate.AutoSize = false;
            this.stsDate.BackColor = System.Drawing.Color.Transparent;
            this.stsDate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stsDate.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.stsDate.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.stsDate.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stsDate.ForeColor = System.Drawing.Color.Black;
            this.stsDate.Name = "stsDate";
            this.stsDate.Size = new System.Drawing.Size(200, 36);
            this.stsDate.Text = "Date : ";
            this.stsDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stsDate.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // grpKeyData
            // 
            this.grpKeyData.Controls.Add(this.lblKey2Data);
            this.grpKeyData.Controls.Add(this.grpButtons);
            this.grpKeyData.Controls.Add(this.txtKey2Data);
            this.grpKeyData.Controls.Add(this.lblKey2User);
            this.grpKeyData.Controls.Add(this.txtKey2User);
            this.grpKeyData.Controls.Add(this.lblKey1Data);
            this.grpKeyData.Controls.Add(this.txtKey1Data);
            this.grpKeyData.Controls.Add(this.lblKey1User);
            this.grpKeyData.Controls.Add(this.txtKey1User);
            this.grpKeyData.Location = new System.Drawing.Point(13, 240);
            this.grpKeyData.Name = "grpKeyData";
            this.grpKeyData.Size = new System.Drawing.Size(1031, 40);
            this.grpKeyData.TabIndex = 64;
            this.grpKeyData.TabStop = false;
            this.grpKeyData.Visible = false;
            // 
            // lblKey2Data
            // 
            this.lblKey2Data.AutoSize = true;
            this.lblKey2Data.Enabled = false;
            this.lblKey2Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey2Data.ForeColor = System.Drawing.Color.White;
            this.lblKey2Data.Location = new System.Drawing.Point(721, 13);
            this.lblKey2Data.Name = "lblKey2Data";
            this.lblKey2Data.Size = new System.Drawing.Size(76, 14);
            this.lblKey2Data.TabIndex = 71;
            this.lblKey2Data.Text = "Key2 Data";
            this.lblKey2Data.Visible = false;
            // 
            // grpButtons
            // 
            this.grpButtons.Location = new System.Drawing.Point(634, 47);
            this.grpButtons.Name = "grpButtons";
            this.grpButtons.Size = new System.Drawing.Size(397, 58);
            this.grpButtons.TabIndex = 42;
            this.grpButtons.TabStop = false;
            // 
            // txtKey2Data
            // 
            this.txtKey2Data.Enabled = false;
            this.txtKey2Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey2Data.Location = new System.Drawing.Point(806, 11);
            this.txtKey2Data.Name = "txtKey2Data";
            this.txtKey2Data.Size = new System.Drawing.Size(206, 22);
            this.txtKey2Data.TabIndex = 72;
            this.txtKey2Data.Visible = false;
            // 
            // lblKey2User
            // 
            this.lblKey2User.AutoSize = true;
            this.lblKey2User.Enabled = false;
            this.lblKey2User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey2User.ForeColor = System.Drawing.Color.White;
            this.lblKey2User.Location = new System.Drawing.Point(519, 13);
            this.lblKey2User.Name = "lblKey2User";
            this.lblKey2User.Size = new System.Drawing.Size(76, 14);
            this.lblKey2User.TabIndex = 69;
            this.lblKey2User.Text = "Key2 User";
            this.lblKey2User.Visible = false;
            // 
            // txtKey2User
            // 
            this.txtKey2User.Enabled = false;
            this.txtKey2User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey2User.Location = new System.Drawing.Point(604, 11);
            this.txtKey2User.Name = "txtKey2User";
            this.txtKey2User.Size = new System.Drawing.Size(111, 22);
            this.txtKey2User.TabIndex = 70;
            this.txtKey2User.Visible = false;
            // 
            // lblKey1Data
            // 
            this.lblKey1Data.AutoSize = true;
            this.lblKey1Data.Enabled = false;
            this.lblKey1Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey1Data.ForeColor = System.Drawing.Color.White;
            this.lblKey1Data.Location = new System.Drawing.Point(208, 13);
            this.lblKey1Data.Name = "lblKey1Data";
            this.lblKey1Data.Size = new System.Drawing.Size(76, 14);
            this.lblKey1Data.TabIndex = 67;
            this.lblKey1Data.Text = "Key1 Data";
            this.lblKey1Data.Visible = false;
            // 
            // txtKey1Data
            // 
            this.txtKey1Data.Enabled = false;
            this.txtKey1Data.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey1Data.Location = new System.Drawing.Point(293, 11);
            this.txtKey1Data.Name = "txtKey1Data";
            this.txtKey1Data.Size = new System.Drawing.Size(206, 22);
            this.txtKey1Data.TabIndex = 68;
            this.txtKey1Data.Visible = false;
            // 
            // lblKey1User
            // 
            this.lblKey1User.AutoSize = true;
            this.lblKey1User.Enabled = false;
            this.lblKey1User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey1User.ForeColor = System.Drawing.Color.White;
            this.lblKey1User.Location = new System.Drawing.Point(6, 13);
            this.lblKey1User.Name = "lblKey1User";
            this.lblKey1User.Size = new System.Drawing.Size(76, 14);
            this.lblKey1User.TabIndex = 65;
            this.lblKey1User.Text = "Key1 User";
            // 
            // txtKey1User
            // 
            this.txtKey1User.Enabled = false;
            this.txtKey1User.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtKey1User.Location = new System.Drawing.Point(91, 11);
            this.txtKey1User.Name = "txtKey1User";
            this.txtKey1User.Size = new System.Drawing.Size(111, 22);
            this.txtKey1User.TabIndex = 66;
            // 
            // grpTxtBoxes1
            // 
            this.grpTxtBoxes1.Controls.Add(this.txtComments);
            this.grpTxtBoxes1.Controls.Add(this.btnSave);
            this.grpTxtBoxes1.Controls.Add(this.btnExit);
            this.grpTxtBoxes1.Controls.Add(this.txtBarcode);
            this.grpTxtBoxes1.Controls.Add(this.lblComments);
            this.grpTxtBoxes1.Controls.Add(this.lblBarcode);
            this.grpTxtBoxes1.Controls.Add(this.chksignature);
            this.grpTxtBoxes1.Controls.Add(this.label2);
            this.grpTxtBoxes1.Controls.Add(this.txtQ2_1);
            this.grpTxtBoxes1.Controls.Add(this.label1);
            this.grpTxtBoxes1.Controls.Add(this.lblQ1_5);
            this.grpTxtBoxes1.Controls.Add(this.label4);
            this.grpTxtBoxes1.Controls.Add(this.txtQ1_5);
            this.grpTxtBoxes1.Controls.Add(this.txtQ2_2);
            this.grpTxtBoxes1.Controls.Add(this.txtQ3_2);
            this.grpTxtBoxes1.Controls.Add(this.txtQ3_1);
            this.grpTxtBoxes1.Controls.Add(this.label3);
            this.grpTxtBoxes1.Controls.Add(this.txtQ1_4);
            this.grpTxtBoxes1.Controls.Add(this.lblQ1_4);
            this.grpTxtBoxes1.Controls.Add(this.grpbxQ1_2B);
            this.grpTxtBoxes1.Controls.Add(this.grpbxQ1_2A);
            this.grpTxtBoxes1.Controls.Add(this.groupBox9);
            this.grpTxtBoxes1.Controls.Add(this.grpbxQ3_4);
            this.grpTxtBoxes1.Controls.Add(this.grpbxQ3_3B);
            this.grpTxtBoxes1.Controls.Add(this.grpbxQ2_3B);
            this.grpTxtBoxes1.Controls.Add(this.grpbxQ3_3A);
            this.grpTxtBoxes1.Controls.Add(this.grpbxQ2_3A);
            this.grpTxtBoxes1.Controls.Add(this.grpbxQ1_3B);
            this.grpTxtBoxes1.Controls.Add(this.grpbxQ1_1B);
            this.grpTxtBoxes1.Controls.Add(this.grpbxQ1_3A);
            this.grpTxtBoxes1.Controls.Add(this.grobxQ1_1A);
            this.grpTxtBoxes1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.grpTxtBoxes1.Location = new System.Drawing.Point(11, 9);
            this.grpTxtBoxes1.Name = "grpTxtBoxes1";
            this.grpTxtBoxes1.Size = new System.Drawing.Size(1031, 231);
            this.grpTxtBoxes1.TabIndex = 2;
            this.grpTxtBoxes1.TabStop = false;
            this.grpTxtBoxes1.Text = "              ";
            // 
            // txtComments
            // 
            this.txtComments.Location = new System.Drawing.Point(776, 200);
            this.txtComments.Name = "txtComments";
            this.txtComments.Size = new System.Drawing.Size(224, 20);
            this.txtComments.TabIndex = 66;
            this.txtComments.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtComments_KeyPress);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.ImageKey = "(none)";
            this.btnSave.Location = new System.Drawing.Point(541, 192);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(59, 29);
            this.btnSave.TabIndex = 67;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(606, 191);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(62, 31);
            this.btnExit.TabIndex = 68;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtBarcode
            // 
            this.txtBarcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtBarcode.Location = new System.Drawing.Point(340, 195);
            this.txtBarcode.MaxLength = 32567;
            this.txtBarcode.Name = "txtBarcode";
            this.txtBarcode.Size = new System.Drawing.Size(176, 22);
            this.txtBarcode.TabIndex = 64;
            this.txtBarcode.Visible = false;
            this.txtBarcode.TextChanged += new System.EventHandler(this.txtBarcode_TextChanged);
            this.txtBarcode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBarcode_KeyPress);
            // 
            // lblComments
            // 
            this.lblComments.AutoSize = true;
            this.lblComments.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComments.ForeColor = System.Drawing.Color.White;
            this.lblComments.Location = new System.Drawing.Point(693, 203);
            this.lblComments.Name = "lblComments";
            this.lblComments.Size = new System.Drawing.Size(76, 14);
            this.lblComments.TabIndex = 65;
            this.lblComments.Text = "Comments";
            // 
            // lblBarcode
            // 
            this.lblBarcode.AutoSize = true;
            this.lblBarcode.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBarcode.ForeColor = System.Drawing.Color.White;
            this.lblBarcode.Location = new System.Drawing.Point(273, 201);
            this.lblBarcode.Name = "lblBarcode";
            this.lblBarcode.Size = new System.Drawing.Size(61, 14);
            this.lblBarcode.TabIndex = 60;
            this.lblBarcode.Text = "Barcode";
            this.lblBarcode.Visible = false;
            // 
            // chksignature
            // 
            this.chksignature.AutoSize = true;
            this.chksignature.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chksignature.ForeColor = System.Drawing.Color.White;
            this.chksignature.Location = new System.Drawing.Point(11, 191);
            this.chksignature.Name = "chksignature";
            this.chksignature.Size = new System.Drawing.Size(93, 20);
            this.chksignature.TabIndex = 59;
            this.chksignature.Text = "Signature";
            this.chksignature.UseVisualStyleBackColor = true;
            this.chksignature.CheckedChanged += new System.EventHandler(this.chksignature_CheckedChanged);
            this.chksignature.Enter += new System.EventHandler(this.chksignature_Enter);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(341, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 15);
            this.label2.TabIndex = 33;
            this.label2.Text = "Q2_2";
            // 
            // txtQ2_1
            // 
            this.txtQ2_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtQ2_1.Location = new System.Drawing.Point(53, 113);
            this.txtQ2_1.Name = "txtQ2_1";
            this.txtQ2_1.Size = new System.Drawing.Size(281, 22);
            this.txtQ2_1.TabIndex = 32;
            this.txtQ2_1.TextChanged += new System.EventHandler(this.txtQ2_1_TextChanged);
            this.txtQ2_1.Enter += new System.EventHandler(this.txtQ2_1_Enter);
            this.txtQ2_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_1_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 15);
            this.label1.TabIndex = 31;
            this.label1.Text = "Q2_1";
            // 
            // lblQ1_5
            // 
            this.lblQ1_5.AutoSize = true;
            this.lblQ1_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ1_5.ForeColor = System.Drawing.Color.White;
            this.lblQ1_5.Location = new System.Drawing.Point(695, 69);
            this.lblQ1_5.Name = "lblQ1_5";
            this.lblQ1_5.Size = new System.Drawing.Size(41, 15);
            this.lblQ1_5.TabIndex = 29;
            this.lblQ1_5.Text = "Q1_5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(267, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 15);
            this.label4.TabIndex = 45;
            this.label4.Text = "Q3_2";
            // 
            // txtQ1_5
            // 
            this.txtQ1_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtQ1_5.Location = new System.Drawing.Point(742, 65);
            this.txtQ1_5.Name = "txtQ1_5";
            this.txtQ1_5.Size = new System.Drawing.Size(258, 22);
            this.txtQ1_5.TabIndex = 30;
            this.txtQ1_5.TextChanged += new System.EventHandler(this.txtQ1_5_TextChanged);
            this.txtQ1_5.Enter += new System.EventHandler(this.txtQ1_5_Enter);
            this.txtQ1_5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_5_KeyPress);
            // 
            // txtQ2_2
            // 
            this.txtQ2_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtQ2_2.Location = new System.Drawing.Point(387, 111);
            this.txtQ2_2.Name = "txtQ2_2";
            this.txtQ2_2.Size = new System.Drawing.Size(281, 22);
            this.txtQ2_2.TabIndex = 34;
            this.txtQ2_2.TextChanged += new System.EventHandler(this.txtQ2_2_TextChanged);
            this.txtQ2_2.Enter += new System.EventHandler(this.txtQ2_2_Enter);
            this.txtQ2_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_2_KeyPress);
            // 
            // txtQ3_2
            // 
            this.txtQ3_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtQ3_2.Location = new System.Drawing.Point(314, 158);
            this.txtQ3_2.Name = "txtQ3_2";
            this.txtQ3_2.Size = new System.Drawing.Size(203, 22);
            this.txtQ3_2.TabIndex = 46;
            this.txtQ3_2.TextChanged += new System.EventHandler(this.txtQ3_2_TextChanged);
            this.txtQ3_2.Enter += new System.EventHandler(this.txtQ3_2_Enter);
            this.txtQ3_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_2_KeyPress);
            // 
            // txtQ3_1
            // 
            this.txtQ3_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtQ3_1.Location = new System.Drawing.Point(53, 154);
            this.txtQ3_1.Name = "txtQ3_1";
            this.txtQ3_1.Size = new System.Drawing.Size(203, 22);
            this.txtQ3_1.TabIndex = 44;
            this.txtQ3_1.TextChanged += new System.EventHandler(this.txtQ3_1_TextChanged);
            this.txtQ3_1.Enter += new System.EventHandler(this.txtQ3_1_Enter);
            this.txtQ3_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_1_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(7, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 15);
            this.label3.TabIndex = 43;
            this.label3.Text = "Q3_1";
            // 
            // txtQ1_4
            // 
            this.txtQ1_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtQ1_4.Location = new System.Drawing.Point(51, 68);
            this.txtQ1_4.Name = "txtQ1_4";
            this.txtQ1_4.Size = new System.Drawing.Size(617, 22);
            this.txtQ1_4.TabIndex = 28;
            this.txtQ1_4.TextChanged += new System.EventHandler(this.txtQ1_4_TextChanged);
            this.txtQ1_4.Enter += new System.EventHandler(this.txtQ1_4_Enter);
            this.txtQ1_4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_4_KeyPress);
            // 
            // lblQ1_4
            // 
            this.lblQ1_4.AutoSize = true;
            this.lblQ1_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ1_4.ForeColor = System.Drawing.Color.White;
            this.lblQ1_4.Location = new System.Drawing.Point(11, 69);
            this.lblQ1_4.Name = "lblQ1_4";
            this.lblQ1_4.Size = new System.Drawing.Size(41, 15);
            this.lblQ1_4.TabIndex = 27;
            this.lblQ1_4.Text = "Q1_4";
            // 
            // grpbxQ1_2B
            // 
            this.grpbxQ1_2B.Controls.Add(this.txtQ1_2B_yy);
            this.grpbxQ1_2B.Controls.Add(this.txtQ1_2B_dd);
            this.grpbxQ1_2B.Controls.Add(this.txtQ1_2B_mm);
            this.grpbxQ1_2B.Enabled = false;
            this.grpbxQ1_2B.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbxQ1_2B.ForeColor = System.Drawing.Color.White;
            this.grpbxQ1_2B.Location = new System.Drawing.Point(518, 7);
            this.grpbxQ1_2B.Name = "grpbxQ1_2B";
            this.grpbxQ1_2B.Size = new System.Drawing.Size(146, 47);
            this.grpbxQ1_2B.TabIndex = 15;
            this.grpbxQ1_2B.TabStop = false;
            this.grpbxQ1_2B.Text = "Q1_2B";
            // 
            // txtQ1_2B_yy
            // 
            this.txtQ1_2B_yy.Location = new System.Drawing.Point(89, 18);
            this.txtQ1_2B_yy.MaxLength = 4;
            this.txtQ1_2B_yy.Name = "txtQ1_2B_yy";
            this.txtQ1_2B_yy.Size = new System.Drawing.Size(50, 22);
            this.txtQ1_2B_yy.TabIndex = 18;
            this.txtQ1_2B_yy.TextChanged += new System.EventHandler(this.txtQ1_2B_yy_TextChanged);
            this.txtQ1_2B_yy.Enter += new System.EventHandler(this.txtQ1_2B_yy_Enter);
            this.txtQ1_2B_yy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_2B_yy_KeyPress);
            this.txtQ1_2B_yy.Leave += new System.EventHandler(this.txtQ1_2B_yy_Leave);
            // 
            // txtQ1_2B_dd
            // 
            this.txtQ1_2B_dd.Location = new System.Drawing.Point(48, 18);
            this.txtQ1_2B_dd.MaxLength = 2;
            this.txtQ1_2B_dd.Name = "txtQ1_2B_dd";
            this.txtQ1_2B_dd.Size = new System.Drawing.Size(34, 22);
            this.txtQ1_2B_dd.TabIndex = 17;
            this.txtQ1_2B_dd.TextChanged += new System.EventHandler(this.txtQ1_2B_dd_TextChanged);
            this.txtQ1_2B_dd.Enter += new System.EventHandler(this.txtQ1_2B_dd_Enter);
            this.txtQ1_2B_dd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_2B_dd_KeyPress);
            this.txtQ1_2B_dd.Leave += new System.EventHandler(this.txtQ1_2B_dd_Leave);
            // 
            // txtQ1_2B_mm
            // 
            this.txtQ1_2B_mm.Location = new System.Drawing.Point(8, 18);
            this.txtQ1_2B_mm.MaxLength = 2;
            this.txtQ1_2B_mm.Name = "txtQ1_2B_mm";
            this.txtQ1_2B_mm.Size = new System.Drawing.Size(34, 22);
            this.txtQ1_2B_mm.TabIndex = 16;
            this.txtQ1_2B_mm.TextChanged += new System.EventHandler(this.txtQ1_2B_mm_TextChanged);
            this.txtQ1_2B_mm.Enter += new System.EventHandler(this.txtQ1_2B_mm_Enter);
            this.txtQ1_2B_mm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_2B_mm_KeyPress);
            this.txtQ1_2B_mm.Leave += new System.EventHandler(this.txtQ1_2B_mm_Leave);
            // 
            // grpbxQ1_2A
            // 
            this.grpbxQ1_2A.Controls.Add(this.txtQ1_2A_yy);
            this.grpbxQ1_2A.Controls.Add(this.txtQ1_2A_dd);
            this.grpbxQ1_2A.Controls.Add(this.txtQ1_2A_mm);
            this.grpbxQ1_2A.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbxQ1_2A.ForeColor = System.Drawing.Color.White;
            this.grpbxQ1_2A.Location = new System.Drawing.Point(354, 7);
            this.grpbxQ1_2A.Name = "grpbxQ1_2A";
            this.grpbxQ1_2A.Size = new System.Drawing.Size(146, 47);
            this.grpbxQ1_2A.TabIndex = 11;
            this.grpbxQ1_2A.TabStop = false;
            this.grpbxQ1_2A.Text = "Q1_2A";
            // 
            // txtQ1_2A_yy
            // 
            this.txtQ1_2A_yy.Location = new System.Drawing.Point(89, 18);
            this.txtQ1_2A_yy.MaxLength = 4;
            this.txtQ1_2A_yy.Name = "txtQ1_2A_yy";
            this.txtQ1_2A_yy.Size = new System.Drawing.Size(50, 22);
            this.txtQ1_2A_yy.TabIndex = 14;
            this.txtQ1_2A_yy.TextChanged += new System.EventHandler(this.txtQ1_2A_yy_TextChanged);
            this.txtQ1_2A_yy.Enter += new System.EventHandler(this.txtQ1_2A_yy_Enter);
            this.txtQ1_2A_yy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_2A_yy_KeyPress);
            this.txtQ1_2A_yy.Leave += new System.EventHandler(this.txtQ1_2A_yy_Leave);
            // 
            // txtQ1_2A_dd
            // 
            this.txtQ1_2A_dd.Location = new System.Drawing.Point(48, 18);
            this.txtQ1_2A_dd.MaxLength = 2;
            this.txtQ1_2A_dd.Name = "txtQ1_2A_dd";
            this.txtQ1_2A_dd.Size = new System.Drawing.Size(34, 22);
            this.txtQ1_2A_dd.TabIndex = 13;
            this.txtQ1_2A_dd.TextChanged += new System.EventHandler(this.txtQ1_2A_dd_TextChanged);
            this.txtQ1_2A_dd.Enter += new System.EventHandler(this.txtQ1_2A_dd_Enter);
            this.txtQ1_2A_dd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_2A_dd_KeyPress);
            this.txtQ1_2A_dd.Leave += new System.EventHandler(this.txtQ1_2A_dd_Leave);
            // 
            // txtQ1_2A_mm
            // 
            this.txtQ1_2A_mm.Location = new System.Drawing.Point(8, 18);
            this.txtQ1_2A_mm.MaxLength = 2;
            this.txtQ1_2A_mm.Name = "txtQ1_2A_mm";
            this.txtQ1_2A_mm.Size = new System.Drawing.Size(34, 22);
            this.txtQ1_2A_mm.TabIndex = 12;
            this.txtQ1_2A_mm.TextChanged += new System.EventHandler(this.txtQ1_2A_mm_TextChanged);
            this.txtQ1_2A_mm.Enter += new System.EventHandler(this.txtQ1_2A_mm_Enter);
            this.txtQ1_2A_mm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_2A_mm_KeyPress);
            this.txtQ1_2A_mm.Leave += new System.EventHandler(this.txtQ1_2A_mm_Leave);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.txtSign_yy);
            this.groupBox9.Controls.Add(this.txtSign_dd);
            this.groupBox9.Controls.Add(this.txtSign_mm);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.ForeColor = System.Drawing.Color.White;
            this.groupBox9.Location = new System.Drawing.Point(110, 178);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(146, 47);
            this.groupBox9.TabIndex = 60;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Signature Date";
            // 
            // txtSign_yy
            // 
            this.txtSign_yy.Location = new System.Drawing.Point(89, 19);
            this.txtSign_yy.MaxLength = 4;
            this.txtSign_yy.Name = "txtSign_yy";
            this.txtSign_yy.Size = new System.Drawing.Size(50, 22);
            this.txtSign_yy.TabIndex = 63;
            this.txtSign_yy.TextChanged += new System.EventHandler(this.txtSign_yy_TextChanged);
            this.txtSign_yy.Enter += new System.EventHandler(this.txtSign_yy_Enter);
            this.txtSign_yy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSign_yy_KeyPress);
            this.txtSign_yy.Leave += new System.EventHandler(this.txtSign_yy_Leave);
            // 
            // txtSign_dd
            // 
            this.txtSign_dd.Location = new System.Drawing.Point(48, 19);
            this.txtSign_dd.MaxLength = 2;
            this.txtSign_dd.Name = "txtSign_dd";
            this.txtSign_dd.Size = new System.Drawing.Size(34, 22);
            this.txtSign_dd.TabIndex = 62;
            this.txtSign_dd.TextChanged += new System.EventHandler(this.txtSign_dd_TextChanged);
            this.txtSign_dd.Enter += new System.EventHandler(this.txtSign_dd_Enter);
            this.txtSign_dd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSign_dd_KeyPress);
            this.txtSign_dd.Leave += new System.EventHandler(this.txtSign_dd_Leave);
            // 
            // txtSign_mm
            // 
            this.txtSign_mm.Location = new System.Drawing.Point(8, 19);
            this.txtSign_mm.MaxLength = 2;
            this.txtSign_mm.Name = "txtSign_mm";
            this.txtSign_mm.Size = new System.Drawing.Size(34, 22);
            this.txtSign_mm.TabIndex = 61;
            this.txtSign_mm.TextChanged += new System.EventHandler(this.txtSign_mm_TextChanged);
            this.txtSign_mm.Enter += new System.EventHandler(this.txtSign_mm_Enter);
            this.txtSign_mm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSign_mm_KeyPress);
            this.txtSign_mm.Leave += new System.EventHandler(this.txtSign_mm_Leave);
            // 
            // grpbxQ3_4
            // 
            this.grpbxQ3_4.Controls.Add(this.txtQ3_4_yy);
            this.grpbxQ3_4.Controls.Add(this.txtQ3_4_dd);
            this.grpbxQ3_4.Controls.Add(this.txtQ3_4_mm);
            this.grpbxQ3_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbxQ3_4.ForeColor = System.Drawing.Color.White;
            this.grpbxQ3_4.Location = new System.Drawing.Point(854, 143);
            this.grpbxQ3_4.Name = "grpbxQ3_4";
            this.grpbxQ3_4.Size = new System.Drawing.Size(146, 47);
            this.grpbxQ3_4.TabIndex = 55;
            this.grpbxQ3_4.TabStop = false;
            this.grpbxQ3_4.Text = "Q3_4";
            // 
            // txtQ3_4_yy
            // 
            this.txtQ3_4_yy.Location = new System.Drawing.Point(89, 17);
            this.txtQ3_4_yy.MaxLength = 4;
            this.txtQ3_4_yy.Name = "txtQ3_4_yy";
            this.txtQ3_4_yy.Size = new System.Drawing.Size(50, 22);
            this.txtQ3_4_yy.TabIndex = 58;
            this.txtQ3_4_yy.TextChanged += new System.EventHandler(this.txtQ3_4_yy_TextChanged);
            this.txtQ3_4_yy.Enter += new System.EventHandler(this.txtQ3_4_yy_Enter);
            this.txtQ3_4_yy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_4_yy_KeyPress);
            this.txtQ3_4_yy.Leave += new System.EventHandler(this.txtQ3_4_yy_Leave);
            // 
            // txtQ3_4_dd
            // 
            this.txtQ3_4_dd.Location = new System.Drawing.Point(48, 17);
            this.txtQ3_4_dd.MaxLength = 2;
            this.txtQ3_4_dd.Name = "txtQ3_4_dd";
            this.txtQ3_4_dd.Size = new System.Drawing.Size(34, 22);
            this.txtQ3_4_dd.TabIndex = 57;
            this.txtQ3_4_dd.TextChanged += new System.EventHandler(this.txtQ3_4_dd_TextChanged);
            this.txtQ3_4_dd.Enter += new System.EventHandler(this.txtQ3_4_dd_Enter);
            this.txtQ3_4_dd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_4_dd_KeyPress);
            this.txtQ3_4_dd.Leave += new System.EventHandler(this.txtQ3_4_dd_Leave);
            // 
            // txtQ3_4_mm
            // 
            this.txtQ3_4_mm.Location = new System.Drawing.Point(8, 17);
            this.txtQ3_4_mm.MaxLength = 2;
            this.txtQ3_4_mm.Name = "txtQ3_4_mm";
            this.txtQ3_4_mm.Size = new System.Drawing.Size(34, 22);
            this.txtQ3_4_mm.TabIndex = 56;
            this.txtQ3_4_mm.TextChanged += new System.EventHandler(this.txtQ3_4_mm_TextChanged);
            this.txtQ3_4_mm.Enter += new System.EventHandler(this.txtQ3_4_mm_Enter);
            this.txtQ3_4_mm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_4_mm_KeyPress);
            this.txtQ3_4_mm.Leave += new System.EventHandler(this.txtQ3_4_mm_Leave);
            // 
            // grpbxQ3_3B
            // 
            this.grpbxQ3_3B.Controls.Add(this.txtQ3_3B_yy);
            this.grpbxQ3_3B.Controls.Add(this.txtQ3_3B_dd);
            this.grpbxQ3_3B.Controls.Add(this.txtQ3_3B_mm);
            this.grpbxQ3_3B.Enabled = false;
            this.grpbxQ3_3B.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbxQ3_3B.ForeColor = System.Drawing.Color.White;
            this.grpbxQ3_3B.Location = new System.Drawing.Point(696, 143);
            this.grpbxQ3_3B.Name = "grpbxQ3_3B";
            this.grpbxQ3_3B.Size = new System.Drawing.Size(146, 47);
            this.grpbxQ3_3B.TabIndex = 51;
            this.grpbxQ3_3B.TabStop = false;
            this.grpbxQ3_3B.Text = "Q3_3B";
            // 
            // txtQ3_3B_yy
            // 
            this.txtQ3_3B_yy.Location = new System.Drawing.Point(89, 17);
            this.txtQ3_3B_yy.MaxLength = 4;
            this.txtQ3_3B_yy.Name = "txtQ3_3B_yy";
            this.txtQ3_3B_yy.Size = new System.Drawing.Size(50, 22);
            this.txtQ3_3B_yy.TabIndex = 54;
            this.txtQ3_3B_yy.TextChanged += new System.EventHandler(this.txtQ3_3B_yy_TextChanged);
            this.txtQ3_3B_yy.Enter += new System.EventHandler(this.txtQ3_3B_yy_Enter);
            this.txtQ3_3B_yy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_3B_yy_KeyPress);
            this.txtQ3_3B_yy.Leave += new System.EventHandler(this.txtQ3_3B_yy_Leave);
            // 
            // txtQ3_3B_dd
            // 
            this.txtQ3_3B_dd.Location = new System.Drawing.Point(48, 17);
            this.txtQ3_3B_dd.MaxLength = 2;
            this.txtQ3_3B_dd.Name = "txtQ3_3B_dd";
            this.txtQ3_3B_dd.Size = new System.Drawing.Size(34, 22);
            this.txtQ3_3B_dd.TabIndex = 53;
            this.txtQ3_3B_dd.TextChanged += new System.EventHandler(this.txtQ3_3B_dd_TextChanged);
            this.txtQ3_3B_dd.Enter += new System.EventHandler(this.txtQ3_3B_dd_Enter);
            this.txtQ3_3B_dd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_3B_dd_KeyPress);
            this.txtQ3_3B_dd.Leave += new System.EventHandler(this.txtQ3_3B_dd_Leave);
            // 
            // txtQ3_3B_mm
            // 
            this.txtQ3_3B_mm.Location = new System.Drawing.Point(8, 17);
            this.txtQ3_3B_mm.MaxLength = 2;
            this.txtQ3_3B_mm.Name = "txtQ3_3B_mm";
            this.txtQ3_3B_mm.Size = new System.Drawing.Size(34, 22);
            this.txtQ3_3B_mm.TabIndex = 52;
            this.txtQ3_3B_mm.TextChanged += new System.EventHandler(this.txtQ3_3B_mm_TextChanged);
            this.txtQ3_3B_mm.Enter += new System.EventHandler(this.txtQ3_3B_mm_Enter);
            this.txtQ3_3B_mm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_3B_mm_KeyPress);
            this.txtQ3_3B_mm.Leave += new System.EventHandler(this.txtQ3_3B_mm_Leave);
            // 
            // grpbxQ2_3B
            // 
            this.grpbxQ2_3B.Controls.Add(this.txtQ2_3B_yy);
            this.grpbxQ2_3B.Controls.Add(this.txtQ2_3B_dd);
            this.grpbxQ2_3B.Controls.Add(this.txtQ2_3B_mm);
            this.grpbxQ2_3B.Enabled = false;
            this.grpbxQ2_3B.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbxQ2_3B.ForeColor = System.Drawing.Color.White;
            this.grpbxQ2_3B.Location = new System.Drawing.Point(854, 90);
            this.grpbxQ2_3B.Name = "grpbxQ2_3B";
            this.grpbxQ2_3B.Size = new System.Drawing.Size(146, 47);
            this.grpbxQ2_3B.TabIndex = 39;
            this.grpbxQ2_3B.TabStop = false;
            this.grpbxQ2_3B.Text = "Q2_3B";
            // 
            // txtQ2_3B_yy
            // 
            this.txtQ2_3B_yy.Location = new System.Drawing.Point(89, 17);
            this.txtQ2_3B_yy.MaxLength = 4;
            this.txtQ2_3B_yy.Name = "txtQ2_3B_yy";
            this.txtQ2_3B_yy.Size = new System.Drawing.Size(50, 22);
            this.txtQ2_3B_yy.TabIndex = 42;
            this.txtQ2_3B_yy.TextChanged += new System.EventHandler(this.txtQ2_3B_yy_TextChanged);
            this.txtQ2_3B_yy.Enter += new System.EventHandler(this.txtQ2_3B_yy_Enter);
            this.txtQ2_3B_yy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_3B_yy_KeyPress);
            this.txtQ2_3B_yy.Leave += new System.EventHandler(this.txtQ2_3B_yy_Leave);
            // 
            // txtQ2_3B_dd
            // 
            this.txtQ2_3B_dd.Location = new System.Drawing.Point(48, 17);
            this.txtQ2_3B_dd.MaxLength = 2;
            this.txtQ2_3B_dd.Name = "txtQ2_3B_dd";
            this.txtQ2_3B_dd.Size = new System.Drawing.Size(34, 22);
            this.txtQ2_3B_dd.TabIndex = 41;
            this.txtQ2_3B_dd.TextChanged += new System.EventHandler(this.txtQ2_3B_dd_TextChanged);
            this.txtQ2_3B_dd.Enter += new System.EventHandler(this.txtQ2_3B_dd_Enter);
            this.txtQ2_3B_dd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_3B_dd_KeyPress);
            this.txtQ2_3B_dd.Leave += new System.EventHandler(this.txtQ2_3B_dd_Leave);
            // 
            // txtQ2_3B_mm
            // 
            this.txtQ2_3B_mm.Location = new System.Drawing.Point(8, 17);
            this.txtQ2_3B_mm.MaxLength = 2;
            this.txtQ2_3B_mm.Name = "txtQ2_3B_mm";
            this.txtQ2_3B_mm.Size = new System.Drawing.Size(34, 22);
            this.txtQ2_3B_mm.TabIndex = 40;
            this.txtQ2_3B_mm.TextChanged += new System.EventHandler(this.txtQ2_3B_mm_TextChanged);
            this.txtQ2_3B_mm.Enter += new System.EventHandler(this.txtQ2_3B_mm_Enter);
            this.txtQ2_3B_mm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_3B_mm_KeyPress);
            this.txtQ2_3B_mm.Leave += new System.EventHandler(this.txtQ2_3B_mm_Leave);
            // 
            // grpbxQ3_3A
            // 
            this.grpbxQ3_3A.Controls.Add(this.txtQ3_3A_yy);
            this.grpbxQ3_3A.Controls.Add(this.txtQ3_3A_dd);
            this.grpbxQ3_3A.Controls.Add(this.txtQ3_3A_mm);
            this.grpbxQ3_3A.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbxQ3_3A.ForeColor = System.Drawing.Color.White;
            this.grpbxQ3_3A.Location = new System.Drawing.Point(526, 137);
            this.grpbxQ3_3A.Name = "grpbxQ3_3A";
            this.grpbxQ3_3A.Size = new System.Drawing.Size(146, 47);
            this.grpbxQ3_3A.TabIndex = 47;
            this.grpbxQ3_3A.TabStop = false;
            this.grpbxQ3_3A.Text = "Q3_3A";
            // 
            // txtQ3_3A_yy
            // 
            this.txtQ3_3A_yy.Location = new System.Drawing.Point(89, 17);
            this.txtQ3_3A_yy.MaxLength = 4;
            this.txtQ3_3A_yy.Name = "txtQ3_3A_yy";
            this.txtQ3_3A_yy.Size = new System.Drawing.Size(50, 22);
            this.txtQ3_3A_yy.TabIndex = 50;
            this.txtQ3_3A_yy.TextChanged += new System.EventHandler(this.txtQ3_3A_yy_TextChanged);
            this.txtQ3_3A_yy.Enter += new System.EventHandler(this.txtQ3_3A_yy_Enter);
            this.txtQ3_3A_yy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_3A_yy_KeyPress);
            this.txtQ3_3A_yy.Leave += new System.EventHandler(this.txtQ3_3A_yy_Leave);
            // 
            // txtQ3_3A_dd
            // 
            this.txtQ3_3A_dd.Location = new System.Drawing.Point(48, 17);
            this.txtQ3_3A_dd.MaxLength = 2;
            this.txtQ3_3A_dd.Name = "txtQ3_3A_dd";
            this.txtQ3_3A_dd.Size = new System.Drawing.Size(34, 22);
            this.txtQ3_3A_dd.TabIndex = 49;
            this.txtQ3_3A_dd.TextChanged += new System.EventHandler(this.txtQ3_3A_dd_TextChanged);
            this.txtQ3_3A_dd.Enter += new System.EventHandler(this.txtQ3_3A_dd_Enter);
            this.txtQ3_3A_dd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_3A_dd_KeyPress);
            this.txtQ3_3A_dd.Leave += new System.EventHandler(this.txtQ3_3A_dd_Leave);
            // 
            // txtQ3_3A_mm
            // 
            this.txtQ3_3A_mm.Location = new System.Drawing.Point(8, 17);
            this.txtQ3_3A_mm.MaxLength = 2;
            this.txtQ3_3A_mm.Name = "txtQ3_3A_mm";
            this.txtQ3_3A_mm.Size = new System.Drawing.Size(34, 22);
            this.txtQ3_3A_mm.TabIndex = 48;
            this.txtQ3_3A_mm.TextChanged += new System.EventHandler(this.txtQ3_3A_mm_TextChanged);
            this.txtQ3_3A_mm.Enter += new System.EventHandler(this.txtQ3_3A_mm_Enter);
            this.txtQ3_3A_mm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ3_3A_mm_KeyPress);
            this.txtQ3_3A_mm.Leave += new System.EventHandler(this.txtQ3_3A_mm_Leave);
            // 
            // grpbxQ2_3A
            // 
            this.grpbxQ2_3A.Controls.Add(this.txtQ2_3A_yy);
            this.grpbxQ2_3A.Controls.Add(this.txtQ2_3A_dd);
            this.grpbxQ2_3A.Controls.Add(this.txtQ2_3A_mm);
            this.grpbxQ2_3A.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbxQ2_3A.ForeColor = System.Drawing.Color.White;
            this.grpbxQ2_3A.Location = new System.Drawing.Point(696, 90);
            this.grpbxQ2_3A.Name = "grpbxQ2_3A";
            this.grpbxQ2_3A.Size = new System.Drawing.Size(146, 47);
            this.grpbxQ2_3A.TabIndex = 35;
            this.grpbxQ2_3A.TabStop = false;
            this.grpbxQ2_3A.Text = "Q2_3A";
            // 
            // txtQ2_3A_yy
            // 
            this.txtQ2_3A_yy.Location = new System.Drawing.Point(89, 17);
            this.txtQ2_3A_yy.MaxLength = 4;
            this.txtQ2_3A_yy.Name = "txtQ2_3A_yy";
            this.txtQ2_3A_yy.Size = new System.Drawing.Size(50, 22);
            this.txtQ2_3A_yy.TabIndex = 38;
            this.txtQ2_3A_yy.TextChanged += new System.EventHandler(this.txtQ2_3A_yy_TextChanged);
            this.txtQ2_3A_yy.Enter += new System.EventHandler(this.txtQ2_3A_yy_Enter);
            this.txtQ2_3A_yy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_3A_yy_KeyPress);
            this.txtQ2_3A_yy.Leave += new System.EventHandler(this.txtQ2_3A_yy_Leave);
            // 
            // txtQ2_3A_dd
            // 
            this.txtQ2_3A_dd.Location = new System.Drawing.Point(48, 17);
            this.txtQ2_3A_dd.MaxLength = 2;
            this.txtQ2_3A_dd.Name = "txtQ2_3A_dd";
            this.txtQ2_3A_dd.Size = new System.Drawing.Size(34, 22);
            this.txtQ2_3A_dd.TabIndex = 37;
            this.txtQ2_3A_dd.TextChanged += new System.EventHandler(this.txtQ2_3A_dd_TextChanged);
            this.txtQ2_3A_dd.Enter += new System.EventHandler(this.txtQ2_3A_dd_Enter);
            this.txtQ2_3A_dd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_3A_dd_KeyPress);
            this.txtQ2_3A_dd.Leave += new System.EventHandler(this.txtQ2_3A_dd_Leave);
            // 
            // txtQ2_3A_mm
            // 
            this.txtQ2_3A_mm.Location = new System.Drawing.Point(8, 17);
            this.txtQ2_3A_mm.MaxLength = 2;
            this.txtQ2_3A_mm.Name = "txtQ2_3A_mm";
            this.txtQ2_3A_mm.Size = new System.Drawing.Size(34, 22);
            this.txtQ2_3A_mm.TabIndex = 36;
            this.txtQ2_3A_mm.TextChanged += new System.EventHandler(this.txtQ2_3A_mm_TextChanged);
            this.txtQ2_3A_mm.Enter += new System.EventHandler(this.txtQ2_3A_mm_Enter);
            this.txtQ2_3A_mm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ2_3A_mm_KeyPress);
            this.txtQ2_3A_mm.Leave += new System.EventHandler(this.txtQ2_3A_mm_Leave);
            // 
            // grpbxQ1_3B
            // 
            this.grpbxQ1_3B.Controls.Add(this.txtQ1_3B_yy);
            this.grpbxQ1_3B.Controls.Add(this.txtQ1_3B_dd);
            this.grpbxQ1_3B.Controls.Add(this.txtQ1_3B_mm);
            this.grpbxQ1_3B.Enabled = false;
            this.grpbxQ1_3B.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbxQ1_3B.ForeColor = System.Drawing.Color.White;
            this.grpbxQ1_3B.Location = new System.Drawing.Point(854, 7);
            this.grpbxQ1_3B.Name = "grpbxQ1_3B";
            this.grpbxQ1_3B.Size = new System.Drawing.Size(146, 47);
            this.grpbxQ1_3B.TabIndex = 23;
            this.grpbxQ1_3B.TabStop = false;
            this.grpbxQ1_3B.Text = "Q1_3B";
            // 
            // txtQ1_3B_yy
            // 
            this.txtQ1_3B_yy.Location = new System.Drawing.Point(89, 18);
            this.txtQ1_3B_yy.MaxLength = 4;
            this.txtQ1_3B_yy.Name = "txtQ1_3B_yy";
            this.txtQ1_3B_yy.Size = new System.Drawing.Size(50, 22);
            this.txtQ1_3B_yy.TabIndex = 26;
            this.txtQ1_3B_yy.TextChanged += new System.EventHandler(this.txtQ1_3B_yy_TextChanged);
            this.txtQ1_3B_yy.Enter += new System.EventHandler(this.txtQ1_3B_yy_Enter);
            this.txtQ1_3B_yy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_3B_yy_KeyPress);
            this.txtQ1_3B_yy.Leave += new System.EventHandler(this.txtQ1_3B_yy_Leave);
            // 
            // txtQ1_3B_dd
            // 
            this.txtQ1_3B_dd.Location = new System.Drawing.Point(48, 18);
            this.txtQ1_3B_dd.MaxLength = 2;
            this.txtQ1_3B_dd.Name = "txtQ1_3B_dd";
            this.txtQ1_3B_dd.Size = new System.Drawing.Size(34, 22);
            this.txtQ1_3B_dd.TabIndex = 25;
            this.txtQ1_3B_dd.TextChanged += new System.EventHandler(this.txtQ1_3B_dd_TextChanged);
            this.txtQ1_3B_dd.Enter += new System.EventHandler(this.txtQ1_3B_dd_Enter);
            this.txtQ1_3B_dd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_3B_dd_KeyPress);
            this.txtQ1_3B_dd.Leave += new System.EventHandler(this.txtQ1_3B_dd_Leave);
            // 
            // txtQ1_3B_mm
            // 
            this.txtQ1_3B_mm.Location = new System.Drawing.Point(8, 18);
            this.txtQ1_3B_mm.MaxLength = 2;
            this.txtQ1_3B_mm.Name = "txtQ1_3B_mm";
            this.txtQ1_3B_mm.Size = new System.Drawing.Size(34, 22);
            this.txtQ1_3B_mm.TabIndex = 24;
            this.txtQ1_3B_mm.TextChanged += new System.EventHandler(this.txtQ1_3B_mm_TextChanged);
            this.txtQ1_3B_mm.Enter += new System.EventHandler(this.txtQ1_3B_mm_Enter);
            this.txtQ1_3B_mm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_3B_mm_KeyPress);
            this.txtQ1_3B_mm.Leave += new System.EventHandler(this.txtQ1_3B_mm_Leave);
            // 
            // grpbxQ1_1B
            // 
            this.grpbxQ1_1B.Controls.Add(this.txtQ1_1B_yy);
            this.grpbxQ1_1B.Controls.Add(this.txtQ1_1B_dd);
            this.grpbxQ1_1B.Controls.Add(this.txtQ1_1B_mm);
            this.grpbxQ1_1B.Enabled = false;
            this.grpbxQ1_1B.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbxQ1_1B.ForeColor = System.Drawing.Color.White;
            this.grpbxQ1_1B.Location = new System.Drawing.Point(169, 7);
            this.grpbxQ1_1B.Name = "grpbxQ1_1B";
            this.grpbxQ1_1B.Size = new System.Drawing.Size(146, 47);
            this.grpbxQ1_1B.TabIndex = 7;
            this.grpbxQ1_1B.TabStop = false;
            this.grpbxQ1_1B.Text = "Q1_1B";
            // 
            // txtQ1_1B_yy
            // 
            this.txtQ1_1B_yy.Location = new System.Drawing.Point(89, 18);
            this.txtQ1_1B_yy.MaxLength = 4;
            this.txtQ1_1B_yy.Name = "txtQ1_1B_yy";
            this.txtQ1_1B_yy.Size = new System.Drawing.Size(50, 22);
            this.txtQ1_1B_yy.TabIndex = 10;
            this.txtQ1_1B_yy.TextChanged += new System.EventHandler(this.txtQ1_1B_yy_TextChanged);
            this.txtQ1_1B_yy.Enter += new System.EventHandler(this.txtQ1_1B_yy_Enter);
            this.txtQ1_1B_yy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_1B_yy_KeyPress);
            this.txtQ1_1B_yy.Leave += new System.EventHandler(this.txtQ1_1B_yy_Leave);
            // 
            // txtQ1_1B_dd
            // 
            this.txtQ1_1B_dd.Location = new System.Drawing.Point(48, 18);
            this.txtQ1_1B_dd.MaxLength = 2;
            this.txtQ1_1B_dd.Name = "txtQ1_1B_dd";
            this.txtQ1_1B_dd.Size = new System.Drawing.Size(34, 22);
            this.txtQ1_1B_dd.TabIndex = 9;
            this.txtQ1_1B_dd.TextChanged += new System.EventHandler(this.txtQ1_1B_dd_TextChanged);
            this.txtQ1_1B_dd.Enter += new System.EventHandler(this.txtQ1_1B_dd_Enter);
            this.txtQ1_1B_dd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_1B_dd_KeyPress);
            this.txtQ1_1B_dd.Leave += new System.EventHandler(this.txtQ1_1B_dd_Leave);
            // 
            // txtQ1_1B_mm
            // 
            this.txtQ1_1B_mm.Location = new System.Drawing.Point(8, 18);
            this.txtQ1_1B_mm.MaxLength = 2;
            this.txtQ1_1B_mm.Name = "txtQ1_1B_mm";
            this.txtQ1_1B_mm.Size = new System.Drawing.Size(34, 22);
            this.txtQ1_1B_mm.TabIndex = 8;
            this.txtQ1_1B_mm.TextChanged += new System.EventHandler(this.txtQ1_1B_mm_TextChanged);
            this.txtQ1_1B_mm.Enter += new System.EventHandler(this.txtQ1_1B_mm_Enter);
            this.txtQ1_1B_mm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_1B_mm_KeyPress);
            this.txtQ1_1B_mm.Leave += new System.EventHandler(this.txtQ1_1B_mm_Leave);
            // 
            // grpbxQ1_3A
            // 
            this.grpbxQ1_3A.Controls.Add(this.txtQ1_3A_yy);
            this.grpbxQ1_3A.Controls.Add(this.txtQ1_3A_dd);
            this.grpbxQ1_3A.Controls.Add(this.txtQ1_3A_mm);
            this.grpbxQ1_3A.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbxQ1_3A.ForeColor = System.Drawing.Color.White;
            this.grpbxQ1_3A.Location = new System.Drawing.Point(696, 7);
            this.grpbxQ1_3A.Name = "grpbxQ1_3A";
            this.grpbxQ1_3A.Size = new System.Drawing.Size(146, 47);
            this.grpbxQ1_3A.TabIndex = 19;
            this.grpbxQ1_3A.TabStop = false;
            this.grpbxQ1_3A.Text = "Q1_3A";
            // 
            // txtQ1_3A_yy
            // 
            this.txtQ1_3A_yy.Location = new System.Drawing.Point(89, 18);
            this.txtQ1_3A_yy.MaxLength = 4;
            this.txtQ1_3A_yy.Name = "txtQ1_3A_yy";
            this.txtQ1_3A_yy.Size = new System.Drawing.Size(50, 22);
            this.txtQ1_3A_yy.TabIndex = 22;
            this.txtQ1_3A_yy.TextChanged += new System.EventHandler(this.txtQ1_3A_yy_TextChanged);
            this.txtQ1_3A_yy.Enter += new System.EventHandler(this.txtQ1_3A_yy_Enter);
            this.txtQ1_3A_yy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_3A_yy_KeyPress);
            this.txtQ1_3A_yy.Leave += new System.EventHandler(this.txtQ1_3A_yy_Leave);
            // 
            // txtQ1_3A_dd
            // 
            this.txtQ1_3A_dd.Location = new System.Drawing.Point(48, 18);
            this.txtQ1_3A_dd.MaxLength = 2;
            this.txtQ1_3A_dd.Name = "txtQ1_3A_dd";
            this.txtQ1_3A_dd.Size = new System.Drawing.Size(34, 22);
            this.txtQ1_3A_dd.TabIndex = 21;
            this.txtQ1_3A_dd.TextChanged += new System.EventHandler(this.txtQ1_3A_dd_TextChanged);
            this.txtQ1_3A_dd.Enter += new System.EventHandler(this.txtQ1_3A_dd_Enter);
            this.txtQ1_3A_dd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_3A_dd_KeyPress);
            this.txtQ1_3A_dd.Leave += new System.EventHandler(this.txtQ1_3A_dd_Leave);
            // 
            // txtQ1_3A_mm
            // 
            this.txtQ1_3A_mm.Location = new System.Drawing.Point(8, 18);
            this.txtQ1_3A_mm.MaxLength = 2;
            this.txtQ1_3A_mm.Name = "txtQ1_3A_mm";
            this.txtQ1_3A_mm.Size = new System.Drawing.Size(34, 22);
            this.txtQ1_3A_mm.TabIndex = 20;
            this.txtQ1_3A_mm.TextChanged += new System.EventHandler(this.txtQ1_3A_mm_TextChanged);
            this.txtQ1_3A_mm.Enter += new System.EventHandler(this.txtQ1_3A_mm_Enter);
            this.txtQ1_3A_mm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_3A_mm_KeyPress);
            this.txtQ1_3A_mm.Leave += new System.EventHandler(this.txtQ1_3A_mm_Leave);
            // 
            // grobxQ1_1A
            // 
            this.grobxQ1_1A.Controls.Add(this.txtQ1_1A_yy);
            this.grobxQ1_1A.Controls.Add(this.txtQ1_1A_dd);
            this.grobxQ1_1A.Controls.Add(this.txtQ1_1A_mm);
            this.grobxQ1_1A.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grobxQ1_1A.ForeColor = System.Drawing.Color.White;
            this.grobxQ1_1A.Location = new System.Drawing.Point(11, 7);
            this.grobxQ1_1A.Name = "grobxQ1_1A";
            this.grobxQ1_1A.Size = new System.Drawing.Size(146, 47);
            this.grobxQ1_1A.TabIndex = 3;
            this.grobxQ1_1A.TabStop = false;
            this.grobxQ1_1A.Text = "Q1_1A";
            // 
            // txtQ1_1A_yy
            // 
            this.txtQ1_1A_yy.Location = new System.Drawing.Point(87, 18);
            this.txtQ1_1A_yy.MaxLength = 4;
            this.txtQ1_1A_yy.Name = "txtQ1_1A_yy";
            this.txtQ1_1A_yy.Size = new System.Drawing.Size(50, 22);
            this.txtQ1_1A_yy.TabIndex = 6;
            this.txtQ1_1A_yy.TextChanged += new System.EventHandler(this.txtQ1_1A_yy_TextChanged);
            this.txtQ1_1A_yy.Enter += new System.EventHandler(this.txtQ1_1A_yy_Enter);
            this.txtQ1_1A_yy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_1A_yy_KeyPress);
            this.txtQ1_1A_yy.Leave += new System.EventHandler(this.txtQ1_1A_yy_Leave);
            // 
            // txtQ1_1A_dd
            // 
            this.txtQ1_1A_dd.Location = new System.Drawing.Point(46, 18);
            this.txtQ1_1A_dd.MaxLength = 2;
            this.txtQ1_1A_dd.Name = "txtQ1_1A_dd";
            this.txtQ1_1A_dd.Size = new System.Drawing.Size(34, 22);
            this.txtQ1_1A_dd.TabIndex = 5;
            this.txtQ1_1A_dd.TextChanged += new System.EventHandler(this.txtQ1_1A_dd_TextChanged);
            this.txtQ1_1A_dd.Enter += new System.EventHandler(this.txtQ1_1A_dd_Enter);
            this.txtQ1_1A_dd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_1A_dd_KeyPress);
            this.txtQ1_1A_dd.Leave += new System.EventHandler(this.txtQ1_1A_dd_Leave);
            // 
            // txtQ1_1A_mm
            // 
            this.txtQ1_1A_mm.Location = new System.Drawing.Point(6, 18);
            this.txtQ1_1A_mm.MaxLength = 2;
            this.txtQ1_1A_mm.Name = "txtQ1_1A_mm";
            this.txtQ1_1A_mm.Size = new System.Drawing.Size(34, 22);
            this.txtQ1_1A_mm.TabIndex = 4;
            this.txtQ1_1A_mm.TextChanged += new System.EventHandler(this.txtQ1_1A_mm_TextChanged);
            this.txtQ1_1A_mm.Enter += new System.EventHandler(this.txtQ1_1A_mm_Enter);
            this.txtQ1_1A_mm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQ1_1A_mm_KeyPress);
            this.txtQ1_1A_mm.Leave += new System.EventHandler(this.txtQ1_1A_mm_Leave);
            // 
            // IGImageViewer
            // 
            this.IGImageViewer.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.IGImageViewer.BackColor = System.Drawing.Color.Azure;
            this.IGImageViewer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.IGImageViewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IGImageViewer.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IGImageViewer.ImageData = null;
            this.IGImageViewer.ImageName = null;
            this.IGImageViewer.ImageScropping = false;
            this.IGImageViewer.ImageSize = new System.Drawing.Size(1360, 768);
            this.IGImageViewer.Location = new System.Drawing.Point(-1, -2);
            this.IGImageViewer.Name = "IGImageViewer";
            this.IGImageViewer.PictureBoxSize = new System.Drawing.Size(0, 0);
            this.IGImageViewer.Size = new System.Drawing.Size(1058, 417);
            this.IGImageViewer.StatusBarVisible = true;
            this.IGImageViewer.TabIndex = 2;
            // 
            // FrmKeying_HEDIS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Healthtel_MRD.Properties.Resources.FormBG;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1055, 742);
            this.Controls.Add(this.IGImageViewer);
            this.Controls.Add(this.grpMain);
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmKeying_HEDIS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Healthtel HEDIS: : Key";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmKeying_HEDIS_FormClosing_1);
            this.Load += new System.EventHandler(this.FrmKeying_HEDIS_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmKeying_HEDIS_KeyDown_1);
            this.grpMain.ResumeLayout(false);
            this.StatusStrip1.ResumeLayout(false);
            this.StatusStrip1.PerformLayout();
            this.grpKeyData.ResumeLayout(false);
            this.grpKeyData.PerformLayout();
            this.grpTxtBoxes1.ResumeLayout(false);
            this.grpTxtBoxes1.PerformLayout();
            this.grpbxQ1_2B.ResumeLayout(false);
            this.grpbxQ1_2B.PerformLayout();
            this.grpbxQ1_2A.ResumeLayout(false);
            this.grpbxQ1_2A.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.grpbxQ3_4.ResumeLayout(false);
            this.grpbxQ3_4.PerformLayout();
            this.grpbxQ3_3B.ResumeLayout(false);
            this.grpbxQ3_3B.PerformLayout();
            this.grpbxQ2_3B.ResumeLayout(false);
            this.grpbxQ2_3B.PerformLayout();
            this.grpbxQ3_3A.ResumeLayout(false);
            this.grpbxQ3_3A.PerformLayout();
            this.grpbxQ2_3A.ResumeLayout(false);
            this.grpbxQ2_3A.PerformLayout();
            this.grpbxQ1_3B.ResumeLayout(false);
            this.grpbxQ1_3B.PerformLayout();
            this.grpbxQ1_1B.ResumeLayout(false);
            this.grpbxQ1_1B.PerformLayout();
            this.grpbxQ1_3A.ResumeLayout(false);
            this.grpbxQ1_3A.PerformLayout();
            this.grobxQ1_1A.ResumeLayout(false);
            this.grobxQ1_1A.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpMain;
        private System.Windows.Forms.GroupBox grpTxtBoxes1;
        private System.Windows.Forms.GroupBox grpKeyData;
        private System.Windows.Forms.Label lblKey2Data;
        private System.Windows.Forms.TextBox txtKey2Data;
        private System.Windows.Forms.Label lblKey2User;
        private System.Windows.Forms.TextBox txtKey2User;
        private System.Windows.Forms.Label lblKey1Data;
        private System.Windows.Forms.TextBox txtKey1Data;
        private System.Windows.Forms.Label lblKey1User;
        private System.Windows.Forms.TextBox txtKey1User;
        private System.Windows.Forms.GroupBox grpButtons;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        internal System.Windows.Forms.StatusStrip StatusStrip1;
        internal System.Windows.Forms.ToolStripStatusLabel stsUser;
        internal System.Windows.Forms.ToolStripStatusLabel stsTotRecs;
        internal System.Windows.Forms.ToolStripStatusLabel stsFinRecs;
        internal System.Windows.Forms.ToolStripStatusLabel stsRemRecs;
        internal System.Windows.Forms.ToolStripStatusLabel stsDate;
        private InfognanaImageViewer.IGImageViewer IGImageViewer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtQ2_1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblQ1_5;
        private System.Windows.Forms.TextBox txtQ1_4;
        private System.Windows.Forms.Label lblQ1_4;
        private System.Windows.Forms.GroupBox grpbxQ1_2B;
        private System.Windows.Forms.GroupBox grpbxQ1_2A;
        private System.Windows.Forms.GroupBox grpbxQ2_3B;
        private System.Windows.Forms.GroupBox grpbxQ2_3A;
        private System.Windows.Forms.GroupBox grpbxQ1_3B;
        private System.Windows.Forms.GroupBox grpbxQ1_1B;
        private System.Windows.Forms.GroupBox grpbxQ1_3A;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtQ3_1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox grpbxQ3_3B;
        private System.Windows.Forms.GroupBox grpbxQ3_3A;
        private System.Windows.Forms.CheckBox chksignature;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox grobxQ1_1A;
        private System.Windows.Forms.TextBox txtBarcode;
        private System.Windows.Forms.Label lblBarcode;
        private System.Windows.Forms.TextBox txtQ1_5;
        private System.Windows.Forms.TextBox txtQ2_2;
        private System.Windows.Forms.TextBox txtQ3_2;
        private System.Windows.Forms.TextBox txtQ1_1A_yy;
        private System.Windows.Forms.TextBox txtQ1_1A_dd;
        private System.Windows.Forms.TextBox txtQ1_1A_mm;
        private System.Windows.Forms.TextBox txtQ1_2B_yy;
        private System.Windows.Forms.TextBox txtQ1_2B_dd;
        private System.Windows.Forms.TextBox txtQ1_2B_mm;
        private System.Windows.Forms.TextBox txtQ1_2A_yy;
        private System.Windows.Forms.TextBox txtQ1_2A_dd;
        private System.Windows.Forms.TextBox txtQ1_2A_mm;
        private System.Windows.Forms.TextBox txtQ1_3B_yy;
        private System.Windows.Forms.TextBox txtQ1_3B_dd;
        private System.Windows.Forms.TextBox txtQ1_3B_mm;
        private System.Windows.Forms.TextBox txtQ1_1B_yy;
        private System.Windows.Forms.TextBox txtQ1_1B_dd;
        private System.Windows.Forms.TextBox txtQ1_1B_mm;
        private System.Windows.Forms.TextBox txtQ1_3A_yy;
        private System.Windows.Forms.TextBox txtQ1_3A_dd;
        private System.Windows.Forms.TextBox txtQ1_3A_mm;
        private System.Windows.Forms.TextBox txtQ3_3B_yy;
        private System.Windows.Forms.TextBox txtQ3_3B_dd;
        private System.Windows.Forms.TextBox txtQ3_3B_mm;
        private System.Windows.Forms.TextBox txtQ2_3B_yy;
        private System.Windows.Forms.TextBox txtQ2_3B_dd;
        private System.Windows.Forms.TextBox txtQ2_3B_mm;
        private System.Windows.Forms.TextBox txtQ3_3A_yy;
        private System.Windows.Forms.TextBox txtQ3_3A_dd;
        private System.Windows.Forms.TextBox txtQ3_3A_mm;
        private System.Windows.Forms.TextBox txtQ2_3A_yy;
        private System.Windows.Forms.TextBox txtQ2_3A_dd;
        private System.Windows.Forms.TextBox txtQ2_3A_mm;
        private System.Windows.Forms.TextBox txtSign_yy;
        private System.Windows.Forms.TextBox txtSign_dd;
        private System.Windows.Forms.TextBox txtSign_mm;
        private System.Windows.Forms.GroupBox grpbxQ3_4;
        private System.Windows.Forms.TextBox txtQ3_4_yy;
        private System.Windows.Forms.TextBox txtQ3_4_dd;
        private System.Windows.Forms.TextBox txtQ3_4_mm;
        private System.Windows.Forms.Label lblComments;
        private System.Windows.Forms.TextBox txtComments;
    }
}