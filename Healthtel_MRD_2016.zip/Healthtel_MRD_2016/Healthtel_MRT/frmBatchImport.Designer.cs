﻿namespace Healthtel_MRT
{
    partial class frmBatchImport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBatchImport));
            this.btnClose = new System.Windows.Forms.Button();
            this.btnImport = new System.Windows.Forms.Button();
            this.txtBatchName = new System.Windows.Forms.TextBox();
            this.txtBatchPath = new System.Windows.Forms.TextBox();
            this.lblBatchName = new System.Windows.Forms.Label();
            this.lblBatchPath = new System.Windows.Forms.Label();
            this.lblImportStatus = new System.Windows.Forms.Label();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.lblBatchType = new System.Windows.Forms.Label();
            this.cmbBatchType = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(371, 188);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(86, 32);
            this.btnClose.TabIndex = 9;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnImport
            // 
            this.btnImport.BackColor = System.Drawing.Color.Transparent;
            this.btnImport.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnImport.ForeColor = System.Drawing.Color.White;
            this.btnImport.Location = new System.Drawing.Point(260, 188);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(86, 32);
            this.btnImport.TabIndex = 8;
            this.btnImport.Text = "Import";
            this.btnImport.UseVisualStyleBackColor = false;
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // txtBatchName
            // 
            this.txtBatchName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtBatchName.Location = new System.Drawing.Point(131, 132);
            this.txtBatchName.Name = "txtBatchName";
            this.txtBatchName.Size = new System.Drawing.Size(498, 22);
            this.txtBatchName.TabIndex = 6;
            // 
            // txtBatchPath
            // 
            this.txtBatchPath.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtBatchPath.Location = new System.Drawing.Point(131, 89);
            this.txtBatchPath.Name = "txtBatchPath";
            this.txtBatchPath.Size = new System.Drawing.Size(498, 22);
            this.txtBatchPath.TabIndex = 3;
            this.txtBatchPath.TextChanged += new System.EventHandler(this.txtBatchPath_TextChanged);
            // 
            // lblBatchName
            // 
            this.lblBatchName.AutoSize = true;
            this.lblBatchName.BackColor = System.Drawing.Color.Transparent;
            this.lblBatchName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBatchName.ForeColor = System.Drawing.Color.White;
            this.lblBatchName.Location = new System.Drawing.Point(33, 133);
            this.lblBatchName.Name = "lblBatchName";
            this.lblBatchName.Size = new System.Drawing.Size(86, 14);
            this.lblBatchName.TabIndex = 5;
            this.lblBatchName.Text = "Batch Name";
            // 
            // lblBatchPath
            // 
            this.lblBatchPath.AutoSize = true;
            this.lblBatchPath.BackColor = System.Drawing.Color.Transparent;
            this.lblBatchPath.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBatchPath.ForeColor = System.Drawing.Color.White;
            this.lblBatchPath.Location = new System.Drawing.Point(33, 95);
            this.lblBatchPath.Name = "lblBatchPath";
            this.lblBatchPath.Size = new System.Drawing.Size(82, 14);
            this.lblBatchPath.TabIndex = 2;
            this.lblBatchPath.Text = "Select Path";
            // 
            // lblImportStatus
            // 
            this.lblImportStatus.AutoSize = true;
            this.lblImportStatus.BackColor = System.Drawing.Color.Transparent;
            this.lblImportStatus.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImportStatus.Location = new System.Drawing.Point(285, 253);
            this.lblImportStatus.Name = "lblImportStatus";
            this.lblImportStatus.Size = new System.Drawing.Size(0, 14);
            this.lblImportStatus.TabIndex = 10;
            this.lblImportStatus.Visible = false;
            // 
            // btnBrowse
            // 
            this.btnBrowse.BackColor = System.Drawing.Color.Transparent;
            this.btnBrowse.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnBrowse.ForeColor = System.Drawing.Color.White;
            this.btnBrowse.Location = new System.Drawing.Point(642, 86);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(41, 24);
            this.btnBrowse.TabIndex = 4;
            this.btnBrowse.Text = "...";
            this.btnBrowse.UseVisualStyleBackColor = false;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // lblBatchType
            // 
            this.lblBatchType.AutoSize = true;
            this.lblBatchType.BackColor = System.Drawing.Color.Transparent;
            this.lblBatchType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBatchType.ForeColor = System.Drawing.Color.White;
            this.lblBatchType.Location = new System.Drawing.Point(33, 57);
            this.lblBatchType.Name = "lblBatchType";
            this.lblBatchType.Size = new System.Drawing.Size(80, 14);
            this.lblBatchType.TabIndex = 0;
            this.lblBatchType.Text = "Batch Type";
            // 
            // cmbBatchType
            // 
            this.cmbBatchType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.cmbBatchType.FormattingEnabled = true;
            this.cmbBatchType.Items.AddRange(new object[] {
            "Heathtel HRA_V2",
            "Heathtel CIP",
            "Heathtel MRD",
            "Heathtel HEDIS",
            "Heathtel HRA_V1",
            "Healthtel_pediatric"});
            this.cmbBatchType.Location = new System.Drawing.Point(131, 50);
            this.cmbBatchType.Name = "cmbBatchType";
            this.cmbBatchType.Size = new System.Drawing.Size(204, 22);
            this.cmbBatchType.TabIndex = 1;
            // 
            // frmBatchImport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(716, 295);
            this.Controls.Add(this.cmbBatchType);
            this.Controls.Add(this.lblBatchType);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.lblImportStatus);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnImport);
            this.Controls.Add(this.txtBatchName);
            this.Controls.Add(this.txtBatchPath);
            this.Controls.Add(this.lblBatchName);
            this.Controls.Add(this.lblBatchPath);
            this.ForeColor = System.Drawing.Color.White;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmBatchImport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Healthtel : : Batch Import";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnImport;
        private System.Windows.Forms.TextBox txtBatchName;
        private System.Windows.Forms.TextBox txtBatchPath;
        private System.Windows.Forms.Label lblBatchName;
        private System.Windows.Forms.Label lblBatchPath;
        private System.Windows.Forms.Label lblImportStatus;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Label lblBatchType;
        private System.Windows.Forms.ComboBox cmbBatchType;
    }
}