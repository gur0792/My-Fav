﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using MySql.Data.MySqlClient;
using DataAccessLayer.ProjectDB;
using DataAccessLayer.GlobalDB;
using DataAccessLayer.ZipCodeDB;
using App.Base;
using System.IO;

namespace Healthtel_MRT
{
    public partial class HRAV1 : Form
    {                
        public HRAV1()
        {
            InitializeComponent();

         }
        batchmaster objBatchmaster = new batchmaster();
        imagemaster objImagemaster = new imagemaster();
        key1_hra_v1 objKey1 = new key1_hra_v1();
        key2_hra_v1 objKey2 = new key2_hra_v1();
        compareqc_hra_v1 objCompareQC = new compareqc_hra_v1();

        imagemaster Image = new imagemaster();
        key1_hra_v1 getkey1Data = new key1_hra_v1();
        key2_hra_v1 getkey2Data = new key2_hra_v1();
        compareqc_hra_v1 getCompareqcData = new compareqc_hra_v1();


        #region Global Fields For Controls
       //public string path = Application.StartupPath + "\\Import_Log_File\\ImportLog.txt";
        public const string GC_FIELDS_RESPONDENTID = "txtRespndentID";
        public const string GC_FIELDS_Q1_9 = "txtQ1_9";
        public const string GC_FIELDS_Q1_1 = "txtQ1_1";
        public const string GC_FIELDS_Q1_2 = "txtQ1_2";
        public const string GC_FIELDS_Q1_3 = "txtQ1_3";
        public const string GC_FIELDS_Q1_4 = "txtQ1_4";
        public const string GC_FIELDS_Q1_5 = "txtQ1_5";
        public const string GC_FIELDS_Q1_6 = "txtQ1_6";
        public const string GC_FIELDS_Q1_7 = "txtQ1_7";
        public const string GC_FIELDS_Q1_8 = "txtQ1_8";
        public const string GC_FIELDS_Q3_1 = "txtQ3_1";
        public const string GC_FIELDS_Q3_2 = "txtQ3_2";
        public const string GC_FIELDS_Q3_3 = "txtQ3_3";
        public const string GC_FIELDS_Q3_4 = "txtQ3_4";
        public const string GC_FIELDS_Q3_5 = "txtQ3_5";
        public const string GC_FIELDS_Q4_1 = "txtQ4_1";
        public const string GC_FIELDS_Q4_2 = "txtQ4_2";
        public const string GC_FIELDS_Q4_3 = "txtQ4_3";
        public const string GC_FIELDS_Q2_1 = "txtQ2_1";
        public const string GC_FIELDS_Q2_TTL = "txtQ2_TTL";
        public const string GC_FIELDS_Q5_1 = "txtQ5_1";
        public const string GC_FIELDS_Q5_TTL = "txtQ5_TTL";
        public const string GC_FIELDS_Q6_1 = "txtQ6_1";
        public const string GC_FIELDS_Q7_2 = "txtQ7_2";
        public const string GC_FIELDS_Q7_1 = "txtQ7_1";
        public const string GC_FIELDS_Q8_1 = "txtQ8_1";
        public const string GC_FIELDS_LANGUAGE = "txtLanguage";
        public const string GC_FIELDS_MailType = "txtmailtype";
        #endregion
        long lngBatchID;
        long lngImageID;
        int intBatchType;
        string strImagePath;
        int totRecs;
        int RemRecs;
        int FinRecs;
        string ProcessType;
        string strSQL;
        DataSet dsKeyData;
        DataSet dsKey1;
        DataSet dskey;
        string strImageSize;
        string strImageFit;
        int iHScrol = 0;
        int iVScrol = 0;
        Object Imageid;

        bool bCtrl = false;
        bool bAlt = false;
        bool bShift = false;
        bool bImageLoad = false;

        #region Property Variables
        public long BatchID
        {
            get { return lngBatchID; }

            set { lngBatchID = value; }
        }

        public string Process
        {
            get { return ProcessType; }

            set { ProcessType = value; }
        }

        public int BatchType
        {
            get { return intBatchType; }

            set { intBatchType = value; }
        }
        #endregion

        private void txtRespndentID_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtRespndentID);
        }

        private void txtRespndentID_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtRespndentID);
        }

        private void txtRespndentID_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtRespndentID);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //File.AppendAllText(path,Environment.NewLine + "Start Save Button Click:" + DateTime.Now);
            SaveandLoad();
        }
        private bool txtChanged(object Sender, System.EventArgs e, Control ObjControl)
        {
            try
            {
                if ((ObjControl is TextBox) || (ObjControl is ComboBox) || (ObjControl is CheckBox))
                {
                    switch (ObjControl.Name)
                    {
                        case GC_FIELDS_RESPONDENTID:
                            if (txtRespndentID.TextLength == txtRespndentID.MaxLength)
                            {
                                txtQ1_9.Focus();  
                            }
                            break;
                        case GC_FIELDS_Q1_9:

                            if (txtQ1_9.TextLength == txtQ1_9.MaxLength)
                            {
                                txtQ1_1.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_1:
                          
                            if (txtQ1_1.TextLength == txtQ1_1.MaxLength)
                            {
                                txtQ1_2.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_2:
                            if (txtQ1_2.TextLength == txtQ1_2.MaxLength)
                            {
                                txtQ1_3.Focus();  
                                                           }
                            break;
                        case GC_FIELDS_Q1_3:
                            if (txtQ1_3.Text.Length == txtQ1_3.MaxLength)
                                 
                            {
                                txtQ1_4.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_4:
                            if (txtQ1_4.TextLength == txtQ1_4.MaxLength)
                            {
                                 txtQ1_5.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_5:
                            if (txtQ1_5.TextLength == txtQ1_5.MaxLength)
                            {
                                txtQ1_6.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_6:
                            if (txtQ1_6.TextLength == txtQ1_6.MaxLength)
                            {
                                txtQ1_7.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_7:
                            if (txtQ1_7.TextLength == txtQ1_7.MaxLength)
                            {
                                txtQ1_8.Focus();
                            }
                            break;
                        case GC_FIELDS_Q1_8:
                            if (txtQ1_8.TextLength == txtQ1_8.MaxLength)
                            {
                                txtQ3_1.Focus();
                            }
                            break;
                        case GC_FIELDS_Q3_1:
                            if (txtQ3_1.TextLength == txtQ3_1.MaxLength)
                            {
                                txtQ3_2.Focus();
                            }
                            break;
                        case GC_FIELDS_Q3_2:
                            if (txtQ3_2.TextLength == txtQ3_2.MaxLength)
                            {
                                txtQ3_3.Focus();
                            }
                            break;
                        case GC_FIELDS_Q3_3:
                            if (txtQ3_3.Text.Length == txtQ3_3.MaxLength)
                            {
                                txtQ3_4.Focus();
                            }
                            break;
                        case GC_FIELDS_Q3_4:
                            if (txtQ3_4.TextLength == txtQ3_4.MaxLength)
                            {
                                txtQ3_5.Focus();
                            }
                            break;
                        case GC_FIELDS_Q3_5:
                            if (txtQ3_5.TextLength == txtQ3_5.MaxLength)
                            {
                                txtQ4_1.Focus();
                            }
                            break;
                        case GC_FIELDS_Q4_1:
                            if (txtQ4_1.TextLength == txtQ4_1.MaxLength)
                            {
                                txtQ4_2.Focus();
                            }
                            break;
                        case GC_FIELDS_Q4_2:
                            if (txtQ4_2.TextLength == txtQ4_2.MaxLength)
                            {
                                txtQ4_3.Focus();
                            }
                            break;
                        case GC_FIELDS_Q4_3:
                            if (txtQ4_3.TextLength == txtQ4_3.MaxLength)
                            {
                                txtQ2_1.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_1:
                            if (txtQ2_1.TextLength == txtQ2_1.MaxLength)
                            {
                                txtQ2_TTL.Focus();
                            }
                            break;
                        case GC_FIELDS_Q2_TTL:
                            if (txtQ2_TTL.TextLength == txtQ2_TTL.MaxLength)
                            {
                                txtQ5_1.Focus();
                            }
                            break;
                        case GC_FIELDS_Q5_1:
                            if (txtQ5_1.TextLength == txtQ5_1.MaxLength)
                            {
                                txtQ5_TTL.Focus();
                            }
                            break;
                        case GC_FIELDS_Q5_TTL:
                            if (txtQ5_TTL.Text.Length == txtQ5_TTL.MaxLength)
                            {
                                txtQ6_1.Focus();
                            }
                            break;
                        case GC_FIELDS_Q6_1:
                            if (txtQ6_1.Text.Length == txtQ6_1.MaxLength)
                            {
                                txtQ7_2.Focus();
                            }
                            break;
                        case GC_FIELDS_Q7_2:
                            if (txtQ7_2.Text.Length == txtQ7_2.MaxLength)
                            {
                                txtQ7_1.Focus();
                            }
                            break;
                        case GC_FIELDS_Q7_1:
                            if (txtQ7_1.Text.Length == txtQ7_1.MaxLength)
                            {
                                txtQ8_1.Focus();
                            }
                            break;
                        case GC_FIELDS_Q8_1:
                            if (txtQ8_1.Text.Length == txtQ8_1.MaxLength)
                            {
                                txtLanguage.Focus();
                            }
                            break;                   
                        case GC_FIELDS_LANGUAGE:
                            if (txtLanguage.Text.Length == txtLanguage.MaxLength)
                            {
                                txtmailtype.Focus();  
                                //btnSave.Focus();
                            }
                            break;
                        case GC_FIELDS_MailType:

                            if (txtmailtype.Text.Length == txtmailtype.MaxLength)
                            {
                                //txtmailtype.Focus();
                                btnSave.Focus();
                            }
                            break;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        private bool txtEnter(object Sender, System.EventArgs e, Control ObjControl)
        {
            try
            {
                if ((ObjControl is TextBox) || (ObjControl is ComboBox) || (ObjControl is CheckBox))
                {
                    switch (ObjControl.Name)
                    {
                        case GC_FIELDS_RESPONDENTID:
                            txtDescription.Text = "Respondent ID number";
                           txtRespndentID.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Respondent_ID; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Respondent_ID; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Respondent_ID; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 100));
                            break;

                        case GC_FIELDS_Q1_1:
                            txtDescription.Text = "Q1 [1 or Blank 1=High Blood Pressure]";
                            txtQ1_9.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q1_1; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q1_1; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q1_1; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 100));
                            break;

                        case GC_FIELDS_Q1_2:
                            txtDescription.Text = "Q1 [1 or Blank 1=Heart Failure]";
                            txtQ2_1.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q1_2; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q1_2; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q1_2; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 100));
                            break;

                        case GC_FIELDS_Q1_3:
                            txtDescription.Text = "Q1 [1 or Blank 1=Emphysema, COPD...]";
                            txtQ1_3.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q1_3; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q1_3; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q1_3; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 100));
                            break;

                        case GC_FIELDS_Q1_4:
                            txtDescription.Text = "Q1 [1 or Blank 1=Kidney Dialysis]";
                            txtQ1_4.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q1_4; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q1_4; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q1_4; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 100));
                            break;

                        case GC_FIELDS_Q1_5:
                            txtDescription.Text = "Q1 [1 or Blank 1=Diabetes Or Blood Sugar Problem ]";
                            txtQ1_5.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q1_5; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q1_5; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q1_5; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 100));
                            break;

                        case GC_FIELDS_Q1_6:
                            txtDescription.Text = "Q1 [1 or Blank 1=Depression]";
                            txtQ1_6.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q1_6; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q1_6; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q1_6; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 100));
                            break;

                        case GC_FIELDS_Q1_7:
                            txtDescription.Text = "Q1 [1 or Blank 1=Other Conditions]";
                            txtQ1_7.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q1_7; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q1_7; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q1_7; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 100));
                            break;

                        case GC_FIELDS_Q1_8:
                            txtDescription.Text = "Q1 [1 or Blank 1=None]";
                            txtQ1_8.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q1_8; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q1_8; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q1_8; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 100));
                            break;

                        case GC_FIELDS_Q1_9:
                            txtDescription.Text = "Q1 [1 or Blank 1=Heart Attack]";
                            txtQ1_9.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q1_9; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q1_9; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q1_9; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 100));
                            break;

                        case GC_FIELDS_Q3_1:
                            txtDescription.Text = "Q2 [1=Yes, 2=No]";
                            txtQ3_1.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q3_1; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q3_1; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q3_1; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q3_2:
                           txtDescription.Text = "Q3 [1=Yes, 2=No]";
                            txtQ3_2.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q3_2; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q3_2; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q3_2; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q3_3:
                           txtDescription.Text = "Q4 [1=Yes, 2=No]";
                            txtQ3_3.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q3_3; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q3_3; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q3_3; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q3_4:
                           txtDescription.Text = "Q5 [1=Yes, 2=No]";
                            txtQ3_4.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q3_4; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q3_4; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q3_4; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q3_5:
                           txtDescription.Text = "Q6 [1=Yes, 2=No]";
                            txtQ3_5.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q3_5; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q3_5; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q3_5; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q4_1:
                            txtDescription.Text = "Q7 [1=Yes, 2=No]";
                            txtQ4_1.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q4_1; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q4_1; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q4_1; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q4_2:
                           txtDescription.Text = "Q8 [1=Yes, 2=No]";
                            txtQ4_2.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q4_2; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q4_2; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q4_2; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q4_3:
                           txtDescription.Text = "Q9 [1=Yes, 2=No]";
                            txtQ4_3.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q4_3; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q4_3; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q4_3; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q2_1:
                            txtDescription.Text = "Q10 [1=Yes, 2=No]";
                            txtQ2_1.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q2_1; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q2_1; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q2_1; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q2_TTL:
                            txtDescription.Text = "Q11 [1=Yes, 2=No]";
                            txtQ2_TTL.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q2_ttl; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q2_ttl; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q2_ttl; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q5_1:
                            txtDescription.Text = "Q12 [1=Yes, 2=No]";
                            txtQ5_1.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q5_1; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q5_1; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q5_1; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q5_TTL:
                            txtDescription.Text = "Q13 [1=1 Time, 2=2 - 3 Times, 3=4 or more times]";
                            txtQ5_TTL.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q5_TTL; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q5_TTL; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q5_TTL; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 70));
                            break;

                        case GC_FIELDS_Q6_1:
                           txtDescription.Text = "Q14 [1=Yes, 2=No]";
                            txtQ6_1.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q6_1; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q6_1; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q6_1; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 34));
                            break;

                        case GC_FIELDS_Q7_2:
                            txtDescription.Text = "Q15 [1=Yes, 2=No]";
                            txtQ7_2.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q7_1; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q7_1; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q7_1; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 34));
                            break;

                        case GC_FIELDS_Q7_1:
                            txtDescription.Text = "Q16 [1=Yes, 2=No]";
                            txtQ7_1.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q7_1; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q7_1; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q7_1; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 34));
                            break;

                        case GC_FIELDS_Q8_1:
                            txtDescription.Text = "Q17 [1=Not at all ,  2=A little ,  3=Somewhat,  4=Quite , 5=Extremely]";
                            txtQ8_1.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Q8_1; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Q8_1; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Q8_1; }
                            }
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 34));
                            break;
                        case GC_FIELDS_LANGUAGE:
                            txtDescription.Text = "LAUGUAGE [1=English, 2=Spanish]";
                            txtLanguage.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.Language; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.Language; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.Language; }
                            }
                        
                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 34));
                            break;
                        case GC_FIELDS_MailType :
                            txtDescription.Text = "";
                            txtmailtype.SelectAll();
                            if (Process.ToUpper() == "COMPAREQC")
                            {
                                if (getkey1Data != null) { txtKey1Data.Text = getkey1Data.MailType; }

                                if (getCompareqcData != null) { txtKey2Data.Text = getCompareqcData.MailType; }
                                else if (getkey2Data != null) { txtKey2Data.Text = getkey2Data.MailType; }
                            }

                            IGImageViewer.MoveImage((IGImageViewer.ImageHorizontalScroll.Maximum / 100), IGImageViewer.ImageVerticalScroll.Maximum - ((IGImageViewer.ImageVerticalScroll.Maximum / 100) * 34));
                            break;
                                                 
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private bool txtKeyPress(object Sender, System.Windows.Forms.KeyPressEventArgs e, Control ObjControl)
        {
            try
            {
                if ((ObjControl is TextBox) || (ObjControl is ComboBox))
                {
                    e.KeyChar= char.ToUpper(e.KeyChar);

                    switch (ObjControl.Name)
                    {
                        case GC_FIELDS_RESPONDENTID:
                        
                            if (char.IsDigit(e.KeyChar) || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back) || char.IsWhiteSpace(e.KeyChar) || char.IsPunctuation(e.KeyChar) || char.IsSymbol(e.KeyChar))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;
                        case GC_FIELDS_Q1_9:
                        case GC_FIELDS_Q1_1:
                        case GC_FIELDS_Q1_2:
                       case GC_FIELDS_Q1_3:
                        case GC_FIELDS_Q1_4:
                        case GC_FIELDS_Q1_5:
                        case GC_FIELDS_Q1_6:
                        case GC_FIELDS_Q1_7:
                        case GC_FIELDS_Q1_8:
                            if (e.KeyChar == '0' || e.KeyChar == '1' || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;



             
                        case GC_FIELDS_Q3_1:
                        case GC_FIELDS_Q3_2:
                        case GC_FIELDS_Q3_3:
                        case GC_FIELDS_Q3_4:
                        case GC_FIELDS_Q3_5:
                        case GC_FIELDS_Q4_1:
                        case GC_FIELDS_Q4_2:
                        case GC_FIELDS_Q4_3:
                        case GC_FIELDS_Q2_1:
                        case GC_FIELDS_Q2_TTL:
                        case GC_FIELDS_Q5_1:
                        case GC_FIELDS_Q6_1:
                        case GC_FIELDS_Q7_2:
                        case GC_FIELDS_Q7_1:
                            if (e.KeyChar == '1' ||e.KeyChar == '2'||  Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;

                       
                        case GC_FIELDS_Q5_TTL:
                            if (e.KeyChar == '1' || e.KeyChar == '2' || e.KeyChar == '3' || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;

                        
                        case GC_FIELDS_LANGUAGE:
                            if (e.KeyChar == '1' || e.KeyChar == '2' || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;
                                                                          

                        case GC_FIELDS_Q8_1:
                            if (e.KeyChar == '1' || e.KeyChar == '2' || e.KeyChar == '3' || e.KeyChar == '4' || e.KeyChar == '5' || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;

                        case GC_FIELDS_MailType:
                            if (char.IsLetterOrDigit(e.KeyChar) || Strings.AscW(e.KeyChar) == Convert.ToInt32(Keys.Back))
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                            break;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void txtQ1_9_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_9);
        }

        private void txtQ1_9_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_9);
        }

        private void txtQ1_9_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_9);
        }

        private void txtQ1_1_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_1);
        }

        private void txtQ1_1_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_1);
        }

        private void txtQ1_1_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_1);
        }

        private void txtQ1_2_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_2);
        }

        private void txtQ1_2_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_2);
        }

        private void txtQ1_2_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_2);
        }

        private void txtQ1_3_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_3);
        }

        private void txtQ1_3_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_3);
        }

        private void txtQ1_3_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_3);
        }

        private void txtQ1_4_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_4);
        }

        private void txtQ1_4_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_4);
        }

        private void txtQ1_4_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_4);
        }

        private void txtQ1_5_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_5);
        }

        private void txtQ1_5_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_5);
        }

        private void txtQ1_5_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_5);
        }

        private void txtQ1_6_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_6);
        }

        private void txtQ1_6_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_6);
        }

        private void txtQ1_6_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_6);
        }

        private void txtQ1_7_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_7);
        }

        private void txtQ1_7_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_7);
        }

        private void txtQ1_7_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_7);
        }

        private void txtQ1_8_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ1_8);
        }

        private void txtQ1_8_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ1_8);
        }

        private void txtQ1_8_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ1_8);
        }

        private void txtQ3_1_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3_1);
        }

        private void txtQ3_1_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3_1);
        }

        private void txtQ3_1_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3_1);
        }

        private void txtQ3_2_TextChanged(object sender, EventArgs e)
        {

            txtChanged(sender, e, txtQ3_2);
        }

        private void txtQ3_2_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3_2);
        }

        private void txtQ3_2_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3_2);
        }

        private void txtQ3_3_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3_3);
        }

        private void txtQ3_3_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3_3);
        }

        private void txtQ3_3_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3_3);
        }

        private void txtQ3_4_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3_4);
        }

        private void txtQ3_4_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3_4);
        }

        private void txtQ3_4_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3_4);
        }

        private void txtQ3_5_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ3_5);
        }

        private void txtQ3_5_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ3_5);
        }

        private void txtQ3_5_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ3_5);
        }

        private void txtQ4_1_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ4_1);
        }

        private void txtQ4_1_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ4_1);
        }

        private void txtQ4_1_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ4_1);
        }

        private void txtQ4_2_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ4_2);
        }

        private void txtQ4_2_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ4_2);
        }

        private void txtQ4_2_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ4_2);
        }

        private void txtQ4_3_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ4_3);
        }

        private void txtQ4_3_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ4_3);
        }

        private void txtQ4_3_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ4_3);
        }

        private void txtQ2_1_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_1);
        }

        private void txtQ2_1_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_1);
        }

        private void txtQ2_1_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_1);
        }

        private void txtQ2_TTL_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ2_TTL);
        }

        private void txtQ2_TTL_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ2_TTL);
        }

        private void txtQ2_TTL_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ2_TTL);
        }

        private void txtQ5_1_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ5_1);
        }

        private void txtQ5_1_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ5_1);
        }

        private void txtQ5_1_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ5_1);
        }

        private void txtQ5_TTL_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ5_TTL);
        }

        private void txtQ5_TTL_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ5_TTL);
        }

        private void txtQ5_TTL_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ5_TTL);

        }

        private void txtQ6_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ6_1 );
        }

        private void txtQ6_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ6_1);
        }

        private void txtQ6_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ6_1);
        }

        private void txtQ7_2_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ7_2);
        }

        private void txtQ7_2_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ7_2);
        }

        private void txtQ7_2_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ7_2);
        }

        private void txtQ7_1_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ7_1);
        }

        private void txtQ7_1_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ7_1);
        }

        private void txtQ7_1_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ7_1);
        }

        private void txtQ8_1_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtQ8_1);
        }

        private void txtQ8_1_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtQ8_1);
        }

        private void txtQ8_1_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtQ8_1);
        }

        private void txtLanguage_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtLanguage);
        }

        private void txtLanguage_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtLanguage);
        }

        private void txtLanguage_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtLanguage);
        }

        private void ClearInfo()
        {
            //txtRespndentID.Clear();
            txtQ1_9.Clear();
            txtQ1_1.Clear();
            txtQ1_2.Clear();
            txtQ1_3.Clear();
            txtQ1_4.Clear();
            txtQ1_5.Clear();
            txtQ1_6.Clear();
            txtQ1_7.Clear();
            txtQ1_8.Clear();
            txtQ3_1.Clear();
            txtQ3_2.Clear();
            txtQ3_3.Clear();
            txtQ3_4.Clear();
            txtQ3_5.Clear();
            txtQ4_1.Clear();
            txtQ4_2.Clear();
            txtQ4_3.Clear();
            txtQ2_1.Clear();
            txtQ2_TTL.Clear();
            txtQ5_1.Clear();
            txtQ5_TTL.Clear();
            txtQ6_1.Clear();
            txtQ7_2.Clear();
            txtQ7_1.Clear();
            txtQ8_1.Clear();
            txtLanguage.Clear();
            txtmailtype.Clear();  
            txtKey1User.Clear();
            txtKey1Data.Clear();
            txtKey2User.Clear();
            txtKey2Data.Clear();
            IGImageViewer.ImageClear();
        }

        private long TotalKeystrokes()
        {
            long lngCount = 0;
            lngCount = 0;

            //lngCount += txtRespndentID.TextLength;
            lngCount += txtQ1_9.TextLength;
            lngCount += txtQ1_1.TextLength;
            lngCount += txtQ1_2.Text.Length;
            lngCount += txtQ1_3.TextLength;
            lngCount += txtQ1_4.TextLength;
            lngCount += txtQ1_5.TextLength;
            lngCount += txtQ1_6.TextLength;
            lngCount += txtQ1_7.Text.Length;
            lngCount += txtQ1_8.TextLength;
            lngCount += txtQ3_1.TextLength;
            lngCount += txtQ3_2.TextLength;
            lngCount += txtQ3_3.TextLength;
            lngCount += txtQ3_4.TextLength;
            lngCount += txtQ3_5.TextLength;
            lngCount += txtQ4_1.TextLength;
            lngCount += txtQ4_2.TextLength;
            lngCount += txtQ4_3.TextLength;
            lngCount += txtQ2_1.TextLength;
            lngCount += txtQ2_TTL.TextLength;
            lngCount += txtQ5_1.TextLength;
            lngCount += txtQ5_TTL.TextLength;
            lngCount += txtQ6_1.TextLength;
            lngCount += txtQ7_2.TextLength;
            lngCount += txtQ7_1.TextLength;
            lngCount += txtQ8_1.TextLength;
            lngCount += txtLanguage.TextLength;
            lngCount += txtmailtype.TextLength;  
            return lngCount;
        }

        private bool LoadImage()
        {


            //if (!File.Exists(path))
            //{
            //    File.Create(path);
            //    TextWriter tw = new StreamWriter(path);
            //    tw.WriteLine("The very first line!");
            //    tw.Close();
            //}                
            
            //bool functionReturnValue = false;
            try
            {

                //File.AppendAllText(path, Environment.NewLine + "Before LoadImage:" + DateTime.Now);
                ClearInfo();
                //File.AppendAllText(path, Environment.NewLine + "After ClearInfo:" + DateTime.Now);
                if (lngBatchID > 0)
                {
                   // File.AppendAllText(path, Environment.NewLine + "Before Image id return:" + DateTime.Now);
                    Image = objImagemaster.LoadImage_HRA_v1(Process, lngBatchID, Constance.GC_USERID);
                   // File.AppendAllText(path, Environment.NewLine + "Image id return:" + DateTime.Now);
                    if (Image == null)
                    {
                        MessageBox.Show("Batch Completed");
                        objBatchmaster.UpdateBatchmaster(lngBatchID.ToInt(), Process);
                        this.Close();
                        return false;
                    }
                    //File.AppendAllText(path, Environment.NewLine + "Before imageviewer to Image Load:" + DateTime.Now);
                    lngImageID = Image.ImageID;
                    IGImageViewer.ImageName = Image.ImagePath;
                    IGImageViewer.LoadImage();
                   // File.AppendAllText(path, Environment.NewLine + "After imageviewer to Image Load:" + DateTime.Now);
                    //MySqlParameter[] cParams = new MySqlParameter[4];
                    //cParams[0] = new MySqlParameter("P_PROCESS", ProcessType);
                    //cParams[1] = new MySqlParameter("P_BATCHID", lngBatchID);
                    //cParams[2] = new MySqlParameter("P_CurrUserID", 0);
                    //cParams[3] = new MySqlParameter("P_IMAGEID", MySqlDbType.Int64);
                    //Object IRESULT;
                    //String StrSqlCall = "CALL LoadImage(?P_PROCESS,?P_BATCHID,?P_CurrUserID,@P_IMAGEID);Select @P_IMAGEID;";
                    //IRESULT = DatabaseClass.ExecuteScalar(StrSqlCall, CommandType.Text, cParams);

                    //if (IRESULT != null)
                    //{
                    //    Imageid = IRESULT;
                    //}
                    //else
                    //{
                    //    Imageid = 0;
                    //}

                    //String strSQL = "Select * from ImageMaster Where ImageID=" + Imageid + " Order by ImageID,ImagePath LIMIT 1;";
                    //DataSet ds = new DataSet();
                    //ds = DatabaseClass.GetDataset(strSQL);
                    //if (ds.Tables[0].Rows.Count > 0)
                    //{
                    //    String Imagepath, SelImageid;
                    //    Imagepath = ds.Tables[0].Rows[0]["ImagePath"].ToString();
                    //    SelImageid = ds.Tables[0].Rows[0]["ImageID"].ToString();
                    //    IGImageViewer.ImageName = Imagepath;
                    //    IGImageViewer.LoadImage();
                    //    //UserVariable.imageintime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    //    //LoginDetails();
                    //    //UpdateImageCount();

                    //}
                    //else
                    //{
                    //    MessageBox.Show("Batch Completed");
                    //    String strSQLup = "Update BatchMaster Set key1 =2 Where ID=" + lngBatchID + " And ID not In (Select Distinct BatchID from ImageMaster where Key1 in ( 0 ,1 ))";
                    //    DatabaseClass.NonQuery(strSQLup, CommandType.Text);
                    //}

                    strImageSize = Interaction.GetSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageSize) + "";
                    if (strImageSize.LastIndexOf(",") > 0)
                    {
                        iHScrol = Convert.ToInt32((strImageSize.Substring(0, strImageSize.LastIndexOf(","))));
                        iVScrol = Convert.ToInt32(strImageSize.Substring(strImageSize.LastIndexOf(",") + 1));
                        IGImageViewer.ImageSize = new System.Drawing.Size(iHScrol, iVScrol);
                    }

                    strImageFit = Interaction.GetSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageFit) + "";
                    if (strImageFit.LastIndexOf(",") > 0)
                    {
                        iHScrol = Convert.ToInt32(strImageFit.Substring(0, strImageFit.LastIndexOf(",")));
                        iVScrol = Convert.ToInt32(strImageFit.Substring(strImageFit.LastIndexOf(",") + 1));
                    }

                    IGImageViewer.MoveImage(iHScrol, iVScrol);
                    IGImageViewer.Refresh();

                    if (Process.ToUpper() == "COMPAREQC")
                    {
                        //File.AppendAllText(path, Environment.NewLine + "Before Restore Info:" + DateTime.Now);
                        RestoreInfo();
                        grpKeyData.Visible = true;
                        //File.AppendAllText(path, Environment.NewLine + "After Restore Info:" + DateTime.Now);
                    }

                    Constance.ImageInTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    int TotalRecord, FinishedRecord, RemainingRecord;
                    TotalRecord = FinishedRecord = RemainingRecord = 0;
                    //File.AppendAllText(path, Environment.NewLine +  "Before Imagecount update status:" + DateTime.Now);
                    objImagemaster.RecordStatus(Process, lngBatchID, ref TotalRecord, ref FinishedRecord, ref RemainingRecord, intBatchType);
                    this.stsUser.Text = "User Name : " + Constance.GC_USERNAME;
                    this.stsTotRecs.Text = "Total Recs : " + TotalRecord;
                    this.stsFinRecs.Text = "Finished Rec : " + FinishedRecord;
                    this.stsRemRecs.Text = "Remine Recs: " + RemainingRecord;
                    this.stsDate.Text = "Date : " + DateAndTime.Now.ToString("dd-MMMM-yyyy");
                    //File.AppendAllText(path, Environment.NewLine + "After Imagecount update status:" + DateTime.Now);
                    txtQ1_9.Focus();

                    if (Process.ToUpper() == "COMPAREQC")
                    {
                        //if (txtRespndentID.Enabled == true)
                        //{ txtRespndentID.Focus(); }
                        if (txtQ1_9.Enabled == true)
                        { txtQ1_9.Focus(); }
                        else if (txtQ1_1.Enabled == true)
                        { txtQ1_1.Focus(); }
                        else if (txtQ1_2.Enabled == true)
                        { txtQ1_1.Focus(); }
                        else if (txtQ1_3.Enabled == true)
                        { txtQ1_3.Focus(); }
                        else if (txtQ1_4.Enabled == true)
                        { txtQ1_4.Focus(); }
                        else if (txtQ1_5.Enabled == true)
                        { txtQ1_5.Focus(); }
                        else if (txtQ1_6.Enabled == true)
                        { txtQ1_6.Focus(); }
                        else if (txtQ1_7.Enabled == true)
                        { txtQ1_8.Focus(); }
                        else if (txtQ3_1.Enabled == true)
                        { txtQ3_1.Focus(); }
                        else if (txtQ3_2.Enabled == true)
                        { txtQ3_2.Focus(); }
                        else if (txtQ3_3.Enabled == true)
                        { txtQ3_3.Focus(); }
                        else if (txtQ3_4.Enabled == true)
                        { txtQ3_4.Focus(); }
                        else if (txtQ3_4.Enabled == true)
                        { txtQ3_4.Focus(); }
                        else if (txtQ3_5.Enabled == true)
                        { txtQ3_5.Focus(); }
                        else if (txtQ3_5.Enabled == true)
                        { txtQ3_5.Focus(); }
                        else if (txtQ4_1.Enabled == true)
                        { txtQ4_1.Focus(); }
                        else if (txtQ4_2.Enabled == true)
                        { txtQ4_2.Focus(); }
                        else if (txtQ4_3.Enabled == true)
                        { txtQ4_3.Focus(); }
                        else if (txtQ2_1.Enabled == true)
                        { txtQ2_1.Focus(); }
                        else if (txtQ2_TTL.Enabled == true)
                        { txtQ2_TTL.Focus(); }
                        else if (txtQ5_1.Enabled == true)
                        { txtQ5_1.Focus(); }
                        else if (txtQ5_TTL.Enabled == true)
                        { txtQ5_TTL.Focus(); }
                        else if (txtQ6_1.Enabled == true)
                        { txtQ6_1.Focus(); }
                        else if (txtQ7_2.Enabled == true)
                        { txtQ7_2.Focus(); }
                        else if (txtQ7_1.Enabled == true)
                        { txtQ7_1.Focus(); }
                        else if (txtQ8_1.Enabled == true)
                        { txtQ8_1.Focus(); }
                        else if (txtLanguage.Enabled == true)
                        { txtLanguage.Focus(); }
                        else if (txtmailtype.Enabled == true)
                        { txtmailtype.Focus(); }
                        else
                        {
                            SaveandLoad();
                        }
                    }


                    return true;
                }
                else
                {
                    Interaction.MsgBox("Invalid Batch Selection", MsgBoxStyle.Information, Constance.gstrappTitle);
                    this.Close();
                    return false;
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            return true;
           // File.AppendAllText(path, Environment.NewLine + "End of loadimage Function:" + DateTime.Now);
        }

        private bool ValidateInfo()
        {
            if (TotalKeystrokes() <= 0)
            {
                if (MessageBox.Show("Do you want to save Blank records?", "Healthtel", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }

        private bool SaveInfo()
        {
            try
            {
                string ImageNumber;
                int iPos;
                string ImagePath = Image.ImagePath;
                string BarcodeVal = string.Empty;

                if (!string.IsNullOrEmpty(ImagePath))
                {
                    if (ImagePath.LastIndexOf("\\") >= ImagePath.Length - 1 & ImagePath.Length > 0)
                    {
                        ImagePath = ImagePath.Substring(0, ImagePath.Length - 1);
                    }
                    iPos = ImagePath.LastIndexOf("\\");
                    ImagePath = ImagePath.Substring(iPos + 1, ImagePath.Length - (iPos + 1));
                    BarcodeVal = ImagePath.Substring(0, ImagePath.IndexOf("."));
                }

                if (Process == Constance.GC_PROCESS_KEY1)
                {
                    key1_hra_v1 checkkey1 = new key1_hra_v1().isImageIDExists(lngImageID);
                    int Key1_HRAID = (checkkey1 == null) ? 0 : checkkey1.Key1_HRAID;
                    key1_hra_v1 objkey1_HRA = new key1_hra_v1(Key1_HRAID);
                    objkey1_HRA.ImageId = lngImageID.ToInt();
                    objkey1_HRA.Image_Number = ImagePath;
                    objkey1_HRA.Respondent_ID = BarcodeVal;//txtRespndentID.Text.Trim();
                    objkey1_HRA.Q1_9 = txtQ1_9.Text.Trim();
                    objkey1_HRA.Q1_1 = txtQ1_1.Text.Trim();
                    objkey1_HRA.Q1_2 = txtQ1_2.Text.Trim();
                    objkey1_HRA.Q1_3 = txtQ1_3.Text.Trim();
                    objkey1_HRA.Q1_4 = txtQ1_4.Text.Trim();
                    objkey1_HRA.Q1_5 = txtQ1_5.Text.Trim();
                    objkey1_HRA.Q1_6 = txtQ1_6.Text.Trim();
                    objkey1_HRA.Q1_7 = txtQ1_7.Text.Trim();
                    objkey1_HRA.Q1_8 = txtQ1_8.Text.Trim();
                    objkey1_HRA.Q3_1 = txtQ3_1.Text.Trim();
                    objkey1_HRA.Q3_2 = txtQ3_2.Text.Trim();
                    objkey1_HRA.Q3_3 = txtQ3_3.Text.Trim();
                    objkey1_HRA.Q3_4 = txtQ3_4.Text.Trim();
                    objkey1_HRA.Q3_5 = txtQ3_5.Text.Trim();
                    objkey1_HRA.Q4_1 = txtQ4_1.Text.Trim();
                    objkey1_HRA.Q4_2 = txtQ4_2.Text.Trim();
                    objkey1_HRA.Q4_3 = txtQ4_3.Text.Trim();
                    objkey1_HRA.Q2_1 = txtQ2_1.Text.Trim();
                    objkey1_HRA.Q2_ttl = txtQ2_TTL.Text.Trim();
                    objkey1_HRA.Q5_1 = txtQ5_1.Text.Trim();
                    objkey1_HRA.Q5_TTL = txtQ5_TTL.Text.Trim();
                    objkey1_HRA.Q6_1 = txtQ6_1.Text.Trim();
                    objkey1_HRA.Q7_2 = txtQ7_2.Text.Trim();
                    objkey1_HRA.Q7_1 = txtQ7_1.Text.Trim();
                    objkey1_HRA.Q8_1 = txtQ8_1.Text.Trim();
                    objkey1_HRA.Language = txtLanguage.Text.Trim();
                    objkey1_HRA.MailType = txtmailtype.Text.Trim();  
                    objkey1_HRA.KeyStroke = TotalKeystrokes().ToInt();
                    objkey1_HRA.userid = Constance.GC_USERID;
                    objkey1_HRA.Store();
                    imagemaster updateImagemasterkey1 = new imagemaster(lngImageID.ToInt());
                    updateImagemasterkey1.Key1 = 2;
                    updateImagemasterkey1.Store();

                    Constance.ImageOutTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                }
                else if (Process == Constance.GC_PROCESS_KEY2)
                {
                    key2_hra_v1 checkkey1 = new key2_hra_v1().isImageIDExists(lngImageID);
                    int Key2_HRAID = (checkkey1 == null) ? 0 : checkkey1.Key1_HRAID;
                    key2_hra_v1 objkey2_HRA = new key2_hra_v1(Key2_HRAID);
                    objkey2_HRA.ImageId = lngImageID.ToInt();
                    objkey2_HRA.Image_Number = ImagePath;
                    objkey2_HRA.Respondent_ID = BarcodeVal; //txtRespndentID.Text.Trim();
                    objkey2_HRA.Q1_9 = txtQ1_9.Text.Trim();
                    objkey2_HRA.Q1_1 = txtQ1_1.Text.Trim();
                    objkey2_HRA.Q1_2 = txtQ1_2.Text.Trim();
                    objkey2_HRA.Q1_3 = txtQ1_3.Text.Trim();
                    objkey2_HRA.Q1_4 = txtQ1_4.Text.Trim();
                    objkey2_HRA.Q1_5 = txtQ1_5.Text.Trim();
                    objkey2_HRA.Q1_6 = txtQ1_6.Text.Trim();
                    objkey2_HRA.Q1_7 = txtQ1_7.Text.Trim();
                    objkey2_HRA.Q1_8 = txtQ1_8.Text.Trim();
                    objkey2_HRA.Q3_1 = txtQ3_1.Text.Trim();
                    objkey2_HRA.Q3_2 = txtQ3_2.Text.Trim();
                    objkey2_HRA.Q3_3 = txtQ3_3.Text.Trim();
                    objkey2_HRA.Q3_4 = txtQ3_4.Text.Trim();
                    objkey2_HRA.Q3_5 = txtQ3_5.Text.Trim();
                    objkey2_HRA.Q4_1 = txtQ4_1.Text.Trim();
                    objkey2_HRA.Q4_2 = txtQ4_2.Text.Trim();
                    objkey2_HRA.Q4_3 = txtQ4_3.Text.Trim();
                    objkey2_HRA.Q2_1 = txtQ2_1.Text.Trim();
                    objkey2_HRA.Q2_ttl = txtQ2_TTL.Text.Trim();
                    objkey2_HRA.Q5_1 = txtQ5_1.Text.Trim();
                    objkey2_HRA.Q5_TTL = txtQ5_TTL.Text.Trim();
                    objkey2_HRA.Q6_1 = txtQ6_1.Text.Trim();
                    objkey2_HRA.Q7_2 = txtQ7_2.Text.Trim();
                    objkey2_HRA.Q7_1 = txtQ7_1.Text.Trim();
                    objkey2_HRA.Q8_1 = txtQ8_1.Text.Trim();
                    objkey2_HRA.Language = txtLanguage.Text.Trim();
                    objkey2_HRA.MailType = txtmailtype.Text.Trim();  
                    objkey2_HRA.KeyStroke = TotalKeystrokes().ToInt();
                    objkey2_HRA.userid = Constance.GC_USERID;
                    objkey2_HRA.Store();

                    imagemaster updateImagemasterkey2 = new imagemaster(lngImageID.ToInt());
                    updateImagemasterkey2.Key2 = 2;
                    updateImagemasterkey2.Store();

                    Constance.ImageOutTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                }
                else if (Process == Constance.GC_PROCESS_COMAPREQC)
                {
                    compareqc_hra_v1 checkkey1 = new compareqc_hra_v1().isImageIDExists(lngImageID);
                    int CompareQC_HRAID = (checkkey1 == null) ? 0 : checkkey1.Key1_HRAID;
                    compareqc_hra_v1 objcompareqc_HRA = new compareqc_hra_v1(CompareQC_HRAID);
                    objcompareqc_HRA.ImageId = lngImageID.ToInt();
                    objcompareqc_HRA.Image_Number = ImagePath;
                    objcompareqc_HRA.Respondent_ID = BarcodeVal; //txtRespndentID.Text.Trim();
                    objcompareqc_HRA.Q1_9 = txtQ1_9.Text.Trim();
                    objcompareqc_HRA.Q1_1 = txtQ1_1.Text.Trim();
                    objcompareqc_HRA.Q1_2 = txtQ1_2.Text.Trim();
                    objcompareqc_HRA.Q1_3 = txtQ1_3.Text.Trim();
                    objcompareqc_HRA.Q1_4 = txtQ1_4.Text.Trim();
                    objcompareqc_HRA.Q1_5 = txtQ1_5.Text.Trim();
                    objcompareqc_HRA.Q1_6 = txtQ1_6.Text.Trim();
                    objcompareqc_HRA.Q1_7 = txtQ1_7.Text.Trim();
                    objcompareqc_HRA.Q1_8 = txtQ1_8.Text.Trim();
                    objcompareqc_HRA.Q3_1 = txtQ3_1.Text.Trim();
                    objcompareqc_HRA.Q3_2 = txtQ3_2.Text.Trim();
                    objcompareqc_HRA.Q3_3 = txtQ3_3.Text.Trim();
                    objcompareqc_HRA.Q3_4 = txtQ3_4.Text.Trim();
                    objcompareqc_HRA.Q3_5 = txtQ3_5.Text.Trim();
                    objcompareqc_HRA.Q4_1 = txtQ4_1.Text.Trim();
                    objcompareqc_HRA.Q4_2 = txtQ4_2.Text.Trim();
                    objcompareqc_HRA.Q4_3 = txtQ4_3.Text.Trim();
                    objcompareqc_HRA.Q2_1 = txtQ2_1.Text.Trim();
                    objcompareqc_HRA.Q2_ttl = txtQ2_TTL.Text.Trim();
                    objcompareqc_HRA.Q5_1 = txtQ5_1.Text.Trim();
                    objcompareqc_HRA.Q5_TTL = txtQ5_TTL.Text.Trim();
                    objcompareqc_HRA.Q6_1 = txtQ6_1.Text.Trim();
                    objcompareqc_HRA.Q7_2 = txtQ7_2.Text.Trim();
                    objcompareqc_HRA.Q7_1 = txtQ7_1.Text.Trim();
                    objcompareqc_HRA.Q8_1 = txtQ8_1.Text.Trim();
                    objcompareqc_HRA.Language = txtLanguage.Text.Trim();
                    objcompareqc_HRA.MailType = txtmailtype.Text.Trim();   
                    objcompareqc_HRA.KeyStroke = TotalKeystrokes().ToInt();
                    objcompareqc_HRA.userid = Constance.GC_USERID;
                    objcompareqc_HRA.Store();
                    imagemaster updateImagemastercompareqc = new imagemaster(lngImageID.ToInt());
                    updateImagemastercompareqc.CompareQC = 2;
                    updateImagemastercompareqc.Store();
                    Constance.ImageOutTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                }

        //        try
        //    {
        //        MySqlParameter[] cParams = new MySqlParameter[27];
        //        cParams[0] = new MySqlParameter("P_Respondent_ID", txtRespndentID.Text);
        //        cParams[1] = new MySqlParameter("P_Q1_9"  ,txtQ1_9.Text);
        //        cParams[2] = new MySqlParameter("P_Q1_1" ,txtQ1_1.Text);
        //        cParams[2] = new MySqlParameter("P_Q1_2 ",txtQ1_2.Text);
        //        cParams[4] = new MySqlParameter("P_ Q1_3" , txtQ1_3.Text);
        //        cParams[5] = new MySqlParameter("P_Q1_4 ",txtQ1_4.Text);
        //        cParams[6] = new MySqlParameter("P_Q1_5  ",txtQ1_5.Text);
        //        cParams[7] = new MySqlParameter("P_Q1_6  ",txtQ1_6.Text);
        //        cParams[8] = new MySqlParameter("P_Q1_7 ",txtQ1_7.Text);
        //        cParams[9] = new MySqlParameter("P_Q1_8 ",txtQ1_8.Text);
        //        cParams[10] = new MySqlParameter("P_Q3_1"  ,txtQ3_1.Text);
        //        cParams[11] = new MySqlParameter("P_Q3_2 ",txtQ3_2.Text);
        //        cParams[12] = new MySqlParameter("P_Q3_3 ",txtQ3_3.Text);
        //        cParams[13] = new MySqlParameter("P_Q3_4 ",txtQ3_4.Text);
        //        cParams[14] = new MySqlParameter("P_Q3_5  ",txtQ3_5.Text);
        //        cParams[15] = new MySqlParameter("P_Q4_1 ",txtQ4_1.Text);
        //        cParams[16] = new MySqlParameter("P_Q4_2",txtQ4_2.Text);
        //        cParams[17] = new MySqlParameter("P_Q4_3" ,txtQ4_3.Text);
        //        cParams[18] = new MySqlParameter("P_Q2_1  ",txtQ2_1.Text);
        //        cParams[19] = new MySqlParameter("P_Q2_ttl  ",txtQ2_TTL.Text);
        //        cParams[20] = new MySqlParameter("P_Q5_1  ",txtQ5_1.Text);
        //        cParams[21] = new MySqlParameter("P_Q5_TTL", txtQ5_TTL.Text);
        //        cParams[22] = new MySqlParameter("P_Q6_1 ",txtQ6_1.Text);
        //        cParams[23] = new MySqlParameter("P_Q7_2  ",txtQ7_2.Text);
        //        cParams[24] = new MySqlParameter("P_Q7_1 ",txtQ7_1.Text);
        //        cParams[25] = new MySqlParameter("P_Q8_1  ",txtQ8_1.Text);
        //        cParams[26] = new MySqlParameter("P_Language",txtLanguage.Text);
        //        String strsql= "CALL Save_" & Process & "(?P_Respondent_ID,?P_Q1_9,?P_Q1_1,?P_Q1_2,?P_ Q1_3,?P_Q1_4,?P_Q1_5,?P_Q1_6,?P_Q1_7,?P_Q1_8,?P_Q3_1,?P_Q3_2,?P_Q3_3,?P_Q3_4,?P_Q3_5,?P_Q4_1,?P_Q4_2,?P_Q4_3,?P_Q2_1,?P_Q2_ttl,?P_Q5_1,?P_Q5_TTL,?P_Q6_1,?P_Q7_2,?P_Q7_1,?P_Q8_1,?P_Language)", CommandType.StoredProcedure, cParams);
        //        return true;

        // Constance.ImageOutTime = DateAndTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        //      //GlobalFunction.saveworklog("worklog", Convert.ToInt32(Imageid) , UserVariable.imageintime, UserVariable.imageouttime, UserVariable.GC_PROCESS_KEY1, UserVariable.GC_VersionStatus);
        //          String strSQL = "Update ImageMaster Set Key1 =2 Where ImageID=" +Imageid ;
           
        //   int iResult =DatabaseClass.NonQuery(strSQL, CommandType.Text);

            
        //    }
        //    catch (Exception EX)
        //    {
        //        MessageBox.Show(EX.ToString());
        //        return false;
        //    }
        //}




                worklog SaveWorklog = new worklog();
                SaveWorklog.UserID = Constance.GC_USERID;
                SaveWorklog.ImageID = lngImageID.ToInt();
                SaveWorklog.In = Convert.ToDateTime(Constance.ImageInTime);
                SaveWorklog.Out = Convert.ToDateTime(Constance.ImageOutTime);
                SaveWorklog.Process = Process;
                SaveWorklog.EXE_Status = Constance.GC_PROJ_VERSIONSTATUS;
                SaveWorklog.Store();

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void RestoreInfo()
        {
            try
            {
                getCompareqcData = objCompareQC.CompareQCDatas(lngImageID.ToInt());

                if (getCompareqcData == null)
                {
                    getkey2Data = objKey2.Key2Datas(lngImageID.ToInt());
                }
                getkey1Data = objKey1.Key1Datas(lngImageID.ToInt());

                if (getCompareqcData != null)
                {
                    txtRespndentID.Text = getCompareqcData.Respondent_ID;
                    txtQ1_9.Text = getCompareqcData.Q1_9;
                    txtQ1_1.Text = getCompareqcData.Q1_1;
                    txtQ1_2.Text = getCompareqcData.Q1_2;
                    txtQ1_3.Text = getCompareqcData.Q1_3;
                    txtQ1_4.Text = getCompareqcData.Q1_4;
                    txtQ1_5.Text = getCompareqcData.Q1_5;
                    txtQ1_6.Text = getCompareqcData.Q1_6;
                    txtQ1_7.Text = getCompareqcData.Q1_7;
                    txtQ1_8.Text = getCompareqcData.Q1_8;
                    txtQ3_1.Text = getCompareqcData.Q3_1;
                    txtQ3_2.Text = getCompareqcData.Q3_2;
                    txtQ3_3.Text = getCompareqcData.Q3_3;
                    txtQ3_4.Text = getCompareqcData.Q3_4;
                    txtQ3_5.Text = getCompareqcData.Q3_5;
                    txtQ4_1.Text = getCompareqcData.Q4_1;
                    txtQ4_2.Text = getCompareqcData.Q4_2;
                    txtQ4_3.Text = getCompareqcData.Q4_3;
                    txtQ2_1.Text = getCompareqcData.Q2_1;
                    txtQ2_TTL.Text = getCompareqcData.Q2_ttl;
                    txtQ5_1.Text = getCompareqcData.Q5_1;
                    txtQ5_TTL.Text = getCompareqcData.Q5_TTL;
                    txtQ6_1.Text = getCompareqcData.Q6_1;
                    txtQ7_2.Text = getCompareqcData.Q7_2;
                    txtQ7_1.Text = getCompareqcData.Q7_1;
                    txtQ8_1.Text = getCompareqcData.Q8_1;
                    txtLanguage.Text = getCompareqcData.Language;
                   txtmailtype.Text = getCompareqcData.MailType;
                    txtKey2User.Text = getCompareqcData.UserName;
                }
                else if (getkey2Data != null)
                {
                    txtRespndentID.Text = getkey2Data.Respondent_ID;
                    txtQ1_9.Text = getkey2Data.Q1_9;
                    txtQ1_1.Text = getkey2Data.Q1_1;
                    txtQ1_2.Text = getkey2Data.Q1_2;
                    txtQ1_3.Text = getkey2Data.Q1_3;
                    txtQ1_4.Text = getkey2Data.Q1_4;
                    txtQ1_5.Text = getkey2Data.Q1_5;
                    txtQ1_6.Text = getkey2Data.Q1_6;
                    txtQ1_7.Text = getkey2Data.Q1_7;
                    txtQ1_8.Text = getkey2Data.Q1_8;
                    txtQ3_1.Text = getkey2Data.Q3_1;
                    txtQ3_2.Text = getkey2Data.Q3_2;
                    txtQ3_3.Text = getkey2Data.Q3_3;
                    txtQ3_4.Text = getkey2Data.Q3_4;
                    txtQ3_5.Text = getkey2Data.Q3_5;
                    txtQ4_1.Text = getkey2Data.Q4_1;
                    txtQ4_2.Text = getkey2Data.Q4_2;
                    txtQ4_3.Text = getkey2Data.Q4_3;
                    txtQ2_1.Text = getkey2Data.Q2_1;
                    txtQ2_TTL.Text = getkey2Data.Q2_ttl;
                    txtQ5_1.Text = getkey2Data.Q5_1;
                    txtQ5_TTL.Text = getkey2Data.Q5_TTL;
                    txtQ6_1.Text = getkey2Data.Q6_1;
                    txtQ7_2.Text = getkey2Data.Q7_2;
                    txtQ7_1.Text = getkey2Data.Q7_1;
                    txtQ8_1.Text = getkey2Data.Q8_1;
                    txtLanguage.Text = getkey2Data.Language;
                    txtmailtype.Text = getkey2Data.MailType;
                    txtKey2User.Text = getkey2Data.UserName;
                    
                    
                    
                    
                  
                }

                if (getkey1Data != null)
                {
                    txtRespndentID.Tag = getkey1Data.Respondent_ID;
                    txtQ1_9.Tag = getkey1Data.Q1_9;
                    txtQ1_1.Tag = getkey1Data.Q1_1;
                    txtQ1_2.Tag = getkey1Data.Q1_2;
                    txtQ1_3.Tag = getkey1Data.Q1_3;
                    txtQ1_4.Tag = getkey1Data.Q1_4;
                    txtQ1_5.Tag = getkey1Data.Q1_5;
                    txtQ1_6.Tag = getkey1Data.Q1_6;
                    txtQ1_7.Tag = getkey1Data.Q1_7;
                    txtQ1_8.Tag = getkey1Data.Q1_8;
                    txtQ3_1.Tag = getkey1Data.Q3_1;
                    txtQ3_2.Tag = getkey1Data.Q3_2;
                    txtQ3_3.Tag = getkey1Data.Q3_3;
                    txtQ3_4.Tag = getkey1Data.Q3_4;
                    txtQ3_5.Tag = getkey1Data.Q3_5;
                    txtQ4_1.Tag = getkey1Data.Q4_1;
                    txtQ4_2.Tag = getkey1Data.Q4_2;
                    txtQ4_3.Tag = getkey1Data.Q4_3;
                    txtQ2_1.Tag = getkey1Data.Q2_1;
                    txtQ2_TTL.Tag = getkey1Data.Q2_ttl;
                    txtQ5_1.Tag = getkey1Data.Q5_1;
                    txtQ5_TTL.Tag = getkey1Data.Q5_TTL;
                    txtQ6_1.Tag = getkey1Data.Q6_1;
                    txtQ7_2.Tag = getkey1Data.Q7_2;
                    txtQ7_1.Tag = getkey1Data.Q7_1;
                    txtQ8_1.Tag = getkey1Data.Q8_1;
                    txtLanguage.Tag = getkey1Data.Language;
                    txtmailtype.Tag = getkey1Data.MailType;
                    txtKey1User.Text = getkey1Data.UserName;
               
                }

                if (txtRespndentID.Text== txtRespndentID.Tag.ToString())
                {
                    txtRespndentID.Enabled = false;
                    txtRespndentID.BackColor = Color.White;
                }
                else
                {
                    txtRespndentID.Enabled = true;
                    txtRespndentID.Text = "";
                    txtRespndentID.BackColor = Color.Yellow;
                }

                if (txtQ1_9.Text.ToUpper() == txtQ1_9.Tag.ToString().ToUpper())
                {
                    txtQ1_9.Enabled = false;
                    txtQ1_9.BackColor = Color.White;
                }
                else
                {
                    txtQ1_9.Enabled = true;
                    txtQ1_9.Text = "";
                    txtQ1_9.BackColor = Color.Yellow;
                }

                if (txtQ1_1.Text.ToUpper() == txtQ1_1.Tag.ToString().ToUpper())
                {
                    txtQ1_1.Enabled = false;
                    txtQ1_1.BackColor = Color.White;
                }
                else
                {
                    txtQ1_1.Enabled = true;
                    txtQ1_1.Text = "";
                    txtQ1_1.BackColor = Color.Yellow;
                }

                if (txtQ1_2.Text.ToUpper() == txtQ1_2.Tag.ToString().ToUpper())
                {
                    txtQ1_2.Enabled = false;
                    txtQ1_2.BackColor = Color.White;
                }
                else
                {
                    txtQ1_2.Enabled = true;
                    txtQ1_2.Text = "";
                    txtQ1_2.BackColor = Color.Yellow;
                }

                if (txtQ1_3.Text.ToUpper() == txtQ1_3.Tag.ToString().ToUpper())
                {
                    txtQ1_3.Enabled = false;
                    txtQ1_3.BackColor = Color.White;
                }
                else
                {
                    txtQ1_3.Enabled = true;
                    txtQ1_3.Text = "";
                    txtQ1_3.BackColor = Color.Yellow;
                }

                if (txtQ1_4.Text.ToUpper() == txtQ1_4.Tag.ToString().ToUpper())
                {
                    txtQ1_4.Enabled = false;
                    txtQ1_4.BackColor = Color.White;
                }
                else
                {
                    txtQ1_4.Enabled = true;
                    txtQ1_4.Text = "";
                    txtQ1_4.BackColor = Color.Yellow;
                }

                if (txtQ1_5.Text.ToUpper() == txtQ1_5.Tag.ToString().ToUpper())
                {
                    txtQ1_5.Enabled = false;
                    txtQ1_5.BackColor = Color.White;
                }
                else
                {
                    txtQ1_5.Enabled = true;
                    txtQ1_5.Text = "";
                    txtQ1_5.BackColor = Color.Yellow;
                }

                if (txtQ1_6.Text.ToUpper() == txtQ1_6.Tag.ToString().ToUpper())
                {
                    txtQ1_6.Enabled = false;
                    txtQ1_6.BackColor = Color.White;
                }
                else
                {
                    txtQ1_6.Enabled = true;
                    txtQ1_6.Text = "";
                    txtQ1_6.BackColor = Color.Yellow;
                }

                if (txtQ1_7.Text.ToUpper() == txtQ1_7.Tag.ToString().ToUpper())
                {
                    txtQ1_7.Enabled = false;
                    txtQ1_7.BackColor = Color.White;
                }
                else
                {
                    txtQ1_7.Enabled = true;
                    txtQ1_7.Text = "";
                    txtQ1_7.BackColor = Color.Yellow;
                }

                if (txtQ1_8.Text.ToUpper() == txtQ1_8.Tag.ToString().ToUpper())
                {
                    txtQ1_8.Enabled = false;
                    txtQ1_8.BackColor = Color.White;
                }
                else
                {
                    txtQ1_8.Enabled = true;
                    txtQ1_8.Text = "";
                    txtQ1_8.BackColor = Color.Yellow;
                }

                if (txtQ3_1.Text.ToUpper() == txtQ3_1.Tag.ToString().ToUpper())
                {
                    txtQ3_1.Enabled = false;
                    txtQ3_1.BackColor = Color.White;
                }
                else
                {
                    txtQ3_1.Enabled = true;
                    txtQ3_1.Text = "";
                    txtQ3_1.BackColor = Color.Yellow;
                }

                if (txtQ3_2.Text.ToUpper() == txtQ3_2.Tag.ToString().ToUpper())
                {
                    txtQ3_2.Enabled = false;
                    txtQ3_2.BackColor = Color.White;
                }
                else
                {
                    txtQ3_2.Enabled = true;
                    txtQ3_2.Text = "";
                    txtQ3_2.BackColor = Color.Yellow;
                }

                if (txtQ3_3.Text.ToUpper() == txtQ3_3.Tag.ToString().ToUpper())
                {
                    txtQ3_3.Enabled = false;
                    txtQ3_3.BackColor = Color.White;
                }
                else
                {
                    txtQ3_3.Enabled = true;
                    txtQ3_3.Text = "";
                    txtQ3_3.BackColor = Color.Yellow;
                }

                if (txtQ3_4.Text.ToUpper() == txtQ3_4.Tag.ToString().ToUpper())
                {
                    txtQ3_4.Enabled = false;
                    txtQ3_4.BackColor = Color.White;
                }
                else
                {
                    txtQ3_4.Enabled = true;
                    txtQ3_4.Text = "";
                    txtQ3_4.BackColor = Color.Yellow;
                }

                if (txtQ3_5.Text.ToUpper() == txtQ3_5.Tag.ToString().ToUpper())
                {
                    txtQ3_5.Enabled = false;
                    txtQ3_5.BackColor = Color.White;
                }
                else
                {
                    txtQ3_5.Enabled = true;
                    txtQ3_5.Text = "";
                    txtQ3_5.BackColor = Color.Yellow;
                }

                if (txtQ4_1.Text.ToUpper() == txtQ4_1.Tag.ToString().ToUpper())
                {
                    txtQ4_1.Enabled = false;
                    txtQ4_1.BackColor = Color.White;
                }
                else
                {
                    txtQ4_1.Enabled = true;
                    txtQ4_1.Text = "";
                    txtQ4_1.BackColor = Color.Yellow;
                }

                if (txtQ4_2.Text.ToUpper() == txtQ4_2.Tag.ToString().ToUpper())
                {
                    txtQ4_2.Enabled = false;
                    txtQ4_2.BackColor = Color.White;
                }
                else
                {
                    txtQ4_2.Enabled = true;
                    txtQ4_2.Text = "";
                    txtQ4_2.BackColor = Color.Yellow;
                }

                if (txtQ4_3.Text.ToUpper() == txtQ4_3.Tag.ToString().ToUpper())
                {
                    txtQ4_3.Enabled = false;
                    txtQ4_3.BackColor = Color.White;
                }
                else
                {
                    txtQ4_3.Enabled = true;
                    txtQ4_3.Text = "";
                    txtQ4_3.BackColor = Color.Yellow;
                }

                if (txtQ2_1.Text.ToUpper() == txtQ2_1.Tag.ToString().ToUpper())
                {
                    txtQ2_1.Enabled = false;
                    txtQ2_1.BackColor = Color.White;
                }
                else
                {
                    txtQ2_1.Enabled = true;
                    txtQ2_1.Text = "";
                    txtQ2_1.BackColor = Color.Yellow;
                }

                if (txtQ2_TTL.Text.ToUpper() == txtQ2_TTL.Tag.ToString().ToUpper())
                {
                    txtQ2_TTL.Enabled = false;
                    txtQ2_TTL.BackColor = Color.White;
                }
                else
                {
                    txtQ2_TTL.Enabled = true;
                    txtQ2_TTL.Text = "";
                    txtQ2_TTL.BackColor = Color.Yellow;
                }

                if (txtQ5_1.Text.ToUpper() == txtQ5_1.Tag.ToString().ToUpper())
                {
                    txtQ5_1.Enabled = false;
                    txtQ5_1.BackColor = Color.White;
                }
                else
                {
                    txtQ5_1.Enabled = true;
                    txtQ5_1.Text = "";
                    txtQ5_1.BackColor = Color.Yellow;
                }

                if (txtQ5_TTL.Text.ToUpper() == txtQ5_TTL.Tag.ToString().ToUpper())
                {
                    txtQ5_TTL.Enabled = false;
                    txtQ5_TTL.BackColor = Color.White;
                }
                else
                {
                    txtQ5_TTL.Enabled = true;
                    txtQ5_TTL.Text = "";
                    txtQ5_TTL.BackColor = Color.Yellow;
                }

                if (txtQ6_1.Text.ToUpper() == txtQ6_1.Tag.ToString().ToUpper())
                {
                    txtQ6_1.Enabled = false;
                    txtQ6_1.BackColor = Color.White;
                }
                else
                {
                    txtQ6_1.Enabled = true;
                    txtQ6_1.Text = "";
                    txtQ6_1.BackColor = Color.Yellow;
                }

                if (txtQ7_2.Text.ToUpper() == txtQ7_2.Tag.ToString().ToUpper())
                {
                    txtQ7_2.Enabled = false;
                    txtQ7_2.BackColor = Color.White;
                }
                else
                {
                    txtQ7_2.Enabled = true;
                    txtQ7_2.Text = "";
                    txtQ7_2.BackColor = Color.Yellow;
                }

                if (txtQ7_1.Text.ToUpper() == txtQ7_1.Tag.ToString().ToUpper())
                {
                    txtQ7_1.Enabled = false;
                    txtQ7_1.BackColor = Color.White;
                }
                else
                {
                    txtQ7_1.Enabled = true;
                    txtQ7_1.Text = "";
                    txtQ7_1.BackColor = Color.Yellow;
                }
                if (txtQ8_1.Text.ToUpper() == txtQ8_1.Tag.ToString().ToUpper())
                {
                    txtQ8_1.Enabled = false;
                    txtQ8_1.BackColor = Color.White;
                }
                else
                {
                    txtQ8_1.Enabled = true;
                    txtQ8_1.Text = "";
                    txtQ8_1.BackColor = Color.Yellow;
                }
                if (txtLanguage.Text.ToUpper() == txtLanguage.Tag.ToString().ToUpper())
                {
                    txtLanguage.Enabled = false;
                    txtLanguage.BackColor = Color.White;
                }
                else
                {
                    txtLanguage.Enabled = true;
                    txtLanguage.Text = "";
                    txtLanguage.BackColor = Color.Yellow;
                }

                if (txtmailtype.Text.ToUpper() == txtmailtype.Tag.ToString().ToUpper())
                {
                    txtmailtype.Enabled = false;
                    txtmailtype.BackColor = Color.White;
                }
                else
                {
                    txtmailtype.Enabled = true;
                    txtmailtype.Text = "";
                    txtmailtype.BackColor = Color.Yellow;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SaveandLoad()
        {
            if (ValidateInfo() == true)
            {
                //File.AppendAllText(path, Environment.NewLine + "after Validate INFO:" + DateTime.Now);
                if (SaveInfo() == true)
                {
                   //File.AppendAllText(path, Environment.NewLine + "after SAVE INFO:" + DateTime.Now);
                    LoadImage();
                  // File.AppendAllText(path, Environment.NewLine + "after Load Image:" + DateTime.Now);
                }
            }
        }

        private void EnableFields()
        {
            txtRespndentID.Enabled = true;
            txtQ1_9.Enabled = true;
            txtQ1_1.Enabled = true;
            txtQ1_2.Enabled = true;
            txtQ1_3.Enabled = true;
            txtQ1_4.Enabled = true;
            txtQ1_5.Enabled = true;
            txtQ1_6.Enabled = true;
            txtQ1_7.Enabled = true;
            txtQ1_8.Enabled = true;
            txtQ3_1.Enabled = true;
            txtQ3_2.Enabled = true;
            txtQ3_3.Enabled = true;
            txtQ3_4.Enabled = true;
            txtQ3_5.Enabled = true;
            txtQ4_1.Enabled = true;
            txtQ4_2.Enabled = true;
            txtQ4_3.Enabled = true;
            txtQ2_1.Enabled = true;
            txtQ2_TTL.Enabled = true;
            txtQ5_1.Enabled = true;
            txtQ5_TTL.Enabled = true;
            txtQ6_1.Enabled = true;
            txtQ7_2.Enabled = true;
            txtQ7_1.Enabled = true;
            txtQ8_1.Enabled = true;
            txtLanguage.Enabled = true;
        }

        private void HRAV1_Load(object sender, EventArgs e)
        {
            if (BatchType == 0)
            {
                this.Text = string.Format("Healthtel HRA :: {0}", Process);
            }
            else if (BatchType == 1)
            {
                this.Text = string.Format("Healthtel CIP :: {0}", Process);
            }
            else if (BatchType == 4)
            {
                this.Text = string.Format("Healthtel HRA V1 :: {0}", Process);
            }
            else if (BatchType == 5)
            {
                this.Text = string.Format("Healthtel pediatric :: {0}", Process);
            }
            LoadImage();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void HRAV1_FormClosing(object sender, FormClosingEventArgs e)
        {
            objImagemaster.ImageReset(Process, lngImageID);
        }

        private void HRAV1_KeyDown(object sender, KeyEventArgs e)
           {
            if (e.Alt & e.KeyCode == Keys.Right)
            {
                IGImageViewer.NextImage(sender, e);
            }
            else if (e.Alt & e.KeyCode == Keys.Left)
            {
                IGImageViewer.PrevImage(sender, e);
            }
            else if (e.Control & (e.KeyCode == Keys.Oemplus || e.KeyCode == Keys.Add))
            {
                IGImageViewer.ZoomIn(sender, e);
            }
            else if (e.Control & (e.KeyCode == Keys.OemMinus || e.KeyCode == Keys.Subtract))
            {
                IGImageViewer.ZoomOut(sender, e);
            }
            else if (e.Control == true & (e.KeyCode == Keys.D1 | e.KeyCode == Keys.NumPad1))
            {
                IGImageViewer.RotateLeft(sender, e);
            }
            else if (e.Control == true & (e.KeyCode == Keys.D2 | e.KeyCode == Keys.NumPad2))
            {
                IGImageViewer.RotateRight(sender, e);
            }
            else if (e.Control & e.KeyCode == Keys.Right)
            {
                IGImageViewer.PageRight();
            }
            else if (e.Control & e.KeyCode == Keys.Left)
            {
                IGImageViewer.PageLeft();
            }
            else if (e.Control & e.KeyCode == Keys.Down)
            {
                IGImageViewer.PageDown();
            }
            else if (e.Control & e.KeyCode == Keys.Up)
            {
                IGImageViewer.PageUp();
            }
            else if (e.Control & e.KeyCode == Keys.PageUp)
            {
                IGImageViewer.PageHome();
            }
            else if (e.Control & e.KeyCode == Keys.Next)
            {
                IGImageViewer.PageEnd();
            }
            //else if (e.Control & e.KeyCode == Keys.Home)
            //{
            //    IGImageViewer.firstpage();
            //}
            //else if (e.Control & e.KeyCode == Keys.End)
            //{
            //    IGImageViewer.lastpage();
            //}
            else if (e.KeyCode == Keys.F5)
            {
                strImageFit = IGImageViewer.ImageHorizontalScroll.Value + "," + IGImageViewer.ImageVerticalScroll.Value;
                strImageSize = IGImageViewer.ImageSize.Width + "," + IGImageViewer.ImageSize.Height;
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageFit, strImageFit);
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageSize, strImageSize);
            }
            else if (e.KeyCode == Keys.F6)
            {
                //IGImageViewer.resizeimg();
                strImageFit = IGImageViewer.ImageHorizontalScroll.Minimum + "," + IGImageViewer.ImageVerticalScroll.Minimum;
                strImageSize = "";
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageFit, strImageFit);
                Interaction.SaveSetting(Constance.GC_PROJ_APPNAME, Constance.GC_PROJ_SECTION, Constance.GC_PROJ_KEY_ImageSize, strImageSize);

                IGImageViewer.ImageClear();
                IGImageViewer.ImageName = Image.ImagePath;
                IGImageViewer.LoadImage();
            }
            else if (e.Control & e.KeyCode == Keys.F7)
            {
                //IGImageViewer.imgfitwidth();
            }
            else if (e.Control & e.KeyCode == Keys.F8)
            {
                //IGImageViewer.imgfitscreen();
            }
            else if (e.KeyCode == Keys.F1)
            {
                EnableFields();
            }
        }

        private void txtmailtype_TextChanged(object sender, EventArgs e)
        {
            txtChanged(sender, e, txtmailtype);
        }

        private void txtmailtype_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e, txtmailtype);
        }

        private void txtmailtype_Enter(object sender, EventArgs e)
        {
            txtEnter(sender, e, txtmailtype);
        }

       
    }
}
