﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DataAccessLayer.GlobalDB;
using DataAccessLayer.ProjectDB;
using App.Base;

namespace Healthtel_MRT
{
    public partial class FrmExport : Form
    {
        public FrmExport()
        {
            InitializeComponent();
        }

        #region Variables

        int BatchID, BatchType;
        string ProjectName;
        batchmaster objBatchMaster = new batchmaster();
        imagemaster objImageMaster = new imagemaster();
        key1 objKey1 = new key1();
        key2 objKey2 = new key2();
        compareqc objCompareQC = new compareqc();

        List<batchmaster> BatchList = new List<batchmaster>();
        List<imagemaster> ImageList = new List<imagemaster>();
        List<key1> Key1List = new List<key1>();
        List<key2> Key2List = new List<key2>();
        List<compareqc> ComapreqcList = new List<compareqc>();

        #endregion

        #region Help Methods

        private void loadBatch()
        {
            List<batchmaster> BatchList = new List<batchmaster>();
            BatchList = objBatchMaster.getBatchList();
            if (BatchList.Count > 0)
            {
                cmbBatch.DisplayMember = "Name";
                cmbBatch.ValueMember = "ID";
                cmbBatch.DataSource = BatchList;
                cmbBatch.Focus();
            }
        }

        #endregion

        #region Events

        private void FrmExport_Load(object sender, EventArgs e)
        {
            loadBatch();
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                string FileName = "";
                string Delimitter = "";
                bool ExportFile = false;
                FolderBrowserDialog fbd = new FolderBrowserDialog();
                DialogResult result = fbd.ShowDialog();
                string ExportPath = null;

                if (result == DialogResult.OK)
                {
                    ExportPath = fbd.SelectedPath;
                }
                else
                {
                    return;
                }

                //Checks whether the fields are empty
                if (string.IsNullOrEmpty(cmbBatch.Text))
                {
                    MessageBox.Show("Select Batch");
                    return;
                }
                else if (string.IsNullOrEmpty(cmbExportFrom.Text))
                {
                    MessageBox.Show("Export From field can not be left blank");
                    return;
                }
                else if (string.IsNullOrEmpty(cmbFileType.Text))
                {
                    MessageBox.Show("Select File Type");
                    return;
                }
                else if (cmbFileType.Text == ".txt")
                {
                    if (string.IsNullOrEmpty(cmbDelimittter.Text))
                    {
                        MessageBox.Show("Select the Delimetter");
                        return;
                    }
                }

                string KeyVal = null;

                var _with1 = cmbExportFrom;
                KeyVal = _with1.Text;

                BatchID = Convert.ToInt32(cmbBatch.SelectedValue);

                BatchType = objBatchMaster.getSelectedBatch(BatchID).BatchType.ToInt();
                List<Export_HRA> BatchExport_HRA = new List<Export_HRA>();
                List<Export_HRA_MailType> BatchExport_HRA_MailType = new List<Export_HRA_MailType>();
                List<Export> BatchExport = new List<Export>();
                List<Export_Hedis> BatchExport_Hedis = new List<Export_Hedis>();
                List<Export_HRA_V1> BatchExport_HRA_V1 = new List<Export_HRA_V1>();
                List<Export_HRA_V1_MailType> BatchExport_HRA_V1_MailType = new List<Export_HRA_V1_MailType>();
                List<Export_pediotric> batchExport_pediatric = new List<Export_pediotric>();

                if (BatchType == 1)
                {
                    BatchExport_HRA = objImageMaster.BatchExport_HRA(BatchID, KeyVal);
                }

                else if (BatchType == 0)
                {
                    BatchExport_HRA_MailType = objImageMaster.BatchExport_HRA_MailType(BatchID, KeyVal);
                }
                else if (BatchType == 2)
                {
                    if (KeyVal == "KeyQC")
                    {
                        KeyVal = "COMPAREQC";
                    }
                    BatchExport = objImageMaster.BatchExport(BatchID, KeyVal);
                }
                else if (BatchType == 3)
                {
                    BatchExport_Hedis = objImageMaster.BatchExport_HEDIS(BatchID, KeyVal);
                }

                else if (BatchType == 4)
                {
                    BatchExport_HRA_V1_MailType = objImageMaster.BatchExport_Hra_v1_MailType(BatchID, KeyVal);
                    //BatchExport_HRA_V1 = objImageMaster.BatchExport_Hra_v1(BatchID, KeyVal);
                }
                else if (BatchType == 5)
                {
                    batchExport_pediatric = objImageMaster.BatchExport_pediatric(BatchID, KeyVal);
                }

                if (BatchType == 0)
                {
                    ProjectName = "Healthtel_HRA";
                }
                else if (BatchType == 1)
                {
                    ProjectName = "Healthtel_CIP";
                }
                else if (BatchType == 2)
                {
                    ProjectName = "Healthtel_MRD";
                    if (KeyVal.ToString().ToUpper() == "KEY2")
                    {
                        MessageBox.Show("Key2 is not available in MRD Type");
                        return;
                    }
                }
                else if (BatchType == 3)
                {
                    ProjectName = "Healthtel_HEDIS";
                    if (KeyVal.ToString().ToUpper() == "KEY2")
                    {
                        MessageBox.Show("Key2 is not available in HEDIS Type");
                        return;
                    }
                }
                else if (BatchType == 4)
                {
                    ProjectName = "Healthtel_HRA_V1";
                    // if (KeyVal.ToString().ToUpper() == "KEY2")
                    {
                        //MessageBox.Show("Key2 is not available in HEDIS Type");
                        //return;
                    }
                }
                else if (BatchType == 5)
                {
                    ProjectName = "Healthtel_PEDIATRIC";
                    //if (KeyVal.ToString().ToUpper() == "KEY2")
                    //{
                    //    MessageBox.Show("Key2 is not available in HEDIS Type");
                    //    return;
                    //}

                }

                switch (cmbDelimittter.SelectedIndex)
                {
                    case 0:
                        Delimitter = "|";
                        break;
                    case 1:
                        Delimitter = ",";
                        break;
                    case 2:
                        Delimitter = ";";
                        break;
                    default:
                        Delimitter = "|";
                        break;
                }

                switch (cmbFileType.SelectedIndex)
                {
                    case 0:

                        if (BatchType == 2)
                        {
                            if (KeyVal == "COMPAREQC")
                            {
                                FileName = ExportPath + "\\" + ProjectName + "_" + cmbBatch.Text + "_" + "KEYQC " + "_Exported_Data.txt";
                            }
                            else
                            {
                                FileName = ExportPath + "\\" + ProjectName + "_" + cmbBatch.Text + "_" + KeyVal + "_Exported_Data.txt";
                            }

                        }
                        else
                        {
                            FileName = ExportPath + "\\" + ProjectName + "_" + cmbBatch.Text + "_" + KeyVal + "_Exported_Data.txt";
                        }
                        if (BatchExport.Count > 0)
                        {
                            var item = BatchExport.Select(x => new
                            {
                                IMAGE_NAME = x.IMAGE_NAME,
                                MEMBER_ID = x.MEMBER_ID,
                                BAR_CODE = x.Bar_Code,
                                FIRSTNAME = x.FIRSTNAME,
                                LASTNAME = x.LASTNAME,
                                PHONE_CAPTURE = x.PHONE_CAPTURE,
                                ADDRESS_OVERRIDE = x.ADDRESS_OVERRIDE,
                                ADDRESS_1 = x.ADDRESS_1,
                                ADDRESS_2 = x.ADDRESS_2,
                                CITY = x.CITY,
                                STATE = x.STATE,
                                ZIP = x.ZIP,
                                DOB = x.DOB,
                                DOS = x.DOS,
                                PROVIDER_SIGNATURE = x.PROVIDER_SIGNATURE,
                                NOT_OPTIN = x.NOT_OPTIN,
                                COMP_EXAM1 = x.COMP_EXAM1,
                                COMP_EXAM2 = x.COMP_EXAM2,
                                COMP_EXAM3 = x.COMP_EXAM3,
                                MERCH_CARD_15 = x.MERCH_CARD_15,
                                FORM_SCAN = x.FORM_SCAN,
                                INTERACTION_DATE_TIME = x.INTERACTION_DATE_TIME,
                                IMAGEPATH = x.IMAGEPATH,
                                User_Name = x.User_Name,
                            }).ToList();

                            ExportFile = IGUtilities.ExportToTxt(item, Delimitter, FileName);
                        }
                        else if (BatchExport_HRA.Count > 0)
                        {
                            var item = BatchExport_HRA.Select(x => new
                            {
                                ImagePath = x.ImagePath,
                                RESPONDENT_ID = x.RESPONDENT_ID,
                                Q1_1 = x.Q1_1,
                                Q1_2 = x.Q1_2,
                                Q1_3 = x.Q1_3,
                                Q1_4 = x.Q1_4,
                                Q1_5 = x.Q1_5,
                                Q1_6 = x.Q1_6,
                                Q1_7 = x.Q1_7,
                                Q1_8 = x.Q1_8,
                                Q2_1 = x.Q2_1,
                                Q2_TTL_1 = x.Q2_TTL,
                                Q3_1 = x.Q3_1,
                                Q3_2 = x.Q3_2,
                                Q3_3 = x.Q3_3,
                                Q3_4 = x.Q3_4,
                                Q3_5 = x.Q3_5,
                                Q4_1 = x.Q4_1,
                                Q4_2 = x.Q4_2,
                                Q5_1 = x.Q5_1,
                                Q5_TTL = x.Q5_2,
                                Q6_1 = x.Q6_1,
                                Q7_1 = x.Q7_1,
                                Q7_2 = x.Q7_2,
                                Q8_1 = x.Q8_1,
                                Q9_1 = x.Q9_1,
                                LANGUAGE = x.LANGUAGE,
                                User_Name = x.User_Name
                            }).ToList();
                            ExportFile = IGUtilities.ExportToTxt(item, Delimitter, FileName);
                        }
                        else if (BatchExport_HRA_MailType.Count > 0)
                        {
                            var item = BatchExport_HRA_MailType.Select(x => new
                            {
                                ImagePath = x.ImagePath,
                                RESPONDENT_ID = x.RESPONDENT_ID,
                                Q1_1 = x.Q1_1,
                                Q1_2 = x.Q1_2,
                                Q1_3 = x.Q1_3,
                                Q1_4 = x.Q1_4,
                                Q1_5 = x.Q1_5,
                                Q1_6 = x.Q1_6,
                                Q1_7 = x.Q1_7,
                                Q1_8 = x.Q1_8,
                                Q2_1 = x.Q2_1,
                                Q2_TTL_1 = x.Q2_TTL,
                                Q3_1 = x.Q3_1,
                                Q3_2 = x.Q3_2,
                                Q3_3 = x.Q3_3,
                                Q3_4 = x.Q3_4,
                                Q3_5 = x.Q3_5,
                                Q4_1 = x.Q4_1,
                                Q4_2 = x.Q4_2,
                                Q5_1 = x.Q5_1,
                                Q5_TTL = x.Q5_2,
                                Q6_1 = x.Q6_1,
                                Q7_1 = x.Q7_1,
                                Q7_2 = x.Q7_2,
                                Q8_1 = x.Q8_1,
                                Q9_1 = x.Q9_1,
                                LANGUAGE = x.LANGUAGE,
                                MailType = x.MailType,
                                User_Name = x.User_Name
                            }).ToList();
                            ExportFile = IGUtilities.ExportToTxt(item, Delimitter, FileName);
                        }
                        else if (batchExport_pediatric.Count > 0)
                        {
                            var item = batchExport_pediatric.Select(x => new
                            {
                                ImagePath = x.ImagePath,
                                Barcode = x.Barcode,
                                Q34 = x.Q34,
                                Q33 = x.Q33,
                                Q1 = x.Q1,
                                Q2 = x.Q2,
                                Q3 = x.Q3,
                                Q4 = x.Q4,
                                Q5 = x.Q5,
                                Q6 = x.Q6,
                                Q8 = x.Q8,
                                Q9 = x.Q9,
                                Q10 = x.Q10,
                                Q11 = x.Q11,
                                Q12 = x.Q12,
                                Q13 = x.Q13,
                                Q14 = x.Q14,
                                Q15 = x.Q15,
                                Q16 = x.Q16,
                                Q17 = x.Q17,
                                Q18 = x.Q18,
                                Q32 = x.Q32,
                                Q29 = x.Q29,
                                Q19 = x.Q19,
                                Q20 = x.Q20,
                                Q21 = x.Q21,
                                Q22 = x.Q22,
                                Q23 = x.Q23,
                                Q24 = x.Q24,
                                Q25 = x.Q25,
                                Q26 = x.Q26,
                                Q27 = x.Q27,
                                Q28 = x.Q28,
                                Q7 = x.Q7,
                                Q31 = x.Q31,
                                Q30 = x.Q30,


                                //Q34 = x.Q1,
                                //Q33 = x.Q2,

                                //Q3 = x.Q1,
                                //Q4 = x.Q2,
                                //Q5 = x.Q3,
                                //Q6 = x.Q4,
                                //Q7 = x.Q5,
                                //Q8 = x.Q6,
                                //Q9 = x.Q8,
                                //Q10 = x.Q9,
                                //Q11 = x.Q10,
                                //Q12 = x.Q11,
                                //Q13 = x.Q12,
                                //Q14 = x.Q13,
                                //Q15 = x.Q14,
                                //Q16 = x.Q15,
                                //Q17 = x.Q16,
                                //Q18 = x.Q17,
                                //Q19 = x.Q18,
                                //Q20 = x.Q32,
                                //Q21 = x.Q29,
                                //Q22 = x.Q19,
                                //Q23 = x.Q20,
                                //Q24 = x.Q21,
                                //Q25 = x.Q22,
                                //Q26 = x.Q23,
                                //Q27 = x.Q24,
                                //Q28 = x.Q25,
                                //Q29 = x.Q26,
                                //Q30 = x.Q27,
                                //Q31 = x.Q28,
                                //Q32 = x.Q7,
                                //Q33 = x.Q31,
                                //Q34 = x.Q30,
                                User_Name = x.User_Name,
                            }).ToList();
                            ExportFile = IGUtilities.ExportToTxt(item, Delimitter, FileName);

                        }
                        else if (BatchExport_HRA_V1_MailType.Count > 0)
                        {
                            var item = BatchExport_HRA_V1_MailType.Select(x => new
                            {
                                ImagePath = x.ImagePath,
                                Respondent_ID = x.RESPONDENT_ID,
                                Q1_9 = x.Q1_9,
                                Q1_1_1 = x.Q1_1_1,
                                Q1_2 = x.Q1_2,
                                Q1_3_1 = x.Q1_3_1,
                                Q1_4 = x.Q1_4,
                                Q1_5 = x.Q1_5,
                                Q1_6_1 = x.Q1_6_1,
                                Q1_7 = x.Q1_7,
                                Q1_8 = x.Q1_8,
                                Q3_1 = x.Q3_1,
                                Q3_2 = x.Q3_2,
                                Q3_3 = x.Q3_3,
                                Q3_4 = x.Q3_4,
                                Q3_5 = x.Q3_5,
                                Q4_1 = x.Q4_1,
                                Q4_2 = x.Q4_2,
                                Q4_3 = x.Q4_3,
                                Q2_1 = x.Q2_1,
                                Q2_TTL_1 = x.Q2_TTL_1,
                                Q5_1 = x.Q5_1,
                                Q5_TTL = x.Q5_TTL,
                                Q6_1 = x.Q6_1,
                                Q7_2 = x.Q7_2,
                                Q7_1 = x.Q7_1,
                                Q8_1 = x.Q8_1,
                                LANGUAGE = x.LANGUAGE,
                                DATEREC = x.DATEREC,
                                DATESCAN = x.DATESCAN,
                                BATCHNUMBER = x.BATCHNUMBER,
                                IMAGEFILENAME = x.IMAGEFILENAME,
                                MailType = x.MailType,
                                User_Name = x.User_Name,
                            }).ToList();

                            ExportFile = IGUtilities.ExportToTxt(item, Delimitter, FileName);
                        }
                        else if (BatchExport_Hedis.Count > 0)
                        {
                            var item = BatchExport_Hedis.Select(x => new
                            {
                                ImagePath = x.ImagePath,
                                Image_Name = x.Image_Name,
                                Bar_Code = x.Bar_Code,
                                Q1_1 = x.Q1_1,
                                Q1_2 = x.Q1_2,
                                Q1_3 = x.Q1_3,
                                Q1_4 = x.Q1_4,
                                Q1_5 = x.Q1_5,
                                Q2_1 = x.Q2_1,
                                Q2_2 = x.Q2_2,
                                Q2_3 = x.Q2_3,
                                Q3_1 = x.Q3_1,
                                Q3_2 = x.Q3_2,
                                Q3_3 = x.Q3_3,
                                Q3_4 = x.Q3_4,
                                Signature = x.Signature,
                                Signature_Date = x.Signature_Date,
                                Interaction_Date_Time = x.Interaction_Date_Time,
                                User_Name = x.User_Name
                            }).ToList();

                            ExportFile = IGUtilities.ExportToTxt(item, Delimitter, FileName);
                        }
                        break;
                    case 1:
                        FileName = ExportPath + "\\" + ProjectName + "_" + cmbBatch.Text + "_" + KeyVal + "_Exported_Data.xls";
                        if (BatchExport.Count > 0)
                        {
                            ExportFile = IGUtilities.ExportToXL(BatchExport, FileName);
                        }
                        else if (BatchExport_HRA.Count > 0)
                        {

                            var item = BatchExport_HRA.Select(x => new
                            {
                                ImagePath = x.ImagePath,
                                RESPONDENT_ID = x.RESPONDENT_ID,
                                Q1_1 = x.Q1_1,
                                Q1_2 = x.Q1_2,
                                Q1_3 = x.Q1_3,
                                Q1_4 = x.Q1_4,
                                Q1_5 = x.Q1_5,
                                Q1_6 = x.Q1_6,
                                Q1_7 = x.Q1_7,
                                Q1_8 = x.Q1_8,
                                Q2_1 = x.Q2_1,
                                Q2_TTL_1 = x.Q2_TTL,
                                Q3_1 = x.Q3_1,
                                Q3_2 = x.Q3_2,
                                Q3_3 = x.Q3_3,
                                Q3_4 = x.Q3_4,
                                Q3_5 = x.Q3_5,
                                Q4_1 = x.Q4_1,
                                Q4_2 = x.Q4_2,
                                Q5_1 = x.Q5_1,
                                Q5_TTL = x.Q5_2,
                                Q6_1 = x.Q6_1,
                                Q7_1 = x.Q7_1,
                                Q7_2 = x.Q7_2,
                                Q8_1 = x.Q8_1,
                                Q9_1 = x.Q9_1,
                                LANGUAGE = x.LANGUAGE,
                                User_Name = x.User_Name
                            }).ToList();
                            ExportFile = IGUtilities.ExportToXL(item, FileName);
                        }
                        else if (BatchExport_Hedis.Count > 0)
                        {
                            ExportFile = IGUtilities.ExportToXL(BatchExport_Hedis, FileName);
                        }
                        else if (BatchExport_HRA_V1.Count > 0)
                        {
                            var item = BatchExport_HRA_V1.Select(x => new
                            {

                                ImagePath = x.ImagePath,
                                Respondent_ID = x.RESPONDENT_ID,
                                Q1_1_1 = x.Q1_1_1,
                                Q1_2 = x.Q1_2,
                                Q1_3_1 = x.Q1_3_1,
                                Q1_4 = x.Q1_4,
                                Q1_5 = x.Q1_5,
                                Q1_6_1 = x.Q1_6_1,
                                Q1_7 = x.Q1_7,
                                Q1_8 = x.Q1_8,
                                Q1_9 = x.Q1_9,
                                Q2_1 = x.Q2_1,
                                Q2_TTL_1 = x.Q2_TTL_1,
                                Q3_1 = x.Q3_1,
                                Q3_2 = x.Q3_2,
                                Q3_3 = x.Q3_3,
                                Q3_4 = x.Q3_4,
                                Q3_5 = x.Q3_5,
                                Q4_1 = x.Q4_1,
                                Q4_2 = x.Q4_2,
                                Q4_3 = x.Q4_3,
                                Q5_1 = x.Q5_1,
                                Q5_TTL = x.Q5_TTL,
                                Q6_1 = x.Q6_1,
                                Q7_2 = x.Q7_2,
                                Q7_1 = x.Q7_1,
                                Q8_1 = x.Q8_1,
                                LANGUAGE = x.LANGUAGE,
                                DATEREC = x.DATEREC,
                                DATESCAN = x.DATESCAN,
                                BATCHNUMBER = x.BATCHNUMBER,
                                IMAGEFILENAME = x.IMAGEFILENAME,
                                User_Name = x.User_Name,
                            }).ToList();
                            ExportFile = IGUtilities.ExportToXL(item, FileName);
                        }

                        break;


                    //case 2:
                    //    FileName = ExportPath + "\\" + cmbBatch.Text + "_" + KeyVal + "_Exported_Data.dat";
                    //    break;
                    default:
                        FileName = ExportPath + "\\" + cmbBatch.Text + "_" + KeyVal + "_Exported_Data.txt";
                        break;
                }

                if (ExportFile == true)
                {
                    MessageBox.Show("File Successfully exported at " + FileName + "");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion
    }
}
