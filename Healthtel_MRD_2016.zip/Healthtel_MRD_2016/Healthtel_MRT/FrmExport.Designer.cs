﻿namespace Healthtel_MRT
{
    partial class FrmExport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmExport));
            this.grpProject = new System.Windows.Forms.GroupBox();
            this.lblProject = new System.Windows.Forms.Label();
            this.txtProject = new System.Windows.Forms.TextBox();
            this.grpExportDetails = new System.Windows.Forms.GroupBox();
            this.cmbFileType = new System.Windows.Forms.ComboBox();
            this.lblFileType = new System.Windows.Forms.Label();
            this.cmbDelimittter = new System.Windows.Forms.ComboBox();
            this.lblDelemitter = new System.Windows.Forms.Label();
            this.cmbBatch = new System.Windows.Forms.ComboBox();
            this.lblBatch = new System.Windows.Forms.Label();
            this.cmbExportFrom = new System.Windows.Forms.ComboBox();
            this.lblExportFrom = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.grpProject.SuspendLayout();
            this.grpExportDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpProject
            // 
            this.grpProject.BackColor = System.Drawing.Color.Transparent;
            this.grpProject.Controls.Add(this.lblProject);
            this.grpProject.Controls.Add(this.txtProject);
            this.grpProject.Location = new System.Drawing.Point(34, 28);
            this.grpProject.Name = "grpProject";
            this.grpProject.Size = new System.Drawing.Size(385, 53);
            this.grpProject.TabIndex = 0;
            this.grpProject.TabStop = false;
            // 
            // lblProject
            // 
            this.lblProject.AutoSize = true;
            this.lblProject.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProject.ForeColor = System.Drawing.Color.White;
            this.lblProject.Location = new System.Drawing.Point(51, 19);
            this.lblProject.Name = "lblProject";
            this.lblProject.Size = new System.Drawing.Size(55, 14);
            this.lblProject.TabIndex = 1;
            this.lblProject.Text = "Project";
            // 
            // txtProject
            // 
            this.txtProject.Enabled = false;
            this.txtProject.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.txtProject.Location = new System.Drawing.Point(112, 17);
            this.txtProject.MaxLength = 1;
            this.txtProject.Name = "txtProject";
            this.txtProject.Size = new System.Drawing.Size(243, 22);
            this.txtProject.TabIndex = 2;
            this.txtProject.Text = "Healthtel";
            this.txtProject.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // grpExportDetails
            // 
            this.grpExportDetails.BackColor = System.Drawing.Color.Transparent;
            this.grpExportDetails.Controls.Add(this.cmbFileType);
            this.grpExportDetails.Controls.Add(this.lblFileType);
            this.grpExportDetails.Controls.Add(this.cmbDelimittter);
            this.grpExportDetails.Controls.Add(this.lblDelemitter);
            this.grpExportDetails.Controls.Add(this.cmbBatch);
            this.grpExportDetails.Controls.Add(this.lblBatch);
            this.grpExportDetails.Controls.Add(this.cmbExportFrom);
            this.grpExportDetails.Controls.Add(this.lblExportFrom);
            this.grpExportDetails.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.grpExportDetails.ForeColor = System.Drawing.Color.White;
            this.grpExportDetails.Location = new System.Drawing.Point(34, 105);
            this.grpExportDetails.Name = "grpExportDetails";
            this.grpExportDetails.Size = new System.Drawing.Size(385, 197);
            this.grpExportDetails.TabIndex = 3;
            this.grpExportDetails.TabStop = false;
            this.grpExportDetails.Text = "Export Options";
            // 
            // cmbFileType
            // 
            this.cmbFileType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.cmbFileType.FormattingEnabled = true;
            this.cmbFileType.Items.AddRange(new object[] {
            ".txt",
            ".xls"});
            this.cmbFileType.Location = new System.Drawing.Point(118, 105);
            this.cmbFileType.Name = "cmbFileType";
            this.cmbFileType.Size = new System.Drawing.Size(243, 22);
            this.cmbFileType.TabIndex = 9;
            // 
            // lblFileType
            // 
            this.lblFileType.AutoSize = true;
            this.lblFileType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFileType.ForeColor = System.Drawing.Color.White;
            this.lblFileType.Location = new System.Drawing.Point(40, 108);
            this.lblFileType.Name = "lblFileType";
            this.lblFileType.Size = new System.Drawing.Size(71, 14);
            this.lblFileType.TabIndex = 8;
            this.lblFileType.Text = "File Type ";
            // 
            // cmbDelimittter
            // 
            this.cmbDelimittter.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.cmbDelimittter.FormattingEnabled = true;
            this.cmbDelimittter.Items.AddRange(new object[] {
            "Pipe (|)",
            "Comma (,)",
            "SemiColon (;)"});
            this.cmbDelimittter.Location = new System.Drawing.Point(118, 143);
            this.cmbDelimittter.Name = "cmbDelimittter";
            this.cmbDelimittter.Size = new System.Drawing.Size(243, 22);
            this.cmbDelimittter.TabIndex = 11;
            // 
            // lblDelemitter
            // 
            this.lblDelemitter.AutoSize = true;
            this.lblDelemitter.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDelemitter.ForeColor = System.Drawing.Color.White;
            this.lblDelemitter.Location = new System.Drawing.Point(38, 150);
            this.lblDelemitter.Name = "lblDelemitter";
            this.lblDelemitter.Size = new System.Drawing.Size(73, 14);
            this.lblDelemitter.TabIndex = 10;
            this.lblDelemitter.Text = "Delimitter";
            // 
            // cmbBatch
            // 
            this.cmbBatch.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.cmbBatch.FormattingEnabled = true;
            this.cmbBatch.Location = new System.Drawing.Point(118, 67);
            this.cmbBatch.Name = "cmbBatch";
            this.cmbBatch.Size = new System.Drawing.Size(243, 22);
            this.cmbBatch.TabIndex = 7;
            // 
            // lblBatch
            // 
            this.lblBatch.AutoSize = true;
            this.lblBatch.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBatch.ForeColor = System.Drawing.Color.White;
            this.lblBatch.Location = new System.Drawing.Point(67, 70);
            this.lblBatch.Name = "lblBatch";
            this.lblBatch.Size = new System.Drawing.Size(44, 14);
            this.lblBatch.TabIndex = 6;
            this.lblBatch.Text = "Batch";
            // 
            // cmbExportFrom
            // 
            this.cmbExportFrom.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.cmbExportFrom.FormattingEnabled = true;
            this.cmbExportFrom.Items.AddRange(new object[] {
            "Key1",
            "Key2",
            "KeyQC",
            "CompareQC"});
            this.cmbExportFrom.Location = new System.Drawing.Point(118, 25);
            this.cmbExportFrom.Name = "cmbExportFrom";
            this.cmbExportFrom.Size = new System.Drawing.Size(243, 22);
            this.cmbExportFrom.TabIndex = 5;
            // 
            // lblExportFrom
            // 
            this.lblExportFrom.AutoSize = true;
            this.lblExportFrom.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExportFrom.ForeColor = System.Drawing.Color.White;
            this.lblExportFrom.Location = new System.Drawing.Point(23, 28);
            this.lblExportFrom.Name = "lblExportFrom";
            this.lblExportFrom.Size = new System.Drawing.Size(88, 14);
            this.lblExportFrom.TabIndex = 4;
            this.lblExportFrom.Text = "Export From";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(251, 322);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(86, 32);
            this.btnClose.TabIndex = 13;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.Transparent;
            this.btnExport.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnExport.ForeColor = System.Drawing.Color.White;
            this.btnExport.Location = new System.Drawing.Point(140, 322);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(86, 32);
            this.btnExport.TabIndex = 12;
            this.btnExport.Text = "Export";
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // FrmExport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(477, 398);
            this.ControlBox = false;
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.grpExportDetails);
            this.Controls.Add(this.grpProject);
            this.MaximizeBox = false;
            this.Name = "FrmExport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Healthtel MRD : : Export";
            this.Load += new System.EventHandler(this.FrmExport_Load);
            this.grpProject.ResumeLayout(false);
            this.grpProject.PerformLayout();
            this.grpExportDetails.ResumeLayout(false);
            this.grpExportDetails.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpProject;
        private System.Windows.Forms.Label lblProject;
        private System.Windows.Forms.TextBox txtProject;
        private System.Windows.Forms.GroupBox grpExportDetails;
        private System.Windows.Forms.ComboBox cmbExportFrom;
        private System.Windows.Forms.Label lblExportFrom;
        private System.Windows.Forms.ComboBox cmbFileType;
        private System.Windows.Forms.Label lblFileType;
        private System.Windows.Forms.ComboBox cmbDelimittter;
        private System.Windows.Forms.Label lblDelemitter;
        private System.Windows.Forms.ComboBox cmbBatch;
        private System.Windows.Forms.Label lblBatch;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnExport;

    }
}