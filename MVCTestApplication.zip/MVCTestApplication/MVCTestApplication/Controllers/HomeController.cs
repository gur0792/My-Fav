﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCTestApplication.Models;

namespace MVCTestApplication.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ViewResult TestMethod()
        {
            Employee Emp = new Employee().GetItem();
            ViewBag.EmployeeList = new Employee().GetList();

            return View("~/Views/Home/MyTestView.cshtml", Emp);
        }

        [HttpPost]
        public ActionResult GetAllEmployees()
        {
            List<Employee> EmpList = new Employee().GetList();
            return Json(new { HasError = false, Data = EmpList });
        }

    }
}