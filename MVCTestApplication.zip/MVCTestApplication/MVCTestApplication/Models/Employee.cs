﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCTestApplication.Models
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public int EmployeeAge { get; set; }
        public string Gender { get; set; }

        public Employee GetItem()
        {
            Employee Emp = new Employee();
            Emp.EmployeeID = 1;
            Emp.EmployeeName = "Kannan";
            Emp.EmployeeAge = 25;
            Emp.Gender = "FeMale";
            return Emp;
        }


        public List<Employee> GetList()
        {
            List<Employee> EmpList = new List<Employee>();
            EmpList.Add(new Employee() { EmployeeID = 1, EmployeeName = "Kannan", EmployeeAge = 25, Gender = "FeMale" });

            Employee Emp = new Employee();
            Emp.EmployeeID = 2;
            Emp.EmployeeName = "Kumar";
            Emp.EmployeeAge = 25;
            Emp.Gender = "Male";
            EmpList.Add(Emp);
            EmpList.Add(new Employee() { EmployeeID = 3, EmployeeName = "Karthick", EmployeeAge = 25, Gender = "Male" });
            EmpList.Add(new Employee() { EmployeeID = 4, EmployeeName = "Karthiga", EmployeeAge = 25, Gender = "FeMale" });
            return EmpList;
        }

    }
}